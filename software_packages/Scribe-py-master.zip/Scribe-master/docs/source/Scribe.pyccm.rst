Scribe.pyccm
====================

causal_network
-----------------------

.. automodule:: Scribe.causal_network.restore_the_raw_expression_data
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: Scribe.causal_network.subset_genes
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: Scribe.pyccm
    :members:
    :undoc-members:
    :show-inheritance:
