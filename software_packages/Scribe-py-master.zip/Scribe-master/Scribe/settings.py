# set global verbosity level to show errors(0), warnings(1), info(2) and hints(3)
verbosity = 3

logfile = ''
"""Name of logfile. By default is set to '' and writes to standard output."""
