import numpy as np
import scipy.spatial as ss
import copy
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigs
def sqdist (a,b):
    """calculate the square distance between a, b

    Arguments
    ---------
        a: 'np.ndarray'
            Array like matrix
        b: 'np.ndarray'
        Array like matrix
        
    Returns
    -------
    dist: 'np.ndarray'
        The distance matrix
    """
    aa = sum(a**2).tolist()
    bb = sum(b**2).tolist()
    ab = np.matrix(a).T * np.matrix(b)   #crossprod
    rep_list = []
    for i in range(len(b.shape[1])):
        rep_list = rep_list+[i for item in aa for i in item]
    aa_repmat = np.array(rep_list).reshape(b.shape[1],len(aa)).T

    for i in range(len(a.shape[1])):
        rep_list = rep_list+[i for item in bb for i in item]
    bb_repmat = np.array(rep_list).reshape(a.shape[1],len(bb))
    dist = abs(aa_repmat + bb_repmat - 2 * ab)
    return dist

def repmat (X, m, n):
    """This function returns an array containing m (n) copies of A in the row (column) dimensions. The size of B is
    size(A)*n when A is a matrix.For example, repmat(np.matrix(1:4), 2, 3) returns a 4-by-6 matrix.

    Arguments
    ---------
        X: 'np.ndarray'
            An array like matrix.
        m: 'int'
            Number of copies on row dimension
        n: 'int'
            Number of copies on column dimension

    Returns
    -------
    xy_rep: 'np.ndarray'
        A matrix of repmat
    """
    x_rep = X
    for i in range(n-1):
        x_rep = np.hstack((x_rep,X))
    xy_rep = x_rep
    for i in range(m-1):
        xy_rep = np.vstack((xy_rep,x_rep))

    return xy_rep

def eye (m, n):
    """Equivalent of eye (matlab)

    Arguments
    ---------
        m: 'int'
            Number of rows
        n: 'int'
            Number of columns

    Returns
    -------
    mat: 'np.ndarray'
        A matrix of eye
    """
    mat = np.zeros((n,m))
    for i in range(min(len(mat), len(mat[0]))):
        mat[i][i] = 1
    return mat

def diag_mat (values):
    """Equivalent of diag (matlab)

    Arguments
    ---------
        values: 'int'
            dim of the matrix

    Returns
    -------
        mat: 'np.ndarray'
            A diag_matrix
    """
    mat = np.zeros((len(values),len(values)))
    for i in range(len(values)):
        mat[i][i] = values[i]
    return mat

def psl_py(Y, sG = None, dist = None, K = 10, C = 1e3, param_gamma = 1e-3, d = 2, maxIter = 10, verbose = False):
    """This function is a pure Python implementation of the PSL algorithm

    Arguments
    ---------
        Y: 'list'
            data list
        sG:
            a prior kNN graph passed to the algorithm
        dist: 'np.ndarray'
            a dense distance matrix between all vertices. If no distance matrix passed, we will use the kNN based aglorithm,
            otherwise we will use the original algorithm reported in the manuscript.
        K: 'int'
            number of nearest neighbors used to build the neighborhood graph. Ignored if sG is used
        C: 'int'
            number of nearest neighbors
        param_gamma: 'int'
            number of nearest neighbors
        d: 'int'
            number of nearest neighbors
        maxIter: 'int'
            Number of maximum iterations
        verbose: 'bool'
            Whether to print running information

    Returns
    -------
        (S,Z): 'tuple'
            a numeric value for the d-dimensional unit ball for Euclidean norm
    """

    if not sG:
        if not dist:
            tree_xz = ss.cKDTree(Y)
            dist_mat, idx_mat = tree_xz.query(Y, k=K + 1)
            N = len(Y)
            distances = dist_mat[:,1:]
            indices = idx_mat[:,1:]

            rows = np.zeros(N * K)
            cols = np.zeros(N * K)
            dists = np.zeros(N * K)
            location = 0

            for i in range(N):

                rows[location:location+K] = i
                cols[location:location+K] = indices[i]
                dists[location:location+K] = distances[i]
                location = location + K

            sG = csr_matrix((np.array(dists) ** 2, (rows, cols)), shape=(N, N))
        else:
            N = len(Y)
            sidx = np.argsort(dist)
            i = repmat(np.array(sidx[:,0]),K,1).reshape(1,-1)[0]
            j = sidx[:,1:K+1].reshape(1,-1)[0]
            sG = csr_matrix(([1 for k in range(N * K)], (i, j)), shape=(N, N))

    if not dist:
        if list(set(sG.data)) == [1]:
            print('Error: sG should not just be an adjacency graph and has to include the distance information between vertices!')
            exit()
        else:
            dist = sG

    N = Y.shape[0]
    D = Y.shape[1]
    G = sG.toarray()

    idx_map = []
    sG_list = sG.toarray()
    sG_list_T = sG.T.toarray()
    # G(Matrix) is already a symmetrical matrix. Why do we need to symmetricalize it?
    for i in range(sG_list.shape[0]):
        for j in range(sG_list.shape[1]):
            G[i,j] = max(sG_list_T[i,j], sG_list[i,j])
    # symmetrize and find edges in the low triangle
    G_tmp = copy.deepcopy(G)

    s0 = []
    for i in range(G.shape[0]):
        for j in range(G.shape[1]):
            if i < j:
                G_tmp[i,j] = 0
            if G_tmp[i,j] > 0:
                idx_map = idx_map+[[i,j]]
                s0 = s0+[G[i,j]]
    idx_map = np.array(idx_map).T
    rows = idx_map[0]
    cols = idx_map[1]
    s = s0
    m = len(s)
    #############################################
    objs = np.zeros(maxIter)

    for iter in range(maxIter):
        S = csr_matrix((s,(rows, cols)), shape=(N, N)).toarray()
        S = S + S.T
        Q = diag_mat(sum(S.T)) - S + 0.25 * (param_gamma + 1) * eye(N, N) ##################
        R = np.linalg.cholesky(Q).T  # Cholesky Decomposition of a Sparse Matrix
        invR = np.linalg.inv(R)  # R:solve(R)
        invR = np.matrix(invR)
        invQ = invR*invR.T
        left = invR.T*np.matrix(Y)
        #if not False in (np.array([left.shape[0],left.shape[1]]) < 3):
        #    res = svd(left)  # get the Lambda, W
        #} else {
        #res < - RSpectra::svds(left, d)  # get the Lambda, W
        #}
        res = np.linalg.svd(left)
        Lambda = res[1]
        W = res[2].T
        invQY = invR * left
        invQYW = invQY * W

        P = 0.5 * D * invQ + 0.125 * param_gamma ** 2 * invQYW*invQYW.T
        logdet_Q =  2 * sum(np.log(np.diag(np.linalg.cholesky(Q).T)))
        # log(det(Q))
        obj = 0.5 * D * logdet_Q - sum(sum(S * dist.toarray())) + 0.25 / C * sum(sum(S ** 2)) - 0.125 * param_gamma ** 2 * sum(np.diag(W.T * (np.matrix(Y).T*invQYW)))  # trace: #sum(diag(m))
        objs[iter] = obj
        if verbose:
            if iter == 0:
                print('i = ', iter+1, ', obj = ', obj)
            else :
                rel_obj_diff = abs(obj - objs[iter - 1]) / abs(objs[iter - 1])
                print('i = ', iter, ', obj = ', obj, ', rel_obj_diff = ', rel_obj_diff, sep = '')
        subgrad = []

        for i in range(len(rows)):
            subgrad = subgrad+[P[rows[i],rows[i]] + P[cols[i],cols[i]] - P[rows[i],cols[i]] - P[cols[i],rows[i]] - 1 / C * S[rows[i],cols[i]] - 2 * dist[rows[i],cols[i]]]
        s = np.array(s)

        subgrad = np.array(subgrad)
        s = s + 1 / (iter+1) * subgrad
        for i in range(len(s)):
            if s[i]<0:
                s[i] = 0
        #print("print s:",s)
        if param_gamma != 0:
            #print("print invQY:",invQY)
            #print("print W:",W)

            Z = 0.25 * (param_gamma + 1) * invQYW
        else:
            # centeralized kernel
            A = np.linalg.inv(Q)
            column_sums = np.array(sum(A) / N)
            J = np.matrix(np.ones(N)).T * np.matrix(column_sums)
            K = A - J - J.T + sum(column_sums) / N

            # eigendecomposition
            V,U = eigs(K, d)
            res = np.diag(V).reshape(1,-1)[0]
            v = np.array(sorted(res,reverse=True))
            i_ind = np.argsort(res)[::-1]
            v = np.array(v[0:d])
            tmp = np.zeros(shape=(d,d))
            for i in range(len(v)):
                tmp[i,i] = np.sqrt(v[i])
            Z = (np.matrix(U) * np.matrix(tmp)).toarray()


    return (S,Z)

