library(testthat)
library(Scribe)

test_check("Scribe")
