# rccm

> Convergent Cross Mapping - Detecting Causalilty in Complex Systems
 


# Description

Impliments the convergent cross mapping (CCM) method described in
    Sugihara, G., May, R., Ye, H., Hsieh, C., Deyle,E., Fogarty, M., Munch, S.
    (2012) Detecting Causality in Complex Ecosystems. Science 338, 496.

# Status

This package is extremely beta. Results have not yet been validaded. Do not trust it yet !
