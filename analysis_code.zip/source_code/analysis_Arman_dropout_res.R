# result from Arman: 
library(monocle)
library(reshape)

# nonsmooth.txt_False_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_False_0.0', row.names = 1)
# nonsmooth.txt_False_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_False_0.1', row.names = 1)
# nonsmooth.txt_False_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_False_0.2', row.names = 1)
# nonsmooth.txt_False_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_False_0.3', row.names = 1)
# nonsmooth.txt_False_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_False_0.4', row.names = 1)
# 
# nonsmooth.txt_True_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_True_0.0', row.names = 1)
# nonsmooth.txt_True_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_True_0.1', row.names = 1)
# nonsmooth.txt_True_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_True_0.2', row.names = 1)
# nonsmooth.txt_True_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_True_0.3', row.names = 1)
# nonsmooth.txt_True_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/SimulationwithSimpleDropout_Results/nonsmooth.txt_True_0.4', row.names = 1)
# 
# nosmooth_df <- Reduce(rbind, list(nonsmooth.txt_False_0.0, nonsmooth.txt_False_0.1, nonsmooth.txt_False_0.2, nonsmooth.txt_False_0.3, nonsmooth.txt_False_0.4))
# smooth_df <- Reduce(rbind, list(nonsmooth.txt_True_0.0, nonsmooth.txt_True_0.1, nonsmooth.txt_True_0.2, nonsmooth.txt_True_0.3, nonsmooth.txt_True_0.4))
# 
# colnames(nosmooth_df) <- c('Cor', 'MI', 'RDI', 'cRDI', 'CCM', 'Granger')
# nosmooth_df$noise_std <- rep(seq(0.01, 0.20, 0.01), 5); nosmooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); nosmooth_df$smooth = F
# colnames(smooth_df) <- c('Cor', 'MI', 'RDI', 'cRDI', 'CCM', 'Granger')
# smooth_df$noise_std <- rep(seq(0.01, 0.20, 0.01), 5);  smooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); smooth_df$smooth = T
# 
# all_df <- rbind(smooth_df, nosmooth_df)
# mlt_all_df <- melt(nosmooth_df, id.vars = c("smooth", "noise_std", "prob_of_drop"))
# 
# ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable)) + geom_line(aes(color = variable)) + facet_wrap(~prob_of_drop, nrow  = 1)
# ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = as.factor(prob_of_drop))) + geom_line(aes(color = as.factor(prob_of_drop))) + facet_wrap(~variable, nrow  = 1)

########################################################################################################################################################
# new version 
########################################################################################################################################################
nonsmooth.txt_False_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.0', row.names = 1)
nonsmooth.txt_False_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.1', row.names = 1)
nonsmooth.txt_False_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.2', row.names = 1)
nonsmooth.txt_False_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.3', row.names = 1)
nonsmooth.txt_False_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.4', row.names = 1)

nonsmooth.txt_True_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.0', row.names = 1)
nonsmooth.txt_True_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.1', row.names = 1)
nonsmooth.txt_True_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.2', row.names = 1)
nonsmooth.txt_True_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.3', row.names = 1)
nonsmooth.txt_True_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.4', row.names = 1)

nosmooth_df_update <- Reduce(rbind, list(nonsmooth.txt_False_0.0, nonsmooth.txt_False_0.1, nonsmooth.txt_False_0.2, nonsmooth.txt_False_0.3, nonsmooth.txt_False_0.4))
smooth_df_update <- Reduce(rbind, list(nonsmooth.txt_True_0.0, nonsmooth.txt_True_0.1, nonsmooth.txt_True_0.2, nonsmooth.txt_True_0.3, nonsmooth.txt_True_0.4))

colnames(nosmooth_df_update) <- c('Correlation', 'MI',  'RDI', 'cRDI', "Granger", 'CCM')
nosmooth_df_update$noise_std <- rep(seq(0.01, 0.20, 0.01), 5); nosmooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); nosmooth_df$smooth = F
colnames(smooth_df_update) <-c('Correlation', 'MI',  'RDI', 'cRDI', "Granger", 'CCM')
smooth_df_update$noise_std <- rep(seq(0.01, 0.20, 0.01), 5);  smooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); smooth_df$smooth = T

all_df_update <- rbind(smooth_df_update, nosmooth_df_update)

# update RDI and cRDI: 
smooth_df$RDI <- smooth_df_update$RDI
smooth_df$cRDI <- smooth_df_update$cRDI
nosmooth_df$RDI <- nosmooth_df_update$RDI
nosmooth_df$cRDI <- nosmooth_df_update$cRDI
mlt_all_df <- melt(nosmooth_df, id.vars = c("smooth", "noise_std", "prob_of_drop"))

ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable)) + geom_line(aes(color = variable)) + facet_wrap(~prob_of_drop, nrow  = 1)

mlt_all_df$variable <- as.character(mlt_all_df$variable)
mlt_all_df$variable <- factor(mlt_all_df$variable, levels = rev(c('Cor', 'MI', "Granger", 'CCM',  'RDI', 'cRDI')))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/AUC_diferent_method.pdf', height = 1.5, width = 6)
ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable), size = 0.5) + geom_line(aes(color = variable), size = 0.5) + 
  facet_wrap(~prob_of_drop, nrow  = 1) + nm_theme() + xacHelper::nm_theme() + xlab('Noise (s.d.)') + ylab('AUC') + scale_color_viridis(discrete = T)
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/AUC_diferent_method_helper.pdf', height = 1.5, width = 6)
ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable), size = 0.5) + geom_line(aes(color = variable), size = 0.5) + 
  facet_wrap(~prob_of_drop, nrow  = 1) + xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T)
dev.off()

########################################################################################################################################################
# understand why do we have the very strange pattern from the results
########################################################################################################################################################


########################################################################################################################################################
# save the results 
########################################################################################################################################################
save.image('./RData/analysis_Arman_dropout_res.Rdata')
