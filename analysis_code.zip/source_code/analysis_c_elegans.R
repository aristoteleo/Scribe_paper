# analyze c elegans data 

# I think the cells in the E lineage (E*) are fairly long-lived and have many TFs active, so you might take a look at those cells first. 
# Also, the first 74 gene columns (column indices on the interval [6-80) ) are protein-fusions, so will show both when the genes come on
# and when they turn off. The rest of the columns are promoter fusion strains that only show the initial gene induction.

##########################################################################################################################################################
# look into the John Isaac Murra paper
##########################################################################################################################################################
# three files: 
# 1. gene_lineage; 2. lineage_cascade; 3. gene_lineage_time
##########################################################################################################################################################
# load libraries 
rm(list = ls())

library(Scribe)
library(monocle)
library(plyr)
library(dplyr)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

##########################################################################################################################################################
# read the file and do some statistics to count times of expressed genes 
##########################################################################################################################################################

c_elegans_data <- read.csv('./csv_data/c_elegans/ImageExpressionTable.all_imaged_strains.prioritized.norm_expr.csv')
c_elegans_data_ori <- read.csv('./csv_data/c_elegans/ImageExpressionTable.all_imaged_strains.prioritized.csv')
sort(unique(c_elegans_data$cell), decreasing = T)

expressed_cnt <- c_elegans_data[, -c(2:6)] %>% group_by(cell) %>% summarise_each(funs(n()))

pdf('./Figures/cell_timepoint_measured.pdf', height = 100, width = 25)
pheatmap::pheatmap(expressed_cnt[, -1]) # set na
dev.off()

expressed_cnt2 <- c_elegans_data[, -c(2:6)] %>% group_by(cell) %>% summarise_each(funs(sum(. > 0, na.rm = T))) # count the number of time points with unique expression values

expressed_cnt3 <- c_elegans_data[, -c(2:6)] %>% group_by(cell) %>% summarise_each(funs(length(unique(.[. > 0])))) # count the number of time points with unique expression values

pdf('./Figures/cell_cnt_valid_measurements.pdf', height = 100, width = 25)
pheatmap::pheatmap(expressed_cnt2[, -1]) # set na
dev.off()

# show maximal measurement counts: 
expressed_cnt2[, -c(1)] %>% summarise_each(funs(max(.)))

# # identify the  maximal measurement counts: 
# expressed_cnt2[, -c(1)] %>% summarise_each(funs(which(. == max(.))))

which(expressed_cnt2$F21A10.2 == 408)
which(expressed_cnt2$R144.3 == 336)

# good_gene_lineages <- as.character(expressed_cnt2[c(429, 430, 535, 536, 559, 561, 572, 573, 575, 576, 979, 980), 'cell'][[1]])

##########################################################################################################################################################
# sort the counts for the body muscle cells:  
##########################################################################################################################################################
# body muscle gene: Hnd-1 -> Unc-120 -> Hlh-1
body_muscle <- c("Cpppppv", "Cpppppd", "Cppppap", "Cppppaa", "Cpppapp", "Cpppapa", "Cppappp", "Cppappa", "Cppapap", "Cppapaa", "Cppaapp", "Cppaapa", "Cppaaap", "Cppaaaa",
                 "Cappppv", "Cappppd", "Capppap", "Capppaa", "Cappapp", "Cappapa", "Cappaap", "Cappaaa", "Capappp", "Capappa", "Capapap", "Capapaa", "Capaapp", "Capaapa", "Capaaap", "Capaaaa",
                 "Dppppp", "Dppppa", "Dpppap", "Dpppaa", "Dppap", "Dppaa", "Dpapp", "Dpapa", "Dpaap", "Dpaaa", "Dapppp", "Dapppa", "Dappap", "Dappaa", "Dapap", "Dapaa", "Daapp", "Daapa", "Daaap", "Daaaa",
                 "MSpppppp", "MSpppppa", "MSppppap", "MSppppaa", "MSpppapp", 
                 "MSpappppp", "Mspppppa", "MSppppap", "MSppppaa")
muscle_genes <- c('hnd.1', 'unc.120', 'hlh.1')

valid_muscle_cell_id <- which(expressed_cnt2$cell %in% body_muscle)
sorted_expressed_cnt2 <- expressed_cnt2[, ] %>% arrange(desc(hnd.1), desc(unc.120), desc(hlh.1)) # valid_muscle_cell_id

sorted_expressed_cnt2[, muscle_genes]

# instentine gene: end3 -> end1 -> elt1/7
intestine_cell <- c("Eprppp", "Eprppa", "Eprpa", "Eprap", "Epraa", "Eplppp", "Eplppa", "Eplpa", "Eplap", "Eplaa", "Earpp", "Earpa", "Earap", "Earaav", "Earaad", "Ealpp", "Ealpa", "Ealap", "Ealaav", "Ealaad")
intestine_gene <- c('end.3', 'end.1', 'elt.2')

valid_intestine_cell_id <- which(expressed_cnt2$cell %in% intestine_cell)
sorted_expressed_cnt2 <- expressed_cnt2[valid_intestine_cell_id, ] %>% arrange(desc(end.3), desc(end.1), desc(elt.2)) # valid_muscle_cell_id
sorted_expressed_cnt2[, c('end.3', 'end.1', 'elt.2')]

good_gene_lineages <- as.character(sorted_expressed_cnt2[, 'cell'][[1]])

cell_id <-  good_gene_lineages[6] #'Capaaa' #Muscle: 5, 6, 8
cell_id <-  "MSpapaapap" #"Capaa" #

get_cell_lineage <- function(cell_id) {
  cell_id_vec <- strsplit(cell_id, "")[[1]]
  
  cell_lineage_vec <- c()
  for(i in 1:length(cell_id_vec)) {
    cell_lineage_vec <- c(cell_lineage_vec, paste0(cell_id_vec[1:i], collapse = ''))
  }
  return(cell_lineage_vec)
} 

cell_lineage_ids <- get_cell_lineage(cell_id)  
test_c_elegans_data_ori <- subset(c_elegans_data, cell == cell_id)
test_c_elegans_data_ori <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids) # === cell_id

test_c_elegans_data <- t(test_c_elegans_data_ori[, -c(1:6)])
colnames(test_c_elegans_data) <- subset(c_elegans_data, cell %in% cell_lineage_ids)[, 'time']

qplot(1:ncol(test_c_elegans_data), test_c_elegans_data[1, ])

# three muscle genes: 
# 
p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['hnd.1', ]) + xlab('Time') + ylab('Hnd-1') + ggtitle(paste('Cell name:', cell_id))
p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['unc.120', ]) + xlab('Time') + ylab('Unc-1') + ggtitle(paste('Cell name:', cell_id))
p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['hlh.1', ]) + xlab('Time') + ylab('Hlh-1') + ggtitle(paste('Cell name:', cell_id))

p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['end.3', ]) + xlab('Time') + ylab('End-3') + ggtitle(paste('Cell name:', cell_id))
p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['end.1', ]) + xlab('Time') + ylab('End-1') + ggtitle(paste('Cell name:', cell_id))
p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['elt.2', ]) + xlab('Time') + ylab('Elt-2') + ggtitle(paste('Cell name:', cell_id))

xacHelper::multiplot(plotlist = list(p1, p2, p3))

rng_hnd <- range(test_c_elegans_data['hnd.1', ]) 
rng_hlh <- range(test_c_elegans_data['hlh.1', ]) 
rng_unc <- range(test_c_elegans_data['unc.120', ]) 

panel_a_df <- data.frame(Time = test_c_elegans_data_ori$time, 
                         Expression = c((test_c_elegans_data['hnd.1', ] - rng_hnd[1])/ diff(rng_hnd), #
                                        (test_c_elegans_data['hlh.1', ] - rng_hlh[1])  / diff(rng_hlh) , #
                                        (test_c_elegans_data['unc.120', ] - rng_unc[1]) / diff(rng_unc)), #  
                         gene_short_name = c(rep(c('Hnd-1', 'Hlh-1', 'Unc-120'), each = nrow(test_c_elegans_data_ori))))

pdf(paste0(main_fig_dir, 'worm_muscle_plot_kinetics.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30))
dev.off()

pdf(paste0(main_fig_dir, 'worm_muscle_plot_kinetics_helper.pdf'))
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xlab('Minutes') + theme(axis.text.x = element_text(angle = 30))
dev.off()

pdf(paste0(main_fig_dir, 'worm_intestine_plot.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name)) + geom_smooth(aes(color = gene_short_name)) + 
  xacHelper::nm_theme()
dev.off()

#+ facet_wrap(~gene_short_name)

##########################################################################################################################################################
# create a test cds and start to analyze the data 
##########################################################################################################################################################

# function to create a time series starting from the very beginning: 

pData <- test_c_elegans_data_ori[, 1:6]
row.names(pData) <- test_c_elegans_data_ori$time
pData$Pseudotime <- pData$time
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(test_c_elegans_data_ori)[-c(1:6)], row.names = colnames(test_c_elegans_data_ori)[-c(1:6)])
fd <- new("AnnotatedDataFrame", data = fData)

# Now, make a new CellDataSet using the RNA counts
test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0 # remove NaN values
test_cds <- newCellDataSet(test_c_elegans_data, 
                       phenoData = pd,
                       featureData = fd,
                       lowerDetectionLimit=1,
                       expressionFamily=gaussianff())

test_urdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(1, 5, 10, 15, 20), uniformalize = T, log = T, pseudo_cnt = 0) #
test_rdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = T, pseudo_cnt = 0) #

test_rdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(20, 30, 40, 50, 60, 80), uniformalize = F, log = F) #
test_urdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(20, 30, 40, 50, 60, 80), uniformalize = T, log = F) #

test_umi_res <- calculate_umi(test_cds[muscle_genes, ], log = F)
test_umi_res_lung <- calculate_umi(AT1_lung, log = T)
test_mi_res_lung <- cal_knn_mi_parmigene(AT1_lung)

write.table(file = 'csv_data/c_elegans_muscle_matrix.csv', exprs(test_cds[muscle_genes, ]), quote = F)
write.table(file = 'csv_data/AT1_lung_matrix.csv', exprs(AT1_lung[, ]), quote = F)

test_rdi_res <- calculate_rdi(test_cds[intestine_gene, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F) #muscle_genes
con_test_rdi_res <- calculate_conditioned_rdi(test_cds[intestine_gene, ], rdi_list = test_rdi_res, uniformalize = T, top_incoming_k = 2, log = F) #muscle_genes

exprs(test_cds)[muscle_genes, ] <- t(apply(exprs(test_cds[muscle_genes, ]), 1, function(x) {
  x_rng <- range(x)
  norm_x <- (x - x_rng[1])/ (diff(x_rng))
  df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data)), 
                   val = norm_x)
  l_model <- loess(val ~ Time, df)
  res <- predict(l_model)
  return(res)
}))

p1 <- qplot(test_c_elegans_data_ori$time, exprs(test_cds)['hnd.1', ]) + xlab('Time') + ylab('hnd.1') + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = 62 + 43)
p2 <- qplot(test_c_elegans_data_ori$time, exprs(test_cds)['hlh.1', ]) + xlab('Time') + ylab('hlh.1') + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = 87 + 43)
p3 <- qplot(test_c_elegans_data_ori$time, exprs(test_cds)['unc.120', ]) + xlab('Time') + ylab('unc.120') + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = 172 + 43)

inflection_points <- apply(exprs(test_cds)[muscle_genes, ], 1, function(data) {
  inflection_point <- bede(1:length(data), data, 0)
  if (!is.finite(inflection_point$iplast)) 
    inflection_point <- bede(1:length(data), data, 
                             1)
  round(inflection_point$iplast)
})


xacHelper::multiplot(plotlist = list(p1, p2, p3))

dimnames(test_rdi_res$max_rdi_value) <- list(c("Hnd-1", "Unc-120", "Hlh-1"), c("Hnd-1", "Unc-120", "Hlh-1"))
pdf(paste0(main_fig_dir, 'worm_muscle_plot.pdf'), width =  1, height = 1)
pheatmap::pheatmap(test_rdi_res$max_rdi_value[c("Hnd-1", "Hlh-1", "Unc-120"), c("Hnd-1", "Hlh-1", "Unc-120")], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = F, border_color = NA)
dev.off()

dimnames(test_urdi_res$max_rdi_value) <- list(c("Hnd-1", "Unc-120", "Hlh-1"), c("Hnd-1", "Unc-120", "Hlh-1"))
pheatmap::pheatmap(test_urdi_res$max_rdi_value[c("Hnd-1", "Hlh-1", "Unc-120"), c("Hnd-1", "Hlh-1", "Unc-120")], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)

pdf(paste0(main_fig_dir, 'worm_muscle_plot_helper.pdf'))
pheatmap::pheatmap(test_rdi_res$max_rdi_value[c("Hnd-1", "Hlh-1", "Unc-120"), c("Hnd-1", "Hlh-1", "Unc-120")], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)
dev.off()
  
norm_test_c_elegans_data <- apply(test_c_elegans_data, 1, function(x) {
  x_rng <- range(x)
  norm_x <- (x - x_rng[1])/ (diff(x_rng))
  df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data)), 
                   val = norm_x)
  l_model <- loess(val ~ Time, df)
  res <- predict(l_model)
  return(res)
})

inflection_points <- apply(norm_test_c_elegans_data, 2, function(data) {
  inflection_point <- bede(1:length(data), data, 0)
  if (!is.finite(inflection_point$iplast)) 
    inflection_point <- bede(1:length(data), data, 
                             1)
  round(inflection_point$iplast)
})

middle_points <- apply(norm_test_c_elegans_data, 2, function(data) {
  loc <- which.min(data - 0.5)
  sign(mean(data[1:loc])) * loc
})

pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(inflection_points), ], cluster_rows = T, cluster_cols = F)

pdf(paste0(main_fig_dir, 'c_elegans_muscle_heatmap.pdf'), width =  1, height = 2)
pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(middle_points), ], cluster_rows = F, cluster_cols = F,
                    annotation_names_row = F, border_color = NA, legend = F, show_rownames = F)
dev.off()

pdf(paste0(main_fig_dir, 'c_elegans_muscle_heatmap_helper.pdf'))
pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(middle_points), ], cluster_rows = F, cluster_cols = F,
                   annotation_names_row = F, border_color = NA, legend = T, show_rownames = F)
dev.off()

pheatmap::pheatmap(con_test_rdi_res[muscle_genes, muscle_genes], cluster_rows = F, cluster_cols = F)

pheatmap::pheatmap(test_rdi_res$max_rdi_value[intestine_gene, intestine_gene], cluster_rows = F, cluster_cols = F)
pheatmap::pheatmap(con_test_rdi_res[intestine_gene, intestine_gene], cluster_rows = F, cluster_cols = F)

pdf('Figures/c_elegans.pdf', width = 40, height = 40)
pheatmap::pheatmap(test_rdi_res$max_rdi_value)
dev.off()

which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[1], arr.ind = T)
plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("unc.120", "hlh.1"), ncol = 2))
row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[2], arr.ind = T)]
row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[3], arr.ind = T)]
row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[4], arr.ind = T)]
row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[5], arr.ind = T)]

qplot(1:ncol(test_cds), exprs(test_cds)['tbx.8', ], geom = 'line', color = 'red') + geom_line(aes(1:ncol(test_cds), exprs(test_cds)['his.72', ], color = 'blue'))

qplot(1:ncol(test_cds), exprs(test_cds)['tbx.8', ], geom = 'line', color = 'red') + geom_line(aes(1:ncol(test_cds), exprs(test_cds)['his.72', ], color = 'blue'))

plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("tbx.8", "Y71G12B.6"), ncol = 2))
plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("crh.2", "Y71G12B.6"), ncol = 2))
plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("sup.37", "Y71G12B.6"), ncol = 2))

plot_comb_logic(test_cds, gene_pairs_target_mat = matrix(c("crh.2", "tbx.8", "Y71G12B.6"), nrow = 1))

##########################################################################################################################################################
# analyze the C cell lineage
##########################################################################################################################################################
C_lineage_cells <- as.character(unique(c_elegans_data$cell)[grep(unique(c_elegans_data$cell), pattern = '^C')])
C_lineage_cells_len <- unlist(lapply(C_lineage_cells, function(x) length(strsplit(x, "")[[1]])))
C_lineage_cells[C_lineage_cells_len == 7]

c_lineage_genes <- c("pal.1", "tbx.8", "tbx.9", "elt.1", "elt.3", "nhr.25", "mab.21", "cwn.1", "nob.1", "vab.7", "hnd.1", "unc.120", "hlh.1", "c55c2.1")
measured_genes <- c_lineage_genes[c_lineage_genes %in% fData(test_cds)$gene_short_name ]


p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[1], ]) + xlab('Time') + ylab(measured_genes[1]) + ggtitle(paste('Cell name:', cell_id))
p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[2], ]) + xlab('Time') + ylab(measured_genes[2]) + ggtitle(paste('Cell name:', cell_id))
p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[3], ]) + xlab('Time') + ylab(measured_genes[3]) + ggtitle(paste('Cell name:', cell_id))

p4 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[4], ]) + xlab('Time') + ylab(measured_genes[4]) + ggtitle(paste('Cell name:', cell_id))
p5 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[5], ]) + xlab('Time') + ylab(measured_genes[5]) + ggtitle(paste('Cell name:', cell_id))
p6 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[6], ]) + xlab('Time') + ylab(measured_genes[6]) + ggtitle(paste('Cell name:', cell_id))

p7 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[7], ]) + xlab('Time') + ylab(measured_genes[7]) + ggtitle(paste('Cell name:', cell_id))
p8 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[8], ]) + xlab('Time') + ylab(measured_genes[8]) + ggtitle(paste('Cell name:', cell_id))
p9 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[9], ]) + xlab('Time') + ylab(measured_genes[9]) + ggtitle(paste('Cell name:', cell_id))

p10 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[10], ]) + xlab('Time') + ylab(measured_genes[10]) + ggtitle(paste('Cell name:', cell_id))
p11 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[11], ]) + xlab('Time') + ylab(measured_genes[11]) + ggtitle(paste('Cell name:', cell_id))
p12 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[12], ]) + xlab('Time') + ylab(measured_genes[12]) + ggtitle(paste('Cell name:', cell_id))


xacHelper::multiplot(plotlist = list(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12), cols = 3)

##########################################################################################################################################################
# analyze the MS cell lineage
##########################################################################################################################################################
E_lineage_cells <- as.character(unique(c_elegans_data$cell)[grep(unique(c_elegans_data$cell), pattern = '^E')])
MS_lineage_cells <- as.character(unique(c_elegans_data$cell)[grep(unique(c_elegans_data$cell), pattern = '^MS')])

E_lineage_cells_len <- unlist(lapply(E_lineage_cells, function(x) length(strsplit(x, "")[[1]])))
E_lineage_cells[E_lineage_cells_len == 7]
MS_lineage_cells_len <- unlist(lapply(MS_lineage_cells, function(x) length(strsplit(x, "")[[1]])))
MS_lineage_cells[MS_lineage_cells_len == 10]

EMS_lineage_genes <- c("pop.1", "skn.1", "pal.1", "med.1", "med.2", "tbx.35", "pha.4", "hlh.1")
measured_genes <- EMS_lineage_genes[EMS_lineage_genes %in% fData(test_cds)$gene_short_name ]

p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[1], ]) + xlab('Time') + ylab(measured_genes[1]) + ggtitle(paste('Cell name:', cell_id))
p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[2], ]) + xlab('Time') + ylab(measured_genes[2]) + ggtitle(paste('Cell name:', cell_id))
p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[3], ]) + xlab('Time') + ylab(measured_genes[3]) + ggtitle(paste('Cell name:', cell_id))
p4 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data[measured_genes[4], ]) + xlab('Time') + ylab(measured_genes[4]) + ggtitle(paste('Cell name:', cell_id))

xacHelper::multiplot(plotlist = list(p1, p2, p3, p4), cols = 2)

##########################################################################################################################################################
# likely ELT-1 directly activates the transcription of at least two other transcription factors, the zinc finger protein LIN-26 and the GATA family protein ELT-3.
##########################################################################################################################################################
# ELT-1 -> LIN-26 and ELT-3 

cell_list <- read.table('./csv_data/c_elegans/PyOpenWorm/OpenWormData/aux_data/C. elegans Cell List - WormAtlas.tsv', sep = '\t', header = T, quote = "")

# Note that:
# - Usually lineage names are codified with a period between the blast and further divisions for postembryonic cells (e.g, QL.ap), while embryonic cells are codified with a space (e.g., AB plpapaaap)
# - Pn may indicate divisions of the embryonic founder cell P0 (i.e., zygote/Z) such that P1/P1'/P0 p is sister of AB; P2/P2'/P0 pp is sister of EMS; P3/P3'/P0 ppp: sister of C and P4/P4'/P0 pppp is sister of D (See FIG 9 in Sulston et al.,1983). Additionally, P1-12 indicate hypodermal blast cells that divide postembryonically (P lineage)

cell_list_wormbase <- read.csv('./csv_data/c_elegans/PyOpenWorm/OpenWormData/aux_data/C. elegans Cell List - WormBase.csv', sep = ',', header = T, quote = "", skip = 1, na.strings = "", row.names = NULL)

# create a 3D embryo plot: 
subset_pd <- subset(pData(c_elegans_cds), time == 200)
# plotly::plot_ly(subset_pd, x = ~x, y = ~y, z = ~z,
#         marker = list(color = ~time, colorscale = c('#FFE1A1', '#683531'), showscale = TRUE),
#         text = ~paste('Cell name:', cell, '<br>Developmental time:', time))  %>% 
#   layout(scene = list(xaxis = list(title = 'X'),
#                       yaxis = list(title = 'Y'),
#                       zaxis = list(title = 'Z'))
#          # ,
#          # annotations = list(
#          #   x = 1.08,
#          #   y = 1.02,
#          #   text = 'Causality',
#          #   xref = 'paper',
#          #   yref = 'paper',
#          #   showarrow = FALSE
#          # )
#          )

x <- subset_pd$x
y <- subset_pd$y
z <- subset_pd$z * 11.1
# scatter3d(x = x, y = y, z = z, point.col = "blue", #groups = iris$Species,
#           surface=FALSE, 
#           grid = T, 
#           ellipsoid = F, 
#           bg.col="white", 
#           axis.scales=F,
#           axis.ticks=T,
#           # radius = 4, 
#           sphere.size = 4, 
#           neg.res.col = 'red',
#           # labels = subset_pd$cell, 
#           # id.n=nrow(subset_pd)
#           )

lim <- function(x){c(min(abs(x), na.rm = T), max(abs(x), na.rm = T)) } # * 1.1

# Make a scatter plot
rgl_init <- function(new.device = FALSE, bg = "white", width = 640) { 
  if( new.device | rgl.cur() == 0 ) {
    rgl.open()
    par3d(windowRect = 50 + c( 0, 0, width, width ) )
    rgl.bg(color = bg )
  }
  rgl.clear(type = c("shapes", "bboxdeco"))
  rgl.viewpoint(theta = 15, phi = 20, zoom = 0.7)
}
rgl_init()
hmcols <- monocle:::blue2green2red(2)
# add the color (expression, causality, etc.) for each cell: 
ap_genes <- c("alr.1", "pes.1")
expression <- as.numeric(exprs(c_elegans_cds[ap_genes[2], row.names(subset_pd)]))

quartiles = cut(expression, breaks=quantile(expression, probs=seq(0,1, by=0.5)), include.lowest=TRUE)
names(hmcols) <- levels(quartiles)

# expression_matrix_by_quartile = split(as.data.frame(expression_matrix), quartiles)
# reference_matrix_by_quartile = split(as.data.frame(reference_matrix), quartiles)

rgl.spheres(x, y, z, r = 8, color = hmcols[quartiles]) 

# Add x, y, and z Axes
# label the rgl lines 
# posterior-anterior, left-right, ventral - dorsal
rgl.lines(lim(x), mean(range(y, na.rm = T)), mean(range(z, na.rm = T)), color = "black")
rgl.lines(mean(range(x, na.rm = T)), lim(y), mean(range(z, na.rm = T)), color = "red")
rgl.lines(mean(range(x, na.rm = T)), mean(range(y, na.rm = T)), lim(z), color = "green")
txt_df <- data.frame(x = c(min(x, na.rm = T) - 10, max(x, na.rm = T) + 10, mean(range(x, na.rm = T)), mean(range(x, na.rm = T)), mean(range(x, na.rm = T)), mean(range(x, na.rm = T))), 
                     y = c(mean(range(y, na.rm = T)), mean(range(y, na.rm = T)), min(y, na.rm = T) - 10, max(y, na.rm = T) + 10, mean(range(y, na.rm = T)), mean(range(y, na.rm = T))), 
                     z = c(mean(range(z, na.rm = T)), mean(range(z, na.rm = T)), mean(range(z, na.rm = T)), mean(range(z, na.rm = T)), min(z, na.rm = T) - 10, c(max(z, na.rm = T) + 30)), 
                     name = c('anterior', 'posterior', 'left', 'right', 'ventral', 'dorsal'))

with(txt_df,text3d(x,y,z,name), cex = rep(16,length=nrow(txt_df)))

rgl.postscript("./Figures/main_figures/pes.1.pdf","pdf")

# identifying the network motif from the data 

# lineage specific genes between different lineages or lineage difference in a big lineage 

# create a heatmap for some master regulators 

# show a few genes with combinatorial regulations 

# adding the network sparsifier procedure 

########################################################################################################################################################################################################################
# save the data 
########################################################################################################################################################################################################################
save.image('./RData/analysis_c_elegans.RData')

