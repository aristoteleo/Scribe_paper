# analyze sea urchin dataset 
library(monocle)
library(Scribe)

source('./Scripts/function.R')

b1 <- read.csv('./csv_data/sea_urchin_batch_1', sep = '\t', row.names = 1)
b2 <- read.csv('./csv_data/sea_urchin_batch_2', sep = '\t', row.names = 1)

sample_sheet <- data.frame(time = rep(colnames(b1), 2), 
                           row.names = c(colnames(b1), paste0(colnames(b1), '_0')), 
                           group = rep(c('1', '2'), each = ncol(b1)),
                           Pseudotime = rep(0:48, 2))
gene_ann <- data.frame(gene_short_name = row.names(b1), row.names = row.names(b1))
pd <- new("AnnotatedDataFrame",data=sample_sheet)
fd <- new("AnnotatedDataFrame",data=gene_ann)

mat <- as.matrix(cbind(b1, b2))
colnames(mat) <- c(colnames(b1), paste0(colnames(b1), '_0'))
b12_cds <- newCellDataSet(t(scale(t(mat))), phenoData = pd, featureData =fd,
                               expressionFamily = gaussianff(),
                               lowerDetectionLimit=1)

plot_genes_in_pseudotime(b12_cds[1:10, ], color_by = 'group')

overlapping_genes <- c('Ac/Sc', "Blimp1a", "Blimp1b", 'Bra', 'Brn1/2/4', 'Delta', 'Dri', 'Erg', 'Ese', 'Eve', 'FoxA', 'FoxB', 'FoxF', 
                       'FoxN2/3', 'FoxO', 'FoxY', 'GataC', 'GataE', 'Gcm', 'Hesc', 'Hex', 'Hh', 'Hnf1', 'Hnf6', 'Hox11/13b', 
                       'Nodal', 'Not', 'Notch', 'Otxa', 'Pks', 'Prox1', 'Scl', 'Six1/2', 'Sm50', 'Smad4', 'SmadIP/Z81', 'SoxB1', 'SoxC', 'SoxE', 'Su(H)', 'Tbr', 'Tel', 'Tgif', 
                       'Unc4.1', 'Vegf3', 'Wnt16', 'Wnt8', 'Z166')
plot_genes_in_pseudotime(b12_cds[example_genes, ], panel_order = example_genes, color_by = 'group')
sea_urchin_res <- calculate_rdi(b12_cds, delays = c(0:20), log = F)
pheatmap::pheatmap(sea_urchin_res$max_rdi_value)
pheatmap::pheatmap(clr_directed_R(sea_urchin_res$max_rdi_value)[overlapping_genes, overlapping_genes], cluster_cols = F, cluster_rows = F)

sea_urchin_res_subset <- calculate_rdi(b12_cds[example_genes, ], delays = c(0:20), log = F)
pheatmap::pheatmap(clr_directed_R(sea_urchin_res_subset$max_rdi_value))

sea_urchin_clr <- clr_directed_R(sea_urchin_res$max_rdi_value[overlapping_genes, overlapping_genes])

# read the Sea urchin network from the data 
ecto <- read.csv('./csv_data/sea_urchin_network/SpEcto-01-21-15-EB-VfG.sif', header = F, sep = '\t')
endo <- read.csv('./csv_data/sea_urchin_network/SpEndomes-01-09-15-EB-VfG.sif', header = F, sep = '\t')

ecto_endo_net <- rbind(ecto, endo)
overlap_true_link <- subset(ecto_endo_net, (toupper(V1) %in% toupper(overlapping_genes)) & (toupper(V3) %in% toupper(overlapping_genes)))

plot_heatmap_with_true_edges <- function(network_res, overlapping_genes) {
  true_mat <- matrix(FALSE, nrow = nrow(network_res), ncol = nrow(network_res))
  other_mat <- matrix(TRUE, nrow = nrow(network_res), ncol = nrow(network_res))
  
  subset_ecto_endo_net <- subset(ecto_endo_net, (toupper(V1) %in% toupper(overlapping_genes)) & (toupper(V3) %in% toupper(overlapping_genes)))
  for(i in 1:nrow(subset_ecto_endo_net)) {
    row_id <- which(toupper(row.names(network_res)) %in% toupper(subset_ecto_endo_net$V1[i]))
    colum_id <- which(toupper(row.names(network_res)) %in% toupper(subset_ecto_endo_net$V3[i]))
    true_mat[row_id, colum_id] <- TRUE
    other_mat[row_id, colum_id] <- FALSE
  }
  
  # plot the result by adding the annotation data from the known Eric Davidson's sea urchin network 
  # draw the true network and then put the order of the interactions on top of it. 
  
  # save the result from the sea urchin analysis 
  
  nx=nrow(network_res)
  ny=nrow(network_res)
  
  # creates a own color palette from red to green
  my_palette <- colorRampPalette(rev(RColorBrewer::brewer.pal(n = 7, 
                                                name = "RdYlBu")))(100)
  print(heatmap.2(network_res,
            # cellnote = mat_data,  # same data set for cell labels
            # main = "Correlation", # heat map title
            # notecol="black",      # change font color of cell labels to black
            density.info="none",  # turns off density plot inside color legend
            trace="none",         # turns off trace lines inside the heat map
            # margins =c(12,9),     # widens margins around plot
            col=my_palette,       # use on color palette defined earlier
            # breaks=col_breaks,    # enable color transition at specified limits
            dendrogram="none",     # only draw a row dendrogram
            Colv="NA",
            Rowv="NA",
            add.expr = {
              makeRects(true_mat,"red")}))            # turn off column clustering
}

plot_heatmap_with_true_edges(sea_urchin_clr, overlapping_genes)

sea_urchin_clr_subset <- clr_directed_R(sea_urchin_res$max_rdi_value)[example_genes, example_genes]
plot_heatmap_with_true_edges(sea_urchin_clr_subset, example_genes)

# show only the example genes: 
example_genes <- c("Alx1", "Dri",
                   "Delta", "Gcm", "Pks",
                   "Wnt8", "Hox11/13b", 
                   "Tbx2/3", "Irxa", "Nodal",
                   "Lefty", "Not")

save.image('./RData/analysis_sea_urchin_data.RData')




