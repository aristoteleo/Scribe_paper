# use flann for knn and radius search: 
query <- matrix(rnorm(10), ncol = 2)
reference <- matrix(rnorm(10), ncol = 2)
RadiusSearch(query, reference, 1, 2, "kdtree", 0, 1)

query[1, ] <- c(0, 0)
query[2, ] <- c(0, 0)
query[3, ] <- c(0, 0)

Neighbour(query, query, 2, "kdtree", 0, 1)

RadiusSearch(rbind(c(0, 0), c(0, 0)), query, 0.0, 100, "kdtree", 0, 1) # doesn't consider duplicate points here

library(reticulate)  # this doesn't work too 
Scipy <- import("scipy")
sp$cKDTree(query)

