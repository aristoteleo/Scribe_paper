# analysis simulation (real time series, RNA-velocity, live-imaging)
library(Scribe)
library(scRNASeqSim)
library(devtools)
load_all("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/monocle_old/monocle-dev")
library(reshape2)
library(xacHelper)
library(plyr)
library(dplyr)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

# we set the time step as 0.1, samples per simulation as 100, the total number of simulations as 20 
set.seed(2018)
time_d <- sample(1:3, 13, replace = T)
time_d <- sample(1, 13, replace = T)

sim_res_list <- simulate_cns(cells = 1000, steps = 100, N_end = 20, delay = time_d)
sim_res <- sim_res_list$cell_simulate
velocity_res <- sim_res_list$cell_gene_velocity
time_delay_res <- sim_res_list$cell_time_delay
# simulate pseudotime 
dim(sim_res)

calClusteringMetrics <- function(cl1, cl2){
  tab_1 <- table(cl1, cl2)
  randi <- flexclust::randIndex(tab_1)
  
  vi <- mcclust::vi.dist(cl1, cl2, parts = FALSE, base = 2)
  
  #arandi
  arandi <- mcclust::arandi(cl1, cl2, adjust = TRUE)
  
  #add all result into a data frame
  randIndex_df <- data.frame(randIndex = c(randi, vi, arandi),
                             Type = c("rand index", "variation of information", "adjusted rand index"))
  
  return(randIndex_df)
}

Root_state <- function(cds){
  which.min((pData(sim_cds[, ]) %>% dplyr::group_by(c(State)) %>% dplyr::summarise(mean = mean(Time)))$mean)
}

make_cds <- function (exprs_matrix, pd, fd, lowerDetectionLimit = 1, expressionFamily) {
  cds <- newCellDataSet(exprs_matrix, phenoData = pd, featureData = fd, lowerDetectionLimit = 1, expressionFamily)
  return(cds)
}

# save the result 
save_cds_for_benchmark <- function(cds, type, file_name) {
  res <- cds@assayData$exprs
  p_df <- pData(cds)
  f_df <- fData(cds)
  
  write.table(as.data.frame(res), sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", type, '_', file_name, '_expr.txt'))
  write.table(p_df, sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", type, '_', file_name, '_pd.txt'))
  write.table(f_df, sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", type, '_', file_name, '_fd.txt'))
}

####################################################################################################################################################################################
# load all required simulation data 
####################################################################################################################################################################################
#CNS simulation data:
all_cell_simulation <- sim_res[, 1:(100 + max(time_d)), ] #time 0-20 are the period two branches appear
row.names(all_cell_simulation) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

#obtain the corresponding lineage for each simulation run:
neuron_cell_ids <- which(all_cell_simulation['Mash1', 100, ] > 3)
astrocyte_cell_ids <- which(all_cell_simulation['Scl', 100, ] > 2)
oligodendrocyte_cell_ids <- which(all_cell_simulation['Olig2', 100, ] > 2)
cell_type <- apply(all_cell_simulation[c('Mash1', 'Scl', 'Olig2'), 100, ], 2, which.max)
cell_type[cell_type == 1] <- 'neuron'
cell_type[cell_type == 2] <- 'astrocyte'
cell_type[cell_type == 3] <- 'oligodendrocyte'

cols <- c("lap" = "black", "original" = "gray", "pt" = "red")
cell_type_cols <- c("neuron" = "#F2746B", "astrocyte" = "#29B14A", "oligodendrocyte" = "#6E95CD")

####################################################################################################################################################################################
# sample a random time point for each cell 
####################################################################################################################################################################################
gene_names <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

run_num <- 100 

for(cur_run in 1:run_num) {
  set.seed(cur_run)
  
  message('use pseudotime data  ...')
  sample_time_ids <- sample(1:100, 100)
  sample_cell_ids <- sample(1:1000, 100)
  print(sample_time_ids[1:5])
  print(sample_cell_ids[1:5])
  
  exprs_mat <- NULL
  for(i in 1:length(sample_time_ids)) {
    exprs_mat <- cbind(exprs_mat, all_cell_simulation[, sample_time_ids[i] + max(time_d), sample_cell_ids[i]])
  }
  
  dimnames(exprs_mat) = list(gene_names, paste('Cell_', rep(1:100, 1), sep = ''))
  
  PD <- data.frame(Time = sample_time_ids, row.names = paste('Cell_', rep(1:100, 1), sep = ''), cell_type = cell_type[sample_cell_ids])
  FD <- data.frame(gene_short_names = gene_names, row.names = gene_names)
  
  pd <- new("AnnotatedDataFrame",data=PD)
  fd <- new("AnnotatedDataFrame",data=FD)
  
  sim_cds <- newCellDataSet(exprs_mat, pd, fd, expressionFamily = gaussianff())
  print(sim_cds@assayData$exprs[1:5, 1:5])
  
  pData(sim_cds)$Size_Factor <- 1
  
  ####################################################################################################################################################################################
  #create figure SI5b (figSI5b.1.pdf is the file used in the paper, same pattern as below)
  ####################################################################################################################################################################################
  sim_cds <- setOrderingFilter(sim_cds, ordering_genes = row.names(sim_cds)[c(2, 6, 7, 8)])
  # sim_cds@auxOrderingData[["PCA"]]$irlba_pca_res <- t(sim_cds)[c(2, 6, 7, 8), ])
  # sim_cds@auxOrderingData$normalize_expr_data <- exprs(sim_cds)[c(2, 6, 7, 8), ]
  pData(sim_cds)$louvain_component <- 1
  
  # sim_cds <- monocle::reduceDimension(sim_cds, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 20,  max_components = 12, pseudo_expr=0, scaling = F, reduction_method = 'simplePPT')
  sim_cds <- reduceDimension(sim_cds, norm_method = 'none', verbose = F, auto_param_selection = F, maxIter = 100,  max_components = 4, pseudo_expr=0, scaling = F)
  sim_cds <- orderCells(sim_cds)
  sim_cds <- orderCells(sim_cds, root_state = Root_state(sim_cds))

  # save pseudotime
  message('save pseudotime ...')
  save_cds_for_benchmark(sim_cds, type = 'Pseuotime', file_name = cur_run)
  
  # save RNA velocity 
  previous_regulator <- NULL # sim_cds@assayData$exprs  

  for(i in 1:length(sample_cell_ids)) {
    tmp_1 <- sim_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))] # + max(time_d)  - time_d
    tmp_2 <- time_delay_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))]
    print(identical(tmp_1, tmp_2))
    previous_regulator <- cbind(previous_regulator, tmp_1)
  }

  velocity_target <- NULL
  
  for(i in 1:length(sample_cell_ids)) {
    # velocity_target <- cbind(velocity_target, sim_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i] + time_d, z = sample_cell_ids[i]))] - 
    #                            all_cell_simulation[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))])
    velocity_target <- cbind(velocity_target, velocity_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))])
  }
  
  colnames(velocity_target) <- paste('Cell_', rep(1:100, 1), sep = '')
  row.names(velocity_target) <- gene_names

  previous_target <- NULL # sim_cds@assayData$exprs
  
  for(i in 1:length(sample_cell_ids)) {
    tmp_1 <- sim_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))] # + max(time_d)  - time_d
    tmp_2 <- time_delay_res[as.matrix(data.frame(x = 1:13, y = sample_time_ids[i], z = sample_cell_ids[i]))]
    print(identical(tmp_1, tmp_2))
    previous_target <- cbind(previous_target, tmp_1)
  }
  
  # save RNA velocity 
  message('save RNA velocity ...')
  write.table(as.data.frame(previous_regulator), sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", 'velocity', '_', cur_run, '_previous_regulator.txt'))
  write.table(as.data.frame(velocity_target), sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", 'velocity', '_', cur_run, '_velocity_target.txt'))
  write.table(as.data.frame(previous_target), sep = '\t', quote = F, file = paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation/", 'velocity', '_', cur_run, '_previous_target.txt'))
  
  # save live imaging
  dim_names <- dimnames(sim_cds@assayData$exprs)
  
  message('save live imaging ...')
  sim_cds_image <- sim_cds
  neuron_exprs <- NULL 
  set.seed(cur_run)
  sample_cell_type <- sample(unique(cell_type), 1)
  for(i in 1:13) {
    cur_cell <- sample(which(cell_type == sample_cell_type), 1)
    print(cur_cell[1:5])
    neuron_exprs <- cbind(neuron_exprs, all_cell_simulation[i, (max(time_d) + 1):dim(all_cell_simulation)[2], cur_cell]) # only select time-series from cells belong to the same cell type   
  }
  sim_cds_image@assayData$exprs <- t(neuron_exprs)
  dimnames(sim_cds_image@assayData$exprs) <- dim_names
  pData(sim_cds_image)$Pseudotime <- 1:100
  save_cds_for_benchmark(sim_cds_image, type = 'live_imaging', file_name = cur_run)
  
  # use real time data 
  message('use real time data  ...')
  sim_cds_real_time <- sim_cds
  set.seed(cur_run)
  cur_cell <- sample(1:1000, 1)
  print(cur_cell[1:5])
  
  sim_cds_real_time@assayData$exprs <- all_cell_simulation[, (max(time_d) + 1):dim(all_cell_simulation)[2], cur_cell]
  dimnames(sim_cds_real_time@assayData$exprs) <- dim_names
  pData(sim_cds_real_time)$Pseudotime <- 1:100
  
  save_cds_for_benchmark(sim_cds_real_time, type = 'real_time', file_name = cur_run)
}

# use true pseudotime 
cor(pData(sim_cds)$Time, pData(sim_cds)$Pseudotime)
calClusteringMetrics(pData(sim_cds)$cell_type[pData(sim_cds)$State %in% c(1, 2, 5)], pData(sim_cds)$State[pData(sim_cds)$State %in% c(1, 2, 5)])

table(pData(sim_cds)[, c('State', 'cell_type')])
neuron_branch_res <- calculate_rdi(sim_cds[, pData(sim_cds)$State %in% c(4, 5)], delays = 1)
astrocyte_branch_res <- calculate_rdi(sim_cds[, pData(sim_cds)$State %in% c(3, 4, 1)], delays = 1)
oligodendrocyte_branch_res <- calculate_rdi(sim_cds[, pData(sim_cds)$State %in% c(3, 4, 2)], delays = 1)
pData(sim_cds)$run <- 1
pData(sim_cds)$run[pData(sim_cds)$State %in% c(3, 1)] <- 2
pData(sim_cds)$run[pData(sim_cds)$State %in% c(4, 2)] <- 0

# run multiple run and compare the results with the true network 
neuron_branch_res <- calculate_rdi_multiple_run(sim_cds, delays = 1, run_vec = pData(sim_cds)$run)

load_all("/Users/xqiu/Dropbox (Personal)/Projects/monocle-dev")
load_all("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe")

########################################################################################################################################################################
# make AUC curves, etc.
########################################################################################################################################################################

# reference network:
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- gene_names[-13]
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
process_data <- function(benchmark_res) {
  all_valid_gene_pairs <- valid_all_cmbns_df$pair
  
  a_mlt_cRDI_benchmark_res <- melt(as.matrix(benchmark_res))
  row.names(a_mlt_cRDI_benchmark_res) <-  paste(tolower(a_mlt_cRDI_benchmark_res$Var2), tolower(a_mlt_cRDI_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X
  
  network_result_df <- data.frame(a_cRDI = as.numeric(as.character(a_mlt_cRDI_benchmark_res[all_valid_gene_pairs, "value"])))
  network_result_df
}

neuron_network_result_df <- process_data(neuron_branch_res$RDI)

neuron_network_result_df <- process_data(neuron_branch_res_crdi)

astrocyte_network_result_df <- process_data(astrocyte_branch_res)
oligodendrocyte_network_result_df <- process_data(oligodendrocyte_branch_res)
all_branch_network_result_df <- process_data(all_branch_res)
adj_mat_result_df <- process_data(adj_mat)

network_result_df <- neuron_network_result_df # adj_mat_result_df # #  # astrocyte_network_result_df # oligodendrocyte_network_result_df all_branch_network_result_df
#use the spike-in as the gold standard
reference_network_pvals <- valid_all_cmbns_df[, 2]
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)

# simulate velocity 
n_genes <- length(gene_names[1:12])
tmp <- expand.grid(1:n_genes, 1:n_genes, stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ]
super_graph[, 1] <- valid_gene[super_graph[, 1]]
super_graph[, 2] <- valid_gene[super_graph[, 2]]

previous_regulator <- sim_cds@assayData$exprs
velocity_target <- NULL
  
for(i in 1:length(sample_cell_ids)) {
  velocity_target <- cbind(velocity_target, sim_res[, sample_cell_ids[i] + 1, i] - all_cell_simulation[, sample_cell_ids[i], i])
}

previous_target <- sim_cds@assayData$exprs
res <- apply(super_graph, 1, function(x) {
  x_t_min_1 <- as.matrix(previous_regulator[x[1], ]) #as.matrix(c(current_n[x[1], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  y_t <- as.matrix(velocity_target[x[2], ]) #as.matrix(c(projected[x[2], ], sort_gene_expression[x[1], (1 + delay):ncells]) )
  y_t_min_1 <- as.matrix(previous_target[x[2], ]) #as.matrix(c(current_n[x[2], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  
  Scribe::cmi(x_t_min_1, y_t, y_t_min_1, k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0

dimnames(adj_mat) <- list(gene_names[1:12], gene_names[1:12])

# simulate live-imaging data 
sim_cds_image <- sim_cds
neuron_exprs <- NULL 
for(i in 1:13) {
  neuron_exprs <- cbind(neuron_exprs, all_cell_simulation[i, , which(cell_type == 'neuron')[i]]) 
}
sim_cds_image@assayData$exprs <- t(neuron_exprs)
pData(sim_cds_image)$Pseudotime <- 1:100
neuron_branch_res <- calculate_rdi(sim_cds_image, delays = 1, log = F)

sim_cds_real_time <- sim_cds
sim_cds_real_time@assayData$exprs <- all_cell_simulation[, , which(cell_type == 'astrocyte')[1]]
sim_cds_real_time@assayData$exprs <- all_cell_simulation[, , which(cell_type == 'neuron')[1]]
sim_cds_real_time@assayData$exprs <- all_cell_simulation[, , which(cell_type == 'astrocyte')[1]]
sim_cds_real_time@assayData$exprs <- all_cell_simulation[, , which(cell_type == 'oligodendrocyte')[1]]
pData(sim_cds_real_time)$Pseudotime <- 1:100

scale_res <- t(apply(exprs(sim_cds_real_time), 1, function(x) x))
scale_res[13, ] <- 0
sim_cds_real_time@assayData$exprs <- scale_res
neuron_branch_res <- calculate_rdi(sim_cds_real_time, delays = 1, log = F, uniformalize = F)
neuron_branch_res_crdi <- calculate_conditioned_rdi(sim_cds_real_time, log = F, rdi_list = neuron_branch_res, uniformalize = F)

subset_res <- neuron_branch_res_crdi[c(2, 6, 7, 8), c(2, 6, 7, 8)]
dimnames(subset_res) <- list(c('Mash1', 'Hes5', 'Scl', 'Olig2'), c('Mash1', 'Hes5', 'Scl', 'Olig2'))
pheatmap::pheatmap(subset_res, cluster_cols = F, cluster_rows = F)

# show top-ranked genes from specific lineage
dimnames(neuron_branch_res_crdi) <- list(gene_names, gene_names)
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")
g <- igraph::graph_from_adjacency_matrix(neuron_branch_res_crdi, weighted = T, mode = "direct")

V(g)$hubness <- -igraph::hub_score(g)$vector 
plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE, layout = layout.circle(g))

# > sort(igraph::hub_score(g)$vector )
# Mature       Aldh1L         Sox8        Stat3        Myt1L        Olig2         Pax6         Tuj1          Scl         Hes5         Zic1        Mash1 
# 3.033375e-17 3.357906e-01 5.135699e-01 5.517103e-01 5.600323e-01 6.612687e-01 6.733849e-01 7.440694e-01 7.461461e-01 8.438716e-01 8.561838e-01 9.410246e-01 
# Brn2 
# 1.000000e+00 
# 
# > sort(igraph::hub_score(g)$vector )
# Mature         Pax6       Aldh1L         Sox8        Olig2        Myt1L        Mash1         Hes5        Stat3         Tuj1         Brn2         Zic1 
# 1.383996e-17 5.708025e-01 5.766256e-01 5.789226e-01 6.906174e-01 7.411875e-01 7.413095e-01 8.288958e-01 8.853923e-01 8.980724e-01 8.982832e-01 9.635378e-01 
# Scl 
# 1.000000e+00 
# 
# > sort(igraph::hub_score(g)$vector )
# Mature        Mash1         Pax6         Sox8          Scl       Aldh1L         Tuj1         Hes5        Stat3         Zic1         Brn2        Myt1L 
# 1.955914e-18 5.011942e-01 5.235056e-01 5.333885e-01 5.870515e-01 6.023933e-01 6.099725e-01 6.194796e-01 6.282568e-01 6.422453e-01 6.569913e-01 7.172200e-01 
# Olig2 
# 1.000000e+00 

####################################################################################################################################################################################
# read in Arman's result: 
####################################################################################################################################################################################
# Full dataset comparison: 
pseudotime_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/pseudotime_results.tsv', sep = '\t')
liveimage_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/liveimage_results.tsv', sep = '\t')
realtime_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/realtime_results.tsv', sep = '\t')
velocity_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/velocity_results.tsv', sep = '\t')

pseudotime_res_mlt <- reshape2::melt(pseudotime_res)
liveimage_res_mlt <- reshape2::melt(liveimage_res)
realtime_res_mlt <- reshape2::melt(realtime_res)
velocity_res_mlt <- reshape2::melt(velocity_res)

res_df <- Reduce(f = rbind, x = list(pseudotime_res_mlt, liveimage_res_mlt, realtime_res_mlt, velocity_res_mlt))
res_df$type <- rep(c('pseudotime', 'liveimage', 'realtime', 'velocity'), each = 30)

qplot(Method, value, data = res_df, color = 'type', geom = 'boxplot')

res_df$Method <- factor(res_df$Method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
res_df$type <- factor(res_df$type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))

pdf(paste0(main_fig_dir, 'delay_1_sim_raw.pdf'), width =  1.5, height = 1)
ggplot(res_df, aes(Method, value)) + geom_boxplot(aes(color = type), notchwidth = 0.1, outlier.size = 0.5,
                                                  outlier.stroke = 0.1, size = I(0.1)) + ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) +
  xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'delay_1_sim_helper.pdf'))
ggplot(res_df, aes(Method, value)) + geom_boxplot(aes(color = type), notchwidth = 0.1, outlier.size = 0.5,
                                                  outlier.stroke = 0.1, size = I(0.1)) + ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30))
dev.off()

####################################################################################################################################################################################
# delay varies between 1-3 
####################################################################################################################################################################################
pseudotime_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/pseudotime_results_delay_1_3.tsv', sep = '\t')
liveimage_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/liveimage_results_delay_1_3.tsv', sep = '\t')
realtime_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/realtime_results_delay_1_3.tsv', sep = '\t')
velocity_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/velocity_results_delay_1_3.tsv', sep = '\t')

pseudotime_res_mlt <- reshape2::melt(pseudotime_res)
liveimage_res_mlt <- reshape2::melt(liveimage_res)
realtime_res_mlt <- reshape2::melt(realtime_res)
velocity_res_mlt <- reshape2::melt(velocity_res)

res_df <- Reduce(f = rbind, x = list(pseudotime_res_mlt, liveimage_res_mlt, realtime_res_mlt, velocity_res_mlt))
res_df$type <- rep(c('pseudotime', 'liveimage', 'realtime', 'velocity'), each = 30)

qplot(Method, value, data = res_df, color = 'type', geom = 'boxplot')

res_df$Method <- factor(res_df$Method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
res_df$type <- factor(res_df$type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))

pdf(paste0(main_fig_dir, 'delay_1_3_sim_raw.pdf'), width =  1.5, height = 1)
ggplot(res_df, aes(Method, value)) + geom_boxplot(aes(color = type), notchwidth = 0.1, outlier.size = 0.5,
                                                  outlier.stroke = 0.1, size = I(0.1)) + ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) + 
xacHelper::nm_theme()
dev.off()
 

####################################################################################################################################################################################
# do downsampling:  
####################################################################################################################################################################################
# a uniform function to call all downsampling dataset: 
process_downsampling_data <- function(folder = c('realtime', 'realtime_mature_removed'), data_file_type = c('realtime', 'liveimage'), 
         base_file_dir = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_res/') {
  ccm_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_CCM.tsv'), sep = '\t')
  cRDI_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_cRDI.tsv'), sep = '\t')
  Granger_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_Granger.tsv'), sep = '\t')
  RDI_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_RDI.tsv'), sep = '\t')
  ucRDI_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_ucRDI.tsv'), sep = '\t')
  uRDI_res <- read.csv(paste0(base_file_dir, folder, '/', data_file_type, '_uRDI.tsv'), sep = '\t')
  
  ccm_res_mlt <- melt(ccm_res, id.vars = c('Number_of_samples'))
  cRDI_res_mlt <- melt(cRDI_res, id.vars = c('Number_of_samples'))
  Granger_res_mlt <- melt(Granger_res, id.vars = c('Number_of_samples'))
  RDI_res_mlt <- melt(RDI_res, id.vars = c('Number_of_samples'))
  ucRDI_res_mlt <- melt(ucRDI_res, id.vars = c('Number_of_samples'))
  uRDI_res_mlt <- melt(uRDI_res, id.vars = c('Number_of_samples'))
  downsampling_res <- Reduce(rbind, list(ccm_res_mlt, cRDI_res_mlt, Granger_res_mlt, RDI_res_mlt, ucRDI_res_mlt, uRDI_res_mlt))
  downsampling_res$method <- rep(c('CCM', 'cRDI', 'Granger', 'RDI', 'ucRDI', 'uRDI'), each = nrow(ccm_res_mlt))
  
  downsampling_res
}

# delay 1 #
velocity_downsampling_res <- process_downsampling_data('velocity_mature_removed', 'velocity')
realtime_downsampling_res <- process_downsampling_data('realtime_mature_removed', 'realtime')
liveimage_downsampling_res <- process_downsampling_data('liveimage_mature_removed', 'liveimage')
pseudotime_downsampling_res <- process_downsampling_data('pseudotime_mature_removed', 'pseudotime')

realtime_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
liveimage_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
pseudotime_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples

downsampling_res <- Reduce(rbind, list(realtime_downsampling_res, liveimage_downsampling_res, velocity_downsampling_res, pseudotime_downsampling_res))
downsampling_res$data_type <- rep(c('realtime', 'liveimage', 'velocity', 'pseudotime'), each = 300)

downsampling_res$method <- factor(downsampling_res$method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
downsampling_res$data_type <- factor(downsampling_res$data_type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))

pdf(paste0(main_fig_dir, 'downsample_delay_1_sim_raw.pdf'), width =  4, height = 1)
ggplot(subset(downsampling_res, Number_of_samples == 2000), aes(method, value)) + geom_boxplot(aes(color = data_type), notchwidth = 0.1, outlier.size = 0.5,
                                                                                               outlier.stroke = 0.1, size = I(0.1)) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + ylim(0.4, 1) + geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2) + viridis::scale_color_viridis(discrete = T)
dev.off()

subset(downsampling_res, Number_of_samples == 2000 & method == 'Granger')
res_df[res_df$Method == 'Granger', 'value'] <- rev(subset(downsampling_res, Number_of_samples == 2000 & method == 'Granger')[, 'value'])

pdf(paste0(main_fig_dir, 'delay_1_sim_remove_mature_raw.pdf'), width =  1.5, height = 1)
ggplot(subset(downsampling_res, Number_of_samples == 2000), aes(method, value)) + geom_boxplot(aes(color = data_type), notchwidth = 0.1, outlier.size = 0.5,
                                                  outlier.stroke = 0.1, size = I(0.1)) + ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() +  + viridis::scale_color_viridis(discrete = T)
dev.off()

# delay 1-3 #
velocity_downsampling_res <- process_downsampling_data('velocity_1to3delay', 'velocity')
realtime_downsampling_res <- process_downsampling_data('realtime_1to3delay', 'realtime')
liveimage_downsampling_res <- process_downsampling_data('liveimage_1to3delay', 'liveimage')
pseudotime_downsampling_res <- process_downsampling_data('pseudotime_1to3delay', 'pseudotime')

realtime_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
liveimage_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
pseudotime_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples

downsampling_res <- Reduce(rbind, list(realtime_downsampling_res, liveimage_downsampling_res, velocity_downsampling_res, pseudotime_downsampling_res))
downsampling_res$data_type <- rep(c('realtime', 'liveimage', 'velocity', 'pseudotime'), each = 300)

downsampling_res$method <- factor(downsampling_res$method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
downsampling_res$data_type <- factor(downsampling_res$data_type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))

pdf(paste0(main_fig_dir, 'downsample_delay_1_3_sim_raw.pdf'), width =  4, height = 1)
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) + ylim(0.4, 1) + geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2) 
dev.off()

pdf(paste0(main_fig_dir, 'downsample_delay_1_3_sim_helper.pdf'))
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + viridis::scale_color_viridis(discrete = T) + ylim(0.4, 1) + geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2)
dev.off()

subset(downsampling_res, Number_of_samples == 2000 & method == 'Granger')
res_df[res_df$Method == 'Granger', 'value'] <- rev(subset(downsampling_res, Number_of_samples == 2000 & method == 'Granger')[, 'value'])

pdf(paste0(main_fig_dir, 'delay_1_3_sim_remove_mature_raw.pdf'), width =  1.5, height = 1)
ggplot(subset(downsampling_res, Number_of_samples == 2000), aes(method, value)) + geom_boxplot(aes(color = data_type), notchwidth = 0.1, outlier.size = 0.5,
                                                  outlier.stroke = 0.1, size = I(0.1)) + ylim(0.4, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) +  geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2) 
dev.off()

# run downsampling ? #
velocity_downsampling_res <- process_downsampling_data('velocity_100steps/', 'velocity')
realtime_downsampling_res <- process_downsampling_data('realtime_results_run_subsetting', 'realtime')
liveimage_downsampling_res <- process_downsampling_data('liveimage_results_run_subsetting', 'liveimage')
pseudotime_downsampling_res <- process_downsampling_data('pseudotime_results_run_subsetting', 'pseudotime')

velocity_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples 
realtime_downsampling_res$Number_of_samples <- realtime_downsampling_res$Number_of_samples * 100
liveimage_downsampling_res$Number_of_samples <- liveimage_downsampling_res$Number_of_samples * 100
pseudotime_downsampling_res$Number_of_samples <- pseudotime_downsampling_res$Number_of_samples * 100

downsampling_res <- Reduce(rbind, list(velocity_downsampling_res, realtime_downsampling_res, liveimage_downsampling_res, pseudotime_downsampling_res))
downsampling_res$data_type <- rep(c('velocity', 'realtime', 'liveimage', 'pseudotime'), each = 600)

downsampling_res$method <- factor(downsampling_res$method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
downsampling_res$data_type <- factor(downsampling_res$data_type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))
downsampling_res$replicates <- downsampling_res$Number_of_samples / 100

pdf(paste0(main_fig_dir, 'downsample_subset_run_sim_raw.pdf'), width =  4, height = 1)
ggplot(data = downsampling_res, aes(x = replicates, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of replicates') + ylab('AUC') + ylim(0.4, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) + geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2)
dev.off()

pdf(paste0(main_fig_dir, 'downsample_subset_run_helper.pdf'))
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + viridis::scale_color_viridis(discrete = T)  
dev.off()

pdf(paste0(main_fig_dir, 'delay_1_downsample_subset_run_raw.pdf'), width =  1.5, height = 1)
ggplot(subset(downsampling_res, Number_of_samples == 2000), aes(method, value)) + 
  geom_boxplot(aes(color = data_type), notchwidth = 0.1, outlier.size = 0.5, outlier.stroke = 0.1, size = I(0.1)) + 
  ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) +
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) 
dev.off()

# 
velocity_downsampling_res <- process_downsampling_data('velocity_xiaojie_suggestion', 'velocity')
realtime_downsampling_res <- process_downsampling_data('realtime_xiaojie_suggestion', 'realtime')
liveimage_downsampling_res <- process_downsampling_data('liveimage_xiaojie_suggestion', 'liveimage')
pseudotime_downsampling_res <- process_downsampling_data('pseudotime_xiaojie_suggestion', 'pseudotime')

velocity_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
realtime_downsampling_res$Number_of_samples <- realtime_downsampling_res$Number_of_samples
liveimage_downsampling_res$Number_of_samples <- liveimage_downsampling_res$Number_of_samples
pseudotime_downsampling_res$Number_of_samples <- pseudotime_downsampling_res$Number_of_samples

downsampling_res_100 <- Reduce(rbind, list(velocity_downsampling_res, realtime_downsampling_res, liveimage_downsampling_res, pseudotime_downsampling_res))
downsampling_res_100$data_type <- rep(c('velocity', 'realtime', 'liveimage', 'pseudotime'), each = nrow(realtime_downsampling_res))

downsampling_res <- rbind(downsampling_res_100, downsampling_res)
downsampling_res$method <- factor(downsampling_res$method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
downsampling_res$data_type <- factor(downsampling_res$data_type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))

pdf(paste0(main_fig_dir, 'downsample_subset_run_sim_xj_raw.pdf'), width =  4, height = 1)
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) 
dev.off()

pdf(paste0(main_fig_dir, 'downsample_subset_run_xj_helper.pdf'))
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + viridis::scale_color_viridis(discrete = T)  
dev.off()

# subset run delay 1-3: 
velocity_downsampling_res <- process_downsampling_data('Results_runsubsetting_delay1to3', 'velocity')
realtime_downsampling_res <- process_downsampling_data('Results_runsubsetting_delay1to3', 'realtime')
liveimage_downsampling_res <- process_downsampling_data('Results_runsubsetting_delay1to3', 'liveimage')
pseudotime_downsampling_res <- process_downsampling_data('Results_runsubsetting_delay1to3', 'pseudotime')

velocity_downsampling_res$Number_of_samples <- velocity_downsampling_res$Number_of_samples
realtime_downsampling_res$Number_of_samples <- realtime_downsampling_res$Number_of_samples * 100
liveimage_downsampling_res$Number_of_samples <- liveimage_downsampling_res$Number_of_samples * 100
pseudotime_downsampling_res$Number_of_samples <- pseudotime_downsampling_res$Number_of_samples * 100

downsampling_res <- Reduce(rbind, list(velocity_downsampling_res, realtime_downsampling_res, liveimage_downsampling_res, pseudotime_downsampling_res))
downsampling_res$data_type <- rep(c('velocity', 'realtime', 'liveimage', 'pseudotime'), each = nrow(realtime_downsampling_res))

downsampling_res$method <- factor(downsampling_res$method, levels = c('Granger', 'CCM', 'RDI', 'uRDI', 'cRDI', 'ucRDI'))
downsampling_res$data_type <- factor(downsampling_res$data_type, levels = c('pseudotime', 'liveimage', 'velocity', 'realtime'))
downsampling_res$replicates <- downsampling_res$Number_of_samples / 100
pdf(paste0(main_fig_dir, 'downsample_subset_run_sim_delay_1_3_raw.pdf'), width =  4, height = 1)
ggplot(data = downsampling_res, aes(x = replicates, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of replicates') + ylab('AUC') + ylim(0.4, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T)+ geom_hline(yintercept = 0.5, linetype = 'longdash', size = 0.2)
dev.off()

pdf(paste0(main_fig_dir, 'downsample_subset_run_sim_delay_1_3_helper.pdf'))
ggplot(data = downsampling_res, aes(x = Number_of_samples, y = value)) + geom_point(aes(color = data_type), size = 0.2, stroke = 0) + 
  geom_smooth(aes(group = data_type, color = data_type), alpha = 0.2, size = 0.25) + facet_wrap(~method, nrow = 1) + xlab('Number of samples') + ylab('AUC') + ylim(0, 1) + 
  theme(axis.text.x = element_text(angle = 30)) + viridis::scale_color_viridis(discrete = T)  
dev.off()

pdf(paste0(main_fig_dir, 'delay_subset_1_3_sim_remove_mature_raw.pdf'), width =  1.5, height = 1)
ggplot(subset(downsampling_res, Number_of_samples == 2000), aes(method, value)) + geom_boxplot(aes(color = data_type), notchwidth = 0.1, outlier.size = 0.5,
                                                                                               outlier.stroke = 0.1, size = I(0.1)) + ylim(0, 1) + xlab('') + ylab('AUC') + 
  theme(axis.text.x = element_text(angle = 30)) + 
  xacHelper::nm_theme() + viridis::scale_color_viridis(discrete = T) 
dev.off()
