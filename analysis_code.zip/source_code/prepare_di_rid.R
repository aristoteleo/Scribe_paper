#generate CMI, di, rdi and crdi

function(x, y, n=10) {
  if(is.numeric(x))
    x <- as.matrix(x)
  if(is.numeric(y))
    y <- as.matrix(y)
  
  if(ncol(x) != ncol(y))
    stop('The number of time samples has to be the same for X and Y')
  tau <- n
  tot_len <- nrow(x) - tau
  x_past <- x[(tau):(tau - 1 + tot_len), ]
  y_past <- y[(tau):(tau - 1 + tot_len), ]
  for(i in 2:n) {
    x_past = cbind(x[(tau - i + 1):(tau - i + tot_len), ], x_past)
    y_past = cbind(y[(tau - i + 1):(tau - i + tot_len), ], y_past)
  }
  
  return(cmi(x_past, as.matrix(y[(tau + 1):(tau+tot_len), ]), y_past))
}

# cmi: I(X; Y | Z) = I(X; Y, Z) - I(X; Z)
knnmi()

x <- rnorm(100)
y <- rnorm(100)
z <- rnorm(100)

computeTE(X, Y, embedding = 3, k = 3)
di_single_run(x, y)
knnmi(x, data.frame(y = y, z = z), 5)

load('./csv_data/XYZ.txt')
dat<-discretize(t(XYZ))

ZXY_emp_time <- Sys.time()
emp_ZXY_res <- condinformation(dat[,3],dat[,1],dat[,2],method="emp") # "emp", "mm", "shrink", "sg" 
ZXY_mm_time <- Sys.time()
mm_ZXY_res <- condinformation(dat[,3],dat[,1],dat[,2],method="mm") # "emp", "mm", "shrink", "sg" 
ZXY_shrink_time <- Sys.time()
shrink_ZXY_res <- condinformation(dat[,3],dat[,1],dat[,2],method="shrink") # "emp", "mm", "shrink", "sg" 
ZXY_sg_time <- Sys.time()
sg_ZXY_res <- condinformation(dat[,3],dat[,1],dat[,2],method="sg") # "emp", "mm", "shrink", "sg" 
ZXY_end_time <- Sys.time()

emp_ZXY_res
mm_ZXY_res
shrink_ZXY_res
sg_ZXY_res

XYZ_emp_time <- Sys.time()
emp_XYZ_res <- condinformation(dat[,1],dat[,2],dat[,3],method="emp") # "emp", "mm", "shrink", "sg" 
XYZ_mm_time <- Sys.time()
mm_XYZ_res <- condinformation(dat[,1],dat[,2],dat[,3],method="mm") # "emp", "mm", "shrink", "sg" 
XYZ_shrink_time <- Sys.time()
shrink_XYZ_res <- condinformation(dat[,1],dat[,2],dat[,3],method="shrink") # "emp", "mm", "shrink", "sg" 
XYZ_sg_time <- Sys.time()
sg_XYZ_res <- condinformation(dat[,1],dat[,2],dat[,3],method="sg") # "emp", "mm", "shrink", "sg" 
XYZ_end_time <- Sys.time()

emp_XYZ_res
mm_XYZ_res
shrink_XYZ_res
sg_XYZ_res

YZX_emp_time <- Sys.time()
emp_YZX_res <- condinformation(dat[,2],dat[,3],dat[,1],method="emp") # "emp", "mm", "shrink", "sg" 
YZX_mm_time <- Sys.time()
mm_YZX_res <- condinformation(dat[,2],dat[,3],dat[,1],method="mm") # "emp", "mm", "shrink", "sg" 
YZX_shrink_time <- Sys.time()
shrink_YZX_res <- condinformation(dat[,2],dat[,3],dat[,1],method="shrink") # "emp", "mm", "shrink", "sg" 
YZX_sg_time <- Sys.time()
sg_YZX_res <- condinformation(dat[,2],dat[,3],dat[,1],method="sg") # "emp", "mm", "shrink", "sg" 
YZX_end_time <- Sys.time()

emp_YZX_res
mm_YZX_res
shrink_YZX_res
sg_YZX_res

CMI(X, Y, Z): 0.47189332607
CMI(X,Z,Y): 0.00569163896183
CMI(Y,Z,X): 0.411085051308

# show the results
estimator_running_time <- data.frame(Type = factor(c('ML', "MM", 'Shrink', 'SG', 'KNN (our implementation)'), levels =
                                                     c('ML', "MM", 'Shrink', 'SG', 'KNN (our implementation)')), 
                                     Time = c(XYZ_mm_time - XYZ_emp_time, XYZ_shrink_time - XYZ_mm_time, XYZ_sg_time - XYZ_shrink_time, XYZ_end_time - XYZ_sg_time, 35.0486419201 / 3))

qplot(Type, Time, data = estimator_running_time, color = Time)

