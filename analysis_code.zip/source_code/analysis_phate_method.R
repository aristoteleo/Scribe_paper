# analyze with phate: 
library(R.matlab)
library(phater)
load('./RData/zebrafish_RNA_velocity_combined_euth_hypo.RData')
cell_type <- pData(comb2_cds_cell)$Cell_type 
condition <- pData(comb2_cds_cell)$condition
library(velocyto.R)

comb2_cds_cell <- setOrderingFilter(comb2_cds_cell, rownames(subset(fData(comb2_cds_cell), gene_short_name %in% row.names(rvel.cd$current))))
zebrafish_data <- t(as.matrix(exprs(comb2_cds_cell)[fData(comb2_cds_cell)$use_for_ordering, ]))

zebrafish_phate <- phate(log(zebrafish_data + 1), 50, 15, 20, pca.method = 'svd', mds.method = 'mmds')
colors <- pagoda2:::fac2col(unique(cell_type))
names(colors) <- unique(cell_type)

df <- data.frame(x = zebrafish_phate$embedding[,1], y = zebrafish_phate$embedding[,2], color = cell_type)
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2", alpha = I(0.5)) + scale_colour_manual(values = colors, name = 'cell_type')
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2") +
  scale_colour_manual(values = colors, name = 'cell_type') + facet_wrap(~color)

emb_phate_x <- zebrafish_phate$embedding
row.names(emb_phate_x) <- colnames(comb2_cds_cell)

vel <- rvel.cd; arrow.scale=6; cell.alpha=0.4; cell.cex=1; fig.height=4; fig.width=4.5;
show.velocity.on.embedding.cor(emb_phate_x,vel,n=100,scale='sqrt',cell.colors=ac(cell.colors,alpha=cell.alpha),cex=cell.cex,arrow.scale=arrow.scale,arrow.lwd=1)

############################################################################################################################################
# Olsson data: (the result doesn't look great with PHATE)
############################################################################################################################################
load("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/tmp/URMM_all_fig1b")
load("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/URMM_all_abs_ori")

olsson_data <- t(as.matrix(exprs(URMM_all_fig1b))[fData(URMM_all_fig1b)$use_for_ordering, ]) # pData(URMM_all_fig1b)$paper_cluster

cell_type <- pData(URMM_all_fig1b)$paper_cluster

# olsson_data <- olsson_data[-c(grep('knockout', cell_type)), ]
olsson_phate <- phate(log(olsson_data + 1), t = 50, k = 15, alpha = 10, ndim = 4, pca.method = 'svd', mds.method = 'mmds', npca = 30) # , pca.method = 'svd',  mds.dist.method = 'cosine'

# cell_type <- cell_type[-c(grep('knockout', cell_type))]
colors <- pagoda2:::fac2col(unique(cell_type))
names(colors) <- unique(cell_type)

df <- data.frame(x = olsson_phate$embedding[,4], y = olsson_phate$embedding[,3], color = cell_type)
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2", alpha = I(0.5)) + scale_colour_manual(values = colors, name = 'cell_type')
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2") +
  scale_colour_manual(values = colors, name = 'cell_type') + facet_wrap(~color)

emb_phate_x <- olsson_phate$embedding
row.names(emb_phate_x) <- colnames(comb2_cds_cell)

vel <- rvel.cd; arrow.scale=6; cell.alpha=0.4; cell.cex=1; fig.height=4; fig.width=4.5;
show.velocity.on.embedding.cor(emb_phate_x,vel,n=100,scale='sqrt',cell.colors=ac(cell.colors,alpha=cell.alpha),cex=cell.cex,arrow.scale=arrow.scale,arrow.lwd=1)


############################################################################################################################################
# data(tree.data)
# tree.branches <- tree.data$branches
# tree.data <- tree.data[,1:60]
# 
# # runs phate
# tree.phate <- phate(tree.data, 20, 15, 20, pca.method = 'none', mds.method = 'mmds')
# #> [1] "No PCA performed"
# #> [1] "MDS distance method: euclidean"
# #> [1] "No PCA performed"
# #> [1] "MDS method: mmds"
# # plot embedding
# palette(rainbow(10))
# plot(tree.phate$embedding[,1], tree.phate$embedding[,2], col = tree.branches, xlab = "phate1", ylab = "phate2")
# 
# DDRTree_res <- DDRTree(t(tree.data[, 1:60]), dimensions = 3, verbose = T)
# qplot(DDRTree_res$Z[2, ], DDRTree_res$Z[3, ], color = as.factor(tree.branches))

Circle <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code/data/Circle.mat')

circle_phate <- phate(Circle$X, t = 50, k = 10, alpha = 10, pca.method = 'none', mds.method = 'mmds') # , pca.method = 'svd',  mds.dist.method = 'cosine'
plot(circle_phate$embedding[,1], circle_phate$embedding[,2], xlab = "phate1", ylab = "phate2")




