library(monocle)
library(xacHelper)
library(stringr)
library(R.matlab)
library(plyr)
library(monocle)
library(R.matlab)
library(rgl)
library(mcclust)

rm(list = ls())

# run all RT-pcr: 
# datasets:  Psaila 2016, Guo, Moignard dataset, Sui dataset, Fabian dataset

####################################################################################################################################################################################
# Helper functions 
####################################################################################################################################################################################
source('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/scripts/function.R')

plot_boxplot_rtPCR <- function(cds, gene_list, nrow=3, ncol=3) {  
  cds_exprs <- exprs(cds)[gene_list, ]
  cds_exprs <- reshape2::melt(as.matrix(cds_exprs))
  colnames(cds_exprs) <- c("f_id", "Cell", "expression")
  cds_pData <- pData(cds)
  cds_fData <- fData(cds)
  
  cds_exprs <- merge(cds_exprs, cds_fData, by.x="f_id", by.y="row.names")
  cds_exprs <- merge(cds_exprs, cds_pData, by.x="Cell", by.y="row.names")
  
  q <- ggplot(aes_string(x="State", y="expression"), data=cds_exprs) 
  q <- q + geom_boxplot(aes_string(color="State"), size=I(0.5))
  
  #q <- q + stat_summary(aes_string(color="State"), fun.data = "mean_cl_boot", size=0.35)
  q <- q + stat_summary(aes_string(x="State", y="expression", color="State", group="State"), fun.data = "mean_cl_boot", size=0.35, geom="line")
  
  q <- q + facet_wrap(~f_id, nrow=nrow, ncol=nrow, scales="free_y")
  
  # # Need this to gaurd against plotting failures caused by non-expressed genes
  # if (min_expr < 1)
  # {
  #   q <- q + expand_limits(y=c(min_expr, 1))
  # }
  
  q <- q + ylab("Expression") + xlab("State")
  q <- q + monocle:::monocle_theme_opts()
  q
}

run_new_dpt <- function(cds, norm_method = 'none', root = NULL, color_by = 'Cell_type'){
  message('root should be the id to the cell not the cell name ....')
  
  norm_data <- monocle:::normalize_expr_data(cds, norm_method = norm_method)
  norm_data <- t(norm_data)
  
  duplicated_points <- which(duplicated(norm_data))
  norm_data[duplicated_points, 1] <- norm_data[duplicated_points, 1] + rnorm(n = length(duplicated_points), mean = 0, sd = 1e-12) # avoid noise points
  dm <- DiffusionMap(norm_data)
  dpt <- DPT(dm)
  
  ts <- dm@transitions
  M <- destiny:::accumulated_transitions(dm)
  
  if(is.null(root)){
    
    # plot(dpt, root = 2, paths_to = c(1,3), col_by = 'branch', pch = 20)
    # plot(dpt, col_by = 'branch', divide = 3, dcs = c(-1,3,-2), pch = 20)
  }
  else{
    dm <- DiffusionMap(norm_data)
    dpt <- DPT(dm, tips = root)
    # plot(dpt, root = root, paths_to = c(1,3), col_by = 'branch', pch = 20)
    # plot(dpt, col_by = 'branch', divide = 3, dcs = c(-1,3,-2), pch = 20)
  }
  
  if('Hours' %in% colnames(pData(cds)))
    pData(cds)$Hours <- pData(cds)[, color_by]
  p1 <- qplot(DM$DC1, DM$DC2, colour = pData(cds)$Hours)
  
  branch <- dpt@branch
  row.names(branch) <- row.names(norm_data[!duplicated(norm_data), ])
  
  if(is.null(root))
    root <- which.min(pData(cds)$Pseudotime)
  pt <- dpt[root, ]
  dp_res <- list(dm = dm, pt = pt, ts = ts, M = M, ev = dm@eigenvectors, p1 = p1, branch = branch)
  
  return(dp_res)
}

run_dpt <- function(data, branching = T, norm_method = 'log', root = NULL, verbose = F){
  if(verbose)
    message('root should be the id to the cell not the cell name ....')
  data <- t(as.matrix(data))
  data <- data[!duplicated(data), ]
  dm <- DiffusionMap(as.matrix(data))
  
  return(dm@eigenvectors)
}

return_myself <- function(data, branching = T, norm_method = 'log', root = NULL, verbose = F){
  # if(verbose)
  #   message('root should be the id to the cell not the cell name ....')
  # data <- t(data)
  # data <- data[!duplicated(data), ]
  # dm <- DiffusionMap(as.matrix(data))
  
  return(t(data))
}

####################################################################################################################################################################################
# Psaila dataset: 
####################################################################################################################################################################################

MOESM2_mega_ery <- read.table('./csv_data/MOESM2_mega_ery.txt', header = T, row.names = 1, sep = '\t')
PD <- data.frame(str_split_fixed(colnames(MOESM2_mega_ery), '\\.', 2))
dimnames(PD) <- list(colnames(MOESM2_mega_ery), c('Cell_type', 'Batch'))
FD <- data.frame(gene_short_names = row.names(MOESM2_mega_ery), row.names = row.names(MOESM2_mega_ery))

pd <- new("AnnotatedDataFrame",data=PD)
fd <- new("AnnotatedDataFrame",data=FD)

MOESM2_mega_ery_cds <- newCellDataSet(40 - as.matrix(abs(MOESM2_mega_ery)), phenoData = pd, featureData = fd)
MOESM2_mega_ery_cds <- setOrderingFilter(MOESM2_mega_ery_cds, ordering_genes = row.names(MOESM2_mega_ery_cds))
MOESM2_mega_ery_cds <- reduceDimension(MOESM2_mega_ery_cds, norm_method = 'none', verbose = T, auto_param_selection = T, maxIter = 100,  pseudo_expr=0, scaling = T)
MOESM2_mega_ery_cds <- orderCells(MOESM2_mega_ery_cds)

plot_cell_trajectory(MOESM2_mega_ery_cds, color_by = 'Cell_type')

# verify the result with DPT 
dpt_res <- run_new_dpt(MOESM2_mega_ery_cds)
qplot(dpt_res$dm$DC1, dpt_res$dm$DC2, color = pData(MOESM2_mega_ery_cds)$Cell_type)

calClusteringMetrics(pData(MOESM2_mega_ery_cds)$State, dpt_res$branch[, 1])

#State 1: Ery; State 3: Meg

# known megakaryocytic genes (e.g. Cd9, Lox, Vwf, Nfib,Cd61, Tgfβ1) and a cluster with several red edges comprising 
# known erythroid genes (e.g. Cd36, Klf1, Lef1, Cnrip1, Tmod1, Ank1, Dhrs3) 

plot_boxplot_rtPCR(MOESM2_mega_ery_cds, gene_list = c('CD9', "LOX", "VWF", 'NFIB', "TGFB1"))
plot_boxplot_rtPCR(MOESM2_mega_ery_cds, gene_list = c('CD36', "KLF1", "LEF1", 'CNRIP1', "TMOD1", "ANK1", "DHRS3"))

MOESM2_mega_ery_cds_ery <- MOESM2_mega_ery_cds[, pData(MOESM2_mega_ery_cds)$State %in% c(1, 2)]
MOESM2_mega_ery_cds_meg <- MOESM2_mega_ery_cds[, pData(MOESM2_mega_ery_cds)$State %in% c(2, 3)]

MOESM2_mega_ery_cds_ery <- setOrderingFilter(MOESM2_mega_ery_cds_ery, ordering_genes = row.names(MOESM2_mega_ery_cds_ery))
MOESM2_mega_ery_cds_ery <- reduceDimension(MOESM2_mega_ery_cds_ery, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=0, scaling = T)
MOESM2_mega_ery_cds_ery <- orderCells(MOESM2_mega_ery_cds_ery)
plot_cell_trajectory(MOESM2_mega_ery_cds_ery)

MOESM2_mega_ery_cds_meg <- setOrderingFilter(MOESM2_mega_ery_cds_meg, ordering_genes = row.names(MOESM2_mega_ery_cds_ery))
MOESM2_mega_ery_cds_meg <- reduceDimension(MOESM2_mega_ery_cds_meg, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=0, scaling = T)
MOESM2_mega_ery_cds_meg <- orderCells(MOESM2_mega_ery_cds_meg)
plot_cell_trajectory(MOESM2_mega_ery_cds_meg)

####################################################################################################################################################################################
# Moignard dataset: 
####################################################################################################################################################################################

genenames_vicki18_data <- readMat('/Users/xqiu/Downloads/inferenceSnapshot 2/Real/genenames_vicki18.mat')
BMApprxCensored_sigma0.9 <- readMat('/Users/xqiu/Downloads/inferenceSnapshot 2/Real/BMApprxCensored_sigma0.9.mat')

#######################################################################################################################################################################################
# confirm the branches 
#######################################################################################################################################################################################
# qplot(BMApprxCensored_sigma0.9$psi[, 2], BMApprxCensored_sigma0.9$psi[, 3], color = factor(BMApprxCensored_sigma0.9$label))
# 
# jet.colors <- colorRampPalette(c("#4F64AD", "#F6F7FB", "#F2991F"))
# bk <- seq(0,3.1, by=0.1)
# hmcols <- jet.colors(length(bk) - 1)
# colorzjet <- jet.colors(100)
# 
# jet.colors <-
#   colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan",
#                      "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000"))
# colorzjet <- jet.colors(100)
#
# plot3d(BMApprxCensored_sigma0.9$psi[, 1], BMApprxCensored_sigma0.9$psi[, 2], BMApprxCensored_sigma0.9$psi[, 3])
# 
# # capture snapshot
# snapshot3d(filename = '3dplot.png', fmt = 'png')

x <- BMApprxCensored_sigma0.9$psi[, 1]
y <- BMApprxCensored_sigma0.9$psi[, 2]
z <- BMApprxCensored_sigma0.9$psi[, 3]

plot3d(x, y, z, col=rainbow(5)[BMApprxCensored_sigma0.9$label], size=3)
legend3d("topright", paste('Cell type', c("1", "2", "3", "4", "5")), pch = 16, cex=1,  col = rainbow(5), inset=c(0.02,0.2))

# 1: CLP; 2: GMP; 3: HSC; 4: LMPP; 5: preMegE
#######################################################################################################################################################################################
# expr_mat <- read.table('/Users/xqiu/Downloads/dpt/examples/gene_exprs_original_data', row.names = 1, header = 1)
expr_mat_norm <- read.table('/Users/xqiu/Downloads/inferenceSnapshot\ 2/Real/vicki_normalized.txt', sep = ',')

expr_mat <- BMApprxCensored_sigma0.9$psi[, 1:3]
colnames(expr_mat) <- unlist(genenames_vicki18_data$genenames18[1:3])
row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                  Time = c(#rep("0", nrow(ctr)),
                                                    rep('Time', nrow(expr_mat))#,
                                                  ),
                                                  label = BMApprxCensored_sigma0.9$label,
                                                  row.names = row.names(expr_mat)))

# new_cds <- newCellDataSet(as(as.matrix(t(log2(expr_mat + 1))), "sparseMatrix"),
#                           phenoData = pd, 
#                           featureData = fd, 
#                           expressionFamily=gaussianff(), 
#                           lowerDetectionLimit=1)

new_cds <- newCellDataSet(as(as.matrix(t(expr_mat)) * 500, "sparseMatrix"), #make the space bigger
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)
new_cds <- estimateSizeFactors(new_cds)
pData(new_cds)$Size_Factor <- 1
# new_cds <- estimateDispersions(new_cds)

pData(new_cds)$label <- revalue(as.character(pData(new_cds)$label), c("1" = 'CLP', '2' = "GMP", "3" = 'HSC', '4' = 'LMPP', '5' = 'preMegE'))
new_cds <- setOrderingFilter(new_cds, row.names(new_cds))
new_cds <- reduceDimension(new_cds, max_components = 3, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F, 
                           auto_param_selection = F, initial_method = run_dpt, reduction_method = 'SimplePPT', maxIter = 20)
new_cds <- orderCells(new_cds)
plot_cell_trajectory(new_cds, color_by = 'label') + facet_wrap(~label)
plot_cell_trajectory(new_cds, color_by = 'State') + facet_wrap(~State)
new_cds <- orderCells(new_cds, root_state = 4)
plot_cell_trajectory(new_cds, color_by = 'Pseudotime')

plot_complex_cell_trajectory(new_cds, color_by = 'label')
plot_complex_cell_trajectory(new_cds, color_by = 'State') + facet_wrap(~State)

#decide the branches
table(pData(new_cds)[, c('label', 'State')])
GMP_states <- c(4, 2, 1)
CLP_states <- c(4, 2, 5)
preMegE_states <- c(4, 3)

GMP_branch_cds <- new_cds[, pData(new_cds)$State %in% GMP_states]
CLP_branch_cds <- new_cds[, pData(new_cds)$State %in% CLP_states]
preMegE_branch_cds <- new_cds[, pData(new_cds)$State %in% preMegE_states]

colnames(expr_mat_norm) <- unlist(genenames_vicki18_data$genenames18)

GMP_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% GMP_states]
CLP_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% CLP_states]
preMegE_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% preMegE_states]

write.table(file = './csv_data/GMP_branch.txt', as.matrix(GMP_branch[, order(pData(GMP_branch_cds)$Pseudotime)]), row.names = T, quote = F)
write.table(file = './csv_data/CLP_branch.txt', as.matrix(CLP_branch[, order(pData(CLP_branch_cds)$Pseudotime)]), row.names = T, quote = F)
write.table(file = './csv_data/preMegE_branch.txt', as.matrix(preMegE_branch[, order(pData(preMegE_branch_cds)$Pseudotime)]), row.names = T, quote = F)

#######################################################################################################################################################################################
# Pseudotime plot
#######################################################################################################################################################################################
# expr_mat <- read.table('/Users/xqiu/Downloads/dpt/examples/gene_exprs_original_data', row.names = 1, header = 1)
# Moignard_blood <- read.table('./csv_data//Moignard_blood', sep = '\t', header = 1, row.names = 1)
# fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(Moignard_blood), row.names = colnames(Moignard_blood)))
# pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(Moignard_blood), 
#                                                   Time = c(#rep("0", nrow(ctr)),
#                                                     rep('Time', nrow(Moignard_blood))#,
#                                                   ),
#                                                   # label = BMApprxCensored_sigma0.9$label,
#                                                   row.names = row.names(Moignard_blood)))
# 
# new_cds <- newCellDataSet(as(as.matrix(t(log2(Moignard_blood + 1))), "sparseMatrix"),
#                           phenoData = pd, 
#                           featureData = fd, 
#                           expressionFamily=gaussianff(), 
#                           lowerDetectionLimit=1)
# 
# new_cds <- setOrderingFilter(new_cds, row.names(new_cds))
# new_cds <- reduceDimension(new_cds, max_components = 3, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F, auto_param_selection = F)
# new_cds <- orderCells(new_cds)
# plot_cell_trajectory(new_cds)

exprs_new_cds <- newCellDataSet(as(as.matrix(t(expr_mat_norm)), "sparseMatrix"), #he cofactor parameter is used for arcsinh
                                phenoData = pd, 
                                featureData = new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat_norm), row.names = colnames(expr_mat_norm))), 
                                expressionFamily=gaussianff(), 
                                lowerDetectionLimit=1)
exprs_new_cds <- estimateSizeFactors(exprs_new_cds)
pData(exprs_new_cds)$Size_Factor <- 1

six_genes <- c('Nfe2', 'Gata2', 'SCL', 'Gfi1', 'Gfi1b')

BMApprxCensored_sigma0.9$labels

pData(exprs_new_cds) <- pData(new_cds)
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(GMP_branch_cds)])
order(pData(CLP_branch_cds)$Pseudotime)

plot_genes_in_pseudotime(exprs_new_cds[six_genes[5], colnames(GMP_branch_cds)]) + ggtitle('GMP branch') #remove outlier cells at the end 
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(CLP_branch_cds)]) + ggtitle('CLP branch') #remove outlier cells at the end 
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(preMegE_branch_cds)]) + ggtitle('preMegE branch') #remove outlier cells at the end 

qplot(pData(exprs_new_cds[six_genes[5], colnames(GMP_branch_cds)])$Pseudotime, as.numeric(exprs(exprs_new_cds[six_genes[5], colnames(GMP_branch_cds)])))

#######################################################################################################################################################################################
# for some reason: the trend again is the opposite to the original paper 
#######################################################################################################################################################################################

#######################################################################################################################################################################################
# Guo dataset
#######################################################################################################################################################################################
load('/Users/xqiu/Downloads/destiny 5/data/guo_norm.rda')

PD <- pData(guo_norm)
FD <- data.frame(gene_short_names = row.names(guo_norm), row.names = row.names(guo_norm))

pd <- new("AnnotatedDataFrame",data=PD)
fd <- new("AnnotatedDataFrame",data=FD)

guo_norm_cds <- newCellDataSet(exprs(guo_norm), phenoData = pd, featureData = fd)
guo_norm_cds <- setOrderingFilter(guo_norm_cds, ordering_genes = row.names(guo_norm_cds))
guo_norm_cds <- reduceDimension(guo_norm_cds, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  
                                 initial_method = run_dpt, reduction_method = 'SimplePPT', max_components = 2, 
                                 pseudo_expr=0, scaling = F)
guo_norm_cds <- orderCells(guo_norm_cds)
plot_cell_trajectory(guo_norm_cds, color_by = 'num_cells')
plot_cell_trajectory(guo_norm_cds, color_by = 'Pseudotime')

# just use DPT result 
# six_genes <- c('Nfe2', 'Gata2', 'SCL', 'Gfi1', 'Gfi1b')
dm <- DiffusionMap(guo_norm)
dpt <- DPT(dm)

qplot(dpt@dm$DC1, dpt@dm$DC2, color = pData(guo_norm)$num_cells)
qplot(dpt@dm$DC1, dpt@dm$DC2, color = dpt@branch[, 1])

root_cell <- which.min(pData(guo_norm_cds)$Pseudotime)
cor(dpt[root_cell, ], pData(guo_norm_cds)$Pseudotime)
calClusteringMetrics(dpt@branch[, 1], pData(guo_norm_cds)$State)

#######################################################################################################################################################################################
# 3000 cells Moignard dataset
#######################################################################################################################################################################################
Moignard_blood_2015_mat <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/dpt/examples/matlab.mat')
dm <- DiffusionMap((Moignard_blood_2015_mat$data))

qplot(dm@eigenvectors[, 3], dm@eigenvectors[, 2])
qplot(Moignard_blood_2015_mat$phi[, 3], Moignard_blood_2015_mat$phi[, 2])

expr_mat <- read.table('./csv_data/Moignard_blood_2015_3k_cells', row.names = 1, header = 1)

#######################################################################################################################################################################################
# 640 cells 
#######################################################################################################################################################################################
Moignard_blood_2015 <- read.table('./csv_data//Moignard_blood', sep = '\t', header = 1, row.names = 1)
fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(Moignard_blood_2015), row.names = colnames(Moignard_blood_2015)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(Moignard_blood_2015), 
                                                  Time = c(#rep("0", nrow(ctr)),
                                                    rep('Time', nrow(Moignard_blood_2015))#,
                                                  ),
                                                  # label = BMApprxCensored_sigma0.9$label,
                                                  row.names = row.names(Moignard_blood_2015)))

Moignard_blood_2015_cds <- newCellDataSet(as(as.matrix(t(Moignard_blood_2015)), "sparseMatrix"),
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)

Moignard_blood_2015_cds <- reduceDimension(Moignard_blood_2015_cds, norm_method = 'none', verbose = T, max_components = 3, 
                                           initial_method = run_dpt, 
                                           auto_param_selection = T, maxIter = 100,  pseudo_expr=0, scaling = F)
Moignard_blood_2015_cds <- orderCells(Moignard_blood_2015_cds)
plot_cell_trajectory(Moignard_blood_2015_cds, color_by = 'Pseudotime')

#######################################################################################################################################################################################
# 2000 cells Sui dataset (multiple) 
#######################################################################################################################################################################################
expr_mat <- read.table('./csv_data/PNAS_sui/log_exp_all_data.txt', row.names = 1, header = 1, sep = '\t')
PD <- t(expr_mat[1:3, ])
gene_list <- row.names(expr_mat)[-(1:3)]
expr_mat <- expr_mat[-(1:3), ]

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = row.names(expr_mat), row.names = row.names(expr_mat)))
pd <- new("AnnotatedDataFrame", data = as.data.frame(PD[sort(row.names(PD)), ]))

expr_mat <- as.matrix(expr_mat)
expr_mat <- apply(expr_mat, 2, function(x) as.numeric(as.character(x)))
row.names(expr_mat) <- gene_list
Kalliopi_cds <- newCellDataSet(as.matrix(expr_mat[, sort(row.names(PD))]),
                                          phenoData = pd, 
                                          featureData = fd, 
                                          expressionFamily=gaussianff(), 
                                          lowerDetectionLimit=1)

plot_pc_variance_explained(Kalliopi_cds, norm_method = 'none') # five dimensions 

# Kalliopi_cds <- reduceDimension(Kalliopi_cds, norm_method = 'none', verbose = T, max_components = 5, auto_param_selection = T, maxIter = 20,  pseudo_expr=0, scaling = F) #, initial_method = run_dpt, reduction_method = 'SimplePPT'
Kalliopi_cds <- reduceDimension(Kalliopi_cds, norm_method = 'none', verbose = T, max_components = 5, auto_param_selection = T, maxIter = 20,  pseudo_expr=0, scaling = F, initial_method = run_dpt, reduction_method = 'SimplePPT') #, initial_method = run_dpt, reduction_method = 'SimplePPT'

Kalliopi_cds <- orderCells(Kalliopi_cds)
plot_cell_trajectory(Kalliopi_cds)

plot_cell_trajectory(Kalliopi_cds, color_by = 'CollectionTime') #Consensus Cluster Phenotype.FACS Size_Factor Pseudotime State
plot_cell_trajectory(Kalliopi_cds, color_by = 'Phenotype.FACS') #Consensus Cluster Phenotype.FACS Size_Factor Pseudotime State

pData(Kalliopi_cds)$Clusters <- pData(Kalliopi_cds)[, 'Consensus Cluster']
plot_cell_trajectory(Kalliopi_cds, color_by = 'Clusters') #Consensus Cluster Phenotype.FACS Size_Factor Pseudotime State

plot_cell_trajectory(Kalliopi_cds, color_by = 'CollectionTime') + facet_wrap(~CollectionTime)

Kalliopi_dm <- DiffusionMap(t(exprs(Kalliopi_cds)))
Kalliopi_dm_dpt <- DPT(Kalliopi_dm)
qplot(Kalliopi_dm$DC1, Kalliopi_dm$DC2, color = pData(Kalliopi_cds)$CollectionTime)
qplot(Kalliopi_dm$DC1, Kalliopi_dm$DC2, color = Kalliopi_dm_dpt@branch[, 1])

which.min(pData(Kalliopi_cds)$Pseudotime)
cor(Kalliopi_dm_dpt$DPT908, pData(Kalliopi_cds)$Pseudotime)
calClusteringMetrics(Kalliopi_dm_dpt@branch[, 1], pData(Kalliopi_cds)$State)

#######################################################################################################################################################################################
# Other datasets (MASS cytof dataset)
#######################################################################################################################################################################################
ETheta <- 0.02102401 
VTheta <- 0
EGamma <- 47.56466
VGamma <- 76.80532


#######################################################################################################################################################################################
# Other datasets (MASS cytof dataset)
#######################################################################################################################################################################################

#######################################################################################################################################################################################
# Save data
#######################################################################################################################################################################################
save.image('./RData/analysis_RT_PCR.RData')
