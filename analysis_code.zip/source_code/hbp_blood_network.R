#create network for the dataset based on the pseudotime, the BEAM test, the motif scanning and the ccm algorithm; 
rm(list = ls())

################################################################################################################################################################################################
#function to generate new cds: 
make_cds <- function (exprs_matrix, pd, fd, expressionFamily) {
  cds <- newCellDataSet(exprs_matrix, 
                        phenoData = new("AnnotatedDataFrame", data = pd), 
                        featureData = new("AnnotatedDataFrame", data = fd), 
                        expressionFamily = expressionFamily, 
                        lowerDetectionLimit = 0.1)
  
  if(identical(expressionFamily, tobit())) {
    cds <- estimateSizeFactors(cds)
    cds <- estimateDispersions(cds)
  }
  return(cds)
}

#create the network plot: 
# Ccr2, Car2
plot_cell_trajectory(URMM_all_abs, markers = c('Ccr2', 'Car2'))
plot_genes_branched_pseudotime(URMM_all_abs[c('Ccr2', 'Car2'), ])

#function to run the ccm and save the result
cal_cross_map <- function(ordered_exprs_mat, lib_colum, target_column) { 
  lib_xmap_target <- ccm(ordered_exprs_mat, E = 3, random_libs = TRUE, lib_column = lib_colum, #ENSG00000122180.4
                         target_column = target_column, lib_sizes = seq(10, 75, by = 5), num_samples = 300)
  target_xmap_lib <- ccm(ordered_exprs_mat, E = 3, random_libs = TRUE, lib_column = target_column, #ENSG00000122180.4
                         target_column = lib_colum, lib_sizes = seq(10, 75, by = 5), num_samples = 300)
  
  lib_xmap_target_means <- ccm_means(lib_xmap_target)
  target_xmap_lib_means <- ccm_means(target_xmap_lib)
  
  return(list(lib_xmap_target = lib_xmap_target, target_xmap_lib = target_xmap_lib, 
              lib_xmap_target_means = lib_xmap_target_means, target_xmap_lib_means = target_xmap_lib_means,
              mean_lib_xmap_target_means = mean(lib_xmap_target_means$rho[is.finite(lib_xmap_target_means$rho)], na.rm = T), 
              mean_target_xmap_lib_means = mean(target_xmap_lib_means$rho[is.finite(target_xmap_lib_means$rho)], na.rm = T)))
}

#function to plot the result from ccm
plot_cross_map <- function(lib_xmap_target_means, target_xmap_lib_means, lib_name, target_name){
  legend_names <- c(paste(lib_name, 'xmap', target_name), paste(target_name, 'xmap', lib_name))
  
  xmap_all <- rbind(lib_xmap_target_means, target_xmap_lib_means)
  xmap_all$type <- c(rep('a_xmap_t_means', nrow(lib_xmap_target_means)), rep('t_xmap_a_means', nrow(target_xmap_lib_means)))
  y_max <- max(xmap_all$rho, na.rm = T) + 0.1
  
  lib_rng <- range(xmap_all$lib_size)
  p1 <- ggplot(aes(lib_size, pmax(0, rho)), data = xmap_all) + geom_line(aes(color = type)) + xlim(lib_rng) + 
    xlab("Library Size") + ylab("Cross Map Skill (rho)") + scale_color_discrete(labels=legend_names) + 
    scale_x_discrete(breaks = unique(xmap_all$lib_size)) + monocle_theme_opts()
  
  return(p1)
}

#parallel the CCM algorithm: 
parallelCCM <- function(ordered_exprs_mat, cores = detectCores() / 2) {
  ordered_exprs_mat <- ordered_exprs_mat
  combn_mat <- combn(1:ncol(ordered_exprs_mat), 2)
  
  combn_mat_split <- split(t(combn_mat), 1:ncol(combn_mat))
  CCM_res <- mclapply(combn_mat_split, function(x, ordered_exprs_mat){ 
    col_names <- colnames(ordered_exprs_mat)[x]
    cross_map_res <- cal_cross_map(ordered_exprs_mat[, col_names], col_names[1], col_names[2])
    cross_map_res[c('mean_lib_xmap_target_means', 'mean_target_xmap_lib_means')]
  }, ordered_exprs_mat = ordered_exprs_mat, mc.cores = cores)
  
  return(list(CCM_res = CCM_res, combn_mat_split = combn_mat_split, gene_names = colnames(ordered_exprs_mat)))
}

#function to prepare the result for CCM: 
prepare_ccm_res <- function(parallel_res, gene_names = NULL){
  if(is.null(gene_names))
    gene_names <- parallel_res$gene_names
  parallel_res_list <- lapply(1:length(parallel_res$CCM_res), function(x, gene_names) {
    
    mean_lib_xmap_target_means = mean(parallel_res$CCM_res[[x]]$lib_xmap_target_means$rho[is.finite(parallel_res$CCM_res[[x]]$lib_xmap_target_means$rho)], na.rm = T) 
    mean_target_xmap_lib_means = mean(parallel_res$CCM_res[[x]]$target_xmap_lib_means$rho[is.finite(parallel_res$CCM_res[[x]]$target_xmap_lib_means$rho)], na.rm = T)
    
    lib_xmap_target_means <- mean_lib_xmap_target_means #mean of mean under different library
    target_xmap_lib_means <- mean_target_xmap_lib_means #mean of mean under different library
    lib_name <- parallel_res$combn_mat_split[[x]][1] 
    target_name <- parallel_res$combn_mat_split[[x]][2] 
    data.frame(lib_name = c(gene_names[lib_name], gene_names[target_name]),
               target_name = c(gene_names[target_name], gene_names[lib_name]),
               mean_rho = c(lib_xmap_target_means, target_xmap_lib_means))
  }, as.character(gene_names))
  
  parallel_res_df <- do.call(rbind.data.frame, parallel_res_list)
  parallel_res_mat <- dcast(parallel_res_df, lib_name ~ target_name, fun.aggregate=mean)
  
  row.names(parallel_res_mat) <- parallel_res_mat$lib_name
  parallel_res_mat <- parallel_res_mat[, -1]
  
  parallel_res_mat[!is.finite(as.matrix(parallel_res_mat))] <- 0
  diag(parallel_res_mat) <- 0
  
  return(parallel_res_mat)
}

################################################################################################################################################################################################
#test rEDM (ccm algortihm for inferring gene regulatory network)
library(rEDM)
library(monocle)
library(xlsx)
library(xacHelper)
library(reshape2)
library(pheatmap)
# library(d3Network)
# library(netbiov)URMM_all_abs

#use the HBP blood dataset: 
load('./RData/figure4_panel.RData')
#load the data and then order the cells: 

plot_spanning_tree(URMM_all_abs, color_by = )

gene_ids <- unique(c(listInput_types$`double knockout`, listInput_types$`Irf8 knockout`, listInput_types$`Gif1 knockout`, 'Irf8', 'Gfi1'))
abs_URMM_mat <- as.matrix(t(exprs(URMM_all_abs)[gene_ids, order(pData(URMM_all_abs)$Pseudotime)]))

abs_parallel_res_lineage1 <- parallelCCM(ordered_exprs_mat = abs_URMM_mat[pData(URMM_all_abs)$State %in% c(2, 3), ], cores = detectCores() - 2)
abs_parallel_res_lineage2 <- parallelCCM(ordered_exprs_mat = abs_URMM_mat[pData(URMM_all_abs)$State %in% c(1, 2), ], cores = detectCores() - 2)

abs_parallel_res_mat1 <- prepare_ccm_res(abs_parallel_res_lineage1, gene_names = gene_ids)
abs_parallel_res_mat2 <- prepare_ccm_res(abs_parallel_res_lineage2)

pdf('abs_ccm.pdf', width = 30, height = 30)
pheatmap::pheatmap(abs_parallel_res_mat1[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()

abs_parallel_res_mat1 <- prepare_ccm_res(abs_parallel_res)

std_parallel_res <- parallelCCM(ordered_exprs_mat = std_lung_mat[, gene_ids], cores = detectCores())
std_parallel_res_mat <- prepare_ccm_res(std_parallel_res)

pdf('std_ccm.pdf', width = 30, height = 30)
pheatmap::pheatmap(std_parallel_res_mat1[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
dev.off()

################################################################################################################################################################################################
#calculate branch time point: 
#perform BEAM branchtimepoint calculation: 
all_gene_ILRs_list <- calILRs(cds = URMM_all_abs[, ], trajectory_states = c(1, 2), stretch = T, cores = detectCores() - 2, #beam_genes
                              trend_formula = "~sm.ns(Pseudotime, df = 3) * Branch", ILRs_limit = 3, relative_expr = T, label_by_short_name = F, 
                              useVST = F, round_exprs = FALSE, output_type = "all", file = "all_gene_ILRs_list", return_all = T)

calILRs(cds = URMM_all_abs[c('Irf8', 'Gfi1'), ], trajectory_states = c(1, 2), stretch = T, cores = detectCores() - 2, #beam_genes
        trend_formula = "~sm.ns(Pseudotime, df = 3) * Branch", ILRs_limit = 3, relative_expr = T, label_by_short_name = F, 
        useVST = T, round_exprs = FALSE, output_type = "all", file = "all_gene_ILRs_list", return_all = T)

all_gene_ILRs_list_fig1b <- calILRs(cds = URMM_all_fig1b[, ], trajectory_states = c(1, 2), stretch = T, cores = detectCores() - 2, #beam_genes
                                    trend_formula = "~sm.ns(Pseudotime, df = 3) * Branch", ILRs_limit = 3, relative_expr = T, label_by_short_name = F, 
                                    useVST = F, round_exprs = FALSE, output_type = "all", file = "all_gene_ILRs_list", return_all = T)

#get the branch point of the MST tree: 
cds_full <- buildBranchCellDataSet(URMM_all_abs[unique(beam_genes), ], progenitor_method = 'duplicate', branch_states = c(1, 2), stretch = T, branch_labels = NULL)
cds_fig1b <- buildBranchCellDataSet(URMM_all_fig1b[unique(beam_genes), ], progenitor_method = 'duplicate', branch_states = c(1, 2), stretch = T, branch_labels = NULL)

#check the longest pseudotime for common progenitors: 
range(pData(cds_full[, pData(cds_full)$State == 3])$Pseudotime)

abs_bifurcation_time <- abs(detectBifurcationPoint(all_gene_ILRs_list$norm_str_logfc_df[, 40:100], ILRs_threshold = 0.1, return_cross_point = F)) + 40#
names(abs_bifurcation_time) <- fData(URMM_all_abs[names(abs_bifurcation_time), ])$gene_short_name

abs_bifurcation_time_fig1b <- abs(detectBifurcationPoint(all_gene_ILRs_list_fig1b$norm_str_logfc_df[, 40:100], ILRs_threshold = 0.1, return_cross_point = F)) + 40 #
names(abs_bifurcation_time_fig1b) <- fData(URMM_all_fig1b[names(abs_bifurcation_time_fig1b), ])$gene_short_name

################################################################################################################################################################################################
#make the barplot: 
#get the Irf8/Gfi1 targets: 
Irf8_targets <- read.table('./csv_data/OG_cancer/Irf8_targets.txt') #2290
Gfi1_targets <- read.table('./csv_data/OG_cancer/Gfi_targets.txt') #9423
Cebpa_targets <- read.table('/Users/xqiu/Downloads/generate_clustering/tf_targets/Cebpa_23403033.txt')
Irf8_1_targets <- read.table('/Users/xqiu/Downloads/generate_clustering/tf_targets/Irf8_21731497.txt')
Irf8_2_targets <- read.table('/Users/xqiu/Downloads/generate_clustering/tf_targets/Irf8_22096565.txt')
Klf1_targets <- read.table('/Users/xqiu/Downloads/generate_clustering/tf_targets/Klf1_pmid20508144.txt')
Zfp1_targets <- read.table('/Users/xqiu/Downloads/generate_clustering/tf_targets/Sfpi1_20887958.txt')

load('./RData/mouse_fd')
row.names(mouse_fd) <- str_split_fixed(row.names(mouse_fd), '\\.', 2)[, 1]

Irf8_trim_ensembl_id <- str_split_fixed(Irf8_targets$V1[-1], '\\.', 2)[, 1]
Gfi1_trim_ensembl_id <- str_split_fixed(Gfi1_targets$V1[-1], '\\.', 2)[, 1]

Irf8_targets_gene_short_name <- as.character(mouse_fd[Irf8_trim_ensembl_id, 'gene_short_name'])
Gfi1_targets_gene_short_name <- as.character(mouse_fd[Gfi1_trim_ensembl_id, 'gene_short_name'])

#get the tf-target pairs from the motif scanning from each cell type: 
# Processing Bcell_Intersect_PKs.bed ...
# Processing CD4cell_Intersect_PKs.bed ...
# Processing CD8_PKs.bed ...
# Processing CMP_Intersect_PKs.bed ...
# Processing EryA_PKs.bed ...
# Processing GMP_Intersect_PKs.bed ...
# Processing Granulocytes_Intersect_PKs.bed ...
# Processing Lsk_Intersect_PKs.bed ...
# Processing MEP_Intersect_PKs.bed ...
# Processing Monocytes_PKs.bed ...
# Processing NK_Intersect_PKs.bed ..

Bcell_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/Bcell_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
CD4cell_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/CD4cell_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
CD8_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/CD8_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
CMP_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/CMP_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
EryA_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/EryA_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
GMP_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/GMP_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
Granulocytes_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/Granulocytes_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
Lsk_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/Lsk_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
MEP_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/MEP_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
Monocytes_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/Monocytes_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 
NK_TF_5k_enrichment_gsc <- loadGSCSafe('./csv_data/OG_cancer/NK_Intersect_PKs.bed_JASPAR_5kb_hits_olap.gmt', encoding="latin1") 

#get the TF lists from those targets: 
URMM_all_abs_beam_genes_vec <- row.names(URMM_all_abs_beam_genes)[URMM_all_abs_beam_genes$qval < 1e-1]

intersect(Irf8_targets_gene_short_name, URMM_all_abs_beam_genes_vec)
intersect(Gfi1_targets_gene_short_name, URMM_all_abs_beam_genes_vec)

length(intersect(c(Irf8_targets_gene_short_name, Gfi1_targets_gene_short_name), URMM_all_abs_beam_genes_vec)) / length(URMM_all_abs_beam_genes_vec)
#0.5610329

# CMP_TF_5k_enrichment_gsc$gsc

tmp <- str_split_fixed(names(GMP_TF_5k_enrichment_gsc$gsc), "\\(", 2)[, 1]
GMP_TF_names <- unique(c(str_split_fixed(tmp, "::", 3)))[-1]
tmp <- str_split_fixed(names(Monocytes_TF_5k_enrichment_gsc$gsc), "\\(", 2)[, 1]
Monocytes_TF_names <- unique(c(str_split_fixed(tmp, "::", 3)))[-1]
tmp <- str_split_fixed(names(Granulocytes_TF_5k_enrichment_gsc$gsc), "\\(", 2)[, 1]
Granulocytes_TF_names <- unique(c(str_split_fixed(tmp, "::", 3)))[-1]

c(Monocytes_TF_names, Granulocytes_TF_names, GMP_TF_names)
#panel c: 
#find the mutual inhibition gene pairs: 
motif_TFs <- c("ELF1", "EWSR1", "FLI1", "RAR", "BACH1", "STAT5A", "PPARG", "STAT5B", "SOX2", "TCFE2A", "RXR", "ARNT", "GATA1", "NR1H2", "BATF", "VDR", "MAX", "TAL1", "FOS", "HAND1", "POU5F1", "TCF3", "MYC", "TLX1", "NR1H3", "CEBPA", "MAF", "NFE2", "RXRA", "SMAD4", "SMAD3", "SMAD2", "MAFK", "STAT1", "DDIT3", "STAT2", "HIF1A", "JUN", "NFIC",  "HSF1", "RFX1", "SPI1", "MEF2C", "MYOD1", "MEF2A", "CDX2", "FOXO1", "TBP", "RORA", "REST", "NR2E3", "FOXO3", "GATA1", "GATA2", "ATOH1", "HOXC9", "FLI1", "GATA3", "GATA4", "FOXF2", "RREB1", "YY1", "RELA", "RXRA", "GABPA", "HNF4G", "MECOM", "JUNB", "HNF4A", "JUN", "TFAP2A", "NFE2L2", "PRDM1", "TFAP2C", "SOX3", "SOX2", "ELK1", "SOX6", "SOX9", "SRF", "MEIS1", "NR2C2", "FOXH1", "SRY", "T", "FOXQ1", "HOXA5", "ELK4", "LHX3", "JUND", "NKX3-2", "HOXA9", "NKX3-1", "BHLHE40", "RUNX1", "DUX4", "NKX2-5", "RUNX2", "TCF3", "PLAG1", "SREBF1", "KLF5", "MAFF", "ESRRA", "ESRRB", "RFX5", "MAFB", "FOXA1", "NR4A2", "TEAD1", "EN1", "MAFK", "USF1", "FOXP1", "BRCA1", "USF2", "FOXP2", "SREBF2", "NRF1", "ETS1", "EBF1", "RFX1", "MZF1", "RFX2", "KLF1", "FOXI1", "TCF12", "KLF4", "E2F1", "HLF", "ZBTB33", "HNF1B", "E2F3", "ELF1", "FOSL2", "HNF1A", "E2F4", "FOXA2", "E2F6", "ELF5", "PPARG", "PAX6", "SPI1", "PAX5", "TP63", "PAX4", "NFKB1", "CTCF", "ZEB1", "PAX2", "FEV", "CRX", "FOS", "MAX", "GFI1B", "HSF1", "NOBOX", "SPIB", "SOX17", "NFIL3", "MYB", "FOSL1", "MYC", "NR2F1", "EGR1", "ZFP423", "AR", "EGR2", "ZFX", "ESR1", "TP53", "ESR2", "ZNF143", "HLTF", "MYCN", "FOXC1", "SPZ1", "NFYB", "EHF", "NFYA", "NR3C1", "TCF7L2", "TCFCP2L1", "STAT6", "STAT4", "REL", "POU2F2", "HINFP", "BCL6", "MYOG", "THAP1", "GFI1", "NFATC2", "FOXD1", "FOXD3", "CEBPA", "INSM1", "ZNF263", "ERG", "CEBPB", "FOXL1", "CREB1", "STAT1", "STAT3", "SP1", "SP2", "IRF1", "IRF2", "PBX1", "NR5A2", "NHLH1")
motif_TFs_add <- c("RARA", "E2A", "TRP63", "TRP53", "ZFP143", "TFCP2L1")

motif_Tfs_id <- row.names(subset(fData(absolute_cds[, ]), toupper(gene_short_name) %in% c(motif_TFs, motif_TFs_add)))

#genes are not shown in the gene_short_name: 
setdiff(motif_TFs, toupper(fData(absolute_cds)$gene_short_name))
# "RAR:RXR"      "TCFE2A"      "DUX4"     "TP63"     "TP53"     "ZNF143" "TCFCP2L1" "ZNF263"
#RARA E2A - ? TRP63 TRP53 ZFP143 TFCP2L1 ?
#update the gene names: 

# checked_TFs_jaspar <- c("Bcl", "BCL6", "CEBP", "Cebp", "Creb3l", "CREB3L", "ELK", "ETS", "Gata", "GATA", "GATA1", "Gfi", "Gfi1", "ID", "id", "IRF", "Klf", "KLF", 
#                         "MEF2", "MEIS", "MIXL", "Myo", "NFKB", "Pitx", "POU2F", "Pou2f", "PRDM", "SMAD", "SOX", "Sox", "SP", "Tcf", "TCF", "ZBED", "ZBTB1", "ZBTB3", "ZBTB7")
checked_TFs_jaspar <- c("CEBPE", "ETS1", "Gfi1", "Id2", "IRF8", "Klf4", "SOX4", "TCF7L2", "Vdr", "VDR", "ZBED1")


# checked_TFs_jaspar <- c("Bcl",  "CEBP", "Cebp", "Creb3l", "CREB3L", "ELK", "ETS", "Gata", "GATA", "GATA1", "Gfi", "Gfi1", "ID", "id", "MEF2", "MEIS", "NFKB", "Pitx", "POU2F", "Pou2f", "PRDM", "SMAD", "ZBED", "ZBTB1", "ZBTB3", "ZBTB7")
# checked_TFs_names <- c("Bcl2", "Bcl2a1b", "Bcl2a1d", "Cebpe", "Creb3l1", "Creb3l3", "Elk3", "Ets1", "Gata2", "Id2", "Gfi1", "Irf5", "Irf6", "Irf7", "Irf8", "Klf4", "Mef2d", 
#                        "Meis1", "Mlkl", "Myo7a", "Nfkbia", "Pitx2", "Pou2f2", "Prdm5", "Smad6", "Sox12", "Sp140", "Tcf19", "Zbed3", "Zbtb5", "Zbtb6")
checked_TFs_names <- c("Cebpe", "Ets1", "Gfi1", "Id2", "Irf8", "Klf4", "Sox4", "Tcf7l2", "Vdr", 'Zbed1')
# checked_TFs_names <- c("Bcl2", "Cebpe", "Creb3l1", "Creb3l3", "Elk3", "Ets1", "Gata2", "Id2", "Gfi1", "Mef2d", "Meis1", "Nfkbia", "Pitx2", "Pou2f2", "Prdm5", "Smad6", "Zbed3", "Zbtb5", "Zbtb6")

################################################################################################################################################################################################
#gene name based on WT cells tree only 
beam_genes <- row.names(subset(fig1b_beam_genes_proj_dup, qval < 1e-1)) # fig1b_beam_genes
beam_genes_all <- row.names(subset(URMM_all_abs_beam_genes_proj_dup, qval < 1e-1)) # fig1b_beam_genes
URMM_all_abs_beam_genes_proj_dup

# checked_TFs_jaspar_fig1b <- c("Bcl", "BCL6", "CEBP", "Cebp", "ELK", "ETS", "Gfi", "Gfi1", "Hoxa", "HOXA", "Hoxa1", "HOXA1", "ID", "id", "IRF", "Klf", "KLF", #'CENP',
#                         "MEF2", "MEIS", "POU2F", "Pou2f", "PRDM", "Rhox1", "SOX", "Sox", "SP", "Tcf", "TCF", "UNC", "ZBED", "ZBTB1", "ZBTB3", "ZBTB7")
# checked_TFs_names_fig1b <- c("Bcl2", "Bcl2a1b", "Bcl2a1d", "Cebpe", "Elk3", "Ets1", "Hoxa9", "Id2", "Gfi1", "Irf5", "Irf9", "Kif3b", "Klf4", "Mef2d", # "Irf8",
#                        "Meis1", "Pou2f2", "Prdm5", "Rhox8", "Sox12", "Sox4", "Sp140", "Tcf7l2", "Unc119", "Unc119b", "Zbed3",  "Zbtb48", "Zeb1",
#                        "Zeb2") #"Tcf19", "Zbtb2",
checked_TFs_jaspar_fig1b <- checked_TFs_jaspar
checked_TFs_names_fig1b <- checked_TFs_names
  
checked_TFs_jaspar_fig1b_valid_ids <- which(!(checked_TFs_jaspar_fig1b %in% c('Hoxa', 'ZBTB7', 'Rhox1', 'ELK', 'BCL6', 'PRDM', 'MEIS')))        #Rhox1      ELK     BCL6     PRDM     MEIS 
checked_TFs_names_fig1b_valid_ids <- which(!(checked_TFs_jaspar_fig1b %in% c('Unc119', 'Mef2d', 'MEIS', 'Rhox8', 'Elk', 'Prdm5')))

checked_TFs_jaspar_fig1b <- checked_TFs_jaspar_fig1b[checked_TFs_jaspar_fig1b_valid_ids]
checked_TFs_names_fig1b <- checked_TFs_names_fig1b[checked_TFs_names_fig1b_valid_ids]

cmp_sets <- unlist(lapply(checked_TFs_jaspar_fig1b, function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names_fig1b) #URMM_all_abs_beam_genes_vec

top_group_branch_time <- abs_bifurcation_time[c(checked_TFs_names_fig1b)]
bottom_group_branch_time <- abs_bifurcation_time[target_genes]

#get the list of targets: 
cmp_sets_time <- unlist(lapply(checked_TFs_jaspar_fig1b, function(x) {
  cmp_sets <- grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))
  target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names_fig1b)
  mean_bif_time <- mean(abs_bifurcation_time_fig1b[target_genes], na.rm = T)
  }))
names(cmp_sets_time) <- checked_TFs_jaspar_fig1b

cmp_sets <- unlist(lapply(checked_TFs_jaspar_fig1b, function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names_fig1b) #URMM_all_abs_beam_genes_vec

Monocytes_sets <- unlist(lapply(checked_TFs_jaspar_fig1b, function(x) grep(x, names(Monocytes_TF_5k_enrichment_gsc$gsc))))
Monocytes_target_genes <- setdiff(intersect(unlist(Monocytes_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names_fig1b) #URMM_all_abs_beam_genes_vec
Granulocytes_sets <- unlist(lapply(checked_TFs_jaspar_fig1b, function(x) grep(x, names(Granulocytes_TF_5k_enrichment_gsc$gsc))))
Granulocytess_target_genes <- setdiff(intersect(unlist(Granulocytes_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names_fig1b) #URMM_all_abs_beam_genes_vec

#perform the enrichment analysis: 
#add Irf8 / Gfi targets: 
Irf8_targets_names <- intersect(checked_TFs_names_fig1b, Irf8_targets_gene_short_name)
Gfi1_targets_names <- intersect(checked_TFs_names_fig1b, Gfi1_targets_gene_short_name)

#genes not binding by Irf8 / Gfi1: 
setdiff(checked_TFs_names_fig1b, c(Gfi1_targets_gene_short_name, Irf8_targets_gene_short_name))
# [1] "Bcl2a1b" "Bcl2a1d" "Cenpu"   "Hoxa9"   "Klf4"    "Mef2d"   "Rhox8"   "Sp140"   "Unc119b" "Zbtb48"  "Zfp85" 
intersect(Gfi1_targets_names, Irf8_targets_names)
# [1] "Bcl2"   "Id2"    "Pou2f2" "Tcf7l2" "Zfp658"
setdiff(Gfi1_targets_names, Irf8_targets_names)
# "Cebpe"  "Elk3"   "Ets1"   "Gfi1"   "Irf9"   "Irf8"   "Kif3b"  "Meis1"  "Prdm5"  "Sox12"  "Sox4"   "Unc119" "Zbed3"  "Zeb1"   "Zeb2"   "Zfp266" "Zfp768"
setdiff(Irf8_targets_names, Gfi1_targets_names)
# [1] "Irf5"

# checked_TFs_jaspar_fig1b_category <-   c("both", "both", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "others", "others", "others", "others", "both", "both", "Irf8", "others", "others", 
#                                          "others", "Irf8", "both", "both", "Gfi1", "others", "Gfi1", "Gfi1", "others", "both", "both", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1")
checked_TFs_jaspar_fig1b_category <- c("Gfi1", "Gfi1", "Gfi1", "both", "Gfi1","others", "Gfi1", "both", 'others', 'others', 'others')
# checked_TFs_names_fig1b_category <- c("both", "both", "both", "Gfi1", "Gfi1", "Gfi1", "others", "both", "Gfi1", "Irf8", "Irf8", "Gfi1", "others", "others", # "Irf8",
#                                       "Gfi1", "both", "Gfi1", "others", "Gfi1", "Gfi1", "others", "both", "Gfi1", "others", "Gfi1",  "others", "Gfi1",
#                                       "Gfi1")
checked_TFs_names_fig1b_category <- c("Gfi1", "Gfi1", "Gfi1", "both", "Gfi1", "others", "Gfi1", "both", 'others', 'others')
checked_TFs_jaspar_fig1b_category <- checked_TFs_jaspar_fig1b_category[checked_TFs_jaspar_fig1b_valid_ids]
checked_TFs_names_fig1b_category <- checked_TFs_names_fig1b_category[checked_TFs_names_fig1b_valid_ids]

Gfi1_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_fig1b_category == 'Gfi1'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
Gfi1_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[Gfi1_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

Irf8_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_fig1b_category == 'Irf8'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
Irf8_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[Irf8_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

both_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_fig1b_category == 'both'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
both_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[both_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

other_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_fig1b_category == 'others'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
other_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[other_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

# 
Monocytes_target_genes <- NULL
Granulocytess_target_genes <- NULL

secondary_target_genes <- c(Gfi1_secondary_target_genes, Irf8_secondary_target_genes, both_secondary_target_genes, other_secondary_target_genes, Monocytes_target_genes, Granulocytess_target_genes)

top_group_branch_time <- abs_bifurcation_time_fig1b[c(checked_TFs_names_fig1b)] #abs_bifurcation_time 
bottom_group_branch_time <- abs_bifurcation_time_fig1b[secondary_target_genes] #abs_bifurcation_time_fig1b
df <- data.frame(labels = c(c(checked_TFs_names_fig1b), secondary_target_genes), 
                 Gfi1_Irf8_type = c(checked_TFs_names_fig1b_category,
                                    rep('Gfi1', length(Gfi1_secondary_target_genes)), 
                                    rep('Irf8', length(Irf8_secondary_target_genes)),
                                    rep('both', length(both_secondary_target_genes)),
                                    rep('other', length(other_secondary_target_genes)),
                                    rep('Gfi1', length(Monocytes_target_genes)),
                                   rep('Irf8', length(Granulocytess_target_genes))
                 ), 
                 bifurcation_time = c(top_group_branch_time, bottom_group_branch_time), 
                 type = c(rep("Direct targets", length(top_group_branch_time)), rep("Secondary targets", length(bottom_group_branch_time))))

df[, 'type'] <- as.character(df[, 'type'])
df[df$labels %in% c('Gfi1', 'Irf8'), 'type'] <- 'Master regulator'
df[, 'type'] <- factor(df[, 'type'], levels = rev(c('Master regulator', 'Direct targets', 'Secondary targets')))

qplot(type, abs(bifurcation_time), color = type, geom = c('jitter'), data = subset(df, abs(bifurcation_time) > 50), alpha = I(0.7), log = 'y', size = 1) +  #, 'boxplot'
  xlab('') + ylab('bifurcation time point') + coord_flip() + scale_size(range = c(0.01, 1), limits = c(0.1, 1)) + 
  geom_boxplot(aes(color = type), fatten = 0.5, lwd = 0.5, outlier.shape=NA, alpha = 0.5) + 
  scale_y_continuous(breaks = round(seq(min(abs(df$bifurcation_time), na.rm = T), max(abs(df$bifurcation_time) + 5, na.rm = T), by = 9),1)) + #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
  nm_theme()

qplot(type, abs(bifurcation_time), color = type, geom = c('jitter'), data = subset(df, !(Gfi1_Irf8_type %in% 'others')), alpha = I(0.7), log = 'y', size = 1) +  #, 'boxplot'
  xlab('') + ylab('bifurcation time point') + coord_flip() + scale_size(range = c(0.01, 1), limits = c(0.1, 1)) + 
  geom_boxplot(aes(color = type), fatten = 0.5, lwd = 0.5, outlier.shape=NA, alpha = 0.5) + 
  scale_y_continuous(breaks = round(seq(min(abs(df$bifurcation_time), na.rm = T), max(abs(df$bifurcation_time) + 5, na.rm = T), by = 9),1)) + #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
  nm_theme()

################################################################################################################################################################################################
#do this for all the dataset: 

#get the list of targets: 
cmp_sets <- unlist(lapply(checked_TFs_jaspar, function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

Monocytes_sets <- unlist(lapply(checked_TFs_jaspar, function(x) grep(x, names(Monocytes_TF_5k_enrichment_gsc$gsc))))
Monocytes_target_genes <- setdiff(intersect(unlist(Monocytes_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec
Granulocytes_sets <- unlist(lapply(checked_TFs_jaspar, function(x) grep(x, names(Granulocytes_TF_5k_enrichment_gsc$gsc))))
Granulocytess_target_genes <- setdiff(intersect(unlist(Granulocytes_TF_5k_enrichment_gsc$gsc[cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

#perform the enrichment analysis: 
#add Irf8 / Gfi targets: 
Irf8_targets_names <- intersect(checked_TFs_names, Irf8_targets_gene_short_name)
Gfi1_targets_names <- intersect(checked_TFs_names, Gfi1_targets_gene_short_name)

#genes not binding by Irf8 / Gfi1: 
setdiff(checked_TFs_names, c(Gfi1_targets_gene_short_name, Irf8_targets_gene_short_name))
# [1] "Bcl2a1b" "Bcl2a1d" "Irf6"    "Irf7"    "Klf4"    "Mef2d"   "Mlkl"    "Pitx2"   "Sp140"   "Zbtb5"  
Irf8_targets_names
# [1] "Bcl2"   "Id2"    "Irf5"   "Pou2f2" "Tcf19" 
setdiff(Gfi1_targets_names, Irf8_targets_names)

# target TFs: 
checked_TFs_jaspar_category <-  c("both", "both", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "both", "both", "Irf8", "Gfi1", "Gfi1", 
                                  "other", "other", "other", "Gfi1", "Gfi1", "other", "both", "both", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "both", "both", "Gfi1", "other", "other", "other")
checked_TFs_names_category <-  c("both", "both", "both", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "Gfi1", "both", "Gfi1", "Irf8", "Irf8", "Irf8", "Irf8", "other", "other", 
                        "Gfi1", "other", "Gfi1", "Gfi1", "other", "both", "Gfi1", "Gfi1", "Gfi1", "other", "both", "Gfi1", "other", "other")

Gfi1_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_category == 'Gfi1'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
Gfi1_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[Gfi1_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

Irf8_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_category == 'Irf8'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
Irf8_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[Irf8_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

both_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_category == 'both'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
both_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[both_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

other_cmp_sets <- unlist(lapply(checked_TFs_jaspar[checked_TFs_jaspar_category == 'other'], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
other_secondary_target_genes <- setdiff(intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[other_cmp_sets]), beam_genes), checked_TFs_names) #URMM_all_abs_beam_genes_vec

Monocytes_target_genes <- NULL
Granulocytess_target_genes <- NULL

secondary_target_genes <- (c(Gfi1_secondary_target_genes, Irf8_secondary_target_genes, both_secondary_target_genes, other_secondary_target_genes, Monocytes_target_genes, Granulocytess_target_genes))

top_group_branch_time <- abs_bifurcation_time[c(checked_TFs_names)] #abs_bifurcation_time_fig1b
bottom_group_branch_time <- abs_bifurcation_time[secondary_target_genes]
df <- data.frame(labels = c(c(checked_TFs_names), secondary_target_genes), 
                 Gfi1_Irf8_type = c(checked_TFs_names_category,
                                    rep('Gfi1', length(Gfi1_secondary_target_genes)), 
                                    rep('Irf8', length(Irf8_secondary_target_genes)),
                                    rep('both', length(both_secondary_target_genes)),
                                    rep('other', length(other_secondary_target_genes)),
                                    rep('Gfi1', length(Monocytes_target_genes)),
                                    rep('Irf8', length(Granulocytess_target_genes))
                 ), 
                 bifurcation_time = c(top_group_branch_time, bottom_group_branch_time), 
                 type = c(rep("Direct targets", length(top_group_branch_time)), rep("Secondary targets", length(bottom_group_branch_time))))

df[, 'type'] <- as.character(df[, 'type'])
df[c(11, 15), 'type'] <- 'Master regulator'
df[, 'type'] <- factor(df[, 'type'], levels = rev(c('Master regulator', 'Direct targets', 'Secondary targets')))

################################################################################################################################################################################################
pdf('main_figures//hbp_regulation_hierarchy.pdf', width = 2, height = 1)
qplot(type, abs(bifurcation_time), color = type, geom = c('jitter'), data = subset(df, bifurcation_time > 50), alpha = I(0.7), log = 'y', size = 1) +  #, 'boxplot'
  xlab('') + ylab('bifurcation time point') + coord_flip() + scale_size(range = c(0.01, 1), limits = c(0.1, 1)) + 
  geom_boxplot(aes(color = type), fatten = 0.5, lwd = 0.5, outlier.shape=NA, alpha = 0.5) + 
  scale_y_continuous(breaks = round(seq(min(abs(df$bifurcation_time), na.rm = T), max(abs(df$bifurcation_time) + 5, na.rm = T), by = 9),1)) + #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
  nm_theme()
dev.off()

pdf('main_figures//hbp_regulation_hierarchy_helper.pdf')
qplot(type, abs(bifurcation_time), color = Gfi1_Irf8_type, geom = c('jitter'), data = df, alpha = I(0.7), log = 'y', size = 1) +  #, 'boxplot'
  xlab('') + ylab('bifurcation time point') + coord_flip() + scale_size(range = c(0.01, 1), limits = c(0.1, 1)) + 
  geom_boxplot(aes(color = Gfi1_Irf8_type), fatten = 0.5, lwd = 0.5, outlier.shape=NA, alpha = 0.5) + 
  scale_y_continuous(breaks = round(seq(min(abs(df$bifurcation_time), na.rm = T), max(abs(df$bifurcation_time) + 5, na.rm = T), by = 9),1))  #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
dev.off()

pdf('main_figures//hbp_regulation_hierarchy2.pdf', width = 3.5, height = 2)
qplot(type, abs(bifurcation_time), color = Gfi1_Irf8_type, geom = c('jitter'), data = df, alpha = I(0.7), log = 'y', size = 1) +  #, 'boxplot'
  xlab('') + ylab('bifurcation time point') + coord_flip() + scale_size(range = c(0.01, 1), limits = c(0.1, 1)) + 
  geom_boxplot(aes(color = Gfi1_Irf8_type), fatten = 0.5, lwd = 0.5, outlier.shape=NA, alpha = 0.5) + 
  scale_y_continuous(breaks = round(seq(min(abs(df$bifurcation_time), na.rm = T), max(abs(df$bifurcation_time) + 5, na.rm = T), by = 9),1)) + nm_theme()  #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
dev.off()

intersect(URMM_all_abs_beam_genes_vec, row.names(subset(fig1b_beam_genes, qval < 0.1))) #852, 543, 290
beam_genes <- row.names(subset(fig1b_beam_genes, qval < 0.1)) #URMM_all_abs_beam_genes_vec
Irf8_ko <- listInput_types$`Irf8 knockout`
Gif1_ko <- listInput_types$`Gif1 knockout`
double_ko <- listInput_types$`double knockout`

element_all <- c(beam_genes, 
                 Irf8_ko, 
                 Gif1_ko, 
                 double_ko)
sets_all <- c(rep(paste('BEAM genes', sep = ''), length(beam_genes)), 
              rep(paste('Irf8 knockout genes', sep = ''), length(Irf8_ko)), 
              rep(paste('Gfi1 knockout genes', sep = ''), length(Gif1_ko)), 
              rep(paste('Double knockout genes', sep = ''), length(double_ko))
              )
table(sets_all) #number of genes

intersect(c(Irf8_ko, Gif1_ko), double_ko)
intersect(c(Irf8_ko, Gif1_ko, double_ko), beam_genes)
intersect(c(Irf8_ko, Gif1_ko, double_ko), URMM_all_abs_beam_genes_vec)

BEAM_cmpr <- list('BEAM genes' = beam_genes, #URMM_all_abs_beam_genes_vec
                          'Irf8 knockout' = Irf8_ko, 
                          'Gif1 knockout' = Gif1_ko,
                          'Double knockout genes' = double_ko
                      )

pdf(paste(main_fig_dir, "knockout_gates_upset_individual_test_all_types.pdf", sep = ''), height = 4, width = 8)
upset(fromList(BEAM_cmpr), nsets = 4, order.by = "freq") #+ nm_theme()
dev.off()

pdf('./main_figures//fig4g.pdf')
venneuler_venn(element_all, sets_all)
dev.off()
table(sets_all) #number of genes

############################################################################################################################################################
#create the venn diagram
############################################################################################################################################################
element_all <- c(Gfi1_targets_names, 
                 Irf8_targets_names)
sets_all <- c(rep(paste('Regulator (Gfi1)', sep = ''), length(Gfi1_targets_names)), 
              rep(paste('Regulator (Irf8)', sep = ''), length(Irf8_targets_names)))

table(sets_all) #number of genes

pdf('./main_figures//fig4_gfi_irf_target.pdf')
venneuler_venn(element_all, sets_all)
dev.off()
table(sets_all) #number of genes

############################################################################################################################################################
#create the venn diagram for secondary targets
############################################################################################################################################################
element_all <- c(Irf8_secondary_target_genes, both_secondary_target_genes, 
                 Gfi1_secondary_target_genes)
sets_all <- c(rep(paste('Regulator (Gfi1)', sep = ''), length(Gfi1_secondary_target_genes)), 
              rep(paste('Regulator (both)', sep = ''), length(both_secondary_target_genes)),
              rep(paste('Regulator (Irf8)', sep = ''), length(Irf8_secondary_target_genes)))

table(sets_all) #number of genes


pdf('./main_figures//fig4_gfi_irf_secondary_target.pdf')
venneuler_venn(element_all, sets_all)
dev.off()
table(sets_all) #number of genes

############################################################################################################################################################
#create the venn diagram for secondary targets
############################################################################################################################################################
#make the network: 
#1. intersect the chip-seq targets with the knockout manifold test 
#2. identifying TFs from the intersection set 
#3. find the targets of those TFs 

#link Gfi1, Irf8 to the TFs 
adj_df <- data.frame(source = c('Irf8'), target = c('Irf8'),  target_type = c('Irf8'))
for(jaspar_ind in 1:length(checked_TFs_jaspar)){
  if(checked_TFs_jaspar_category[jaspar_ind] == 'both')
    adj_df = rbind(adj_df, data.frame(source = c("Gfi1", "Irf8"), target = c(checked_TFs_jaspar[jaspar_ind]), target_type = 'both'))
  else if(checked_TFs_jaspar_category[jaspar_ind] == 'Gfi1')
    adj_df = rbind(adj_df, data.frame(source = c("Gfi1"), target = c(checked_TFs_jaspar[jaspar_ind]), target_type = 'Gfi1'))
  else if(checked_TFs_jaspar_category[jaspar_ind] == 'Irf8')
    adj_df = rbind(adj_df, data.frame(source = c("Irf8"), target = c(checked_TFs_jaspar[jaspar_ind]), target_type = 'Irf8'))
}
    
#link TFs to their targets 
for(jaspar_ind in 1:length(checked_TFs_jaspar)){
  message(jaspar_ind)
  tmp_cmp_sets <- unlist(lapply(checked_TFs_jaspar[jaspar_ind], function(x) grep(x, names(GMP_TF_5k_enrichment_gsc$gsc))))
  inter_cmp <- intersect(unlist(GMP_TF_5k_enrichment_gsc$gsc[tmp_cmp_sets]), beam_genes)
  
  if(length(inter_cmp) > 0){
    tmp_secondary_target_genes <- setdiff(inter_cmp, checked_TFs_names) #URMM_all_abs_beam_genes_vec
    adj_df = rbind(adj_df, data.frame(source = checked_TFs_jaspar[jaspar_ind], target = tmp_secondary_target_genes, target_type = checked_TFs_jaspar_category[jaspar_ind]))
  }
}

uniq_genes <- unique(c(as.character(adj_df[, 1]), as.character(adj_df[, 2])))
hbp_network_mat <- as.data.frame(matrix(rep(0, length(uniq_genes)^2), nrow = length(uniq_genes), dimnames = list(uniq_genes,  uniq_genes)))
for(ind in 1:nrow(adj_df)){
  message(ind)
  hbp_network_mat[as.character(adj_df[ind, 1]), as.character(adj_df[ind, 2])] <- 1
}

g1 <- graph_from_adjacency_matrix(as.matrix(hbp_network_mat), mode = "directed")

# #
# load('./RData/ccm_res')
# 
# abs_parallel_res_mat1 <- prepare_ccm_res(abs_parallel_res_lineage1, gene_names = colnames(abs_parallel_res_mat1))
# abs_parallel_res_mat2 <- prepare_ccm_res(abs_parallel_res_lineage2, gene_names = colnames(abs_parallel_res_mat1))
# 
# #create a graph and then plot the graph as a hiearchical fashion: 
# abs_parallel_res_mat1_g <- abs_parallel_res_mat1
# abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) > 0.1, arr.ind = T)] <- abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) > 0.1, arr.ind = T)]
# abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) < 0.1, arr.ind = T)] <- 0
# 
# #netbiov, igraph, 
# #build a graph: 
# layouts <- grep("^layout_", ls("package:igraph"), value=TRUE)[-1]
# g1 <- graph_from_adjacency_matrix(as.matrix(abs_parallel_res_mat1_g), mode = "directed", weighted = T)
# 
# plot(g1, layout = layout.reingold.tilford(g1, root = c('Irf8','Gfi1')), vertex.size = 6)
# # plot(g1, layout = layout_nicely(g1, ))
# 
# g5 <- graph.adjacency(m5$adjacency, mode="undirected")
# plot(g5, layout = layout_as_tree(g5) )
# tkplot(g1)
# 
# # create data frames for vertices and edges with the right variable names
# MapperNodes <- mapperVertices(mapper_res, 1:length(mapper_res$points_in_vertex) )
# dev.off()
# 
# MapperLinks <- mapperEdges(mapper_res)
# 
# # interactive plot
# forceNetwork(Nodes = MapperNodes, Links = MapperLinks,
#              Source = "Linksource", Target = "Linktarget",
#              Value = "Linkvalue", NodeID = "Nodename",
#              Group = "Nodegroup", opacity = 0.8,
#              linkDistance = 10, charge = -400)
# 
# mst.plot.mod(g1, v.size=1.5,e.size=.25,
#              colors=c("red",   "orange",   "yellow",   "green"),
#              mst.e.size=1.2,expression=abs(runif(vcount(g1),
#                                                  max=5,   min=1)),   sf=1,   v.sf=1,
#              mst.edge.col="white",   layout.function=layout.fruchterman.reingold)
# 
# 
# plot.abstract.nodes(g1,
#                     lab.cex=1, lab.color="white", v.sf=0, e.sf = 0, 
#                     layout.function=layout.fruchterman.reingold)

level.plot(g1, layout.function=NULL, type=1, initial_nodes=c('Gfi1', 'Irf8'),
           init_nodes=0, order_degree = "in", plotsteps = FALSE, 
           saveplots=FALSE, dirname=NULL, vertex.colors=NULL, 
           edge.col=NULL, tkplot=F, nodeset=NULL,path.col="green", 
           col.s1="red", col.s2="yellow", nodes.on.path=TRUE,v.size=2, 
           e.size=.5, v.lab=T, bg="black", v.lab.cex=0.5, 
           v.lab.col="skyblue",sf=4,e.path.width=1,e.curve=.5, 
           level.spread=FALSE)  

pdf('./main_figures/level_plot.pdf')
level.plot(g1, layout.function=NULL, type=1, initial_nodes=c(1, 2),
           init_nodes=0, order_degree = "in", plotsteps = FALSE, 
           saveplots=FALSE, dirname=NULL, vertex.colors=NULL, 
           edge.col=NULL, tkplot=F, nodeset=NULL,path.col="green", 
           col.s1="red", col.s2="yellow", nodes.on.path=TRUE,v.size=2, 
           e.size=.5, v.lab=T, bg="black", v.lab.cex=0.5, 
           v.lab.col="skyblue",sf=4,e.path.width=1,e.curve=.5, 
           level.spread=FALSE)  
dev.off()

################################################################################################################################################################################################
#save data for Sreeram: 
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Irf8_targets_gene_short_name', Irf8_targets_gene_short_name[!is.na(Irf8_targets_gene_short_name)], row.names = F, quote = F, col.names = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Gfi1_targets_gene_short_name', Gfi1_targets_gene_short_name[!is.na(Gfi1_targets_gene_short_name)], row.names = F, quote = F, col.names = F)

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Irf8_ko_deg', listInput_types.1$`Irf8 knockout`, row.names = F, quote = F, col.names = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Gfi1_ko_deg', listInput_types.1$`Gif1 knockout`, row.names = F, quote = F, col.names = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/double_ko_deg', listInput_types.1$`double knockout`, row.names = F, quote = F, col.names = F)

#beam genes: 
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/wt_beam_genes', beam_genes, row.names = F, quote = F, col.names = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/all_data_beam_genes', beam_genes_all, row.names = F, quote = F, col.names = F)
################################################################################################################################################################################################

save.image('./RData/hbp_blood_network.RData')
