# compare with other algorithms: 
# WCGNA, Genie3, MINET, G1DBN, edbNet, GenNet
# http://bonneaulab.bio.nyu.edu/networks.html (th cell differentiation network)
