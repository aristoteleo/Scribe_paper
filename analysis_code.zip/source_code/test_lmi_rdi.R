################################################################################################################################################################################################
# test lmi and rdi, etc. 
################################################################################################################################################################################################

a <- Sys.time()
rdi_res <- calculate_rdi(t(exprs(AT1_lung)[1:100, ]), delays = 10, method = 1)
b <- Sys.time()
b - a 
a <- Sys.time()
lmi_res <- calculate_rdi(t(exprs(AT1_lung)[1:100, ]), delays = 10, method = 2) #only one or two folder fast but we can use the very fast implementation from parinfogene package, etc. 
b <- Sys.time()
b - a 

a <- Sys.time()
mi_res <- parmigene::knnmi.all(exprs(AT1_lung)[1:100, ], k = 5)
b <- Sys.time()
b - a 

qplot(as.vector(rdi_res$RDI), as.vector(lmi_res$RDI)) + geom_abline() + xlab('RDI') + ylab('Lagged mutual information') + geom_smooth()
qplot(as.vector(mi_res), as.vector(rdi_res$RDI)) + geom_abline() + xlab('MI') + ylab('Lagged mutual information') + geom_smooth()

# write this in C ++ if this is important 
fast_lmi <- function(ordered_data, delay = 10) {
  mat_ori <- ordered_data[, -c((ncol(ordered_data) - 10):ncol(ordered_data))]
  mat_delay <- ordered_data[, 11:ncol(ordered_data)]
  # parmigene::knnmi.cross(mat_ori, mat_delay)
}

all_Olsson_granulocyte_cds_exprs <- t(exprs(Olsson_granulocyte_cds)[, order(granulocyte_dpt_res$pt)])

a <- Sys.time()
res <- parmigene::knnmi.all(exprs(Olsson_granulocyte_cds)[, order(granulocyte_dpt_res$pt)], k = 5)
b <- Sys.time()
b - a 
# if this work, we can just take the top 10 % edges and then do the cRDI or RDI 
# we can only use the extremely fast implementation of the MI code 

################################################################################################################################################################################################
# do the State Space Reconstruction on the neuron simulation 
################################################################################################################################################################################################

# lag 1, 2, 3 vs the original data 
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision//RData/fig3.RData')

nao_sim_cds_subset <- nao_sim_cds[, c(1:100, 401:500, 801:900)]
qplot(exprs(nao_sim_cds_subset)['Mash1', 1:100], exprs(nao_sim_cds_subset)['Hes5', 1:100])
plot3d(exprs(nao_sim_cds_subset)['Mash1', ], exprs(nao_sim_cds_subset)['Hes5', ], exprs(nao_sim_cds_subset)['Pax6', ], col = c(rep(c('red', 'blue', 'green'), each = 100)))

plot3d(exprs(nao_sim_cds_subset)['Mash1', ], exprs(nao_sim_cds_subset)['Hes5', ], exprs(nao_sim_cds_subset)['Olig2', ], 
       col = c(rep(c('red', 'blue', 'green'), each = 100)), xlab = 'Mash1', ylab = 'Hes5', zlab = 'Olig2')
# add the state space reconstruction 

plot3d(exprs(nao_sim_cds_subset)['Mash1', c(1:98, 101:198, 201:298)], exprs(nao_sim_cds_subset)['Mash1', c(2:99, 102:199, 202:299)],
       exprs(nao_sim_cds_subset)['Mash1', c(3:100, 103:200, 203:300)], col = c(rep(c('red', 'blue', 'green'), each = 98)), 
       xlab = 'Mash1', ylab = 'Mash1 (delay 1)', zlab = 'Mash1 (delay 2)')
plot3d(exprs(nao_sim_cds_subset)['Hes5', c(1:98, 101:198, 201:298)], exprs(nao_sim_cds_subset)['Hes5', c(2:99, 102:199, 202:299)], 
       exprs(nao_sim_cds_subset)['Hes5', c(3:100, 103:200, 203:300)], col = c(rep(c('red', 'blue', 'green'), each = 98)),
       xlab = 'Hes5', ylab = 'Hes5 (delay 1)', zlab = 'Hes5 (delay 2)')
plot3d(exprs(nao_sim_cds_subset)['Scl', c(1:98, 101:198, 201:298)], exprs(nao_sim_cds_subset)['Scl', c(2:99, 102:199, 202:299)], 
       exprs(nao_sim_cds_subset)['Scl', c(3:100, 103:200, 203:300)], col = c(rep(c('red', 'blue', 'green'), each = 98)),
       xlab = 'Scl', ylab = 'Scl (delay 1)', zlab = 'Scl (delay 2)')

################################################################################################################################################################################################
# finalize the simulation analysis with drop-out, etc. 
################################################################################################################################################################################################

################################################################################################################################################################################################
# finalize the simulation analysis with drop-out, etc. 
################################################################################################################################################################################################


