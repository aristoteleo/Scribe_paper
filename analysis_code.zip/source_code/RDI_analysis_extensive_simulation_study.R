library(monocle)
library(InformationEstimator)
library(ROCR)
source("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R", echo = T)

# RDI analysis on the extensive simulation analysis 
setwd("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/")

# same cell and fix time; add dropout 
same_cell_time_fixed_res_dropout <- read.table("./csv_data/same_cell_time_fixed_res_dropout.txt")

# Run RDI / cRDI on it and then calculate the benchmark result (boxplot)
# each row is a run; columns: 1. rdi AUC value (true time); 2. crdi roc value (true time); 3. rdi AUC value (DPT time), crdi roc value (DPT time)
same_cell_time_fixed_res_dropout_roc_res <- matrix(0, nrow = 25, ncol = 4) 

rdi_res_list <- list()
crdi_res_list <- list()

run_id_vec <- same_cell_time_fixed_res_dropout$V2

same_cell_time_fixed_res_dropout_R465 <- same_cell_time_fixed_res_dropout[same_cell_time_fixed_res_dropout$V2 == 'R465', ]
same_cell_time_fixed_res_dropout_R465 <- same_cell_time_fixed_res_dropout_R465[, -c(1:2)]

# multiple cores: 
all_res_list <- mclapply(run_id_vec, function(i) {
  same_cell_time_fixed_res_dropout_tmp <- same_cell_time_fixed_res_dropout[run_id_vec == i, ]
  gene_name <- same_cell_time_fixed_res_dropout_tmp$V1
  same_cell_time_fixed_res_dropout_tmp <- same_cell_time_fixed_res_dropout_tmp[, -c(1:2)]
  row.names(same_cell_time_fixed_res_dropout_tmp) <- gene_name
  
  a <- Sys.time() # 11 minutes
  rdi_res <- calculate_rdi(t(same_cell_time_fixed_res_dropout_R465), delays = c(1)) # true delay is 1 
  b <- Sys.time()
  
  ca <- Sys.time()
  crdi_res <- calculate_conditioned_rdi(t(same_cell_time_fixed_res_dropout_R465), super_graph = NULL, rdi_res, 1L)
  cb <- Sys.time()
  
  message('current i is ', i, " rdi running time is ", b - a, " crdi running time is ", cb - ca)
  return(list(rdi_res = rdi_res, crdi_res = crdi_res))
}, mc.cores = detectCores())

# calculate rdi and crdi


# calculate the ROC values

#reference network:
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- unique(as.character(unique(same_cell_time_fixed_res_dropout$V1)[1:13]))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste((valid_all_cmbns$Var1), (valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste((neuron_network$V1), (neuron_network$V2), sep = '_'), 2] <- 1

network_result_df <- valid_all_cmbns_df

dimnames(rdi_res$max_rdi_value) <- list(gene_uniq, gene_uniq)
dimnames(crdi_res) <- list(gene_uniq, gene_uniq)
network_result_df$RDI <- apply(valid_all_cmbns, 1, function(x) rdi_res$max_rdi_value[x[1], x[2]])
network_result_df$cRDI <- apply(valid_all_cmbns, 1, function(x) crdi_res[x[1], x[2]])

reference_network_pvals <- valid_all_cmbns_df[, 2]
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(network_result_df[, 3:4]), function(x, reference_network_pvals_df = reference_network_pvals) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)

###############################################################################################################################################
# test on other settings: 
###############################################################################################################################################
library(monocle)
library(R.matlab)

#CNS simulation data:
cell_simulate <- readMat('/Users/xqiu/Documents/MATLAB/cell_simulate.mat')
all_cell_simulation <- cell_simulate$cell.simulate[, 1:400, ] #time 0-20 are the period two branches appear
row.names(all_cell_simulation) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

#obtain the corresponding lineage for each simulation run:
neuron_cell_ids <- which(all_cell_simulation['Mash1', 400, ] > 3)
astrocyte_cell_ids <- which(all_cell_simulation['Scl', 400, ] > 2)
oligodendrocyte_cell_ids <- which(all_cell_simulation['Olig2', 400, ] > 2)

gene_names <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

neuron_exprs_mat <- as.matrix(all_cell_simulation[, , neuron_cell_ids[1]])
dimnames(neuron_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

astrocyte_exprs_mat <- as.matrix(all_cell_simulation[, , astrocyte_cell_ids[1]])
dimnames(astrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

oligodendrocyte_exprs_mat <- as.matrix(all_cell_simulation[, , oligodendrocyte_cell_ids[1]])
dimnames(oligodendrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

PD <- data.frame(Time = rep(1:400, 1), row.names = paste('Cell_', rep(1:400, 1), sep = ''))
FD <- data.frame(gene_short_name = gene_names, row.names = gene_names)

pd <- new("AnnotatedDataFrame",data=PD)
fd <- new("AnnotatedDataFrame",data=FD)

make_cds <- function (exprs_matrix, pd, fd, lowerDetectionLimit = 1, expressionFamily) {
  cds <- newCellDataSet(exprs_matrix, phenoData = pd, featureData = fd, lowerDetectionLimit = 1, expressionFamily = negbinomial())
  return(cds)
}

neuron_sim_cds <- newCellDataSet(neuron_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'neuron'
astrocyte_sim_cds <- newCellDataSet(astrocyte_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'astrocyte'
oligodendrocyte_sim_cds <- newCellDataSet(oligodendrocyte_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'oligodendrocyte'


# experimental design: 
# 1. using the same cell or different cells 

# 2. using zero-forcing or no zero-forcing 

# 3. using true time or the pseudotime 
# 

# same cell / correct time 

# same_cell_time_fixed_res_pseudotime # use the Pseudotime 

# same_cell_time_fixed_res_dropout # original data but with dropout 

# same_cell_time_fixed_res_dropout_pseudotime # droput data and use Pseudotime 

# same cell / gaussian sampled time 

# same_cell_time_gaussian_res_pseudotime # use the Pseudotime 

# same_cell_time_gaussian_res_dropout # original data but with dropout 

# same_cell_time_gaussian_res_dropout_pseudotime # droput data and use Pseudotime 

# different cell / correct time 

# different_cell_time_fixed_res # correct time  

# different_cell_time_fixed_res_pseudotime # pseudotime

# different_cell_time_fixed_res_dropout # droput data 

# different_cell_time_fixed_res_pseudotime_dropout # droput data and use Pseudotime 

# different cell / gaussain sampled time 

# different_cell_time_Gaussian_res # gaussian time  

# different_cell_time_Gaussian_res_pseudotime # pseudotime

# different_cell_time_Gaussian_res_dropout # droput data 

# different_cell_time_Gaussian_res_dropout_pseudotime # droput data and use Pseudotime 


read.table("./csv_data/same_cell_time_fixed_res_dropout.txt")
