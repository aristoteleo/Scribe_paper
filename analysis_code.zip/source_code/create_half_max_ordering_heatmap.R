# load('./RData/analysis_c_elegans.RData')

curves <- t(norm_test_c_elegans_data)

hm_mat <- as.matrix(curves)
hm_mat_scaled <- hm_mat
# hm_mat_scaled <- hm_mat - apply(hm_mat, 1, min)
# hm_mat_scaled <- hm_mat_scaled / apply(hm_mat_scaled, 1, max)

hm_mat_scaled_z <- t(scale(t(hm_mat)))
temp <- hm_mat_scaled_z < 0
#temp <- temp[,10:90]
transient <- apply(temp, 1, function(x) {
  current <- x[1]
  count <- 0
  for(y in x) {
    if (y != current) {
      count <- count + 1
      current <- y
    }
  }
  count
})

trans_max <- apply(hm_mat_scaled, 1, which.max)
trans <- hm_mat_scaled[transient > 1 & !trans_max %in% c(1:5, (dim(hm_mat_scaled) - 5):(dim(hm_mat_scaled))),]

row_dist <- as.dist((1 - cor(Matrix::t(trans)))) #/2
row_dist[is.na(row_dist)] <- 1
clust <- pheatmap::pheatmap(trans, cluster_cols = FALSE, clustering_distance_rows = row_dist, clustering_method="ward.D2",scale="none", show_rownames = FALSE, silent=TRUE, show_colnames = FALSE)

anno_row <- as.data.frame(cutree(clust$tree_row, 12))
names(anno_row)<- "cluster"
anno_row$cluster <- as.factor(anno_row$cluster)

pheatmap::pheatmap(trans, cluster_cols = FALSE, scale="none",clustering_method="ward.D2", show_rownames = FALSE, annotation_row = anno_row, show_colnames = FALSE) # filename = "find_transient.pdf",

trans_list <- row.names(trans)

nt <- hm_mat_scaled[!row.names(hm_mat_scaled) %in% trans_list,]
up <- nt[nt[,1] < nt[,ncol(hm_mat_scaled)],]
down <- nt[nt[,1] > nt[,ncol(hm_mat_scaled)],]

up_cp <- apply(up, 1, function(x) which.min(abs(x - 0.5)) )
up <- up[order(up_cp),]

down_cp <- apply(down, 1, function(x) which.min(abs(x - 0.5)) )
down <- down[order(down_cp),]

all <- rbind(up, down)

trans_cp <- apply(trans, 1, function(x) which.min(abs(x - 0.5)))
trans <- trans[order(trans_cp),]

all <- rbind(all, trans)
clusts <-  pheatmap::pheatmap(all,
                              color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                              fontsize = 6,
                              scale = "none",
                              width=2,
                              height=3,
                              gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                              cluster_cols = FALSE,
                              cluster_rows = FALSE,
                              show_colnames = FALSE,
                              show_rownames = FALSE)
pheatmap::pheatmap(all, legend = FALSE,
                   #annotation_colors = list(Type = c(Proximal = "#241023", `Other Distal` = "#47A025", `Distal Enhancer` = "#735CDD")),
                   color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                   fontsize = 6,
                   scale = "none",
                   width=2.8,
                   height=3.3,
                   gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                   cluster_cols = FALSE,
                   cluster_rows = FALSE,
                   show_colnames = FALSE,
                   show_rownames = FALSE)

if(!exists("cur_cell_types")) {
  cur_cell_types <- cell_types[2]
}

pdf(paste0(main_fig_dir, 'c_elegans_', cur_cell_types, '_heatmap.pdf'), width =  1, height = 2)
pheatmap::pheatmap(all,
                   #color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                   fontsize = 6,
                   scale = "none",
                   width=2,
                   height=3,
                   gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                   cluster_cols = FALSE,
                   cluster_rows = FALSE,
                   show_colnames = FALSE,
                   legend = F,
                   border_color = NA,
                   show_rownames = FALSE)
dev.off()
