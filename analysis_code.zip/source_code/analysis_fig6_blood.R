# run the RDI for the entire blood tree (Paul dataset)
rm(list = ls())

# https://www.nature.com/ncb/journal/v19/n4/abs/ncb3493.html

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

library(Scribe)
library(monocle)
library(destiny)

source("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R")

#######################################################################################################################################
hspc_qpcr_processed <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_qPCR/hspc_qpcr_processed.csv')
B_qpcr_processed <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_qPCR/416B_qpcr_processed.csv')
HoxB8_qpcr_processed <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_qPCR/HoxB8-FL_qpcr_processed.csv')

#######################################################################################################################################
# create cds for the HSPC, B and HoxBB data
createCDS <- function(data, expressionFamily = gaussianff()) {
  exprs_matrix <- t(data[, -c(1:2)])

  PD <- data.frame(Cell_type = data[, 1], row.names = data[, 2])
  FD <- data.frame(gene_short_name = colnames(data)[-c(1:2)], row.names = colnames(data)[-c(1:2)])
  
  pd <- new("AnnotatedDataFrame",data=PD)
  fd <- new("AnnotatedDataFrame",data=FD)
  
  cds <- newCellDataSet(exprs_matrix, phenoData = pd, featureData = fd, lowerDetectionLimit = 1, expressionFamily = expressionFamily)

  return(cds)

}

hspc_qpcr_processed_cds <- createCDS(hspc_qpcr_processed)

#######################################################################################################################################
# run dpt on this dataset 
#######################################################################################################################################

dpt_res <- run_new_dpt(hspc_qpcr_processed_cds)
dpt_df <- data.frame(DC1 = dpt_res$dm$DC1, DC2 = dpt_res$dm$DC2, color = pData(hspc_qpcr_processed_cds)$Cell_type)
qplot(DC1, DC2, color = color, facets = "color")

hspc_qpcr_processed_cds_SimplePPT <- reduceDimension(hspc_qpcr_processed_cds, norm_method = 'none', method = 'SimplePPT')
hspc_qpcr_processed_cds_SimplePPT <- orderCell(hspc_qpcr_processed_cds_SimplePPT)


#######################################################################################################################################

hspc_qpcr_processed_cds <- reduceDimension(hspc_qpcr_processed_cds, norm_method = 'none')
hspc_qpcr_processed_cds <- orderCells(hspc_qpcr_processed_cds)

plot_cell_trajectory(hspc_qpcr_processed_cds)
plot_cell_trajectory(hspc_qpcr_processed_cds, color_by = 'Cell_type')
plot_complex_cell_trajectory(hspc_qpcr_processed_cds, color_by = 'Cell_type') + facet_wrap(~Cell_type)

gene_pairs_mat <- matrix(c('Gata2', 'Nfe2', 'Gata2', 'Cbfa2t3h'), ncol = 2, byrow = T)
plot_lagged_drevi(hspc_qpcr_processed_cds, gene_pairs_mat = gene_pairs_mat, d = 0, log = F, grids = 25) # show the regulation between Gata2, Nfe2 and Cbfa2t3h

uMI_res <- calculate_umi(hspc_qpcr_processed_cds, log = FALSE) # don't use log because the data is gaussian distributed. 
MI_res <- cal_knn_mi_parmigene(exprs(hspc_qpcr_processed_cds))
which(MI_res == max(MI_res), arr.ind = T) # c('Ubc', 'Polr2a', 'Polr2a', 'Ubc') just opposite direction 

which(MI_res ==sort(MI_res, decreasing=T)[3], arr.ind = T)

gene_pairs_mat <- matrix(c('Mpl', 'Mecom', 'Mpl', 'Procr'), ncol = 2, byrow = T)
pdf('./Figures/main_figures/blood_example_drevi_ori.pdf', height = 1, width = 2)
plot_lagged_drevi(hspc_qpcr_processed_cds, gene_pairs_mat = gene_pairs_mat, d = 0, log = F, grids = 25, n_col = 2, n_row = 1) + xacHelper::nm_theme()# show the regulation between Gata2, Nfe2 and Cbfa2t3h
dev.off()

gene_pairs_mat <- matrix(c('Mecom', 'Procr'), ncol = 2, byrow = T)
plot_lagged_drevi(hspc_qpcr_processed_cds, gene_pairs_mat = gene_pairs_mat, d = 0, log = F, grids = 25, n_col = 2, n_row = 1) + xacHelper::nm_theme()# show the regulation between Gata2, Nfe2 and Cbfa2t3h

reverseEmbeddingCDS <- function(cds, norm_method = c("log", "vstExprs", "none"), pseudo_expr = 1) {
  if(nrow(cds@reducedDimW) < 1)
    stop('You need to first apply reduceDimension function on your cds before the reverse embedding')
  
  FM <- monocle:::normalize_expr_data(cds, norm_method = norm_method, pseudo_expr = pseudo_expr)
  
  #FM <- FM[unlist(sparseApply(FM, 1, sd, convert_to_dense=TRUE)) > 0, ]
  xm <- Matrix::rowMeans(FM)
  xsd <- sqrt(Matrix::rowMeans((FM - xm)^2))
  FM <- FM[xsd > 0,]
  
  reverse_embedding_data <- reducedDimW(cds) %*% reducedDimS(cds)
  row.names(reverse_embedding_data) <- row.names(FM)
  
  cds_subset <- cds[row.names(FM), ]
  
  #make every value larger than 1: 
  reverse_embedding_data <- t(apply(reverse_embedding_data, 1, function(x) x + abs(min(x))))
  
  #rescale to the original scale: 
  raw_data <- as.matrix(exprs(cds)[row.names(FM), ]) 
  reverse_embedding_data <- reverse_embedding_data * (apply(raw_data, 1, function(x) quantile(x, 0.99)) ) / apply(reverse_embedding_data, 1, max)
  
  Biobase::exprs(cds_subset) <- reverse_embedding_data
  
  return(cds_subset)
}

res <- reverseEmbeddingCDS(hspc_qpcr_processed_cds, norm_method = 'none', pseudo_expr = 0) # apply RGE to get the denoised data 

gene_pairs_mat <- matrix(c('Mpl', 'Mecom', 'Procr'), ncol = 3, byrow = T)
pdf('./Figures/main_figures/blood_example_combinatorial_ori.pdf', height = 1, width = 1)
plot_comb_logic(hspc_qpcr_processed_cds, gene_pairs_mat, grid_num = 50, d = 0) + xacHelper::nm_theme()
dev.off()

