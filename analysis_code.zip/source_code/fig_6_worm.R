library(monocle)
# library(Scribe)
library(devtools)
load_all('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe/')
library(stringr)
library(igraph)
library(reshape2)
library(igraph)
library(dplyr)
library(viridis)
library(cowplot)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################
source('~/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R', echo=TRUE)
#######################################################################################################################################
# create the cds to include all cells 
#######################################################################################################################################

pData <- c_elegans_data_ori[, 1:6]
row.names(pData) <- paste0(c_elegans_data_ori$cell, "_", c_elegans_data_ori$time)
pData$Pseudotime <- pData$time
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(c_elegans_data_ori)[-c(1:6)], row.names = colnames(c_elegans_data_ori)[-c(1:6)])
fd <- new("AnnotatedDataFrame", data = fData)

# Now, make a new CellDataSet using the RNA counts
c_elegans_data_ori_dup <- as.matrix(c_elegans_data_ori[, -c(1:6)])
c_elegans_data_ori_dup[!is.finite(c_elegans_data_ori_dup)] <- 0 # remove NaN values
row.names(c_elegans_data_ori_dup) <- paste0(c_elegans_data_ori$cell, "_", c_elegans_data_ori$time)
c_elegans_cds <- newCellDataSet(as(t(c_elegans_data_ori_dup), 'sparseMatrix'), 
                                phenoData = pd,
                                featureData = fd,
                                lowerDetectionLimit=-62224,
                                expressionFamily=gaussianff())

#######################################################################################################################################
# set a few cell phenotype information
# - founder_cell, anatomical.cell.name.long, anatomical.cell.name.short, cell.type.description, cell.type, tissue.type
#######################################################################################################################################
pData(c_elegans_cds)$founder_cell <- gsub("[:a-z:]","",pData(c_elegans_cds)$cell) # set up the founder cells 

waterston_celltypes_filtered <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/c_elegans/waterston_celltypes_filtered.csv', sep = ',', header = T, row.names = 1)
lineage.cell.name..again. <- waterston_celltypes_filtered$lineage.cell.name..again.

# set up terminal cells and dead cells: 
terminal_cells <- as.character(lineage.cell.name..again.[(lineage.cell.name..again. %in% unique(str_split_fixed(colnames(c_elegans_cds), "_", 2)[, 1]))])
dead_cell <- row.names(subset(waterston_celltypes_filtered, anatomical.cell.name.long == "death"))

pData(c_elegans_cds)$anatomical.cell.name.long <- NA
pData(c_elegans_cds)$anatomical.cell.name.short <- NA
pData(c_elegans_cds)$cell.type.description <- NA
pData(c_elegans_cds)$cell.type <- NA
pData(c_elegans_cds)$tissue.type <- NA

for(cell_iter in row.names(waterston_celltypes_filtered)) {
  message(paste0("current cell_iter is ", cell_iter))
  cell_lineage_names <- get_cell_lineage(cell_iter)
  valid_cell_ids <- which(str_split_fixed(colnames(c_elegans_cds), "_", 2)[, 1] %in% cell_lineage_names)
  
  pData(c_elegans_cds)[valid_cell_ids, 'anatomical.cell.name.long'] <- as.character(waterston_celltypes_filtered[cell_iter, 'anatomical.cell.name.long'])
  pData(c_elegans_cds)[valid_cell_ids, 'anatomical.cell.name.short'] <- as.character(waterston_celltypes_filtered[cell_iter, 'anatomical.cell.name.short'])
  pData(c_elegans_cds)[valid_cell_ids, 'cell.type.description'] <- as.character(waterston_celltypes_filtered[cell_iter, 'cell.type.description'])
  pData(c_elegans_cds)[valid_cell_ids, 'cell.type'] <- as.character(waterston_celltypes_filtered[cell_iter, 'cell.type'])
  pData(c_elegans_cds)[valid_cell_ids, 'tissue.type'] <- as.character(waterston_celltypes_filtered[cell_iter, 'tissue.type'])
}

#######################################################################################################################################
# create the Gardiner plots: (lagged drevi plot, causality plot and the combinatorial logic plot)
#######################################################################################################################################
c_elegans_cds_c_lineage <- c_elegans_cds[, 129945:144880]

plot_lagged_drevi(c_elegans_cds[c('hnd.1', 'hlh.1'), which(pData(c_elegans_cds)[, 'cell.type'] == 'muscle')], gene_pairs_mat = matrix(c('hnd.1', 'hlh.1'), nrow = 1), grid_num = c(40, 40), log = F)
plot_gene_pairs_causality(c_elegans_cds[c('hnd.1', 'hlh.1'), which(pData(c_elegans_cds)[, 'cell.type'] == 'muscle')], gene_pairs_mat = matrix(c('hnd.1', 'hlh.1'), nrow = 1), grid_num = 25, log = F)
plot_comb_logic(c_elegans_cds[c('hnd.1', 'hlh.1', 'unc.120'), which(pData(c_elegans_cds)[, 'cell.type'] == 'body muscle')], gene_pairs_target_mat = matrix(c('hnd.1', 'hlh.1', 'unc.120'), nrow = 1), grid_num = 25, log = F)

qplot(as.numeric(exprs(c_elegans_cds)['hnd.1', ]), exprs(c_elegans_cds)['hlh.1', ])
qplot(as.numeric(exprs(c_elegans_cds_c_lineage)['hnd.1', ]), exprs(c_elegans_cds_c_lineage)['hlh.1', ])

#######################################################################################################################################
# perform tSNE dimension reduction analysis 
#######################################################################################################################################
# tSNE
c_elegans_cds_c_lineage <- reduceDimension(c_elegans_cds_c_lineage, norm_method = 'none', reduction_method = 'tSNE', check_duplicates = F, num_dim = 20) # avoid checking
c_elegans_cds_c_lineage <- clusterCells(c_elegans_cds_c_lineage)
plot_cell_clusters(c_elegans_cds_c_lineage, color_by = 'Time') # cell 
plot_cell_clusters(c_elegans_cds, color_by = 'founder_cell') + xacHelper::nm_theme()

# DM 
dpt_c_elegans <- run_new_dpt(c_elegans_cds_c_lineage)
# plot the result 

# run DDRTree: 
c_elegans_cds <- reduceDimension(c_elegans_cds, norm_method = 'none', max_component = 5) # avoid checking
c_elegans_cds <- orderCells(c_elegans_cds) # avoid checking
plot_cell_trajectory(c_elegans_cds)

#######################################################################################################################################
# show the spatial causality on the embryo 
#######################################################################################################################################

#######################################################################################################################################
# do some BEAM analysis 
#######################################################################################################################################

#######################################################################################################################################
# analyze the gene set collected from the paper 
#######################################################################################################################################

#######################################################################################################################################
# understand the L-R, A-P gene regulation pattern 
#######################################################################################################################################

#######################################################################################################################################
# create a network map like the one in the cell paper to demonstrate the relationship between lineage and gene regulation 
#######################################################################################################################################
cell_network_fig6e <- c("pop.1", "gld.2", "arc.1", "src.1", "mex.3", "par.2", "mom.2", "gsk.3", "mex.5", "pie.1", "wwp.1", "apx.1", 
                        "par.6", "glp.1", "lag.1", "pal.1", "cdc.25.1", "skn.1", "skr.1/2", "hda.1", "rba.1")

#######################################################################################################################################

row.names(c_elegans_cds)[tolower(row.names(c_elegans_cds)) %in% cell_network_fig6e]
# add the temporal RDI on this dataset 
temporal_causality <- calculate_temporal_causality(test_cds[unique(lineage_specific_genes), ], delay = 5, log = FALSE)

# use Hanna's approach to show the temporal RDI value 
pdf(paste0(main_fig_dir, 'temporal_rdi.pdf'), width =  1, height = 2)
plot_temporal_causality(temporal_causality, legend = FALSE)
dev.off()

#######################################################################################################################################
# run the analysis with multiple cells 
# 1. gene_lineage; 2. lineage_cascade; 3. gene_lineage_time
# use the genes from the cascade to create a network for the EMS lineage 
#######################################################################################################################################
gene_lineage <- read.table('./csv_data/gene_lineage')
lineage_cascade <- read.table('./csv_data/lineage_cascade')
gene_lineage_time <- read.table('./csv_data/gene_lineage_time')

#######################################################################################################################################
# analyze the network structure based on data from MS, E lineages 
#######################################################################################################################################

# create a lineage tree for c. elegans: 
all_terminal_cells <- get_all_terminal_cells() # get all the terminal cells on the c. elegans tree 

# set up a data.frame for storing the coordinates for the nodes 
unique_cell_name <- unique(stringr::str_split_fixed(colnames(c_elegans_cds), "_", 2)[, 1]) # unique names for all c. elegans cells

# create a tree object: 

# assign the x / y coordinate values for each cell before making the dendrogram 
lineage_order <- c('AB', 'MS', 'E', 'C', 'D', 'Z2', 'Z3') # P1-P4

lineage_coord <- assign_x_y_values()
ddata <- lineage_coord$ddata
lineage_tree <- lineage_coord$lineage_tree

# post-processing the lineage tree data: 
ddata$cell_id <- as.character(ddata$father)
ddata$cell_id[c(2 * (1:(nrow(ddata) / 3)), 3 * (1:(nrow(ddata) / 3)))]  <- NA

# create the dendrogram plot: 
ggplot(data = ddata) +
  geom_label(aes(label=str_wrap(father,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + coord_flip() + 
  geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end)) + coord_flip() + xlab('') + ylab('Time (min)')

# create new function to visualize the gene expression from a subset of cells

ggplot(data = subset(ddata, father %in% reachable_cells &  target %in% reachable_cells & x_start > 570)) + coord_flip() + 
  geom_label(aes(label=str_wrap(cell_id,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + 
  geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end, color = y_start)) + xlab('') + ylab('Time (min)')

#####################################################################################################################################################################
# apply a recursive procedure to build the lineage tree: 
#####################################################################################################################################################################

# x_coord_recursive <- function(curr_cell = 'P0', lineage_tree, curr_cells_coord) {
#   message('current cell is ', curr_cell)
#   descenants <- neighborhood(lineage_tree, order = 1, nodes = curr_cell, mode = 'out')[[1]]$name[-1]
#   if(length(descenants) == 0 | curr_cells_coord[curr_cell] != 0) {
#     return(curr_cells_coord)
#   }
#     
#   if(all(curr_cells_coord[descenants] != 0)) {
#     curr_cells_coord[curr_cell] <- mean(curr_cells_coord[descenants])
#     # message('update curr_cells_coord for ', curr_cell)
#     
#     return(curr_cells_coord)
#     
#   } else {
#     curr_cells_coord[curr_cell] <- (x_coord_recursive(curr_cell = descenants[1], lineage_tree, curr_cells_coord)[descenants[1]] + 
#       x_coord_recursive(curr_cell = descenants[2], lineage_tree, curr_cells_coord)[descenants[2]]) / 2
#     
#     # curr_cells_coord[curr_cell] <- (res1[descenants[1]] + res2[descenants[2]]) / 2
#     return(curr_cells_coord)
#   }
# }
# 
# list_res <- graph.neighborhood(lineage_tree, order = 1, nodes = all_terminal_cells, mode = 'in')
# res <- unlist(lapply(list_res, function(x) {
#   print(x)
#   V(x)$name[-1]
# }))
# 
# curr_cells_coord <- lineage_coord$lineage_coord[, 1]
# names(curr_cells_coord) <- row.names(lineage_coord$lineage_coord)
# curr_cells_coord <- c(P0 = 0, curr_cells_coord)
# curr_cells_coord[setdiff(names(curr_cells_coord), all_terminal_cells)] <- 0
# curr_cells_coord['EMS'] <- 0
# 
# res2 <- x_coord_recursive(curr_cell = 'P0', lineage_coord$lineage_tree, curr_cells_coord)

########################################################################################################################################
# create expression pattern over lineages 
# 1. create a hc class object; 2. create the figure; 3. add color for the lines; 4. add cell names for each terminal cells 
#######################################################################################################################################

res <- plot_lineage_expression(c_elegans_cds, 'alr.1', ddata = ddata, lineage_tree = lineage_tree, lineage_depth = 250, 
                               lineage_coord = lineage_coord, root_cell = 'MS', show_lineage_pair = TRUE, return_all = T)
plot_lineage_expression(c_elegans_cds, 'pes.1', ddata = ddata, lineage_tree = lineage_tree, lineage_coord = lineage_coord, root_cell = 'MS')
res <- plot_lineage_expression(c_elegans_cds, 'pes.1', ddata = ddata, lineage_tree = lineage_tree, 
                               lineage_coord = lineage_coord, root_cell = 'Cp', show_lineage_pair = TRUE, return_all = T)

#######################################################################################################################################
# 1. perform a lineage branch test to identify all the patterned genes over the c. elegans lineage 
#######################################################################################################################################
lineage_cascade_gene <- lineage_cascade$V1
valid_lineage_cascade_gene <- intersect(lineage_cascade_gene, row.names(c_elegans_cds))
# T28h10.3 -> true value in cds: T28H10.3
# b0336.3 -> true value in cds: B0336.3
# f17c11.1 -> true value in cds: F17C11.1
# pg.2 -> true value in cds: pgp.2 
# C01B7.1 -> true value in cds: sup-37
# missing: T23H4.2 and C0B7.1

s <- unique(c(valid_lineage_cascade_gene, "T28H10.3", "B0336.3", "F17C11.1", "pgp.2", "sup.37"))

valid_lineage_cascade_gene %in% row.names(c_elegans_cds)

#######################################################################################################################################
# 2. calculate the causality score for all those lineage gene pairs over the lineage and space 
#######################################################################################################################################

#######################################################################################################################################
# 3. show the co-expression and causality score in 3D embryo over time 
#######################################################################################################################################
# send data to and ask Tim for this section 
qplot(data = subset(Eala_causality$temp_rdi_res, source == 'end.3' & target == 'end.1'), x = time, y = temp_causality, facets = "~cur_terminal_cell") + xacHelper::nm_theme()
pdf('./Figures/main_figures/end.1_end.3_tempo_causality.pdf', width = 2, height = 1)
qplot(data = subset(Eala_causality$temp_rdi_res, source == 'end.3' & target == 'end.1' & cur_terminal_cell == 'Ealaad'), x = time, y = temp_causality, size = I(0.5)) + 
  xlim(0, 250) + xacHelper::nm_theme() + ylab('Temporal causality') + xlab("time (min)")
dev.off()

curr_terminal_cell <- 'Ealaad'
lineage_path <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = curr_terminal_cell, 'in')[[1]])$name
lineage_path_cells <- unlist(lapply(lineage_path, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
subset_cds <- cds[, lineage_path_cells]
df <- data.frame(exprs = c(as.numeric(exprs(subset_cds)['end.3', ]),  as.numeric(exprs(subset_cds)['end.1', ])),
                 gene_name <- rep(c('end.3', 'end.1'), each = ncol(subset_cds)),
                 time = pData(subset_cds)$time)

qplot(data = df, x = time, y = exprs, color = gene_name)

Ealaad_temp_res <- calculate_temporal_causality(subset_cds[c('end.1', 'end.3'), ], log = F, window_size = 50, verbose = T)
no_smooth_Ealaad_temp_res <- calculate_temporal_causality(subset_cds[c('end.1', 'end.3'), ], log = F, smoothing = F, verbose = T, window_size = 50)

window_sz <- 150
temp_rdi_res <- reshape2::melt(Ealaad_temp_res$rdi_res) #Ealaad_temp_res no_smooth_Ealaad_temp_res
colnames(temp_rdi_res) <- c('time', 'source', 'target', 'temp_causality') # add cell here: 
time <- sort(pData(subset_cds)$time)[-c(1:window_sz)]
temp_rdi_res$time <- time[as.numeric(temp_rdi_res$time)]

qplot(data = subset(temp_rdi_res, source == 1 & target == 2), x = time, y = temp_causality)
qplot(data = subset(temp_rdi_res, source == 2 & target == 1), x = time, y = temp_causality)

df1 <- data.frame(Pseudotime = pData(subset_cds)$time, Expression = exprs(subset_cds)['end.1', ])
test1 <- loess(Expression ~ Pseudotime, df1, span = 0.1)
df2 <- data.frame(Pseudotime = pData(subset_cds)$time, Expression = exprs(subset_cds)['end.3', ])
test2 <- loess(Expression ~ Pseudotime, df2, span = 0.1)

data <- data.frame(prediction = c(predict(test1), predict(test2)), rawdata = c(df1$Expression, df2$Expression), time = rep(df1$Pseudotime, 2), gene_name = rep(c('end.1', 'end.3'), each = nrow(df1)))

pdf('./Figures/main_figures/end.1_end.3.pdf', width = 2, height = 1)
qplot(data = data, x = time, y = prediction, color = I('white'), size = 0.5) + geom_point(aes(data$time, data$rawdata, color = data$gene_name), size = 0.5) + 
  xlim(0, 250) + xacHelper::nm_theme() + xlab('time (min)')
dev.off()

pdf('./Figures/main_figures//end.1_end.3_helper.pdf')
qplot(data = data, x = time, y = prediction, color = I('white'), size = 0.5) + geom_point(aes(data$time, data$rawdata, color = data$gene_name), size = 0.5) + 
  xlim(0, 250) #+ xacHelper::nm_theme() + xlab('time (min)')
dev.off()

qplot(df[, 'Pseudotime'], predict(test)) + geom_point(aes(x = df$Pseudotime, y = df[, 'Expression']), color = 'red')

#######################################################################################################################################
# show the gene expression dynamics over time for all the genes over the all E lineage terminal cells 
#######################################################################################################################################
plot_lineage_expression(c_elegans_cds, 'end.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('end.1')
plot_lineage_expression(c_elegans_cds, 'end.3', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('end.3')
plot_lineage_expression(c_elegans_cds, 'ref.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('ref.1')
plot_lineage_expression(c_elegans_cds, 'nhr.57', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('nhr.57')
plot_lineage_expression(c_elegans_cds, 'dve.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('dve.1')
plot_lineage_expression(c_elegans_cds, 'elt.7', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('elt.7')
plot_lineage_expression(c_elegans_cds, 'tps.2', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('tps.2')
plot_lineage_expression(c_elegans_cds, 'mml.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('mml.1')
plot_lineage_expression(c_elegans_cds, 'elt.2', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('elt.2')
plot_lineage_expression(c_elegans_cds, 'nhr.79', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('nhr.79')
plot_lineage_expression(c_elegans_cds, 'dpy.31', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('dpy.31')
plot_lineage_expression(c_elegans_cds, 'mel.28', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('mel.28')
plot_lineage_expression(c_elegans_cds, 'nhr.68', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('nhr.68')
plot_lineage_expression(c_elegans_cds, 'nob.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('nob.1')
plot_lineage_expression(c_elegans_cds, 'pax.3', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('pax.3')
plot_lineage_expression(c_elegans_cds, 'tlp.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('tlp.1')
plot_lineage_expression(c_elegans_cds, 'ges.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('ges.1')
# "T28H10.3", "B0336.3", "F17C11.1", "pgp.2", "sup.37"
plot_lineage_expression(c_elegans_cds, 'T28H10.3', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('T28H10.3')
plot_lineage_expression(c_elegans_cds, 'B0336.3', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('B0336.3')
plot_lineage_expression(c_elegans_cds, 'F17C11.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('F17C11.1')
plot_lineage_expression(c_elegans_cds, 'pgp.2', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('pgp.2')
plot_lineage_expression(c_elegans_cds, 'sup.37', ddata = ddata, lineage_tree = lineage_tree,
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('sup.37')

#######################################################################################################################################
# run generalized BEAM test on the E lineages and identify all the genes that have bifurcation pattern at each cell division 
#######################################################################################################################################

#######################################################################################################################################
# 2. calculate the causality score for all those lineage gene pairs over the lineage and space 
#######################################################################################################################################
root_cell <- "E"

reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = root_cell, 'out')[[1]])$name
lineage_branch_test <- function(cds, root_cell, lineage_tree, lineage_depth = 250, verbose = FALSE) {
  reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = root_cell, 'out')[[1]])$name
  mathced_cells <- unlist(lapply(reachable_cells, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
  
  res_list <- lapply(reachable_cells, function(curr_root_cell, verbose_flag = verbose) {
    if(verbose_flag) {
      message('current root cell is ', curr_root_cell)
    }
    
    direct_offspring_cells <- V(graph.neighborhood(lineage_tree, 1, nodes = curr_root_cell, 'out')[[1]])$name
    direct_offspring_cells <- setdiff(direct_offspring_cells, curr_root_cell)
    
    if(length(direct_offspring_cells) < 1) {
      return(data.frame(root_cell = curr_root_cell, gene = NA, status = "FAIL", pval = -Inf, 
                        avg_A = -Inf, avg_B = -Inf, occurrence_A = -Inf, occurrence_B = -Inf,
                        onset = -Inf, end = -Inf))
    }
    
    a_reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = direct_offspring_cells[1], 'out')[[1]])$name
    a_mathced_cells <- unlist(lapply(a_reachable_cells, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
    b_reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = direct_offspring_cells[2], 'out')[[1]])$name
    b_mathced_cells <- unlist(lapply(b_reachable_cells, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
    
    subset_cds <- cds[, c(a_mathced_cells, b_mathced_cells)]
    
    pData(subset_cds)[a_mathced_cells, 'Lineage'] <- 'A'
    pData(subset_cds)[b_mathced_cells, 'Lineage'] <- 'B'
    
    subset_cds <- subset_cds[, pData(subset_cds)$time < lineage_depth] 
    
    res <- differentialGeneTest(subset_cds, fullModelFormulaStr = "~sm.ns(time, df = 3) * Lineage", reducedModelFormulaStr = "~sm.ns(time, df = 3)")
    
    stat_res <- apply(exprs(subset_cds), 1, function(x, subset_cds_input = subset_cds) {
      avg_A <- mean(as.matrix(x)[colnames(subset_cds_input) %in% a_mathced_cells])
      avg_B <- mean(as.matrix(x)[colnames(subset_cds_input) %in% b_mathced_cells])
      
      occurrence_A <- sum(as.matrix(x)[colnames(subset_cds_input) %in% a_mathced_cells] > 2000)
      occurrence_B <- sum(as.matrix(x)[colnames(subset_cds_input) %in% b_mathced_cells] > 2000)
      
      onset <- pData(subset_cds_input)$time[min(which(as.numeric(x) > 2000))]
      end <- pData(subset_cds_input)$time[max(which(as.numeric(x) > 2000))]
      
      c(avg_A = avg_A, avg_B = avg_B, 
        occurrence_A = occurrence_A / length(a_mathced_cells), 
        occurrence_B = occurrence_B / length(b_mathced_cells),
        onset = onset, end = end)
    })
    
    stat_res <- as.data.frame(t(stat_res))
    
    res_all <- data.frame(root_cell = curr_root_cell, gene = row.names(res), status = res$status, pval = res$pval, 
                          avg_A = stat_res$avg_A, avg_B = stat_res$avg_B, occurrence_A = stat_res$occurrence_A, occurrence_B = stat_res$occurrence_B, 
                          onset = stat_res$onset, end = stat_res$end)
    
    return(res_all)
  })
  
  res <- do.call(rbind, res_list)
  
}

res <- lineage_branch_test(c_elegans_cds[, ], root_cell, lineage_tree, verbose = T) # valid_lineage_cascade_gene
res$occurrence_fc <- (res$occurrence_A + .Machine$double.eps) / (res$occurrence_B + .Machine$double.eps)
sig_ids <- which(res$occurrence_fc >= 2 | res$occurrence_fc <= 0.5)
length(sig_ids)

valid_res <- res[sig_ids, ]
valid_res %>% group_by(root_cell) %>% summarise(length(gene)) # count the number of time points with unique expression values

plot_lineage_expression(c_elegans_cds, 'nob.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord, root_cell = 'E', show_lineage_pair = TRUE)

valid_gBEAM_genes <- as.character(unique(valid_res$gene))
#######################################################################################################################################
# calculate the MI / RDI for all the gene pairs across each lineage (from E to each to the terminal cells in the E lineage)
#######################################################################################################################################
uMI_res <- calculate_umi(c_elegans_cds[valid_gBEAM_genes, pData(c_elegans_cds)$time < 250], log = F) # run uMI algorithm 

valid_gBEAM_genes_mi_res <- parmigene::knnmi.all(as.matrix(exprs(c_elegans_cds[valid_gBEAM_genes, pData(c_elegans_cds)$time < 250])))
valid_gBEAM_genes_mi_clr_res <- clr(valid_gBEAM_genes_mi_res)
valid_gBEAM_genes_mi_aracne.a_res <- parmigene::aracne.a(valid_gBEAM_genes_mi_res)
valid_gBEAM_genes_mi_aracne.m_res <- parmigene::aracne.m(valid_gBEAM_genes_mi_res)

# visualize the MI (as well as the clr) gene pair 
pheatmap::pheatmap(valid_gBEAM_genes_mi_res)
pheatmap::pheatmap(valid_gBEAM_genes_mi_clr_res)
pheatmap::pheatmap(valid_gBEAM_genes_mi_aracne.a_res)
pheatmap::pheatmap(valid_gBEAM_genes_mi_aracne.m_res)

# high mi score: ceh.93 / hlh.2
# elt2.1 vs. med.2 has the strongest CLR / ARACNE score (visualize it)
plot_lineage_expression(c_elegans_cds, 'elt.2.1', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('elt.2.1')
plot_lineage_expression(c_elegans_cds, 'med.2', ddata = ddata, lineage_tree = lineage_tree, 
                        lineage_coord = lineage_coord$lineage_coord, root_cell = 'E', show_lineage_pair = FALSE, lineage_depth = 250) + ggtitle('med.2')

qplot(as.numeric(exprs(c_elegans_cds['ceh.93', ])), 
      as.numeric(exprs(c_elegans_cds['hlh.2', ])))
qplot(as.numeric(exprs(c_elegans_cds['elt.2.1', ])), 
      as.numeric(exprs(c_elegans_cds['med.2', ])))

# all other pairs: 
mi_thrsld <- 1
df <- data.frame(gene_1 = row.names(valid_gBEAM_genes_mi_res)[which(valid_gBEAM_genes_mi_res > mi_thrsld, arr.ind = T, useNames = T)[, 1]], 
                 gene_2 = row.names(valid_gBEAM_genes_mi_res)[which(valid_gBEAM_genes_mi_res > mi_thrsld, arr.ind = T, useNames = T)[, 2]],
                 mi = valid_gBEAM_genes_mi_res[valid_gBEAM_genes_mi_res > mi_thrsld])

# no inhibition gene pairs 
pdf('./Figures/tmp/high_mi_gene_pairs.pdf')
for(i in 1:nrow(df)) {
  message('running i is ', i)
  p <- qplot(as.numeric(exprs(c_elegans_cds[df[i, 1], ])), 
             as.numeric(exprs(c_elegans_cds[df[i, 2], ]))) + ggtitle(paste(df[i, 1], df[i, 2]))
  print(p)
}
dev.off()

# show some Gardiner plots (pairwise gene interactions, causality plot and combinatorial logic plot): 
# ensure Gardiner functions work well for the large datasets 

# calculate lineage causality score
calculate_lineage_causality <- function(cds, root_cell, lineage_tree, all_terminal_cells, verbose = FALSE, window_size = 10) {
  reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = root_cell, 'in')[[1]])$name
  mathced_cells <- unlist(lapply(reachable_cells, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
  valid_terminal_cells <- intersect(all_terminal_cells, reachable_cells)
  reachable_cells <- setdiff(reachable_cells, 'P0')
  
  rdi_res_list <- lapply(reachable_cells, function(curr_root_cell, verbose_flag = verbose) {
    if(verbose_flag) {
      message('current root cell is ', curr_root_cell)
    }
    
    lineage_path <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = curr_root_cell, 'in')[[1]])$name
    lineage_path_cells <- unlist(lapply(lineage_path, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
    subset_cds <- cds[, lineage_path_cells]
    
    rdi_res <- calculate_rdi(subset_cds[, ], delays = c(1), uniformalize = F, log = F)
    
    mlt_rdi_res <- melt(rdi_res$max_rdi_value)
    colnames(mlt_rdi_res) <- c('source', 'target', 'causality')
    mlt_delay_res <- melt(rdi_res$max_rdi_delays)
    colnames(mlt_delay_res) <- c('source', 'target', 'delay')
    
    res <- merge(mlt_rdi_res, mlt_delay_res, by.x = c(1, 2), by.y = c(1, 2))
    
    res
  })
  
  rdi_res <- do.call(rbind, rdi_res_list)
  
  # or just use root_cell 
  valid_terminal_cells <- reachable_cells[which.max(unlist(lapply(reachable_cells, function(x) nchar(x))))] # the last cells 
  temp_rdi_res_list <- lapply(valid_terminal_cells, function(curr_terminal_cell, verbose_flag = verbose, window_sz = window_size) {
    lineage_path <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = curr_terminal_cell, 'in')[[1]])$name
    lineage_path_cells <- unlist(lapply(lineage_path, function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
    subset_cds <- cds[, lineage_path_cells]
    
    temp_causality_list <- calculate_temporal_causality(subset_cds[, ], delay = c(1), uniformalize = F, log = F, window_size = window_sz)
    temp_rdi_res <- temp_causality_list$rdi_res
    time <- sort(pData(subset_cds)$time)[-c(1:window_sz)]
    dimnames(temp_rdi_res) <- list(time, row.names(subset_cds), row.names(subset_cds))
    
    temp_rdi_res <- reshape2::melt(temp_rdi_res)
    colnames(temp_rdi_res) <- c('time', 'source', 'target', 'temp_causality') # add cell here: 
    temp_rdi_res$time <- time[as.numeric(temp_rdi_res$time)]
    temp_rdi_res$cur_terminal_cell <- curr_terminal_cell
    
    temp_rdi_res
  })
  
  temp_rdi_res <- do.call(rbind, temp_rdi_res_list)
  
  return(list(rdi_res = rdi_res, temp_rdi_res = temp_rdi_res))
}

# test the code: 
pData(c_elegans_cds)$Pseudotime <- pData(c_elegans_cds)$time

as.character(unique(pData(c_elegans_cds[, pData(c_elegans_cds)$time < 250])$cell[grep('^E', pData(c_elegans_cds[, pData(c_elegans_cds)$time < 250])$cell)]))
# [1] "E"     "EMS"   "Ea"    "Eal"   "Eala"  "Ealaa" "Ealap" "Ealp"  "Ealpa" "Ealpp" "Ear"   "Eara"  "Earaa" "Earap" "Earp"  "Earpa" "Earpp" "Ep"    "Epl"   "Epla"  "Eplaa"
# [22] "Eplap" "Eplp"  "Eplpa" "Eplpp" "Epr"   "Epra"  "Epraa" "Eprap" "Eprp"  "Eprpa" "Eprpp"

valid_E_lineage_terminal_cell <- c("Ealaa", "Ealap", "Ealpa", "Ealpp", "Earaa", "Earap", "Earpa", "Earpp", "Eplaa", "Eplap", "Eplpa", "Eplpp", "Epraa", "Eprap", "Eprpa", "Eprpp") 

for(cur_terminal_cells in valid_E_lineage_terminal_cell) {
  message('cur_terminal_cells is ', cur_terminal_cells, " ...")
  assign(cur_terminal_cells, calculate_lineage_causality(c_elegans_cds[valid_gBEAM_genes, ], cur_terminal_cells, lineage_tree, all_terminal_cells))
}

#######################################################################################################################################
# performing temporal RDI for gene pairs with high MI / RDI 
#######################################################################################################################################
# already done above 

#######################################################################################################################################
# calculate the MI in each cell 
#######################################################################################################################################

calculate_cell_uMI <- function(cds, root_cell, lineage_tree, verbose = FALSE) {
  reachable_cells <- V(graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = root_cell, 'out')[[1]])$name
  matched_cells <- row.names(subset(pData(c_elegans_cds), cell %in% reachable_cells))

  umi_res_list <- lapply(reachable_cells, function(current_cell, verbose_flag = verbose) {
    if(verbose_flag) {
      message('current cell is ', current_cell)
    }
    
    cur_cell_names <- row.names(subset(pData(c_elegans_cds), cell %in% current_cell))
    subset_cds <- cds[, cur_cell_names]
    
    # avoid consider cases where there is no enough time point for uMI calculation 
    if(ncol(subset_cds) < 5) {
      return(data.frame(source = NA, target = NA, uMI = NA, current_cell = current_cell, avg_source = NA, avg_target = NA))
    }
    
    #umi_res <- calculate_umi(subset_cds[, ], log = F) # , uniformalize = F
    umi_res <- parmigene::knnmi.all(as.matrix(exprs(subset_cds)))
    mlt_umi_res <- melt(umi_res)
    colnames(mlt_umi_res) <- c('source', 'target', 'uMI')

    mlt_umi_res$current_cell <- current_cell
    
    avg_exprs <- rowMeans(as.matrix(exprs(subset_cds))) 
    mlt_umi_res$avg_source <- avg_exprs[mlt_umi_res$source]
    mlt_umi_res$avg_target <- avg_exprs[mlt_umi_res$target]
    
    return(mlt_umi_res)
  })
  
  umi_res <- do.call(rbind, umi_res_list)
}

# "earap" # duplicated points 
uMI_res <- calculate_cell_uMI(c_elegans_cds, 'E', lineage_tree = lineage_coord$lineage_tree, verbose = T)

expr_threshold <- 0
subset(uMI_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == 'E')
qplot(as.numeric(exprs(c_elegans_cds['pal.1', pData(c_elegans_cds)$cell == 'E'])), as.numeric(exprs(c_elegans_cds['ama.1', pData(c_elegans_cds)$cell == 'E'])))

#######################################################################################################################################
# visualize the causality on the embryo; 
# temporal RDI over the lineage (in supplementary figures, show expression over lineage) (L-R, A-P asymmetry);
# An integrative plot to integrate lineage and gene regulation and causality, etc. 
#######################################################################################################################################
# show the integrative plot 

#######################################################################################################################################
# save the data 
#######################################################################################################################################
save.image('./RData/fig_6_worm.RData')

