###############################################################################################################################################################################################
# alias run_jupyter='module load R/latest; module load python/3.3.3; module load jupyter/1.0.0; jupyter notebook --ip=$(dig +short $(hostname))'
# run jupyter on cluster 
###############################################################################################################################################################################################

# figure 1 
# add the panels 
library(Scribe)
library(monocle)
library(reshape2)
library(viridis)

###############################################################################################################################################################################################
# create panels for making the figure 1 
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig3.RData')
###############################################################################################################################################################################################
neuron_sim_cds

# Zic1, Brn2, Tuj1 
qplot(1:400, exprs(neuron_sim_cds)["Brn2", ]) + monocle:::monocle_theme_opts() 
qplot(1:400, exprs(neuron_sim_cds)["Brn2", ]) + monocle:::monocle_theme_opts() 
qplot(1:400, exprs(neuron_sim_cds)["Brn2", ]) + monocle:::monocle_theme_opts() 

set.seed(2018)
rnorm_val_x <- rnorm(100)
qplot(1:100, rnorm_val_x, geom = 'line')

rnorm_val_y <- c(rnorm(10), (sin(rnorm_val_x[11:100])))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_x_dynamics.pdf', height = 0.75, width = 2.15)
qplot(seq(1, 100, 2), scale(rnorm_val_x)[seq(1, 100, 2)], geom = 'line', size = I(0.25)) + ylim(-3, 3) + monocle:::monocle_theme_opts() + xlab('') + ylab('') # + scale_y_continuous(breaks = seq(-6, 6, 0.5))  + 
  theme(axis.ticks.x = element_blank(), axis.text = element_blank()) 
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_y_dynamics.pdf', height = 0.75, width = 2.15)
qplot(seq(1, 100, 2), scale(rnorm_val_y)[seq(1, 100, 2)], geom = 'line', size = I(0.25)) + ylim(-6, 6)  + monocle:::monocle_theme_opts() + xlab('') + ylab('') # + + scale_y_continuous(breaks = seq(-6, 6, 0.5)) 
  theme(axis.ticks.x = element_blank(), axis.text = element_blank()) 
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_y_dynamics.pdf', height = 6, width = 14)
plot(1:100, scale(rnorm_val_y), tck = 0.02, type='l', lwd=4,  xaxt='n',  ylab='', ylim = c(-8, 8))  + axis(4, tck = 0.02)
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_x_dynamics.pdf', height = 6, width = 14)
plot(1:100, scale(rnorm_val_x), tck = 0.02, type='l', lwd=4,  xaxt='n',  ylab='', ylim = c(-8, 8))  + axis(4, tck = 0.02)
dev.off()

# make 3D scatter plot, kinetic curve and the Taylor diagram 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_3D_scatter.pdf')
scatter3d(x = rnorm_val_y[1:99], y = rnorm_val_y[1:99], z = rnorm_val_y[2:100], 
          point.col = "blue", surface=FALSE)
rgl.postscript('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/fig1_3D_scatter.pdf',fmt="pdf")

# density plot, drevi's approach 
# 
# >>> from sklearn.neighbors.kde import KernelDensity
# >>> import numpy as np
# >>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
# >>> kde = KernelDensity(kernel='gaussian', bandwidth=0.2).fit(X)
# >>> kde.score_samples(X)
# array([-0.41075698, -0.41075698, -0.41076071, -0.41075698, -0.41075698,
#        -0.41076071])

exp(c(-0.41075698, -0.41075698, -0.41076071, -0.41075698, -0.41075698, -0.41076071))
mat <- matrix(c(-1, -1, -2, -1, -3, -2, 1, 1, 2, 1, 3, 2), nrow = 2)
den <- density(mat, bw = 0.2, n = 5)

density(1:10, bw = 0.2, n = 10, from = 1, to = 10)$y
library(MASS)
kde2d_res <- kde2d(mat[1, ], mat[2, ], h = 0.2, n = c(7, 5),  lims = c(range(mat[1, ]), range(mat[2, ])))
log(kde2d_res$z)


########################################################################################################################################################
# new version 
########################################################################################################################################################
nonsmooth.txt_False_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.0', row.names = 1)
nonsmooth.txt_False_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.1', row.names = 1)
nonsmooth.txt_False_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.2', row.names = 1)
nonsmooth.txt_False_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.3', row.names = 1)
nonsmooth.txt_False_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_False_0.4', row.names = 1)

nonsmooth.txt_True_0.0 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.0', row.names = 1)
nonsmooth.txt_True_0.1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.1', row.names = 1)
nonsmooth.txt_True_0.2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.2', row.names = 1)
nonsmooth.txt_True_0.3 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.3', row.names = 1)
nonsmooth.txt_True_0.4 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Results/nonsmooth.txt_True_0.4', row.names = 1)

nosmooth_df_update <- Reduce(rbind, list(nonsmooth.txt_False_0.0, nonsmooth.txt_False_0.1, nonsmooth.txt_False_0.2, nonsmooth.txt_False_0.3, nonsmooth.txt_False_0.4))
smooth_df_update <- Reduce(rbind, list(nonsmooth.txt_True_0.0, nonsmooth.txt_True_0.1, nonsmooth.txt_True_0.2, nonsmooth.txt_True_0.3, nonsmooth.txt_True_0.4))

colnames(nosmooth_df_update) <- c('Correlation', 'MI',  'RDI', 'cRDI', "Granger", 'CCM')
nosmooth_df_update$noise_std <- rep(seq(0.01, 0.20, 0.01), 5); nosmooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); nosmooth_df$smooth = F
colnames(smooth_df_update) <-c('Correlation', 'MI',  'RDI', 'cRDI', "Granger", 'CCM')
smooth_df_update$noise_std <- rep(seq(0.01, 0.20, 0.01), 5);  smooth_df$prob_of_drop  <- rep(seq(0, 0.4, 0.1), each = 20); smooth_df$smooth = T

all_df_update <- rbind(smooth_df_update, nosmooth_df_update)

# update RDI and cRDI: 
smooth_df$RDI <- smooth_df_update$RDI
smooth_df$cRDI <- smooth_df_update$cRDI
nosmooth_df$RDI <- nosmooth_df_update$RDI
nosmooth_df$cRDI <- nosmooth_df_update$cRDI
mlt_all_df <- melt(nosmooth_df, id.vars = c("smooth", "noise_std", "prob_of_drop"))

ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable)) + geom_line(aes(color = variable)) + facet_wrap(~prob_of_drop, nrow  = 1)

mlt_all_df$variable <- as.character(mlt_all_df$variable)
mlt_all_df$variable <- factor(mlt_all_df$variable, levels = rev(c('Cor', 'MI', "Granger", 'CCM',  'RDI', 'cRDI')))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/AUC_diferent_method.pdf', height = 1.5, width = 6)
ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable), size = 0.5) + geom_line(aes(color = variable), size = 0.5) + 
  facet_wrap(~prob_of_drop, nrow  = 1) + nm_theme() + xacHelper::nm_theme() + xlab('Noise (s.d.)') + ylab('AUC') + scale_color_viridis(discrete = T)
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/AUC_diferent_method_helper.pdf', height = 1.5, width = 6)
ggplot(aes(noise_std, value), data = mlt_all_df[mlt_all_df$smooth == F, ]) + geom_point(aes(color = variable), size = 0.5) + geom_line(aes(color = variable), size = 0.5) + 
  facet_wrap(~prob_of_drop, nrow  = 1) + xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T)
dev.off()

########################################################################################################################################################
# understand why do we have the very strange pattern from the results
########################################################################################################################################################

########################################################################################################################################################
# create the 3D cartoon figure to demonstrate the idea of causality 
########################################################################################################################################################
# use the results from the gallery of response functions and rotate those results to put into a 3D cartoon 

########################################################################################################################################################
# prepare the result for benchmarking all different algorithms in detecting causality 
########################################################################################################################################################
# look the file all_estimators  
########################################################################################################################################################
# load and process Arman's final results
########################################################################################################################################################
Arman_res <- read.table('./csv_data/arman_noise_results.csv', sep = ',', row.names = NULL)
nCol <- ncol(Arman_res)
col_names <- colnames(Arman_res)
Arman_res <- Arman_res[, -nCol]
colnames(Arman_res) <- col_names[-1]
Arman_res_mlt <- melt(Arman_res, id.vars = c('Method', 'Repeat'))
Arman_res_mlt$variable <- as.numeric(gsub(Arman_res_mlt$variable, pattern='X', replacement = ''))
colnames(Arman_res_mlt)[3:4] <- c('Noise.std', 'AUC') 

ggplot(aes(Noise.std, AUC), data = subset(Arman_res_mlt, Method == 'ccm')) + #geom_point(aes(color = Method), size = 0.5) +
  geom_smooth(aes(color = Method), size = 0.5) +
  xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T)

subset_Arman_res_mlt <- subset(Arman_res_mlt, Method %in% c('ccm', 'granger', 'rdi', 'crdi', 'urdi', 'ucrdi'))
subset_Arman_res_mlt$Method <- factor(subset_Arman_res_mlt$Method, levels = c('ucrdi', 'crdi', 'urdi', 'rdi', 'ccm', 'granger'))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res.pdf', height = 1.25, width = 1.5)
ggplot(aes(Noise.std, AUC), data = subset(subset_Arman_res_mlt, Method %in% c('crdi', 'rdi', 'ccm', 'granger')) ) + # + geom_point(aes(color = Method), size = 0.5) +
  geom_smooth(aes(color = Method), size = 0.5, method = "loess") + # , method = 'lowess'
  xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T) + xacHelper::nm_theme() #+ ylim(0, 1)
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res_uRDI.pdf', height = 1, width = 1)
ggplot(aes(Noise.std, AUC), data = subset(subset_Arman_res_mlt, Method %in% c('ucrdi', 'crdi', 'urdi', 'rdi')) ) + # + geom_point(aes(color = Method), size = 0.5) +
  geom_smooth(aes(color = Method), size = 0.5, method = "loess") + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T) + xacHelper::nm_theme() #+ ylim(0, 1)
dev.off()
theme(axis.text.x = element_text(angle = 90, hjust = 1))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res_helper.pdf')
ggplot(aes(Noise.std, AUC), data = subset_Arman_res_mlt) + #geom_point(aes(color = Method), size = 0.5) +
  geom_smooth(aes(color = Method), size = 0.5) +
  xlab('Noise (s.d.)') + ylab('') + scale_color_viridis(discrete = T) 
dev.off()

Arman_ROC_res <- read.table('./csv_data/linear_system_results.csv', sep = ',', row.names = NULL)
colnames(Arman_ROC_res)[1:3] <- c('Method', 'Repeat', 'Axis')
Arman_ROC_res_mlt <- melt(Arman_ROC_res, id.vars = c('Method', 'Repeat'))

subset_Arman_ROC_res <- subset(Arman_ROC_res, Repeat == 0)
subset_Arman_ROC_res <- subset_Arman_ROC_res[, -2]
subset_Arman_ROC_res_df <- t(Reduce(cbind, list(subset_Arman_ROC_res[1:2, -c(1:2)],
                                              subset_Arman_ROC_res[3:4, -c(1:2)],
                                              subset_Arman_ROC_res[5:6, -c(1:2)],
                                              subset_Arman_ROC_res[7:8, -c(1:2)],
                                              subset_Arman_ROC_res[9:10, -c(1:2)],
                                              subset_Arman_ROC_res[11:12, -c(1:2)])))
dimnames(subset_Arman_ROC_res_df) <- list(paste0('roc_', 1:nrow(subset_Arman_ROC_res_df)), c('X', 'Y'))
subset_Arman_ROC_res_df <- as.data.frame(subset_Arman_ROC_res_df)
subset_Arman_ROC_res_df$Type <- rep(c('CCM', 'GC', 'RDI (k = 0)', 'RDI (k = 1)', 'uRDI (k = 0)', 'uRDI (k = 1)'), 
                                    each = ncol(subset_Arman_ROC_res[1:2, -c(1:2)]))

subset_Arman_ROC_res_df$Type <- factor(subset_Arman_ROC_res_df$Type, levels = c('uRDI (k = 1)', 'RDI (k = 1)', 'uRDI (k = 0)', 'RDI (k = 0)', 'CCM', 'GC'))
colnames(subset_Arman_ROC_res_df)[1:2] <- c('FPR', 'TPR')

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res_linear.pdf', height = 1.25, width = 1.5)
ggplot(aes(FPR, TPR), data = subset(subset_Arman_ROC_res_df, Type %in% c('RDI (k = 1)', 'RDI (k = 0)', 'CCM', 'GC'))) + 
  geom_line(aes(color = Type)) + scale_color_viridis(discrete = T) + xacHelper::nm_theme() + xlab('False positive rate') + ylab('True positive rate')
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res_linear_helper.pdf')
ggplot(aes(FPR, TPR), data = subset(subset_Arman_ROC_res_df, Type %in% c('RDI (k = 1)', 'RDI (k = 0)', 'CCM', 'GC'))) + geom_line(aes(color = Type)) + scale_color_viridis(discrete = T) 
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/Arman_AUC_res_linear_uRDI.pdf', height = 1, width = 1.2)
ggplot(aes(FPR, TPR), data = subset(subset_Arman_ROC_res_df, Type %in% c('RDI (k = 1)', 'RDI (k = 0)', 'uRDI (k = 0)', 'uRDI (k = 1)'))) + 
  geom_line(aes(color = Type)) + scale_color_viridis(discrete = T) + xacHelper::nm_theme() + xlab('False positive rate') + ylab('True positive rate') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
dev.off()
########################################################################################################################################################
# save the results 
########################################################################################################################################################
save.image('./RData/analysis_Arman_dropout_res.Rdata')
