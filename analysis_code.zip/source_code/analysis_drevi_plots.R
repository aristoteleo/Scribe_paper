# analysis the delay effect on drevi plots: 
library(devtools)
load_all('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/InformationEstimator/')

load("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Monocle 2/first_revision/Monocle2_revision/RData/fig3.RData")
neuron_network$Type <- c('Neuron', 'Oligo', 'Astro', 'Neuron', 'AO', 'Neuron', 'Neuron', 'Neuron', 'Neuron', "Neuron", 
                         'AO', 'AO', 'Astro', 'Oligo', 'Olig', 'Astro', 'Astro', 'Astro', 'Olig', 'Astro', 'Oligo')

fData(neuron_sim_cds)$gene_short_name <- fData(neuron_sim_cds)$gene_short_names

# show the gene-pair density plot:  
plot_gene_pairs(neuron_sim_cds, matrix(c('Zic1', 'Sox8', 'Brn2', 'Myt1L', 'Tuj1', 'Stat3'), ncol = 2, byrow = T))

# show the drevi plot result for all existing edges:  
exprs(neuron_sim_cds) <- 10^(exprs(neuron_sim_cds)) #increase the data avoid the fitting issue
plot_rdi_pairs(neuron_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5)

# x <- all_cell_simulation[1, , 1]
# y <- all_cell_simulation[2, , 1]
# 
# plot_rdi_drevi(x, y, x_label = 'Pax6', y_label = 'Mash1')

# negative controls: 
plot_rdi_pairs(neuron_sim_cds, gene_pairs_mat = matrix(c('Zic1', 'Sox8', 'Brn2', 'Myt1L', 'Tuj1', 'Stat3'), ncol = 2, byrow = T), scales = 'free')

# show the pair-wise gene plot:   
neuron_sim_cds@lowerDetectionLimit <- 0.01
plot_gene_pairs_in_pseudotime(neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[, 1:2]), nrow = 5, ncol = 5)

fData(na_sim_cds)$gene_short_name <- fData(na_sim_cds)$gene_short_names
exprs(na_sim_cds) <- 10^(exprs(na_sim_cds)) #increase the data avoid the fitting issue

plot_gene_pairs_branched_pseudotime(na_sim_cds, gene_pairs_mat = as.matrix(neuron_network)[, 1:2], ncol = 5, nrow = 5) # neuron_sim_cds is not a branch trajectory 

# test temporal RDI, etc. 
rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime(t(exprs(na_sim_cds)[1:12, 1:200]), window_size = 50) #13 mature gives Na values 

rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res

dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])

all_cmbns <- expand.grid(gene_name_vec[1:12], gene_name_vec[1:12])
valid_all_cmbns_df <- data.frame(pair = paste(tolower(all_cmbns$Var1), tolower(all_cmbns$Var2), sep = '_'), pval = 0)

row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
rdi_res <- as.data.frame(rdi_res)
colnames(rdi_res) <- valid_all_cmbns_df$pair

valid_all_cmbns_df <- data.frame(pair = paste(tolower(as.character(neuron_network[, 1])), tolower(as.character(neuron_network[, 2])), sep = '_'), pval = 0)
valid_rdi_res <- rdi_res[, as.character(valid_all_cmbns_df$pair)]
norm_valid_rdi_res <- apply(valid_rdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
pheatmap::pheatmap(norm_valid_rdi_res[, ], cluster_rows = F, cluster_cols = T, annotation_names_col = T)

# plot crdi_res
dim(crdi_res) <- c(dim(crdi_res)[1], dim(crdi_res)[2] * dim(crdi_res)[2])

valid_all_cmbns_df <- data.frame(pair = paste(tolower(all_cmbns$Var1), tolower(all_cmbns$Var2), sep = '_'), pval = 0)
colnames(crdi_res) <- valid_all_cmbns_df$pair

valid_all_cmbns_df <- data.frame(pair = paste(tolower(as.character(neuron_network[, 1])), tolower(as.character(neuron_network[, 2])), sep = '_'), pval = 0)
valid_crdi_res <- crdi_res[, as.character(valid_all_cmbns_df$pair)]
norm_valid_crdi_res <- apply(valid_crdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
pheatmap::pheatmap(norm_valid_crdi_res, cluster_rows = F, cluster_cols = F, annotation_names_col = T)

### work to do at Sat: 
# 1. add ccm, mi, cor, granger, etc. into the package 
# ------------------------------------------------------ done ------------------------------------------------------
# 2. support principal curve for getting the pseudotime after identifying the branch 
reduceDimension <- function(cds,
         max_components=2,
         reduction_method=c("DDRTree", "ICA", 'tSNE', "Principal.curve", "SimplePPT", 'L1-graph', 'SGL-tree'),
         norm_method = c("log", "vstExprs", "none"),
         residualModelFormulaStr=NULL,
         pseudo_expr=NULL,
         relative_expr=TRUE,
         auto_param_selection = TRUE,
         verbose=FALSE,
         scaling = TRUE,
         ...){
  extra_arguments <- list(...)
  set.seed(2016) #ensure results from RNG sensitive algorithms are the same on all calls
  
  FM <- normalize_expr_data(cds, norm_method, pseudo_expr)
  
  #FM <- FM[unlist(sparseApply(FM, 1, sd, convert_to_dense=TRUE)) > 0, ]
  xm <- Matrix::rowMeans(FM)
  xsd <- sqrt(Matrix::rowMeans((FM - xm)^2))
  FM <- FM[xsd > 0,]
  
  if (is.null(residualModelFormulaStr) == FALSE) {
    if (verbose)
      message("Removing batch effects")
    X.model_mat <- sparse.model.matrix(as.formula(residualModelFormulaStr),
                                       data = pData(cds), drop.unused.levels = TRUE)
    
    fit <- limma::lmFit(FM, X.model_mat, ...)
    beta <- fit$coefficients[, -1, drop = FALSE]
    beta[is.na(beta)] <- 0
    FM <- as.matrix(FM) - beta %*% t(X.model_mat[, -1])
  }else{
    X.model_mat <- NULL
  }
  
  if(scaling){
    FM <- as.matrix(Matrix::t(scale(Matrix::t(FM))))
    FM <- FM[!is.na(row.names(FM)), ]
  } else FM <- as.matrix(FM)
  
  if (nrow(FM) == 0) {
    stop("Error: all rows have standard deviation zero")
  }
  
  FM <- FM[apply(FM, 1, function(x) all(is.finite(x))), ] #ensure all the expression values are finite values
  if (is.function(reduction_method)) {
    reducedDim <- reduction_method(FM, ...)
    colnames(reducedDim) <- colnames(FM)
    reducedDimW(cds) <- as.matrix(reducedDim)
    reducedDimA(cds) <- as.matrix(reducedDim)
    reducedDimS(cds) <- as.matrix(reducedDim)
    reducedDimK(cds) <- as.matrix(reducedDim)
    dp <- as.matrix(dist(reducedDim))
    cellPairwiseDistances(cds) <- dp
    gp <- graph.adjacency(dp, mode = "undirected", weighted = TRUE)
    dp_mst <- minimum.spanning.tree(gp)
    minSpanningTree(cds) <- dp_mst
    cds@dim_reduce_type <- "function_passed"
  }
  else{
    reduction_method <- match.arg(reduction_method)
    if (reduction_method == "tSNE") {
      #first perform PCA
      if (verbose)
        message("Remove noise by PCA ...")
      
      # # Calculate the variance across genes without converting to a dense
      # # matrix:
      # FM_t <- Matrix::t(FM)
      # cell_means <- Matrix::rowMeans(FM_t)
      # cell_vars <- Matrix::rowMeans((FM_t - cell_means)^2)
      # Filter out genes that are constant across all cells:
      #genes_to_keep <- expression_vars > 0
      #FM <- FM[genes_to_keep,]
      #expression_means <- expression_means[genes_to_keep]
      #expression_vars <- expression_vars[genes_to_keep]
      # Here✬s how to take the top PCA loading genes, but using
      # sparseMatrix operations the whole time, using irlba.
      
      
      if("num_dim" %in% names(extra_arguments)){ #when you pass pca_dim to the function, the number of dimension used for tSNE dimension reduction is used
        num_dim <- extra_arguments$num_dim #variance_explained
      }
      else{
        num_dim <- 50
      }
      
      irlba_res <- prcomp_irlba(t(FM), n = min(num_dim, min(dim(FM)) - 1),
                                center = TRUE, scale. = TRUE)
      irlba_pca_res <- irlba_res$x
      
      # irlba_res <- irlba(FM,
      #                    nv=min(num_dim, min(dim(FM)) - 1),
      #                        nu=0,
      #                        center=cell_means,
      #                        scale=sqrt(cell_vars),
      #                        right_only=TRUE)
      # irlba_pca_res <- irlba_res$v
      # row.names(irlba_pca_res) <- genes_to_keep
      
      # pca_res <- prcomp(t(FM), center = T, scale = T)
      # std_dev <- pca_res$sdev
      # pr_var <- std_dev^2
      # prop_varex <- pr_var/sum(pr_var)
      # prop_varex <- irlba_res$sdev^2 / sum(irlba_res$sdev^2)
      
      topDim_pca <- irlba_pca_res#[, 1:num_dim]
      
      # #perform the model formula transformation right before tSNE:
      # if (is.null(residualModelFormulaStr) == FALSE) {
      #   if (verbose)
      #     message("Removing batch effects")
      #   X.model_mat <- sparse.model.matrix(as.formula(residualModelFormulaStr),
      #                                      data = pData(cds), drop.unused.levels = TRUE)
      
      #   fit <- limma::lmFit(topDim_pca, X.model_mat, ...)
      #   beta <- fit$coefficients[, -1, drop = FALSE]
      #   beta[is.na(beta)] <- 0
      #   topDim_pca <- as.matrix(FM) - beta %*% t(X.model_mat[, -1])
      # }else{
      #   X.model_mat <- NULL
      # }
      
      #then run tSNE
      if (verbose)
        message("Reduce dimension by tSNE ...")
      
      tsne_res <- Rtsne::Rtsne(as.matrix(topDim_pca), dims = max_components, pca = F,...)
      
      tsne_data <- tsne_res$Y[, 1:max_components]
      row.names(tsne_data) <- colnames(tsne_data)
      
      reducedDimA(cds) <- t(tsne_data) #this may move to the auxClusteringData environment
      
      #set the important information from densityClust to certain part of the cds object:
      cds@auxClusteringData[["tSNE"]]$pca_components_used <- num_dim
      cds@auxClusteringData[["tSNE"]]$reduced_dimension <- t(tsne_data)
      #cds@auxClusteringData[["tSNE"]]$variance_explained <- prop_varex
      
      cds@dim_reduce_type <- "tSNE"
    }
    
    else if (reduction_method == "ICA") {
      # FM <- as.matrix(Matrix::t(scale(Matrix::t(FM))))
      # FM <- FM[!is.na(row.names(FM)), ]
      
      if (verbose)
        message("Reducing to independent components")
      init_ICA <- ica_helper(Matrix::t(FM), max_components,
                             use_irlba = TRUE, ...)
      x_pca <- Matrix::t(Matrix::t(FM) %*% init_ICA$K)
      W <- Matrix::t(init_ICA$W)
      weights <- W
      A <- Matrix::t(solve(weights) %*% Matrix::t(init_ICA$K))
      colnames(A) <- colnames(weights)
      rownames(A) <- rownames(FM)
      S <- weights %*% x_pca
      rownames(S) <- colnames(weights)
      colnames(S) <- colnames(FM)
      reducedDimW(cds) <- as.matrix(W)
      reducedDimA(cds) <- as.matrix(A)
      reducedDimS(cds) <- as.matrix(S)
      reducedDimK(cds) <- as.matrix(init_ICA$K)
      adjusted_S <- Matrix::t(reducedDimS(cds))
      dp <- as.matrix(dist(adjusted_S))
      cellPairwiseDistances(cds) <- dp
      gp <- graph.adjacency(dp, mode = "undirected", weighted = TRUE)
      dp_mst <- minimum.spanning.tree(gp)
      minSpanningTree(cds) <- dp_mst
      cds@dim_reduce_type <- "ICA"
    }
    else if (reduction_method == "DDRTree") {
      # FM <- as.matrix(Matrix::t(scale(Matrix::t(FM))))
      # FM <- FM[!is.na(row.names(FM)), ]
      
      if (verbose)
        message("Learning principal graph with DDRTree")
      
      # TODO: DDRTree should really work with sparse matrices.
      if(auto_param_selection & ncol(cds) >= 100){
        if("ncenter" %in% names(extra_arguments)) #avoid overwrite the ncenter parameter
          ncenter <- extra_arguments$ncenter
        else
          ncenter <- cal_ncenter(ncol(FM))
        #add other parameters...
        ddr_args <- c(list(X=FM, dimensions=max_components, ncenter=ncenter, verbose = verbose),
                      extra_arguments[names(extra_arguments) %in% c("initial_method", "maxIter", "sigma", "lambda", "param.gamma", "tol")])
        #browser()
        ddrtree_res <- do.call(DDRTree, ddr_args)
      } else{
        ddrtree_res <- DDRTree(FM, max_components, verbose = verbose, ...)
      }
      if(ncol(ddrtree_res$Y) == ncol(cds))
        colnames(ddrtree_res$Y) <- colnames(FM) #paste("Y_", 1:ncol(ddrtree_res$Y), sep = "")
      else
        colnames(ddrtree_res$Y) <- paste("Y_", 1:ncol(ddrtree_res$Y), sep = "")
      
      colnames(ddrtree_res$Z) <- colnames(FM)
      reducedDimW(cds) <- ddrtree_res$W
      reducedDimS(cds) <- ddrtree_res$Z
      reducedDimK(cds) <- ddrtree_res$Y
      cds@auxOrderingData[["DDRTree"]]$objective_vals <- ddrtree_res$objective_vals
      
      adjusted_K <- Matrix::t(reducedDimK(cds))
      dp <- as.matrix(dist(adjusted_K))
      cellPairwiseDistances(cds) <- dp
      gp <- graph.adjacency(dp, mode = "undirected", weighted = TRUE)
      dp_mst <- minimum.spanning.tree(gp)
      minSpanningTree(cds) <- dp_mst
      cds@dim_reduce_type <- "DDRTree"
      cds <- findNearestPointOnMST(cds)
    }
    else if(reduction_method == "Principal.curve") {
      dm <- destiny::DiffusionMap(t(FM))

      if (verbose)
        message("Learning principal graph with Principal.curve")
      
      diam_pc <- princurve::principal.curve(dm@eigenvectors[, 1:2]) 
      diam_pc <- as.data.frame(diam_pc$s)
      
      # FM <- as.matrix(Matrix::t(scale(Matrix::t(FM))))
      # FM <- FM[!is.na(row.names(FM)), ]
      
      colnames(ddrtree_res$Y) <- colnames(FM) #paste("Y_", 1:ncol(ddrtree_res$Y), sep = "")

      reducedDimW(cds) <- dm@eigenvectors[, 1:2]
      diam_pc$s <- t(diam_pc$s)
      colnames(diam_pc$s) <- colnames(cds)
        
      reducedDimS(cds) <- diam_pc$s
      reducedDimK(cds) <- diam_pc$s
      cds@auxOrderingData[["Principal.curve"]]$pc_res <- diam_pc
      
      adjusted_K <- Matrix::t(reducedDimK(cds))
      dp <- as.matrix(dist(adjusted_K))
      cellPairwiseDistances(cds) <- dp
      gp <- graph.adjacency(dp, mode = "undirected", weighted = TRUE)
      dp_mst <- minimum.spanning.tree(gp)
      minSpanningTree(cds) <- dp_mst
      cds@dim_reduce_type <- "Principal.curve"
      cds <- findNearestPointOnMST(cds)
    }
    else {
      stop("Error: unrecognized dimensionality reduction method")
    }
  }
  cds
}

# branching_pc <- function(cds = AT12_cds_subset_all_gene, x = 1, y = 2, depth = 1, plotting = T, neighbor_num = 5) {
#   gene_short_name <- NULL
#   sample_name <- NULL
#   lib_info_with_pseudo <- pData(cds)
#   S_matrix <- reducedDimS(cds)
#   if (is.null(S_matrix)) {
#     stop("You must first call reduceDimension() before using this function")
#   }
#   ica_space_df <- data.frame(t(S_matrix[c(x, y), ]))
#   colnames(ica_space_df) <- c("ICA_dim_1", "ICA_dim_2")
#   ica_space_df$sample_name <- row.names(ica_space_df)
#   ica_space_with_state_df <- merge(ica_space_df, lib_info_with_pseudo, 
#                                    by.x = "sample_name", by.y = "row.names")
#   dp_mst <- minSpanningTree(cds)
#   if (is.null(dp_mst)) {
#     stop("You must first call orderCells() before using this function")
#   }
#   edge_list <- as.data.frame(get.edgelist(dp_mst))
#   colnames(edge_list) <- c("source", "target")
#   edge_df <- merge(ica_space_with_state_df, edge_list, by.x = "sample_name", 
#                    by.y = "source", all = TRUE)
#   edge_df <- plyr::rename(edge_df, c(ICA_dim_1 = "source_ICA_dim_1", 
#                                      ICA_dim_2 = "source_ICA_dim_2"))
#   edge_df <- merge(edge_df, ica_space_with_state_df[, c("sample_name", 
#                                                         "ICA_dim_1", "ICA_dim_2")], by.x = "target", by.y = "sample_name", 
#                    all = TRUE)
#   edge_df <- plyr::rename(edge_df, c(ICA_dim_1 = "target_ICA_dim_1", 
#                                      ICA_dim_2 = "target_ICA_dim_2"))
#   diam <- as.data.frame(as.vector(V(dp_mst)[get.diameter(dp_mst, 
#                                                          weights = NA)]$name))
#   colnames(diam) <- c("sample_name")
#   diam <- plyr::arrange(merge(ica_space_with_state_df, diam, 
#                               by.x = "sample_name", by.y = "sample_name"), Pseudotime)
#   pro_state_pseudotime <- diam[as.numeric(diam$State) == min(as.numeric(diam$State)), 
#                                "Pseudotime"]
#   bifurcation_sample <- diam[which(diam$Pseudotime == max(pro_state_pseudotime)), 
#                              ]
#   bifurcation_sample$State <- diam$State[which(diam$Pseudotime == 
#                                                  max(pro_state_pseudotime)) + 1]
#   diam <- rbind(diam[1:which(diam$Pseudotime == max(pro_state_pseudotime)), 
#                      ], bifurcation_sample, diam[(which(diam$Pseudotime == 
#                                                           max(pro_state_pseudotime)) + 1):nrow(diam), ])
#   no_diam_states <- setdiff(lib_info_with_pseudo$State, lib_info_with_pseudo[diam[, 
#                                                                                   1], "State"])
#   
#   reduced_data <- cds@reducedDimS
#   start <- reduced_data[, diam[, 1]]
#   diam_pc <- principal.curve(t(reduced_data[, pData(cds)$State %in% pData(cds[, diam[, 1]])$State]), start = t(start)) 
#   diam_pc <- as.data.frame(diam_pc$s)
#   row.names(diam_pc) <- colnames(cds[, pData(cds)$State %in% pData(cds[, diam[, 1]])$State])
#   diam_pc[, 'State'] <- pData(cds[, pData(cds)$State %in% pData(cds[, diam[, 1]])$State])$State
#   
#   diam <- rbind(diam[1:which(diam$Pseudotime == max(pro_state_pseudotime)), 
#                      ], bifurcation_sample, diam[(which(diam$Pseudotime == 
#                                                           max(pro_state_pseudotime)) + 1):nrow(diam), ])
#   
#   bifurcation_pc <- diam_pc[bifurcation_sample[, 1], ]
#   bifurcation_pc$State <- bifurcation_sample$State
#   
#   diam_pc <- rbind(diam_pc[1:which(row.names(diam_pc) == row.names(bifurcation_pc)), 
#                            ], bifurcation_pc, diam_pc[((which(row.names(diam_pc) == row.names(bifurcation_pc)) + 1):nrow(diam_pc)), ]) #add bifurcation_pc?
#   
#   
#   for (state in no_diam_states) {
#     state_sample <- ica_space_with_state_df[ica_space_with_state_df$State == 
#                                               state, "sample_name"]
#     subset_dp_mst <- induced.subgraph(dp_mst, state_sample, 
#                                       impl = "auto")
#     subset_diam <- as.data.frame(as.vector(V(subset_dp_mst)[get.diameter(subset_dp_mst, 
#                                                                          weights = NA)]$name))
#     # colnames(subset_diam) <- c("sample_name")
#     
#     start <- reduced_data[, subset_diam[, 1]]
#     #add 5 cells near the bifurcation_sample
#     print(bifurcation_sample[, 1])
#     bif_sample_neighbors <- names(sort(cds@cellPairwiseDistances[bifurcation_sample[, 1], ])[1:neighbor_num])
#     subset_cell <- c(colnames(cds)[pData(cds)$State %in% state], bif_sample_neighbors)
#     
#     subset_diam_pc <- principal.curve(t(reduced_data[, subset_cell])) #, start = t(start)) 
#     subset_diam_pc <- as.data.frame(subset_diam_pc$s)
#     subset_diam_pc$State <- state
#     
#     #find the cloeset point to the subset_diam_pc
#     distance  <- as.matrix(dist(rbind(subset_diam_pc[, 1:2], diam_pc[, 1:2])))[row.names(subset_diam_pc), row.names(diam_pc)]
#     
#     distance <- as.matrix(dist(rbind(subset_diam_pc[, 1:2], diam_pc['SRR1034029_0', 1:2])))[row.names(subset_diam_pc), ]
#     
#     neigh_closet <- which(distance == min(distance[distance > 0]), arr.ind = TRUE)
#     
#     linking_pc <- diam_pc[neigh_closet[, 2], ]
#     linking_pc <- diam_pc['SRR1034029_01', ] #the bifurcation point
#     
#     linking_pc$State <- state
#     diam_all <- rbind(diam_pc,  subset_diam_pc) #add linking_pc ?
#     
#     bifurcation_pc$State <- state
#     diam_pc <- rbind(diam_pc, bifurcation_pc, subset_diam_pc)
#   }
#   
#   if(plotting)
#     qplot(reduced_data[1,  ], reduced_data[2, ], geom = 'point', color = pData(cds[, ])$State) + 
#     geom_line(aes(x = V1, y = V2, color = State), data = diam_all)  + monocle_theme_opts() + xlab("component_1") + ylab('component_2')
#   
# }
# ------------------------------------------------------ done ------------------------------------------------------
# 3. provide a time del,ay heatmap plotting function 
plot_time_delay_heatmap <- function(cds, use_gene_short_name = TRUE, cluster_row = TRUE, cluster_cols = TRUE) {
  turning_point <- fData(time_delay)[, c('gene_short_name', 'turning_point')] 
  
  if(use_gene_short_name) {
    if(any(duplicated(turning_point$gene_short_name)))
      stop('gene_short_name column in fData has duplicated points!')
      
    row.names(turning_point) <- turning_point$gene_short_name
  }
  
  time_delay_mat <- matrix(nrow = nrow(turning_point), ncol = nrow(turning_point), 
                           dimnames = list(row.names(turning_point), row.names(turning_point)))
  for(gene_i in row.names(turning_point)) {
    for(gene_j in row.names(turning_point)) {
      time_delay_mat[gene_i, gene_j] <- abs(abs(turning_point[gene_i, 'turning_point']) - abs(turning_point[gene_j, 'turning_point']))
    }
  }
  
  if(any(!is.finite(time_delay_mat))) {
    message('There is NA values in turining points calculated, the time delay is set to 0 by default')
    
    time_delay_mat[!is.finite(time_delay_mat)] <- 0
  }
  
  ph_res <- pheatmap::pheatmap(time_delay_mat[, ], #ph$tree_row$order
                     useRaster = T,
                     cluster_cols=cluster_row, 
                     cluster_rows=cluster_row, 
                     show_rownames=T, 
                     show_colnames=F, 
                     #scale="row",
                     # clustering_distance_rows=row_dist, #row_dist
                     clustering_method = "ward.D2", #
                     # cutree_rows=num_clusters,
                     # cutree_cols = 2,
                     # annotation_row=annotation_row,
                     # annotation_col=annotation_col,
                     # annotation_colors=annotation_colors,
                     # gaps_col = col_gap_ind,
                     treeheight_row = 20, 
                     # breaks=bks,
                     fontsize = 6,
                     # color=hmcols, 
                     silent=TRUE)
  
  grid::grid.rect(gp=grid::gpar("fill", col=NA))
  grid::grid.draw(ph_res$gtable)
}

plot_time_delay_heatmap(lung, use_gene_short_name = F)

# ------------------------------------------------------ done ------------------------------------------------------

# 4. support igraph plot, hiearchy plot 
# layout_as_bipartite, layout_as_star, layout_as_tree, layout_in_circle, layout_nicely, layout_on_grid, layout_on_sphere, layout_randomly, 
# layout_with_dh, layout_with_fr, layout_with_gem, layout_with_graphopt, layout_with_kk, layout_with_lgl, layout_with_mds, layout_with_sugiyama

# currently hiearhical plot support only two hiearchy (consider multiple hiearchies)
plot_network <- function(graph, type = c('igraph', 'hiearchy', 'hive', 'arcdiagram'), layout = NULL, ...) {
  if(type == 'igraph') {
    if(is.null(layout)) {
      if(is.function(layout)) {
        stop("Please make sure layout is a supported FUNCTION from igraph or customized layout FUNCTION")
      } else {
        layout_coord = layout(knn_graph)
      }
    }
    
    plot(knn_graph, layout = layout_coord) #, vertex.size=2, vertex.label=NA, vertex.color = 'black'        
  }
  else if(type == 'hiearchy') {
    res <- level.plot(graph) # create the hiearchical plot 
    
    cus_layout <- res$layout
    master_regulator_id <- cus_layout[, 2] %in% min(unique(cus_layout[, 2])) #1:2 #
    direct_target_id <- cus_layout[, 2] %in% unique(cus_layout[, 2])[order(unique(cus_layout[, 2])) == 2]
    secondary_target_id <- cus_layout[, 2] %in% max(unique(cus_layout[, 2]))
    
    cus_layout[master_regulator_id, 1]
    cus_layout[master_regulator_id, 1] <- c(-10, 10)
    cus_layout[direct_target_id, 1] <- cus_layout[direct_target_id, 1] * 1.5 #order(cus_layout[direct_target_id, 1]) * 2  - length(cus_layout[direct_target_id, 1]) * 20
    cus_layout[secondary_target_id, 1] <- cus_layout[secondary_target_id, 1] * 1#order(cus_layout[secondary_target_id, 1]) * 10 - length(cus_layout[secondary_target_id, 1])  * 5
    
    v_size <- rep(res$vertex.size, nrow(cus_layout))
    v_size[master_regulator_id] <- 12
    v_size[direct_target_id] <- 4#v_size[direct_target_id] * 1.5
    v_size[secondary_target_id] <- 2.5
    
    cus_layout[master_regulator_id, 2] <- 0
    cus_layout[direct_target_id, 2] <- -1
    cus_layout[secondary_target_id, 2] <- -2
    
    res$vertex.label.cex <- rep(0.25, length(v_size))
    res$vertex.label.cex[1:2] <- 1
    res$layout <- cus_layout
    res$bg <- 'white'
    res$vertex.size <- v_size
    
    res$vertex.label <- V(res$g)$name
    res$lab.color <- 'black'
    
    res$vertex.color[1:2] <- c('#BCA0CC')
    res$vertex.color[direct_target_id] <- '#77CCD2'
    res$vertex.color[res$vertex.color == 'orange2'] <- '#7EB044'
    
    secondary_layer_degree <- degree(res$g, v = V(res$g)$name[cus_layout[, 2] == -1], mode = c("out"),
                                     loops = TRUE, normalized = FALSE)
    res$vertex.color[which(cus_layout[, 2] == -1)[secondary_layer_degree == 0]] <- '#F3756C'
    # secondary_layer <- degree(res$g, v = V(res$g)$name[cus_layout[, 2] == -1], mode = c("out"),
    #                           loops = TRUE, normalized = FALSE)
    
    res$vertex.frame.color <- res$vertex.color
    res$vertex.label <- c(res$vertex.label[1:2], rep('', length(res$vertex.label) - 2))
    
    netbiov::plot.netbiov(res)
  }
  else if(type == 'hive') {
    
    # use the hiveR package 
  }
  else if(type == 'arcdiagram') {
    edge <- get.edgelist(graph)
    
    arcplot(edge, ordering=sort(unique(c(edge[, 1], edge[, 2]))), 
            horizontal=TRUE,
            #labels=paste("node",1:10,sep="-"),
            #lwd.arcs=4*runif(10,.5,2), 
            col.arcs=hsv(runif(9,0.6,0.8),alpha=0.4),
            show.nodes=TRUE, pch.nodes=21, cex.nodes=runif(10,1,3), 
            col.nodes="gray80", bg.nodes="gray90", lwd.nodes=2)
    
    # # create the figure according the hiearchical plot 
    # arcplot(edge, ordering=unique(c(edge[, 1], edge[, 2])), horizontal=TRUE,
    #         #labels=paste("node",1:10,sep="-"),
    #         #lwd.arcs=4*runif(10,.5,2), 
    #         col.arcs=hsv(abs(cus_layout) / max(abs(cus_layout)),alpha=0.4),
    #         show.nodes=TRUE, pch.nodes=21, cex.nodes=runif(10,1,3), 
    #         col.nodes="gray80", bg.nodes="gray90", lwd.nodes=2)
  }
}

# 5. show the 3d scatter plot as well as the state space plot; show the network plot 
# 
# 6. make a draft of the vignettee
# 
# 7. finish Sreeram's request and try to implement 3D drevi or the method we proposed 
# 
# 8. improve the comprehensive benchmark result; support density adjustment or not; support the lmi function (corresponding the figure)
# 
# 9. take the residual and make drevi; create a plot function for this 
# ------------------------------------------------------ done ------------------------------------------------------
# show the conditioning drevi plot: 
plot_rdi_pairs(neuron_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, conditioning = T, nrow = 5, ncol = 5)

# x <- all_cell_simulation[2, 1:199, 1]
# y <- all_cell_simulation[3, 2:200, 1]
# y_t_min_1 <- all_cell_simulation[3, 1:199, 1]
# 
# plot_rdi_drevi(x, y, x_label = 'Pax6', y_label = 'Mash1')
# df <- data.frame(y = y, y_t_min_1 = y_t_min_1)
# full_model_fit_curve <- VGAM::vglm(as.formula("y~sm.ns(y_t_min_1, df = 3)"), data = df, family=gaussianff())
# full_model_fit_line <- lm(y~y_t_min_1, data = df)
# 
# qplot(y_t_min_1, predict(full_model_fit_line, data = data.frame(y_t_min_1 = y_t_min_1)))
# qplot(predict(full_model_fit_curve), predict(full_model_fit_line))
# 
# qplot(y_t_min_1, resid(full_model_fit))
# plot_rdi_drevi(x, resid(full_model_fit), x_label = 'Pax6', y_label = 'Mash1')
# 

################################################################################################################################################
# make the time delay plot 
################################################################################################################################################
qplot(exprs(neuron_sim_cds)[1, 1:199], exprs(neuron_sim_cds)[1, 2:200]) + xlab(gene_name_vec[1]) + ylab(gene_name_vec[1])
qplot(exprs(neuron_sim_cds)[2, 1:199], exprs(neuron_sim_cds)[2, 2:200]) + xlab(gene_name_vec[2]) + ylab(gene_name_vec[2])
qplot(exprs(neuron_sim_cds)[3, 1:199], exprs(neuron_sim_cds)[3, 2:200]) + xlab(gene_name_vec[3]) + ylab(gene_name_vec[3])
qplot(exprs(neuron_sim_cds)[4, 1:199], exprs(neuron_sim_cds)[4, 2:200]) + xlab(gene_name_vec[4]) + ylab(gene_name_vec[4])
qplot(exprs(neuron_sim_cds)[5, 1:199], exprs(neuron_sim_cds)[5, 2:200]) + xlab(gene_name_vec[5]) + ylab(gene_name_vec[5])
qplot(exprs(neuron_sim_cds)[6, 1:199], exprs(neuron_sim_cds)[6, 2:200]) + xlab(gene_name_vec[6]) + ylab(gene_name_vec[6])
qplot(exprs(neuron_sim_cds)[7, 1:199], exprs(neuron_sim_cds)[7, 2:200]) + xlab(gene_name_vec[7]) + ylab(gene_name_vec[7])
qplot(exprs(neuron_sim_cds)[8, 1:199], exprs(neuron_sim_cds)[8, 2:200]) + xlab(gene_name_vec[8]) + ylab(gene_name_vec[8])
qplot(exprs(neuron_sim_cds)[9, 1:199], exprs(neuron_sim_cds)[9, 2:200]) + xlab(gene_name_vec[9]) + ylab(gene_name_vec[9])
qplot(exprs(neuron_sim_cds)[10, 1:199], exprs(neuron_sim_cds)[10, 2:200]) + xlab(gene_name_vec[10]) + ylab(gene_name_vec[10])
qplot(exprs(neuron_sim_cds)[11, 1:199], exprs(neuron_sim_cds)[11, 2:200]) + xlab(gene_name_vec[11]) + ylab(gene_name_vec[11])
qplot(exprs(neuron_sim_cds)[12, 1:199], exprs(neuron_sim_cds)[12, 2:200]) + xlab(gene_name_vec[12]) + ylab(gene_name_vec[12])
qplot(exprs(neuron_sim_cds)[13, 1:199], exprs(neuron_sim_cds)[13, 2:200]) + xlab(gene_name_vec[13]) + ylab(gene_name_vec[13])


qplot(exprs(neuron_sim_cds)[1, 1:199], exprs(neuron_sim_cds)[1, 2:200]) + xlab(gene_name_vec[1]) + ylab(gene_name_vec[1])
qplot(exprs(neuron_sim_cds)[2, 1:199], exprs(neuron_sim_cds)[2, 2:200]) + xlab(gene_name_vec[2]) + ylab(gene_name_vec[2])
qplot(exprs(neuron_sim_cds)[3, 1:199], exprs(neuron_sim_cds)[3, 2:200]) + xlab(gene_name_vec[3]) + ylab(gene_name_vec[3])
qplot(exprs(neuron_sim_cds)[4, 1:199], exprs(neuron_sim_cds)[4, 2:200]) + xlab(gene_name_vec[4]) + ylab(gene_name_vec[4])
qplot(exprs(neuron_sim_cds)[5, 1:199], exprs(neuron_sim_cds)[5, 2:200]) + xlab(gene_name_vec[5]) + ylab(gene_name_vec[5])
qplot(exprs(neuron_sim_cds)[6, 1:199], exprs(neuron_sim_cds)[6, 2:200]) + xlab(gene_name_vec[6]) + ylab(gene_name_vec[6])
qplot(exprs(neuron_sim_cds)[7, 1:199], exprs(neuron_sim_cds)[7, 2:200]) + xlab(gene_name_vec[7]) + ylab(gene_name_vec[7])
qplot(exprs(neuron_sim_cds)[8, 1:199], exprs(neuron_sim_cds)[8, 2:200]) + xlab(gene_name_vec[8]) + ylab(gene_name_vec[8])
qplot(exprs(neuron_sim_cds)[9, 1:199], exprs(neuron_sim_cds)[9, 2:200]) + xlab(gene_name_vec[9]) + ylab(gene_name_vec[9])
qplot(exprs(neuron_sim_cds)[10, 1:199], exprs(neuron_sim_cds)[10, 2:200]) + xlab(gene_name_vec[10]) + ylab(gene_name_vec[10])
qplot(exprs(neuron_sim_cds)[11, 1:199], exprs(neuron_sim_cds)[11, 2:200]) + xlab(gene_name_vec[11]) + ylab(gene_name_vec[11])
qplot(exprs(neuron_sim_cds)[12, 1:199], exprs(neuron_sim_cds)[12, 2:200]) + xlab(gene_name_vec[12]) + ylab(gene_name_vec[12])
qplot(exprs(neuron_sim_cds)[13, 1:199], exprs(neuron_sim_cds)[13, 2:200]) + xlab(gene_name_vec[13]) + ylab(gene_name_vec[13])