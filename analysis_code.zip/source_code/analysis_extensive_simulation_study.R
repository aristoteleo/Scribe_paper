# ##########################################################################################################################################################
# # history:
# # v0.1: check all the four functions to generate the dataset for performing an extensive benchmark for the RDI algorithm (7-27)
# # v0.2: run the entire code from scratch 
# # v0.3:
# # v0.4:
# ##########################################################################################################################################################
# 
# # 1. zero-forcing for simulation of dropout
# # 2. sample the time points from different cells randomly (with / without dropout; use correct time or time order by DPT)
# # 3. different cell with the time has a Gaussian distribution (with / without dropout; use correct time or time order by DPT)
# 
# ##########################################################################################################################################################
# # load packages
# ##########################################################################################################################################################
# rm(list = ls())
# 
# library(devtools)
# load_all('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe/')
# 
library(R.matlab)
library(monocle)
library(destiny)
library(diffusionMap)
library(xacHelper)
library(reshape2)
library(stringr)
# 
# capture_rate <- 0.1
# 
# # load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision//RData/fig3.RData')
# # load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/prepare_lung_data.RData')
# 
# main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
# SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
# 
# source('./Scripts/function.R', echo = T)
# ##########################################################################################################################################################
# # helper functions
# ##########################################################################################################################################################
# # two stage model from Characterizing noise structure in single-cell RNA-seq distinguishes genuine from technical stochastic allelic expression
# two_stage_model <- function(Xi, ETheta, VTheta, EGamma, VGamma, Aij, nCell, BV) {
#   nGenes = length(Xi)
#   if (VGamma > 0) {
#     gammaShape = EGamma^2 / VGamma
#     gammaScale = VGamma / EGamma
#   }
#   if (VTheta > 0) {
#     thetaA = ETheta*( (ETheta*(1-ETheta))/VTheta - 1)
#     thetaB = (1-ETheta)*( (ETheta*(1-ETheta))/VTheta - 1)
#   }
#   if (VGamma > 0) {
#     gammaj = rgamma(nCell*nGenes, shape=gammaShape, scale=gammaScale)
#   } else {
#     gammaj = rep(EGamma, nCell*nGenes)
#   }
#   if (VTheta > 0) {
#     thetaj = rbeta(nCell*nGenes, shape1=thetaA, shape2=thetaB)
#   } else {
#     thetaj = rep(ETheta, nCell*nGenes)
#   }
#   if (sum(BV) > 0) {
#     Yi = rgamma(nCell*nGenes, shape=Xi^2/BV, scale=BV/Xi)
#   } else {
#     Yi = rep(Xi, nCell)
#   }
# 
#   # print(gammaj)
#   Zij = rbinom(nGenes, round(Yi), thetaj)
#   Kij = rpois(nGenes, gammaj*Aij*Zij)
#   Kij[Xi==0] = 0
#   Kij
# }
# 
# ETheta <- 0.02102401
# VTheta <- 0
# EGamma <- 47.56466
# VGamma <- 76.80532
# Aij <- 1 #Cell size factor
# BV <- 0 #Biological noise
# 
# ##########################################################################################################################################################
# # DPT pseudotime
# ##########################################################################################################################################################
# # # update the auto_branch detection
# auto_branch <- function (dpt, cells, stats, w_width, nmin = 10L, gmin = 1) {
#   n <- length(cells)
#   stopifnot(n >= nmin)
#   stopifnot(stats$g >= gmin)
#   branches <- cut_branches(dpt[cells, stats$tips], cells, w_width)
#   branch <- matrix(idx_list_to_vec(branches, cells, n), n,
#                    1L)
#   tips <- matrix(logical(n), n, 1L)
#   tips[match(stats$tips, cells), 1L] <- TRUE
#   subs <- mapply(function(idx_sub, i) {
#     if (length(idx_sub) < nmin || !i %in% idx_sub)
#       return(NULL)
#     sub_stats <- tipstats(dpt, idx_sub, i)
#     if (sub_stats$g < gmin)
#       return(NULL)
#     auto_branch(dpt, idx_sub, sub_stats, w_width, nmin, gmin)
#   }, branches, stats$tips, SIMPLIFY = FALSE)
#   nonnull_subs <- vapply(subs, Negate(is.null), logical(1L))
#   if (any(nonnull_subs)) {
#     n_sublevels <- do.call(max, lapply(subs[nonnull_subs],
#                                        function(s) ncol(s$branch)))
#     branch <- cbind(branch, matrix(NA_integer_, n, n_sublevels))
#     tips <- cbind(tips, matrix(NA, n, n_sublevels))
#     for (s in which(nonnull_subs)) {
#       sub <- subs[[s]]
#       idx_sub <- branches[[s]]
#       idx_newcol <- seq.int(ncol(branch) - n_sublevels +
#                               1L, length.out = ncol(sub$branch))
#       stopifnot(ncol(sub$branch) == ncol(sub$tips))
#       branch_offset <- max(branch, na.rm = TRUE)
#       branch[match(idx_sub, cells), idx_newcol] <- sub$branch +
#         branch_offset
#       tips[match(idx_sub, cells), idx_newcol] <- sub$tips
#     }
#   }
#   stopifnot(ncol(branch) == ncol(tips))
#   list(branch = branch, tips = tips)
# }
# 
# just_DPT <- function (dm, tips = random_root(dm), ..., w_width = 0.1) {
#   if (!is(dm, "DiffusionMap"))
#     stop("dm needs to be of class DiffusionMap, not ", class(dm))
#   if (!length(tips) %in% 1:3)
#     stop("you need to specify 1-3 tips, got ", length(tips))
#   dpt <- destiny:::dummy_dpt(dm)
#   all_cells <- seq_len(nrow(dpt))
#   # stats <- destiny:::tipstats(dpt, all_cells, tips)
#   # branches <- auto_branch(dpt, all_cells, stats, w_width)
#   # colnames(branches$branch) <- paste0("Branch", seq_len(ncol(branches$branch)))
#   # colnames(branches$tips) <- paste0("Tips", seq_len(ncol(branches$tips)))
#   # dpt@branch <- branches$branch
#   # dpt@tips <- branches$tips
#   dpt
# }
# 
# run_cell_by_dpt <- function(exp_mat, root = NULL) {
#   exp_mat <- t(exp_mat)
#   duplicated_cells <- duplicated(exp_mat)
# 
#   # avoid dpt to remove duplicated cells
#   exp_mat[duplicated_cells, 1] <-  exp_mat[duplicated_cells, 1] + rnorm(sum(duplicated_cells), sd = min(exp_mat[exp_mat > 0]))
# 
#   dm_res <- DiffusionMap(exp_mat)
#   # qplot(dm_res@eigenvectors[, 1], dm_res@eigenvectors[, 2])
#   if(is.null(root))
#     root = 1
# 
#   dpt_res <- just_DPT(dm_res, tips = root, branching = FALSE)
#   # qplot(dm_res@eigenvectors[, 1], dm_res@eigenvectors[, 2], size = dpt_res$DPT1)
#   # cor(order(dpt_res$DPT1), 1:length(dpt_res$DPT1))
#   # qplot(order(dpt_res$DPT1), 1:length(dpt_res$DPT1))
# 
#   order_exp_mat <- t(exp_mat[order(dpt_res[root, ]), ])
#   return(order_exp_mat)
# }
# 
# # just set 90% of the genes to zero
# zero_forcing <- function(data, drop_rate = 0.1) {
#   dims <- dim(data)
#   element_num <- dims[1] * dims[2]
# 
#   drop_out_position <- sample(1:element_num, drop_rate * element_num) # sample based on the expression value (high expressed gene has low dropout)
#   data[drop_out_position] <- 0
# 
#   return(data)
#  }
# # two_stage_model(1, ETheta, VTheta, EGamma, VGamma, Aij, nCell = 1, BV)
# #
# # dropout based on 0.9^n (consider implement the logistic function later)
# drop_out <- function(n, one_transcript_val, capture_rate) { # one_transcript_val: expression level corresponding to one transcript
#   n_new <- n / one_transcript_val
#   drop_out_p <- (1 - capture_rate)^n_new
# 
#   cell_num <- length(n_new)
#   sample_res <- sample(c(rep(0, cell_num), rep(1, cell_num)), size = cell_num, replace = F, prob = c(drop_out_p, 1 - drop_out_p))
# 
#   n[sample_res == 0] <- 0
#   return(n)
# }
# # dropout based on Sreeram's suggestion (Poisson distribution for the data)
# dropout_rate <- function(capture_rate, num_transcript) {
#   (1 - capture_rate)^num_transcript
# }
# 
# sreeram_drop_out <- function(n, assumed_value, capture_rate, type = c('poisson', 'zipoisson', 'negbinomial', 'zinegbinomial')) {
#   if(type == 'poisson') {
#     res_list <- lapply(n, function(x) rpois(1, x))
#   }
#   else if(type == 'zipoisson') {
#     res_list <- lapply(n, function(x) rzipois(1, x, pstr0 = dropout_rate(capture_rate, x)))
#   }
#   else if(type == 'negbinomial') {
#     res_list <- lapply(n, function(x) rzinegbin(1, size = disp_func(x), mu = x, pstr0 = 0))
#   }
#   else if(type == 'zinegbinomial') {
#     res_list <- lapply(n, function(x) rzinegbin(1, size = disp_func(x), mu = x, pstr0 = dropout_rate(capture_rate, x)))
#   }
# 
#   res <- unlist(res_list)
#   return(res)
# }
# 
# ##########################################################################################################################################################
# # create a CDS based on simulation data
# # how to create the read counts from a negative binomial distribution?
# #
# ##########################################################################################################################################################
# createTenxCDSfromSimulation <- function(simulation_data, assumed_cell_types, gene_num = 5000, expected_total_mRNAs = 5000) {
#   num_sim_genes <- nrow(simulation_data)
#   num_sim_cells <- ncol(simulation_data)
# 
#   set.seed(2016)
# 
#   #random sample coefficients of genes in each lineage
#   transcriptome_basedon_simulated_data <- matrix(rep(0, gene_num * num_sim_cells), ncol = num_sim_cells)
#   random_coefficients_df <- matrix(runif(num_sim_genes * gene_num, min = 0, max = 1), ncol = gene_num)
# 
#   # use negative binomial distribution
#   # rng_res <- matrix(rnbinom(num_sim_genes * gene_num, prob = 0, mu = 1), ncol = gene_num)
#   # rng_res <- (rng_res - min(rng_res)) / (max(rng_res) - min(rng_res))
# 
#   random_coefficients_df <- t(random_coefficients_df)
# 
#   for(i in unique(assumed_cell_types)) {
#     current_cell_type_ids <- which(assumed_cell_types == i)
# 
#     # switch lineage may be not necessary
#     switch (i,
#             "neuron" = random_coefficients_df[, 6:12] <- 0.1,
#             "astrocyte" = random_coefficients_df[, c(2:5, 8, 10, 12)] <- 0.1,
#             "oligodendrocyte" = random_coefficients_df[, c(2:5, 7, 9, 11)] <- 0.1
#     )
# 
#     transcriptome_basedon_simulated_data[, current_cell_type_ids] <- random_coefficients_df %*% simulation_data[, current_cell_type_ids]
#   }
# 
#   transcriptome_basedon_simulated_data <- rbind(transcriptome_basedon_simulated_data, simulation_data)
# 
#   # transcriptome_simulated <- apply(transcriptome_basedon_simulated_data, 2, function(x) x / sum(x) * expected_total_mRNAs)
#   transcriptome_simulated <- transcriptome_basedon_simulated_data
# 
#   res <- transcriptome_simulated
#   return(res)
# }
# 
# ################################################################################################################################################
# # Same cell but fixed time with Monocle 2  (Same cell means observing the same cell over time)
# ################################################################################################################################################
# same_cell_correct_time_pseudotime <- function(all_cell_simulation, num_sample = 25, probs = 0.2, cell_type = 'neuron') {
#   gene_steps_cell <- dim(all_cell_simulation)
#   
#   all_new_files <- c(paste0("./csv_data/", cell_type, "same_cell_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_realtime_zero_forcing.txt"),
#                      paste0("./csv_data/", cell_type, "same_cell_realtime_two_stage_dropout.txt"),
#                      paste0("./csv_data/", cell_type, "same_cell_realtime_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_zero_forcing_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_two_stage_dropout_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_dropout_pseudotime.txt"))
#   unlink(all_new_files, recursive = FALSE)
#   
#   set.seed(2017)
#   cells_sampled <- sample(1:gene_steps_cell[3], num_sample)
# 
#   for(i in cells_sampled) {
#     message('sample id ', i)
#     data <- all_cell_simulation[, , i]
# 
#     #############################################################################################################################################################################################
#     # save the raw data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(data, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_vec <- as.vector(data)
#     quantile_val <- quantile(data_vec[data_vec > 0], probs = probs)
#     message('quantile_val is ', quantile_val)
# 
#     # save dropout data without running DPT
#     zero_forcing_drop_out_p <- zero_forcing(data, drop_rate = 0.1) #t(apply(data, 1, function(x) zero_forcing(x, drop_rate = 0.9))) # replace by the more sophisticated dropout approach
#     two_stage_drop_out_p <- t(apply(data, 1, function(x) two_stage_model(round(x / quantile_val), ETheta, VTheta, EGamma, VGamma, Aij, nCell = 1, BV))) # replace by the more sophisticated dropout approach
#     drop_out_p <- t(apply(data, 1, function(x) drop_out(x, quantile_val, capture_rate = 0.1))) # replace by the more sophisticated dropout approach
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), zero_forcing_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_realtime_zero_forcing.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), two_stage_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_realtime_two_stage_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_realtime_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     # save dropout data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(zero_forcing_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_zero_forcing_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(two_stage_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_two_stage_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     #############################################################################################################################################################################################
#     num_dropout <- sum(as.vector(drop_out_p) == 0 & as.vector(data) != 0)
# 
#     print(num_dropout / sum(as.vector(data) != 0))
#   }
# }
# 
# ################################################################################################################################################
# # Same cell but Gaussian time with Monocle 2
# # ---------------------------------------------------- Need to update the sample steps ----------------------------------------------------
# ################################################################################################################################################
# same_cell_gaussian_time_pseudotime <- function(all_cell_simulation, num_sample = 25, probs = 0.2, sd = 5, cell_type = 'neuron') {
#   gene_steps_cell <- dim(all_cell_simulation)
#   all_new_files <- c(paste0("./csv_data/", cell_type, "same_cell_gaussian_time.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_pseudotime.txt"),
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_zero_time_forcing.txt"),
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_time_two_stage_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_time_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_zero_forcing_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_two_stage_dropout_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "same_cell_gaussian_dropout_pseudotime.txt"))
#   unlink(all_new_files, recursive = FALSE)
#   
#   set.seed(2017)
#   cells_sampled <- sample(1:gene_steps_cell[3], num_sample)
# 
#   for(i in cells_sampled) {
#     message('sample id ', i)
# 
#     # do this for a subset of all cells sequence: gene_steps_cell -->
#     time_series_cell <- unlist(lapply(1:gene_steps_cell[2], function(x) rnorm(1, mean = x, sd = sd))) # the real time is sampled from a distribution
#     invalid_ids <- c(which(time_series_cell < 1), which(time_series_cell > gene_steps_cell[2])) # any index below 0 and above maximal steps are invid
# 
#     message('length of invalid IDs is ', length(invalid_ids))
#     time_series_cell[which(time_series_cell < 1)] <- 1
#     time_series_cell[which(time_series_cell > gene_steps_cell[2])] <- gene_steps_cell[2]
# 
#     data <- c()
#     for(j in 1:gene_steps_cell[3]) {
#       data <- cbind(data, all_cell_simulation[, time_series_cell[j], i])
#     }
# 
#     #save the Gaussian distributed pseudotime
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_time.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     #############################################################################################################################################################################################
#     # save the raw data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(data, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order) # remove duplicated cells
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_vec <- as.vector(data)
#     quantile_val <- quantile(data_vec[data_vec > 0], probs = probs)
#     message('quantile_val is ', quantile_val)
# 
#     # save dropout data without running DPT
#     zero_forcing_drop_out_p <- zero_forcing(data, drop_rate = 0.1) #t(apply(data, 1, function(x) zero_forcing(x, drop_rate = 0.9))) # replace by the more sophisticated dropout approach
#     two_stage_drop_out_p <- t(apply(data, 1, function(x) two_stage_model(round(x / quantile_val), ETheta, VTheta, EGamma, VGamma, Aij, nCell = 1, BV))) # replace by the more sophisticated dropout approach
#     drop_out_p <- t(apply(data, 1, function(x) drop_out(x, quantile_val, capture_rate = 0.1))) # replace by the more sophisticated dropout approach
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), zero_forcing_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_zero_time_forcing.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), two_stage_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_time_two_stage_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_time_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     # save dropout data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(zero_forcing_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_zero_forcing_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(two_stage_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_two_stage_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "same_cell_gaussian_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     #############################################################################################################################################################################################
# 
#     num_dropout <- sum(as.vector(drop_out_p) == 0 & as.vector(data) != 0)
# 
#     print(num_dropout / sum(as.vector(data) != 0))
#   }
# }
# 
# ###############################################################################################################################################
# # different cell but fixed time with Monocle 2 (as well as the result after running dpt)
# ###############################################################################################################################################
# sample_cell_correct_time_pseudotime <- function(all_cell_simulation, num_sample = 25, probs = 0.2, sd = 5, cell_type = 'neuron') {
#   gene_steps_cell <- dim(all_cell_simulation)
# 
#   set.seed(2017)
#   all_new_files <- c(paste0("./csv_data/", cell_type, "different_cell_realtime.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_pseudotime.txt"),
#                      paste0("./csv_data/", cell_type, "different_cell_realtime_zero_forcing.txt"),
#                      paste0("./csv_data/", cell_type, "different_cell_realtime_two_stage_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_realtime_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_zero_forcing_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_two_stage_dropout_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_dropout_pseudotime.txt"))
#   unlink(all_new_files, recursive = FALSE)
#   for(i in 1:num_sample) {
#     message('sample id ', i)
# 
#     message('current sampling iteration ...')
#     time_series_cell <- sort(sample(1:gene_steps_cell[2], gene_steps_cell[3])) # sample this number of steps
#     data <- c()
#     for(j in 1:gene_steps_cell[3]) {
#       data <- cbind(data, all_cell_simulation[, time_series_cell[j], j])
#     }
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_realtime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     #############################################################################################################################################################################################
#     # save the raw data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(data, which.min(time_series_cell))
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order) # remove duplicated cells
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_vec <- as.vector(data)
#     quantile_val <- quantile(data_vec[data_vec > 0], probs = probs)
#     message('quantile_val is ', quantile_val)
# 
#     # save dropout data without running DPT
#     zero_forcing_drop_out_p <- zero_forcing(data, drop_rate = 0.1) #t(apply(data, 1, function(x) zero_forcing(x, drop_rate = 0.9))) # replace by the more sophisticated dropout approach
#     two_stage_drop_out_p <- t(apply(data, 1, function(x) two_stage_model(round(x / quantile_val), ETheta, VTheta, EGamma, VGamma, Aij, nCell = 1, BV))) # replace by the more sophisticated dropout approach
#     drop_out_p <- t(apply(data, 1, function(x) drop_out(x, quantile_val, capture_rate = 0.1))) # replace by the more sophisticated dropout approach
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), zero_forcing_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_realtime_zero_forcing.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), two_stage_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_realtime_two_stage_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_realtime_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     
#     # save dropout data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(zero_forcing_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_zero_forcing_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(two_stage_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_two_stage_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     #############################################################################################################################################################################################
# 
#   }
# }
# ################################################################################################################################################
# # different cell but Gaussian time with Monocle 2
# # ---------------------------------------------------- Need to update the sampling steps ----------------------------------------------------
# ################################################################################################################################################
# 
# # different cell with the time has a Gaussian distribution with Monocle 2
# sample_cell_gaussian_time_pseudotime <- function(all_cell_simulation, num_sample = 25, probs = 0.2, sd = 5, cell_type = 'neuron') {
#   gene_steps_cell <- dim(all_cell_simulation)
#   all_new_files <- c(paste0("./csv_data/", cell_type, "different_cell_gaussian_time.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_pseudotime.txt"),
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_time_zero_forcing.txt"),
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_time_two_stage_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_time_dropout.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_zero_forcing_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_two_stage_dropout_pseudotime.txt"), 
#                      paste0("./csv_data/", cell_type, "different_cell_gaussian_dropout_pseudotime.txt"))
#   unlink(all_new_files, recursive = FALSE)
#   set.seed(2017)
#   for(i in 1:num_sample) {
#     message('sample id ', i)
# 
#     time_series_cell <- unlist(lapply(1:gene_steps_cell[2], function(x) rnorm(1, mean = x, sd = sd))) # the real time is sampled from a distribution
#     invalid_ids <- c(which(time_series_cell < 1), which(time_series_cell > gene_steps_cell[2])) # any index below 0 and above maximal steps are invid
# 
#     message('length of invalid IDs is ', length(invalid_ids))
#     time_series_cell[which(time_series_cell < 1)] <- 1
#     time_series_cell[which(time_series_cell > gene_steps_cell[2])] <- gene_steps_cell[2]
# 
#     data <- c()
#     for(j in 1:gene_steps_cell[3]) {
#       data <- cbind(data, all_cell_simulation[, time_series_cell[j], j])
#     }
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_time.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     #############################################################################################################################################################################################
#     # save the raw data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(data, which.min(time_series_cell))
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order) # remove duplicated cells
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_vec <- as.vector(data)
#     quantile_val <- quantile(data_vec[data_vec > 0], probs = probs)
#     message('quantile_val is ', quantile_val)
# 
#     # save dropout data without running DPT
#     zero_forcing_drop_out_p <- zero_forcing(data, drop_rate = 0.1) #t(apply(data, 1, function(x) zero_forcing(x, drop_rate = 0.9))) # replace by the more sophisticated dropout approach
#     two_stage_drop_out_p <- t(apply(data, 1, function(x) two_stage_model(round(x / quantile_val), ETheta, VTheta, EGamma, VGamma, Aij, nCell = 1, BV))) # replace by the more sophisticated dropout approach
#     drop_out_p <- t(apply(data, 1, function(x) drop_out(x, quantile_val, capture_rate = 0.1))) # replace by the more sophisticated dropout approach
# 
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), zero_forcing_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_time_zero_forcing.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), two_stage_drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_time_two_stage_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), drop_out_p)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_time_dropout.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     # save dropout data after running DPT
#     data_pseudotime_order <- run_cell_by_dpt(zero_forcing_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_zero_forcing_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(two_stage_drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_two_stage_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
# 
#     data_pseudotime_order <- run_cell_by_dpt(drop_out_p, 1)
#     output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), data_pseudotime_order)
#     write.table(output_res, paste0("./csv_data/", cell_type, "different_cell_gaussian_dropout_pseudotime.txt"), append = T, quote=F, col.names=F, row.names=F, sep="\t")
#     #############################################################################################################################################################################################
# 
#   }
# }
# 
# ##########################################################################################################################################################
# # load data
# ##########################################################################################################################################################
# gene_name_vec <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')
# 
# # arman_result <- read.table('/Users/xqiu/Downloads/simulation_expr_mat (2).txt', sep = '\t', header = F)
# #
# # cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/neuron_network/cell_simulate_13_10002_1000.mat')
# # cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/neuron_network/cell_simulate.mat')
# # all_cell_simulation <- cell_simulate$cell.simulate[, 1:10002, ] #time 0-20 are the period two branches appear
# 
# cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')
# all_cell_simulation <- cell_simulate$cell.simulate[, 1:400, ] #time 0-20 are the period two branches appear
# 
# row.names(all_cell_simulation) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')
# 
# #obtain the corresponding lineage for each simulation run:
# neuron_cell_ids <- which(all_cell_simulation['Mash1', 400, ] > 2.9)
# astrocyte_cell_ids <- which(all_cell_simulation['Scl', 400, ] > 1.9)
# oligodendrocyte_cell_ids <- which(all_cell_simulation['Olig2', 400, ] > 1.9)
# 
# cell_type_id_list <- list(neuron = neuron_cell_ids, astrocyte = astrocyte_cell_ids, oligodendrocyte = oligodendrocyte_cell_ids)
# 
# # ##########################################################################################################################################################
# # # Simulate a transcriptome from the neuron simulation data (Test Cole's idea)
# # ##########################################################################################################################################################
# # neuron_cell_simulation <- exprs(neuron_sim_cds)
# #
# # transcriptome_simulated <- createTenxCDSfromSimulation(neuron_cell_simulation, assumed_cell_types = rep('neuron', ncol(neuron_cell_simulation)), gene_num = 1500, expected_total_mRNAs = 50000)
# #
# # dm_res <- DiffusionMap(t(transcriptome_simulated))
# #
# # dpt_res <- just_DPT(dm_res)
# # print(cor(c(1:ncol(neuron_cell_simulation))[1:200], order(dpt_res$DPT1[1:200])))
# #
# # transcriptome_simulated_DDRTree_res <- DDRTree(transcriptome_simulated, dimensions = 3, verbose = T, initial_method = PCA) #ncenter = 1000, , maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2
# #
# # realtime <- 1:ncol(transcriptome_simulated)
# # qplot(transcriptome_simulated_DDRTree_res$Y[1, ], transcriptome_simulated_DDRTree_res$Y[2, ], size = realtime) +
# #   xlab('Component 1') + ylab('Component 2')#
# #
# # print(cor(c(1:ncol(neuron_cell_simulation))[1:200], order(dpt_res$DPT1[1:200])))
# #
# # for(gene_num in c(1000, 1500, 2000, 3000, 5000)) {
# #   message('gene_num is ', gene_num)
# #   transcriptome_simulated <- createTenxCDSfromSimulation(neuron_cell_simulation, assumed_cell_types = rep('neuron', ncol(neuron_cell_simulation)),
# #                                                          gene_num = gene_num, expected_total_mRNAs = 50000)
# #
# #   dm_res <- DiffusionMap(t(transcriptome_simulated))
# #
# #   dpt_res <- just_DPT(dm_res)
# #   print(cor(c(1:length(order(dpt_res$DPT1))), order(dpt_res$DPT1)))
# #
# #   transcriptome_simulated_DDRTree_res <- DDRTree(transcriptome_simulated, dimensions = 3, verbose = T, initial_method = PCA) #ncenter = 1000, , maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2
# #
# #   realtime <- 1:ncol(transcriptome_simulated)
# #   qplot(transcriptome_simulated_DDRTree_res$Y[1, ], transcriptome_simulated_DDRTree_res$Y[2, ], size = realtime) +
# #     xlab('Component 1') + ylab('Component 2')#
# #
# #   p <- qplot(dm_res$DC1, dm_res$DC2, color = c(1:length(order(dpt_res$DPT1))), size = I(0.5)) + xlab('DC 1') + ylab('DC 2') + nm_theme() +
# #     theme(axis.text.x = element_text(angle = 30, hjust = .9))
# #
# #   pdf(paste(SI_fig_dir, gene_num, "_dpt.pdf", sep = ''), height = 1, width = 1)
# #   print(p)
# #   dev.off()
# # }
# #
# # ##########################################################################################################################################################
# # # Perform the two-stage models for generating read counts
# # ##########################################################################################################################################################
# #
# # for(gene_num in c(1000, 1500, 2000, 3000, 25000)) {
# #   message('gene_num is ', gene_num)
# #   transcriptome_simulated <- createTenxCDSfromSimulation(neuron_cell_simulation, assumed_cell_types = rep('neuron', ncol(neuron_cell_simulation)),
# #                                                          gene_num = gene_num, expected_total_mRNAs = 50000)
# #
# #   transcriptome_simulated_update <- apply(transcriptome_simulated[, ], 1, function(x)
# #     two_stage_model(x, ETheta, VTheta, EGamma, VGamma, rep(Aij, length(x)), nCell = 1, rep(BV, length(x))))
# #
# #   dm_res <- DiffusionMap(transcriptome_simulated_update)
# #
# #   dpt_res <- just_DPT(dm_res)
# #   print(cor(c(1:length(order(dpt_res$DPT1))), order(dpt_res$DPT1)))
# #
# #   transcriptome_simulated_DDRTree_res <- DDRTree(transcriptome_simulated, dimensions = 3, verbose = T, initial_method = PCA) #ncenter = 1000, , maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2
# #
# #   realtime <- 1:ncol(transcriptome_simulated)
# #   qplot(transcriptome_simulated_DDRTree_res$Y[1, ], transcriptome_simulated_DDRTree_res$Y[2, ], size = realtime) +
# #     xlab('Component 1') + ylab('Component 2')#
# #
# #   p <- qplot(dm_res$DC1, dm_res$DC2, color = c(1:length(order(dpt_res$DPT1))), size = I(0.5)) + xlab('DC 1') + ylab('DC 2') + nm_theme() +
# #     theme(axis.text.x = element_text(angle = 30, hjust = .9))
# #
# #   pdf(paste(SI_fig_dir, gene_num, "_dpt_two_stage_model.pdf", sep = ''), height = 1, width = 1)
# #   print(p)
# #   dev.off()
# # }
# #
# ##########################################################################################################################################################
# # do the entire analysis for each lineage
# ##########################################################################################################################################################
# cell_type <- 'neuron'
# for(cell_type in c('neuron', 'astrocyte', 'oligodendrocyte')) {
#   # add sampling 25 raw simulation dataset
# 
# 
#   all_cell_simulation <- cell_simulate$cell.simulate[, , cell_type_id_list[[cell_type]]]
#   row.names(all_cell_simulation) <- gene_name_vec
# 
#   # perform all downstream analysis:
#   # message('Running same_cell_correct_time_pseudotime ...')
#   # # save the data to check why do the program crash
#   # # debug(same_cell_correct_time_pseudotime) # crash after zero-forcing part
#   #
#   # same_cell_correct_time_pseudotime(all_cell_simulation, cell_type = cell_type)
#   #
#   # message('Running same_cell_gaussian_time_pseudotime ...')
#   # same_cell_gaussian_time_pseudotime(all_cell_simulation, cell_type = cell_type)
# 
#   message('Running sample_cell_correct_time_pseudotime ...')
#   sample_cell_correct_time_pseudotime(all_cell_simulation, cell_type = cell_type)
# 
#   message('Running sample_cell_gaussian_time_pseudotime ...')
#   sample_cell_gaussian_time_pseudotime(all_cell_simulation, cell_type = cell_type)
# }
# 
# # Run RDI / cRDI on the above sampled datasets and then show the benchmark result and draw conclusion, regarding
# # to pseudotime, real time, dropout rate as well as the read counts from the two stage model and the real expression
# # value
# 
# # calculate the pseudotime ordering performance under different cases
# 
# 
# # 1. box plot for AUC
# 
# # read the file and then calculate the RDI values for each pair of genes
# # a. same cell but with Pseudotime
# neuronsame_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_pseudotime.txt', sep = '\t')
# astrocytesame_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_pseudotime.txt', sep = '\t')
# oligodendrocytesame_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_pseudotime.txt', sep = '\t')
# 
# # b. same cell real time but with zero-forcing
# neuronsame_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_realtime_zero_forcing.txt', sep = '\t')
# astrocytesame_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_realtime_zero_forcing.txt', sep = '\t')
# oligodendrocytesame_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_realtime_zero_forcing.txt', sep = '\t')
# 
# # c. same cell but with time sampled from a Guassian distribution
# neuronsame_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_gaussian_time.txt', sep = '\t')
# astrocytesame_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_gaussian_time.txt', sep = '\t')
# oligodendrocytesame_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_gaussian_time.txt', sep = '\t')
# 
# # d. same cell but with time sampled from a Guassian distribution
# neuronsame_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_gaussian_pseudotime.txt', sep = '\t')
# astrocytesame_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_gaussian_pseudotime.txt', sep = '\t')
# oligodendrocytesame_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_gaussian_pseudotime.txt', sep = '\t')
# 
# # e. same cell but with cells with time sampled from a Guassian distribution; Pseudotime is used
# neuronsame_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_gaussian_zero_time_forcing.txt', sep = '\t')
# astrocytesame_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_gaussian_zero_time_forcing.txt', sep = '\t')
# oligodendrocytesame_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_gaussian_zero_time_forcing.txt', sep = '\t')
# 
# # e. same cell but with cells with time sampled from a Guassian distribution; Pseudotime is used
# neuronsame_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuronsame_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# astrocytesame_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytesame_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# 
# # ######################################################################################################################################################################################################
# # # different cells
# # ######################################################################################################################################################################################################
# # # a. different cell but with Pseudotime
# # bug for the following
# neurondifferent_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_pseudotime.txt', sep = '\t')
# astrocytedifferent_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_pseudotime.txt', sep = '\t')
# oligodendrocytedifferent_cell_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_pseudotime.txt', sep = '\t')
# 
# # b. different cell real time but with zero-forcing
# neurondifferent_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_realtime_zero_forcing.txt', sep = '\t')
# astrocytedifferent_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_realtime_zero_forcing.txt', sep = '\t')
# oligodendrocytedifferent_cell_realtime_zero_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_realtime_zero_forcing.txt', sep = '\t')
# 
# # c. different cell but with time sampled from a Guassian distribution
# neurondifferent_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neurondifferent_cell_gaussian_time.txt', sep = '\t')
# astrocytedifferent_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_gaussian_time.txt', sep = '\t')
# oligodendrocytedifferent_cell_gaussian_time <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_gaussian_time.txt', sep = '\t')
# 
# # d. different cell but with time sampled from a Guassian distribution
# neurondifferent_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neurondifferent_cell_gaussian_pseudotime.txt', sep = '\t')
# astrocytedifferent_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_gaussian_pseudotime.txt', sep = '\t')
# oligodendrocytedifferent_cell_gaussian_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_gaussian_pseudotime.txt', sep = '\t')
# 
# # e. different cell but with cells with time sampled from a Guassian distribution; Pseudotime is used
# neurondifferent_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neurondifferent_cell_gaussian_time_zero_forcing.txt', sep = '\t')
# astrocytedifferent_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_gaussian_time_zero_forcing.txt', sep = '\t')
# oligodendrocytedifferent_cell_gaussian_zero_time_forcing <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_gaussian_time_zero_forcing.txt', sep = '\t')
# 
# # e. different cell but with cells with time sampled from a Guassian distribution; Pseudotime is used
# neurondifferent_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neurondifferent_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# astrocytedifferent_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/astrocytedifferent_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime.txt', sep = '\t')
# 
# ######################################################################################################################################################################################################
# neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)
# 
# gene_uniq <- unique(c(as.character(neuron_network[, 1]), as.character(neuron_network[, 2])))
# all_cmbns <- expand.grid(gene_uniq, gene_uniq)
# valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
# valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
# row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
# valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

neuronsame_cell_pseudotime <- calStatistics(neuronsame_cell_pseudotime, reference_network_pvals)
astrocytesame_cell_pseudotime <- calStatistics(astrocytesame_cell_pseudotime, reference_network_pvals)
oligodendrocytesame_cell_pseudotime <- calStatistics(oligodendrocytesame_cell_pseudotime, reference_network_pvals)

neuronsame_cell_realtime_zero_forcing <- calStatistics(neuronsame_cell_realtime_zero_forcing, reference_network_pvals)
astrocytesame_cell_realtime_zero_forcing <- calStatistics(astrocytesame_cell_realtime_zero_forcing, reference_network_pvals)
oligodendrocytesame_cell_realtime_zero_forcing <- calStatistics(oligodendrocytesame_cell_realtime_zero_forcing, reference_network_pvals)

neuronsame_cell_gaussian_time <- calStatistics(neuronsame_cell_gaussian_time, reference_network_pvals)
astrocytesame_cell_gaussian_time <- calStatistics(astrocytesame_cell_gaussian_time, reference_network_pvals)
oligodendrocytesame_cell_gaussian_time <- calStatistics(oligodendrocytesame_cell_gaussian_time, reference_network_pvals)

neuronsame_cell_gaussian_pseudotime <- calStatistics(neuronsame_cell_gaussian_pseudotime, reference_network_pvals)
astrocytesame_cell_gaussian_pseudotime <- calStatistics(astrocytesame_cell_gaussian_pseudotime, reference_network_pvals)
oligodendrocytesame_cell_gaussian_pseudotime <- calStatistics(oligodendrocytesame_cell_gaussian_pseudotime, reference_network_pvals)

neuronsame_cell_gaussian_zero_time_forcing <- calStatistics(neuronsame_cell_gaussian_zero_time_forcing, reference_network_pvals)
astrocytesame_cell_gaussian_zero_time_forcing <- calStatistics(astrocytesame_cell_gaussian_zero_time_forcing, reference_network_pvals)
oligodendrocytesame_cell_gaussian_zero_time_forcing <- calStatistics(oligodendrocytesame_cell_gaussian_zero_time_forcing, reference_network_pvals)

neuronsame_cell_gaussian_zero_forcing_pseudotime <- calStatistics(neuronsame_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)
astrocytesame_cell_gaussian_zero_forcing_pseudotime <- calStatistics(astrocytesame_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)
oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime <- calStatistics(oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)

######################################################################################################################################################################################################
neurondifferent_cell_pseudotime <- calStatistics(neurondifferent_cell_pseudotime, reference_network_pvals)
astrocytedifferent_cell_pseudotime <- calStatistics(astrocytedifferent_cell_pseudotime, reference_network_pvals)
oligodendrocytedifferent_cell_pseudotime <- calStatistics(oligodendrocytedifferent_cell_pseudotime, reference_network_pvals) # this one crashes at R11

neurondifferent_cell_realtime_zero_forcing <- calStatistics(neurondifferent_cell_realtime_zero_forcing, reference_network_pvals)
astrocytedifferent_cell_realtime_zero_forcing <- calStatistics(astrocytedifferent_cell_realtime_zero_forcing, reference_network_pvals) # crash at run 22
oligodendrocytedifferent_cell_realtime_zero_forcing <- calStatistics(oligodendrocytedifferent_cell_realtime_zero_forcing, reference_network_pvals)

neurondifferent_cell_gaussian_time <- calStatistics(neurondifferent_cell_gaussian_time, reference_network_pvals)
astrocytedifferent_cell_gaussian_time <- calStatistics(astrocytedifferent_cell_gaussian_time, reference_network_pvals)
oligodendrocytedifferent_cell_gaussian_time <- calStatistics(oligodendrocytedifferent_cell_gaussian_time, reference_network_pvals)

neurondifferent_cell_gaussian_pseudotime <- calStatistics(neurondifferent_cell_gaussian_pseudotime, reference_network_pvals)
astrocytedifferent_cell_gaussian_pseudotime <- calStatistics(astrocytedifferent_cell_gaussian_pseudotime, reference_network_pvals)
oligodendrocytedifferent_cell_gaussian_pseudotime <- calStatistics(oligodendrocytedifferent_cell_gaussian_pseudotime, reference_network_pvals)

neurondifferent_cell_gaussian_zero_time_forcing <- calStatistics(neurondifferent_cell_gaussian_zero_time_forcing, reference_network_pvals)
astrocytedifferent_cell_gaussian_zero_time_forcing <- calStatistics(astrocytedifferent_cell_gaussian_zero_time_forcing, reference_network_pvals)
oligodendrocytedifferent_cell_gaussian_zero_time_forcing <- calStatistics(oligodendrocytedifferent_cell_gaussian_zero_time_forcing, reference_network_pvals)

neurondifferent_cell_gaussian_zero_forcing_pseudotime <- calStatistics(neurondifferent_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)
astrocytedifferent_cell_gaussian_zero_forcing_pseudotime <- calStatistics(astrocytedifferent_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)
oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime <- calStatistics(oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime, reference_network_pvals)
 
# make the bar plot: 

# # fake the data first: 
# oligodendrocytedifferent_cell_pseudotime <- astrocytedifferent_cell_pseudotime
# astrocytedifferent_cell_realtime_zero_forcing <- neurondifferent_cell_realtime_zero_forcing

# #uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])
RDI_cRDI_auc_df <- data.frame(Type = c(rep("neuron_same_cell_pseudotime", 25),
                                  rep("astrocyte_same_cell_pseudotime", 25),
                                  rep("oligodendrocyte_same_cell_pseudotime", 25),
                                  rep("neuron_same_cell_realtime_zero_forcing", 25),
                                  rep("astrocyte_same_cell_realtime_zero_forcing", 25),
                                  rep("oligodendrocyte_same_cell_realtime_zero_forcing", 25),
                                  rep("neuron_same_cell_gaussian_time", 25),
                                  rep("astrocyte_same_cell_gaussian_time", 25),
                                  rep("oligodendrocyte_same_cell_gaussian_time", 25),
                                  rep("neuron_same_cell_gaussian_pseudotime", 25),
                                  rep("oligodendrocyte_same_cell_gaussian_pseudotime", 25),
                                  rep("neuron_same_cell_gaussian_zero_time_forcing", 25),
                                  rep("astrocyte_same_cell_gaussian_zero_time_forcing", 25),
                                  rep("oligodendrocyte_same_cell_gaussian_zero_time_forcing", 25),
                                  rep("neuron_same_cell_gaussian_zero_forcing_pseudotime", 25),
                                  rep("astrocyte_same_cell_gaussian_zero_forcing_pseudotime", 25),
                                  rep("oligodendrocyte_same_cell_gaussian_zero_forcing_pseudotime", 25)),
                              RDI = c(unique(neuronsame_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], #'method',
                                  unique(astrocytesame_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')][, 'auc'])),
                              cRDI = c(unique(neuronsame_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(neuronsame_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(astrocytesame_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                  unique(oligodendrocytesame_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc']))

# str_split_fixed(RDI_cRDI_auc_df$Type, '_', 8)
split_df <- str_split_fixed(RDI_cRDI_auc_df$Type, '_', 8)
RDI_cRDI_auc_df <- cbind(RDI_cRDI_auc_df, split_df)
colnames(RDI_cRDI_auc_df)[4:5] <- c('Cell_type', 'Cell')
RDI_cRDI_auc_df <- cbind(RDI_cRDI_auc_df, ann_type = str_split_fixed(RDI_cRDI_auc_df$Type, 'cell_', 2)[, 2])


RDI_cRDI_auc_df$Cell_type <- as.character(RDI_cRDI_auc_df$Cell_type)
RDI_cRDI_auc_df$Cell_type[RDI_cRDI_auc_df$Cell_type == 'oligodendrocyte'] <- "olig"

pdf(paste0(SI_fig_dir, 'comprehensive_benchmark.pdf'), width =  2, height = 1)
ggplot(aes(ann_type, RDI), data = RDI_cRDI_auc_df) + geom_boxplot(aes(color = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (cRDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()

pdf(paste0(SI_fig_dir, 'comprehensive_benchmark_cRDI.pdf'), width =  2, height = 1)
ggplot(aes(ann_type, cRDI), data = RDI_cRDI_auc_df) + geom_boxplot(aes(color = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (cRDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()


pdf(paste0(SI_fig_dir, 'comprehensive_benchmark_cRDI_helper.pdf'))
ggplot(aes(ann_type, cRDI), data = RDI_cRDI_auc_df) + geom_boxplot(aes(color = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") 
dev.off()

# ggplot(aes(Type, cRDI), data = RDI_cRDI_auc_df) + geom_boxplot(aes(fill = Type)) + xlab('') + theme(axis.text.x = element_text(angle = 30, hjust = 1))

# # different cell
different_cell_RDI_cRDI_auc_df <- data.frame(Type = c(rep("neuron_different_cell_pseudotime", 25), 
                                       rep("astrocyte_different_cell_pseudotime", 25), 
                                       rep("oligodendrocyte_different_cell_pseudotime", 25), 
                                       rep("neuron_different_cell_realtime_zero_forcing", 25), 
                                       rep("astrocyte_different_cell_realtime_zero_forcing", 25), 
                                       rep("oligodendrocyte_different_cell_realtime_zero_forcing", 25), 
                                       rep("neuron_different_cell_gaussian_time", 25), 
                                       rep("astrocyte_different_cell_gaussian_time", 25), 
                                       rep("oligodendrocyte_different_cell_gaussian_time", 25), 
                                       rep("neuron_different_cell_gaussian_pseudotime", 25), 
                                       rep("oligodendrocyte_different_cell_gaussian_pseudotime", 25), 
                                       rep("neuron_different_cell_gaussian_zero_time_forcing", 25), 
                                       rep("astrocyte_different_cell_gaussian_zero_time_forcing", 25), 
                                       rep("oligodendrocyte_different_cell_gaussian_zero_time_forcing", 25), 
                                       rep("neuron_different_cell_gaussian_zero_forcing_pseudotime", 25), 
                                       rep("astrocyte_different_cell_gaussian_zero_forcing_pseudotime", 25), 
                                       rep("oligodendrocyte_different_cell_gaussian_zero_forcing_pseudotime", 25)), 
                              RDI = c(unique(neurondifferent_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], #'method',  
                                      unique(astrocytedifferent_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(oligodendrocytedifferent_cell_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(neurondifferent_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                      unique(astrocytedifferent_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                      unique(oligodendrocytedifferent_cell_realtime_zero_forcing$RDI_df[, c('method', 'auc')])[, 'auc'],
                                      unique(neurondifferent_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(astrocytedifferent_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(oligodendrocytedifferent_cell_gaussian_time$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(neurondifferent_cell_gaussian_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(oligodendrocytedifferent_cell_gaussian_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(neurondifferent_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(astrocytedifferent_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(oligodendrocytedifferent_cell_gaussian_zero_time_forcing$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(neurondifferent_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(astrocytedifferent_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')])[, 'auc'], 
                                      unique(oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime$RDI_df[, c('method', 'auc')][, 'auc'])),
                              cRDI = c(unique(neurondifferent_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(astrocytedifferent_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(oligodendrocytedifferent_cell_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(neurondifferent_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(astrocytedifferent_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(oligodendrocytedifferent_cell_realtime_zero_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(neurondifferent_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(astrocytedifferent_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(oligodendrocytedifferent_cell_gaussian_time$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(neurondifferent_cell_gaussian_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(oligodendrocytedifferent_cell_gaussian_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(neurondifferent_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(astrocytedifferent_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(oligodendrocytedifferent_cell_gaussian_zero_time_forcing$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(neurondifferent_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(astrocytedifferent_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'], 
                                       unique(oligodendrocytedifferent_cell_gaussian_zero_forcing_pseudotime$cRDI_df[, c('method', 'auc')])[, 'auc'])) 

split_df <- str_split_fixed(different_cell_RDI_cRDI_auc_df$Type, '_', 8)
different_cell_RDI_cRDI_auc_df <- cbind(different_cell_RDI_cRDI_auc_df, split_df)
colnames(different_cell_RDI_cRDI_auc_df)[4:5] <- c('Cell_type', 'Cell')
different_cell_RDI_cRDI_auc_df <- cbind(different_cell_RDI_cRDI_auc_df, ann_type = str_split_fixed(different_cell_RDI_cRDI_auc_df$Type, 'cell_', 2)[, 2])

different_cell_RDI_cRDI_auc_df$Cell_type <- as.character(different_cell_RDI_cRDI_auc_df$Cell_type)
different_cell_RDI_cRDI_auc_df$Cell_type[different_cell_RDI_cRDI_auc_df$Cell_type == 'oligodendrocyte'] <- "olig"

ggplot(aes(ann_type, RDI), data = different_cell_RDI_cRDI_auc_df) + geom_boxplot(aes(fill = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x")
ggplot(aes(Type, cRDI), data = different_cell_RDI_cRDI_auc_df) + geom_boxplot(aes(fill = Type)) + xlab('') + theme(axis.text.x = element_text(angle = 30, hjust = 1))

different_cell_RDI_cRDI_auc_df_mlt <- melt(different_cell_RDI_cRDI_auc_df, var.id = c('RDI', 'cRDI'))
ggplot(aes(ann_type, value), data = different_cell_RDI_cRDI_auc_df_mlt) + geom_boxplot(aes(fill = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type + variable, scales = "free_x")


pdf(paste0(SI_fig_dir, 'different_cell_comprehensive_benchmark.pdf'), width =  2, height = 1)
ggplot(aes(ann_type, RDI), data = different_cell_RDI_cRDI_auc_df) + geom_boxplot(aes(color = ann_type)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (RDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()

###############################################################################################################################################################################
# combine same / different cell: 
###############################################################################################################################################################################
same_different_RDI_cRDI_auc_df <- rbind(RDI_cRDI_auc_df, different_cell_RDI_cRDI_auc_df)

pdf(paste0(main_fig_dir, 'RDI_cell_type_auc_all_benchmark_same_different.pdf'))
ggplot(aes(ann_type, RDI), data = same_different_RDI_cRDI_auc_df) + geom_boxplot(aes(fill = Cell)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (RDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()

pdf(paste0(main_fig_dir, 'cRDI_cell_type_auc_all_benchmark_same_different.pdf'))
ggplot(aes(ann_type, cRDI), data = same_different_RDI_cRDI_auc_df) + geom_boxplot(aes(fill = Cell)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (RDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()

same_different_RDI_cRDI_auc_df_mlt <-  melt(same_different_RDI_cRDI_auc_df, var.id = c('RDI', 'cRDI'))
same_different_RDI_cRDI_auc_df_mlt$Cell_type_variable <- paste0(same_different_RDI_cRDI_auc_df_mlt$Cell, same_different_RDI_cRDI_auc_df_mlt$variable)

# one figure includes every benchmark I did: 
pdf(paste0(main_fig_dir, 'cell_type_auc_all_benchmark_same_different.pdf'))
ggplot(aes(ann_type, value), data = same_different_RDI_cRDI_auc_df_mlt) + geom_boxplot(aes(fill = Cell_type_variable)) + xlab('') + 
  theme(axis.text.x = element_text(angle = 30, hjust = 1)) + facet_wrap(~Cell_type, scales = "free_x") + nm_theme() + xlab('') + ylab('AUC (RDI)') + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())
dev.off()

###############################################################################################################################################################################

# qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
#   xlab("False positive rate") +
#   ylab("True positive rate") +
#   ylim(c(0, 1.0)) + geom_abline(color = 'red') +
#   facet_wrap(~method) +
#   #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
#   xlim(c(0, 1.0))

# uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

# ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
#   xlab("") + ylim(0, 1)

# 2. facet plot for the ROC curves 

# run the 25 samples for each test case and visualize the results; calculate the AUC score and make ROC curve using the box plot
# also show the ROC curves 

##########################################################################################################################################################
# make the analysis result figures 
##########################################################################################################################################################

# 1. histogram of AUC of N, A, O under different sampling 
# 2. histogram of AUC of N, A, O under different dropout cases 
# 3. histogram of AUC of N, A, O under gaussian or true time  
# 4. histogram of AUC of N, A, O under pseudotime or true time  

##########################################################################################################################################################
# make the analysis result figures 
##########################################################################################################################################################
# 13 10002  1000
# 503 cells 
# range: 0-20, 

# experimental design: 
# 1. using the same cell or different cells 
# 2. using zero-forcing or no zero-forcing 
# 3. using true time or the pseudotime 
# 

# same cell / correct time 
# same_cell_time_fixed_res_pseudotime # use the Pseudotime 
# same_cell_time_fixed_res_dropout # original data but with dropout 
# same_cell_time_fixed_res_dropout_pseudotime # droput data and use Pseudotime 

# same cell / gaussian sampled time 
# same_cell_time_gaussian_res_pseudotime # use the Pseudotime 
# same_cell_time_gaussian_res_dropout # original data but with dropout 
# same_cell_time_gaussian_res_dropout_pseudotime # droput data and use Pseudotime 

# different cell / correct time 
# different_cell_time_fixed_res # correct time  
# different_cell_time_fixed_res_pseudotime # pseudotime
# different_cell_time_fixed_res_dropout # droput data 
# different_cell_time_fixed_res_pseudotime_dropout # droput data and use Pseudotime 

# different cell / gaussain sampled time 
# different_cell_time_Gaussian_res # gaussian time  
# different_cell_time_Gaussian_res_pseudotime # pseudotime
# different_cell_time_Gaussian_res_dropout # droput data 
# different_cell_time_Gaussian_res_dropout_pseudotime # droput data and use Pseudotime 

# ##########################################################################################################################################################
# # test Sreeram's analysis (we can replace this section with the two-step model)
# ##########################################################################################################################################################

# disp_func <- absolute_cds@dispFitInfo$blind$disp_func

# rzipois(5, lambda = 5, pstr0 = 0.9^5)
# rzinegbin()

# neuron_cell_simulation <- exprs(neuron_sim_cds)
# exp_vec <- as.vector(neuron_cell_simulation)
# quantile_val <- quantile(exp_vec[exp_vec > 0], probs = 0.02)

# scaled_neuron_cell_simulation <- t(neuron_cell_simulation) / quantile_val

# for(type in c('poisson', 'zipoisson', 'negbinomial', 'zinegbinomial')) {
#   message('type is ', type)
#   drop_out_p <- apply(scaled_neuron_cell_simulation[1:200, ], 1, function(x) sreeram_drop_out(x, assumed_value = quantile_val, capture_rate = 0.1, type = type))
  
#   dm_res <- DiffusionMap(t(drop_out_p))
#   dpt_res <- just_DPT(dm_res)
#   print(cor(c(1:ncol(neuron_cell_simulation))[1:200], order(dpt_res$DPT1[1:200])))

#   p <- qplot(dm_res$DC1, dm_res$DC2, color = c(1:ncol(neuron_sim_cds))[1:200], size = I(0.5)) + xlab('DC 1') + ylab('DC 2') + nm_theme()+ 
#     theme(axis.text.x = element_text(angle = 30, hjust = .9))

#   pdf(paste(SI_fig_dir, type, "_dpt.pdf", sep = ''), height = 1, width = 1)
#   print(p)
#   dev.off()
# }

# test_dm_ori <- DiffusionMap(t(neuron_cell_simulation))
# test_dpt_ori <- just_DPT(test_dm_ori)
# test_dm <- DiffusionMap(t(neuron_cell_simulation) / quantile_val)
# test_dpt <- just_DPT(test_dm)
# dropout_dm <- DiffusionMap(t(drop_out_p))
# dropout_dpt <- just_DPT(dropout_dm)

# qplot(test_dm_ori$DC1, test_dm_ori$DC2)
# qplot(test_dm$DC1, test_dm$DC2)

# qplot(dropout_dm$DC1, dropout_dm$DC2, color = 1:400)

# cor(1:ncol(neuron_cell_simulation), test_dpt_ori$DPT1)
# cor(1:ncol(neuron_cell_simulation), test_dpt$DPT1)
# cor(test_dpt_ori$DPT1, test_dpt$DPT1)
# cor(dropout_dpt$DPT1, 1:ncol(neuron_cell_simulation))

# # show the distribution of gene expression:
# exp_vec <- as.vector(all_cell_simulation)
# min(exp_vec[exp_vec > 0])
# qplot(exp_vec) + stat_bin(bins = 150)
# assumed_value <- quantile(exp_vec[exp_vec > 0], probs = 0.02)

# quantile(exp_vec, probs = 0.2) /  quantile(exp_vec, probs = 0.15)

# # Some prior analysis here: 
# all_cell_simulation <- all_cell_simulation[, , neuron_cell_ids]
# gene_steps_cell <- dim(all_cell_simulation)
# # cols <- c("lap" = "black", "original" = "gray", "pt" = "red")
# # cell_type_cols <- c("neuron" = "#F2746B", "astrocyte" = "#29B14A", "oligodendrocyte" = "#6E95CD")

# # show the distribution of gene expression:
# exp_vec <- as.vector(all_cell_simulation)
# min(exp_vec[exp_vec > 0])
# qplot(exp_vec) + stat_bin(bins = 150)
# assumed_value <- quantile(exp_vec[exp_vec > 0], probs = 0.02)

# quantile(exp_vec, probs = 0.2) /  quantile(exp_vec, probs = 0.15)

# # show the distribution of normlized expression:
# qplot(exp_vec[exp_vec > 0] /  quantile(exp_vec[exp_vec > 0], probs = 0.02))

# ##########################################################################################################################################################
# # add dropout for all cells 
# ##########################################################################################################################################################
# set.seed(2017)

# for(i in 1:gene_steps_cell[3]) {
#   data <- all_cell_simulation[, , i]
#   data_vec <- as.vector(data)
#   quantile_val <- quantile(data_vec[data_vec > 0], probs = 0.2)
#   message('quantile_val is ', quantile_val)
#   drop_out_p <- t(apply(data, 1, function(x) drop_out(x, assumed_value = quantile_val, capture_rate = 0.1)))
  
#   output_res <- cbind(data.frame(gene = row.names(all_cell_simulation), run = paste0('R', i)), drop_out_p)
#   write.table(output_res, "dropout_res.txt", append = T, quote=F, col.names=F, row.names=F, sep="\t")

#   num_dropout <- sum(as.vector(drop_out_p) == 0 & as.vector(data) != 0)
  
#   print(num_dropout / sum(as.vector(data) != 0))
# }

# ##########################################################################################################################################################
# # Create CDS on the biggest dataset and then run dpFeature and Monocle 2  
# ##########################################################################################################################################################
# make_cds(transcriptome_simulated_update)

##########################################################################################################################################################
# make the analysis result figures 
##########################################################################################################################################################

# # dropout based on Sreeram's suggestion (Poisson distribution for the data): not implemented yet 
# sreeram_drop_out <- function(n, assumed_value, capture_rate) {
#   n_new <- n / assumed_value
#   drop_out_p <- (1 - capture_rate)^n_new
#   
#   cell_num <- length(n_new)
#   sample_res <- sample(c(rep(0, cell_num), rep(1, cell_num)), size = cell_num, replace = F, prob = c(drop_out_p, 1 - drop_out_p))
#   
#   n[sample_res == 0] <- 0
#   return(n)
# }
# 

save.image('./RData/analysis_extensive_simulation_study.RData')
