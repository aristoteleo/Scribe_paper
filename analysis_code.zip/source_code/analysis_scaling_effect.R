# analyze the effect of scaling on the MI, CMI, RDI as well as the cRDI 
library(monocle)
library(InformationEstimator)

lung <- load_lung()

# create some noise: 
set.seed(2017)
n_genes <- 10
n_samples <- ncol(lung)
noise = matrix(rnorm(mean = 0, sd = 1e-10, n_genes * n_samples), nrow = n_samples)

# no scaling: 
mi_res <- matrix(0, nrow = 10, ncol = 10)
cmi_res <- matrix(0, nrow = 10, ncol = 10)

for(i in 1:10) {
  for(j in 1:10) {
    mi_res[i, j ] <- mi(as.matrix(exprs(lung)[i, ]) + as.matrix(noise[, i]), as.matrix(exprs(lung)[j, ]) + as.matrix(noise[, j]), k = 5L)
    #cmi_res[i, j ] <- cmi(as.matrix(exprs(lung)[1, ]) + as.matrix(noise[, 1]), as.matrix(exprs(lung)[2, ]) + as.matrix(noise[, 2]), z = as.matrix(exprs(lung)[3, ]) + as.matrix(noise[, 3]), k = 5)
  }
}

ori_rid <- calculate_rdi(t(exprs(lung)[1:10, ]), delays = c(5), method = 1)

# scaling: 
scaling_mi_res <- matrix(0, nrow = 10, ncol = 10)
for(i in 1:10) {
  for(j in 1:10) {
    scaling_mi_res[i, j ] <- mi(as.matrix(scale(exprs(lung)[i, ])) + as.matrix(noise[, i]), as.matrix(as.matrix(scale(exprs(lung)[j, ]))) + as.matrix(noise[, j]), k = 5)
    # cmi(as.matrix(exprs(lung)[1, ]) + as.matrix(noise[, 1]), as.matrix(exprs(lung)[2, ]) + as.matrix(noise[, 2]), z = as.matrix(exprs(lung)[2, ])+ as.matrix(noise[, 3]), k = 5)
  }
}

scaling_rid <- calculate_rdi(scale(t(exprs(lung)[1:10, ])), delays = c(5), method = 1)

# log: 
log_mi_res <- matrix(0, nrow = 10, ncol = 10)
for(i in 1:10) {
  for(j in 1:10) {
    log_mi_res[i, j ] <- mi(as.matrix(log(exprs(lung)[i, ] + 1)) + as.matrix(noise[, i]), as.matrix(as.matrix(log(exprs(lung)[j, ] + 1))) + as.matrix(noise[, j]), k = 5)
    # cmi(as.matrix(exprs(lung)[1, ]) + as.matrix(noise[, 1]), as.matrix(exprs(lung)[2, ]) + as.matrix(noise[, 2]), z = as.matrix(exprs(lung)[2, ])+ as.matrix(noise[, 3]), k = 5)
  }
}

log_rid <- calculate_rdi(log(t(exprs(lung)[1:10, ]) + 1), delays = c(5), method = 1)

# make results
qplot(as.vector(ori_rid$RDI), as.vector(scaling_rid$RDI)) + geom_abline() + xlab('RDI original') + ylab("RDI (Scaling)")
qplot(as.vector(ori_rid$RDI), as.vector(log_rid$RDI)) + geom_abline()

qplot(as.vector(mi_res), as.vector(scaling_mi_res)) + xlim(0, 1) + ylim(0, 1) + xlab('MI original') + ylab('MI (Scaling)') + geom_abline()
qplot(as.vector(mi_res), as.vector(log_mi_res))  + xlab('MI original') + ylab('MI (Log)') + geom_abline()

# AWGN: additive Weighted Gaussian Noise 
# MI(X, X): infinity when use a lot samples 

########################################################################################################################################################
# check whether or not do the scaling for lung, LPS and blood datasets we still get the correct network 
########################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/verify_network_hiearchy.RData') # load the dataset 
# scale the data 
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/InformationEstimator/scale_data_regulatory_hiearchy_network')

scale_data_regulatory_hiearchy_network <- function(cds, exprs_data_1, exprs_data_2, 
                                        early_1 = AT1_early, late_1 = AT1_late, 
                                        early_2 = AT2_early, late_2 = AT2_late,
                                        cell_types = c("AT1", 'AT2'),
                                        time_category = c('AT1_early', 'AT1_late', 'AT2_early', 'AT2_late')) {
  set.seed(2017)
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_1) * ncol(exprs_data_1)), nrow = nrow(exprs_data_1))
  a <- Sys.time()
  RDI_parallel_res_1_list <- calculate_rdi(scale(exprs_data_1) + noise, delays = c(5, 10, 15), method = 1) #, R_cores = detectCores() - 2
  b <- Sys.time()
  
  set.seed(2017)
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_2) * ncol(exprs_data_2)), nrow = nrow(exprs_data_2))
  a <- Sys.time()
  RDI_parallel_res_2_list <- calculate_rdi(scale(exprs_data_2) + noise, delays = c(5, 10, 15), method = 1)
  b <- Sys.time()
  
  RDI_parallel_res_1 <- RDI_parallel_res_1_list$RDI
  RDI_parallel_res_2 <- RDI_parallel_res_2_list$RDI
  # clr_res_1 <- clr(AT1_RDI_parallel_res) #
  clr_res_1 <- t(apply(RDI_parallel_res_1[, 1:nrow(RDI_parallel_res_1)], 1, function(x) (x - mean(x)) / (sd(x)))); clr_res_1[clr_res_1 < 0] <- 0
  #clr_res_2 <- clr(AT2_RDI_parallel_res) #
  clr_res_2 <- t(apply(RDI_parallel_res_2[, 1:nrow(RDI_parallel_res_1)], 1, function(x) (x - mean(x)) / (sd(x)))); clr_res_2[clr_res_2 < 0] <- 0
  
  RDI_parallel_res_subset_1 <- RDI_parallel_res_1[, 1:nrow(RDI_parallel_res_1)] 
  # dimnames(RDI_parallel_res_subset_1) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);
  RDI_parallel_res_subset_2 <- RDI_parallel_res_2[, 1:nrow(RDI_parallel_res_1)] 
  # dimnames(RDI_parallel_res_subset_2) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);
  
  dimnames(clr_res_1) <- dimnames(RDI_parallel_res_subset_1);
  dimnames(clr_res_2) <- dimnames(RDI_parallel_res_subset_2);
  
  valid_gene_short_name <- fData(cds)[colnames(RDI_parallel_res_subset_1), 'gene_short_name']
  early_1 <- intersect(early_1, valid_gene_short_name); late_1 <- intersect(late_1, valid_gene_short_name); 
  early_2 <- intersect(early_2, valid_gene_short_name); late_2 <- intersect(late_2, valid_gene_short_name); 
  
  all_genes <- c(early_1, late_1, early_2, late_2)
  
  graph_res_1 <- igraph::graph_from_adjacency_matrix(clr_res_1[all_genes, all_genes], mode = 'directed', weighted = T)
  # plot(graph_res_1, layout = layout.fruchterman.reingold(graph_res_1), vertex.size=2, vertex.label.size=4)
  
  graph_res_2 <- igraph::graph_from_adjacency_matrix(clr_res_2, mode = 'directed', weighted = T)
  # plot(graph_res_2, layout = layout.fruchterman.reingold(graph_res_2), vertex.size=2, vertex.label.size=4)
  
  Branch_1_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_1, ], na.rm = T)
  Branch_1_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_1, ], na.rm = T)
  Branch_2_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_2, ], na.rm = T)
  Branch_2_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_2, ], na.rm = T)
  
  Branch_1_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_1, ], na.rm = T)
  Branch_1_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_1, ], na.rm = T)
  Branch_2_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_2, ], na.rm = T)
  Branch_2_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_2, ], na.rm = T)
  
  rdi_df <- data.frame(sum_of_output_rdi =
                         c(Branch_1_rdi_sum_early_1, Branch_1_rdi_sum_late_1, Branch_2_rdi_sum_early_1, Branch_2_rdi_sum_late_1,
                           Branch_1_rdi_sum_early_2, Branch_1_rdi_sum_late_2, Branch_2_rdi_sum_early_2, Branch_2_rdi_sum_late_2),
                       Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                       Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                    rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))
  
  p <- ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') + geom_jitter(aes(color = Time))
  
  # cRDI  
  set.seed(2017)
  a <- Sys.time()
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_1) * ncol(exprs_data_1)), nrow = nrow(exprs_data_1))
  cRDI_R_1 <- calculate_conditioned_rdi(scale(exprs_data_1) + noise, super_graph = NULL, RDI_parallel_res_1_list, 1L)
  b <- Sys.time(); b - a
  
  set.seed(2017)
  a <- Sys.time()
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_2) * ncol(exprs_data_2)), nrow = nrow(exprs_data_2))
  cRDI_R_2 <- calculate_conditioned_rdi(scale(exprs_data_2) + noise, super_graph = NULL, RDI_parallel_res_2_list, 1L)
  b <- Sys.time(); b - a
  
  return(list(RDI_parallel_res_subset_1 = RDI_parallel_res_subset_1, RDI_parallel_res_subset_2 = RDI_parallel_res_subset_2, 
              clr_res_1 = clr_res_1, clr_res_2 = clr_res_2, rdi_df = rdi_df, p = NA, 
              RDI_res_list_1 = RDI_parallel_res_1_list, RDI_res_list_2 = RDI_parallel_res_2_list,
              cRDI_R_1 = cRDI_R_1, cRDI_R_2 = cRDI_R_2))
}

save(file = 'scale_data_regulatory_hiearchy_network', scale_data_regulatory_hiearchy_network)
debug(scale_data_regulatory_hiearchy_network)
lung_AT1_AT2_scale <- scale_data_regulatory_hiearchy_network(lung, lung_exprs_AT1, lung_exprs_AT2)

dimnames(lung_AT1_AT2_scale$RDI_parallel_res_subset_1) <- list(fData(lung)$gene_short_name[-158], fData(lung)$gene_short_name[-158])
dimnames(lung_AT1_AT2_scale$RDI_parallel_res_subset_2) <- list(fData(lung)$gene_short_name[-158], fData(lung)$gene_short_name[-158])
dimnames(lung_AT1_AT2_scale$cRDI_R_1) <- list(fData(lung)$gene_short_name[-158], fData(lung)$gene_short_name[-158])
dimnames(lung_AT1_AT2_scale$cRDI_R_2) <- list(fData(lung)$gene_short_name[-158], fData(lung)$gene_short_name[-158])

RDI_parallel_res_subset_1 <- lung_AT1_AT2_scale$RDI_parallel_res_subset_1; RDI_parallel_res_subset_2 <- lung_AT1_AT2_scale$RDI_parallel_res_subset_2
cRDI_R_1 <- lung_AT1_AT2_scale$cRDI_R_1; cRDI_R_2 <- lung_AT1_AT2_scale$cRDI_R_2

### do the same thing for the LPS and the two blood datasets ###  
clr_res_1[is.na(clr_res_1)]
clr_res_1 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_1) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_1))))

RDI_parallel_res_subset_2[is.na(RDI_parallel_res_subset_2)]
clr_res_2 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_2) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_2))))

# run eigen_centrality  
which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% early_1)
which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% early_2)

which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% late_1)
which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% late_2)

graph_res_1 <- igraph::graph_from_adjacency_matrix(RDI_parallel_res_subset_1, mode = 'directed', weighted = T)
# plot(graph_res_1, layout = layout.fruchterman.reingold(graph_res_1), vertex.size=2, vertex.label.size=4)
graph_res_2 <- igraph::graph_from_adjacency_matrix(RDI_parallel_res_subset_2, mode = 'directed', weighted = T)

a <- which(names(sort(eigen_centrality(graph_res_1)$vector)) %in% early_1)
b <- which(names(sort(eigen_centrality(graph_res_1)$vector)) %in% early_2)
c <- which(names(sort(eigen_centrality(graph_res_1)$vector)) %in% late_1)
d <- which(names(sort(eigen_centrality(graph_res_1)$vector)) %in% late_2)

a.1 <- which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% early_1)
b.1 <- which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% early_2)
c.1 <- which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% late_1)
d.1 <- which(names(sort(eigen_centrality(graph_res_2)$vector)) %in% late_2)

a <- which(names(sort(hub_score(graph_res_1)$vector)) %in% early_1)
b <- which(names(sort(hub_score(graph_res_1)$vector)) %in% early_2)
c <- which(names(sort(hub_score(graph_res_1)$vector)) %in% late_1)
d <- which(names(sort(hub_score(graph_res_1)$vector)) %in% late_2)

a.1 <- which(names(sort(hub_score(graph_res_2)$vector)) %in% early_1)
b.1 <- which(names(sort(hub_score(graph_res_2)$vector)) %in% early_2)
c.1 <- which(names(sort(hub_score(graph_res_2)$vector)) %in% late_1)
d.1 <- which(names(sort(hub_score(graph_res_2)$vector)) %in% late_2)

a <- which(names(sort(authority_score(graph_res_1)$vector)) %in% early_1)
b <- which(names(sort(authority_score(graph_res_1)$vector)) %in% early_2)
c <- which(names(sort(authority_score(graph_res_1)$vector)) %in% late_1)
d <- which(names(sort(authority_score(graph_res_1)$vector)) %in% late_2)

a.1 <- which(names(sort(authority_score(graph_res_2)$vector)) %in% early_1)
b.1 <- which(names(sort(authority_score(graph_res_2)$vector)) %in% early_2)
c.1 <- which(names(sort(authority_score(graph_res_2)$vector)) %in% late_1)
d.1 <- which(names(sort(authority_score(graph_res_2)$vector)) %in% late_2)

rdi_df <- data.frame(sum_of_output_rdi =
                       c(a, b, c, d,
                         a.1, b.1, c.1, d.1),
                     Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                     Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                  rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))


########################################################################################################################################################
# save the results 
########################################################################################################################################################
save.image('./RData/analysis_scaling_effect.Rdata')
