# implement the idea about converting the pseudotime into real time: 
load('example_RNA_velocity')

df <- as.data.frame(cbind(emb, projected))
colnames(df) <- c('x_start', 'y_start', 'x_end', 'y_end')

ggplot(df, aes(x = x_start, y = y_start)) + 
  geom_point(aes(x = x_start, y = y_start), color = 'red', alpha = 0.4) + 
  geom_segment(aes(xend = x_end, yend = y_end),
               arrow = arrow(length = unit(0.1,"cm"))) 

# create a cds 
pData <- data.frame(cell = row.names(df), row.names = row.names(df))
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(df)[1:2], row.names = colnames(df)[1:2])
fd <- new("AnnotatedDataFrame", data = fData)

tSNE_embedding <- newCellDataSet(t(df[, 1:2]), 
                           phenoData = pd, 
                           featureData = fd,
                           lowerDetectionLimit=1,
                           expressionFamily=gaussianff())

tSNE_embedding_res <- reduceDimension(tSNE_embedding, ncenter = NULL,  norm_method = 'none', scaling = F, pseudo_expr = 0, verbose = T, reduction_method = 'SimplePPT')
tSNE_embedding_res <- orderCells(tSNE_embedding_res)
plot_cell_trajectory(tSNE_embedding_res)

dm <- destiny::DiffusionMap(t(FM))
if (verbose) 
  message("Learning principal graph with Principal.curve")
diam_pc_tmp <- princurve::principal.curve(dm@eigenvectors[, 
                                                          1:max_components])

FM <- t(exprs(tSNE_embedding))
fit <- princurve::principal.curve(FM, plot.true = T, smoother = 'lowess')
points(fit)
plot(fit)

whiskers <- function(from, to)
  segments(from[, 1], from[, 2], to[, 1], to[, 2])

df <- as.data.frame(cbind(FM, fit$s))
colnames(df) <- c('x_start', 'y_start', 'x_end', 'y_end')

df_arrow <- as.data.frame(cbind(emb, projected))
colnames(df_arrow) <- c('x_start', 'y_start', 'x_end', 'y_end')

ggplot(df_arrow, aes(x = x_start, y = y_start)) + 
  geom_point(aes(x = x_start, y = y_start), color = 'red', alpha = 0.4) + 
  geom_line(aes(x = df$x_end, y = df$y_end), color = 'blue', alpha = 0.4, size = 1.5) + 
  geom_segment(aes(xend = x_end, yend = y_end),
               arrow = arrow(length = unit(0.1,"cm"))) + 
  geom_segment(aes(x = df$x_start, y = df$y_start, xend = df$x_end, yend = df$y_end))

# a: the line between cell and the projection point on principal curve 
# b: the line between cell and its predicted future state 
A <- data.frame(df$x_end - df$x_start, df$y_start - df$y_end)
B <- data.frame(df_arrow$x_end - df_arrow$x_start, df_arrow$y_start - df_arrow$y_end)

projected_v <- lapply(1:nrow(A), function(x) {
  y <- - A[x, 1] /  A[x, 2]
  a <- c(1, y)
  b <- B[x, ]
  
  theta <- acos( sum(a * b) / ( sqrt(sum(a * a)) * sqrt(sum(b * b)) ) )
  projected_v <- sum(a * b) / ( sqrt(sum(a * a)) )
  projected_v
})

unlist(projected_v)

project_v <- unlist(projected_v) + abs(min(unlist(projected_v))) + .Machine$double.eps

# calculate kernel smoothed velocity: 
knn_res <- nn2(df[, 1:2], k = 50)
knn_res <- nn2(df[, 3:4], k = 15)

smoothed_projected_v <- project_v
for(index in 1:nrow(knn_res$nn.idx)) {
  u <- exp(-knn_res$nn.dists[index, -1]/min(knn_res$nn.dists[index, -1]))
  w <- u/sum(u)
  smoothed_projected_v[index] <- sum(w * project_v[knn_res$nn.idx[index, -1]])
}
  
# aes(x = x_start, y = y_start, xend = x_end, 
#    yend = y_end), size = 2)
  
ggplot(df_arrow, aes(x = x_start, y = y_start)) + 
  geom_point(aes(x = x_start, y = y_start), color = 'red', alpha = 0.4) + 
  geom_line(aes(x = df$x_end, y = df$y_end, 
                color = project_v),size = 3) + scale_color_gradient2() + 
  geom_segment(aes(xend = x_end, yend = y_end),
               arrow = arrow(length = unit(0.1,"cm"))) + 
   geom_segment(aes(x = df$x_start, y = df$y_start, xend = df$x_end, yend = df$y_end), alpha = I(0.2))

ggplot(df_arrow, aes(x = x_start, y = y_start)) + 
  geom_point(aes(x = x_start, y = y_start), color = 'red', alpha = 0.4) + 
  geom_line(aes(x = df$x_end, y = df$y_end, 
                color = smoothed_projected_v),size = 3) + scale_color_gradient2() + 
  geom_segment(aes(xend = x_end, yend = y_end),
               arrow = arrow(length = unit(0.1,"cm"))) + 
  geom_segment(aes(x = df$x_start, y = df$y_start, xend = df$x_end, yend = df$y_end), alpha = I(0.2))

# convert the pseudotime into "real time"
qplot(df[, 3], df[, 4], size = fit$lambda) # pseudotime 
df_sorted <- df[order(fit$lambda), ]
df_sorted$pseudotime <- sort(fit$lambda)
df_sorted$projected_v <- smoothed_projected_v[order(fit$lambda)]

df_sorted$real_time <- c(0, cumsum(diff(df_sorted$pseudotime) / df_sorted$projected_v[-length(smoothed_projected_v)]))

qplot(x_end, y_end, data = df_sorted, size = pseudotime) # pseudotime 

qplot(x_end, y_end, data = df_sorted, size = real_time) # pseudotime 

df_sorted$type <- "early"
df_sorted$type[df_sorted$pseudotime > 15 & df_sorted$pseudotime < 50] <- "middle"
df_sorted$type[df_sorted$pseudotime >= 50]  <- "late"

ggplot(aes(x = pseudotime, y = real_time), data = df_sorted) + geom_point(color = I('black'), alpha = I(0.4)) + geom_smooth(aes(color = type), method = 'lm', size = 4)

# a <- c(1, 1)
# b <- c(1, -1)
# theta <- acos( sum(a*b) / ( sqrt(sum(a * a)) * sqrt(sum(b * b)) ) )






