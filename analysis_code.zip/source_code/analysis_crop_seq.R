#CROP-seq data analysis: 

################################################################################################################################################################################################
# load required packages
################################################################################################################################################################################################
library(monocle)
library(Scribe)

################################################################################################################################################################################################
# create a CDS
################################################################################################################################################################################################

# read all data and annotation file 
annotation <- read.csv('./csv_data/CROP-seq/annotation.csv', row.names = 1)
count_matrix <- read.csv('./csv_data/CROP-seq/GSE92872_CROP-seq_Jurkat_TCR.count_matrix.csv', row.names = 1)
digital_expression <- read.csv('./csv_data/CROP-seq/GSE92872_CROP-seq_Jurkat_TCR.digital_expression.csv', row.names = 1, header = F)
guide_annotation <- read.csv('./csv_data/CROP-seq/guide_annotation.csv')
merge_table <- read.csv('./csv_data/CROP-seq/merge_table.csv')

# prepare the pData 
digital_expression_anno <- t(digital_expression[1:5, ]) 
crop_seq_vec <- as.character(t(digital_expression['cell', ]))
row.names(digital_expression_anno) <- crop_seq_vec
dup_id <- which(duplicated(crop_seq_vec))

digital_expression_anno <- digital_expression_anno[-dup_id, ]
digital_expression_anno <- as.data.frame(digital_expression_anno)

# combine pData with guide RNA-information 

# prepare the expression matrix 
digital_expression_process <- digital_expression[-c(1:6), ]
colnames(digital_expression_process) <- crop_seq_vec
digital_expression_process <- digital_expression_process

# create a CDS 
digital_expression_process_mat <- data.matrix(digital_expression_process)
digital_expression_process_mat <- digital_expression_process_mat[, -dup_id]

# fData
fd <- data.frame(gene_short_name = row.names(digital_expression_process_mat), row.names = row.names(digital_expression_process_mat))

crop_seq_cds <- newCellDataSet(as(digital_expression_process_mat, 'sparseMatrix'),
                               phenoData = new("AnnotatedDataFrame",data=digital_expression_anno),
                               featureData = new("AnnotatedDataFrame",data=fd),
                               expressionFamily = negbinomial.size(),
                               lowerDetectionLimit=1)
crop_seq_cds <- estimateSizeFactors(crop_seq_cds)
crop_seq_cds <- estimateDispersions(crop_seq_cds) # error here

################################################################################################################################################################################################
# reconstruct a trajectory: 
################################################################################################################################################################################################

# run dpFeature and create a trajectory (hopefully it is a linear trajectory)
crop_seq_cds_ntc <- crop_seq_cds[, pData(crop_seq_cds)$gene == "CTRL"] 
crop_seq_cds_ntc <- estimateSizeFactors(crop_seq_cds_ntc)
crop_seq_cds_ntc <- estimateDispersions(crop_seq_cds_ntc, min_cells_detected = 50) # still error 

crop_seq_cds_ntc <- estimateDispersions(crop_seq_cds_ntc[, sample(1:ncol(crop_seq_cds_ntc), 500)], min_cells_detected = 50) # still error 

# remove some low quality cells: 
pData(crop_seq_cds_ntc)$total_mRNAs <- esApply(crop_seq_cds_ntc, 2, sum)

diff_res <- differentialGeneTest(crop_seq_cds_ntc, fullModelFormulaStr = "~condition + grna + total_mRNAs", reducedModelFormulaStr = '~grna + total_mRNAs', cores = detectCores() / 2)
condition <- pData(crop_seq_cds_ntc)$condition
fc_res <- esApply(crop_seq_cds_ntc, 2, function(x) log2(mean(x[condition == 'stimulated']) / mean(x[condition == 'unstimulated'])))
range(fc_res) #the data is just so noisy 

mean_crop_seq_cds_ntc <- esApply(crop_seq_cds_ntc, 1, mean)
crop_seq_ordering_genes <- intersect(row.names(diff_res[order(diff_res$pval), ]), names(mean_crop_seq_cds_ntc)[mean_crop_seq_cds_ntc > 15])[1:100]
crop_seq_cds_ntc <- setOrderingFilter(crop_seq_cds_ntc, ordering_genes = c(crop_seq_ordering_genes))
plot_pc_variance_explained(crop_seq_cds_ntc)
crop_seq_cds_ntc <- monocle::reduceDimension(crop_seq_cds_ntc, verbose = F, scaling = T, max_components = 2, norm_method = 'log')#, residualModelFormulaStr = '~grna + total_mRNAs') 
crop_seq_cds_ntc <- orderCells(crop_seq_cds_ntc)
plot_cell_trajectory(crop_seq_cds_ntc, color_by = 'condition')

################################################################################################################################################################################################
# visualize the following gene pairs: 
################################################################################################################################################################################################
# LCK -> ZAP70
# PTPN6 -| LCK 
# DOK2 -| ZAP70
# ZAP70 -| LAT 

example_pair <- matrix(c('LCK', 'ZAP70', 'PTPN6', 'LCK', 'DOK2', 'ZAP70', 'ZAP70', 'LAT', 'PTPN11', 'EGR3'), ncol = 2, byrow = T)

plot_rdi_pairs(crop_seq_cds, gene_pairs_mat = example_pair, d = 0, grids = 50)
plot_rdi_pairs(crop_seq_cds_ntc, gene_pairs_mat = example_pair, d = 0, grids = 50)

# provide method to remove those residual effects 
# stimulation
plot_rdi_pairs(crop_seq_cds_ntc[, pData(crop_seq_cds_ntc)$condition == 'stimulated'], gene_pairs_mat = example_pair, d = 0, grids = 20)
# no-stimulation
plot_rdi_pairs(crop_seq_cds_ntc[, pData(crop_seq_cds_ntc)$condition == 'unstimulated'], gene_pairs_mat = example_pair, d = 0, grids = 20)

################################################################################################################################################################################################
# run MAGIC to check the result: 
################################################################################################################################################################################################
MAGIC_NTC <- MAGIC_R(t(as.matrix(exprs(crop_seq_cds_ntc[, ]))), knn_autotune = 3, knn=9, t = 3) #knn = 3
# exprs(crop_seq_cds_ntc) <- as(t(MAGIC_NTC), 'sparseMatrix')

MAGIC_NTC_cds <- newCellDataSet(as(t(MAGIC_NTC), 'sparseMatrix'),
                               phenoData = new("AnnotatedDataFrame",data=pData(crop_seq_cds_ntc)),
                               featureData = new("AnnotatedDataFrame",data=fData(crop_seq_cds_ntc)),
                               expressionFamily = negbinomial.size(),
                               lowerDetectionLimit=1)
plot_rdi_pairs(MAGIC_NTC_cds, gene_pairs_mat = example_pair, d = 0, grids = 50)
# stimulation
plot_rdi_pairs(MAGIC_NTC_cds[, pData(crop_seq_cds_ntc)$condition == 'stimulated'], gene_pairs_mat = example_pair, d = 0, grids = 20)
# no-stimulation
plot_rdi_pairs(MAGIC_NTC_cds[, pData(crop_seq_cds_ntc)$condition == 'unstimulated'], gene_pairs_mat = example_pair, d = 0, grids = 20)

################################################################################################################################################################################################
# save the data: 
################################################################################################################################################################################################
save.image('./RData/crop_seq_cds')
