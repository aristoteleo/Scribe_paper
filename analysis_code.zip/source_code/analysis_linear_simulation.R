library(rEDM)
library(monocle)
library(reshape2)
library(pheatmap)

#analysis Arman's data
linear_sim <- read.table('./csv_data/simulation_expr_mat_linear_random_graph_noise01.txt', header = F, sep = '\t', skip = 1) #simulation_expr_mat_linear_random_graph.txt

gene_names <- unique(linear_sim$V1)
all_linear_sim_mat <- data.frame(matrix(rep(NA, 13*10020), nrow = 13), row.names = gene_names)

for(i in gene_names)
  all_linear_sim_mat[i, ] <- as.vector(t(as.matrix(subset(linear_sim, V1 == i)[, -c(1:2)])))

all_linear_sim_mat <- t(all_linear_sim_mat)

all_linear_sim_parallel_res <- parallelCCM(ordered_exprs_mat = all_linear_sim_mat, cores = detectCores() - 3)
all_linear_sim_parallel_res_mat <- prepare_ccm_res(all_linear_sim_parallel_res)

pdf('all_linear_sim_ccm.pdf', width = 30, height = 30)
pheatmap(all_linear_sim_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()


gene_names <- colnames(all_linear_sim_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = all_linear_sim_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'all_linear_sim_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

#run a single run and report the result 
all_linear_sim_parallel_res_run1 <- parallelCCM(ordered_exprs_mat = all_linear_sim_mat[1:501, ], cores = detectCores() - 3)
all_linear_sim_parallel_res_mat_run1 <- prepare_ccm_res(all_linear_sim_parallel_res_run1)

pdf('all_linear_sim_ccm_run1.pdf', width = 30, height = 30)
pheatmap(all_linear_sim_parallel_res_mat_run1[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()


gene_names <- colnames(all_linear_sim_parallel_res_mat_run1)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = all_linear_sim_parallel_res_mat_run1[gene_id1, gene_id2] )
    write.table(file = 'all_linear_sim_ccm_res_run1.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

#run for each run and then average the result: 
res_list <- list()
for(i in 1:20) {
  all_linear_sim_parallel_res_run1 <- parallelCCM(ordered_exprs_mat = all_linear_sim_mat[c(1:501) * i, ], cores = detectCores() - 3)
  all_linear_sim_parallel_res_mat_run1 <- prepare_ccm_res(all_linear_sim_parallel_res_run1)
  
  res_list <- c(res_list, list(all_linear_sim_parallel_res_mat_run1))
}

#average values: 
avg_all_linear_sim_parallel_res_mat <- Reduce("+", res_list) / 20

pdf('avg_all_linear_sim_ccm_run1.pdf', width = 30, height = 30)
pheatmap(avg_all_linear_sim_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()

gene_names <- colnames(avg_all_linear_sim_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = avg_all_linear_sim_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'avg_all_linear_sim_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

################################################################################################################################################################
#do the Granger test: 
################################################################################################################################################################
all_linear_sim_granger_res <- parallel_cal_grangertest(all_linear_sim_mat[, ], cores =  detectCores() - 3, filename = 'all_linear_sim_granger_res.txt', delays = c(1, 11, 21))
all_linear_sim_granger_res_run1 <- parallel_cal_grangertest(all_linear_sim_mat[, ], cores =  detectCores() - 3, filename = 'all_linear_sim_granger_res_run1.txt', delays = c(1, 11, 21))

granger_res_list <- list()
for(i in 1:20) {
  all_linear_sim_granger_res_inidividual_run <- parallel_cal_grangertest(all_linear_sim_mat[, ], cores =  detectCores() - 3, filename = 'all_linear_sim_granger_res_individual_run.txt', delays = c(1, 11, 21))
  
  granger_res_list <- c(granger_res_list, list(all_linear_sim_granger_res_inidividual_run))
}

#average values: 
avg_all_linear_sim_parallel_res_mat <- Reduce("+", res_list) / 20

pdf('avg_all_linear_sim_ccm_run1.pdf', width = 30, height = 30)
pheatmap(avg_all_linear_sim_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()

gene_names <- colnames(avg_all_linear_sim_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = avg_all_linear_sim_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'avg_all_linear_sim_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}
################################################################################################################################################################
#average values: 
################################################################################################################################################################
avg_granger_res_mat <- Reduce("+", granger_res_list) / 20
write.table(file = 'avg_granger_res_mat.txt', avg_granger_res_mat, row.names = F, col.names = F, quote = F, sep = '\t')

