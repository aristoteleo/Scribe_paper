rm(list = ls())

library(InformationEstimator)
library(destiny)
library(monocle)

# add the test for the RT-PCR experiments
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_RT_PCR.RData') # for the run_new_dpt function

load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Olsson.RData')
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Paul.RData')
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_pancreas.RData')

load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res")
gene_list <- V(res$g)$name
# ================================================================================================================================================
# Olsson dataset
# ================================================================================================================================================
# MEP branch: 
exprs(Olsson_MEP_cds) <- as.matrix(exprs(Olsson_MEP_cds))
exprs(Olsson_monocyte_cds) <- as.matrix(exprs(Olsson_monocyte_cds))
exprs(Olsson_granulocyte_cds) <- as.matrix(exprs(Olsson_granulocyte_cds))

MEP_dpt_res <- run_new_dpt(Olsson_MEP_cds)
monocyte_dpt_res <- run_new_dpt(Olsson_monocyte_cds)
granulocyte_dpt_res <- run_new_dpt(Olsson_granulocyte_cds)

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_MEP_cds[gene_list, ]) * ncol(Olsson_MEP_cds)), nrow = ncol(Olsson_MEP_cds[gene_list, ]))
MEP_rdi <- calculate_rdi(t(exprs(Olsson_MEP_cds)[gene_list, order(MEP_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_monocyte_cds[gene_list, ]) * ncol(Olsson_monocyte_cds)), nrow = ncol(Olsson_monocyte_cds[gene_list, ]))
monocyte_rdi <- calculate_rdi(t(exprs(Olsson_monocyte_cds)[gene_list, order(monocyte_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_granulocyte_cds[gene_list, ]) * ncol(Olsson_granulocyte_cds)), nrow = ncol(Olsson_granulocyte_cds[gene_list, ]))
granulocyte_rdi <- calculate_rdi(t(exprs(Olsson_granulocyte_cds)[gene_list, order(granulocyte_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins

# make the network 
MEP_rdi_subset <- as.data.frame(MEP_rdi[, 1:77]); dimnames(MEP_rdi_subset) <- list(row.names(Olsson_MEP_cds[gene_list, ]), row.names(Olsson_MEP_cds[gene_list, ])) 
monocyte_rdi_subset <- as.data.frame(monocyte_rdi[, 1:77]); dimnames(monocyte_rdi_subset) <- list(row.names(Olsson_MEP_cds[gene_list, ]), row.names(Olsson_MEP_cds[gene_list, ])) 
granulocyte_rdi_subset <- as.data.frame(granulocyte_rdi[, 1:77]); dimnames(granulocyte_rdi_subset) <- list(row.names(Olsson_MEP_cds[gene_list, ]), row.names(Olsson_MEP_cds[gene_list, ])) 

MEP_quantile_res <- quantile_selection_network(MEP_rdi_subset, experiment = 'MEP')
monocyte_quantile_res <- quantile_selection_network(monocyte_rdi_subset, experiment = 'monocyte')
granulocyte_quantile_res <- quantile_selection_network(granulocyte_rdi_subset, experiment = 'granulocyte')

all_e <- Reduce(rbind, list(MEP_quantile_res, monocyte_quantile_res, granulocyte_quantile_res))
all_e$type[duplicated(all_e[, 1:2])] <- 'all'
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/all_e_Olsson.txt', all_e, sep = '\t', quote = F, col.names = T, row.names = F)

# ================================================================================================================================================
# Paul dataset
# ================================================================================================================================================
Paul_DC <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 3)]
Paul_Neu_Eos <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 1)]
Paul_Bas <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 4)]
Paul_Mono <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 6)]
Paul_MK <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 11)]
Paul_Ery <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 9)]

exprs(Paul_DC) <- as.matrix(exprs(Paul_DC))
exprs(Paul_Neu_Eos) <- as.matrix(exprs(Paul_Neu_Eos))
exprs(Paul_Bas) <- as.matrix(exprs(Paul_Bas))
exprs(Paul_Mono) <- as.matrix(exprs(Paul_Mono))
exprs(Paul_MK) <- as.matrix(exprs(Paul_MK))
exprs(Paul_Ery) <- as.matrix(exprs(Paul_Ery))

Paul_DC_dpt_res <- run_new_dpt(Paul_DC)
Paul_Neu_dpt_res <- run_new_dpt(Paul_Neu_Eos)
Paul_Bas_dpt_res <- run_new_dpt(Paul_Bas)
Paul_Mono_res <- run_new_dpt(Paul_Mono)
Paul_MK_dpt_res <- run_new_dpt(Paul_MK)
Paul_Ery_dpt_res <- run_new_dpt(Paul_Ery)

valid_gene_list <- gene_list[gene_list %in% row.names(Paul_DC)]
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_DC[valid_gene_list, ]) * ncol(Paul_DC)), nrow = ncol(Paul_DC[valid_gene_list, ]))
Paul_DC_rdi <- calculate_rdi(t(exprs(Paul_DC)[valid_gene_list, order(Paul_DC_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 2.298918 mins

# error 
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_Neu_Eos[valid_gene_list, ]) * ncol(Paul_Neu_Eos)), nrow = ncol(Paul_Neu_Eos[valid_gene_list, ]))
Paul_Neu_Eos_rdi <- calculate_rdi(t(exprs(Paul_Neu_Eos)[valid_gene_list, order(Paul_Neu_Eos_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
Neuo_Eos_t <- b -a ; 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_Bas[valid_gene_list, ]) * ncol(Paul_Bas)), nrow = ncol(Paul_Bas[valid_gene_list, ]))
Paul_Bas_rdi <- calculate_rdi(t(exprs(Paul_Bas)[valid_gene_list, order(Paul_Bas_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
Bas_t <- b -a ; 

# error 
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_Mono[valid_gene_list, ]) * ncol(Paul_Mono)), nrow = ncol(Paul_Mono[valid_gene_list, ]))
Paul_Mono_rdi <- calculate_rdi(t(exprs(Paul_Mono)[valid_gene_list, order(Paul_Mono_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
Mono_t <- b -a ; 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_MK[valid_gene_list, ]) * ncol(Paul_MK)), nrow = ncol(Paul_MK[valid_gene_list, ]))
Paul_MK_rdi <- calculate_rdi(t(exprs(Paul_MK)[valid_gene_list, order(Paul_MK_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
MK_t <- b -a ; 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_Ery[valid_gene_list, ]) * ncol(Paul_Ery)), nrow = ncol(Paul_Ery[valid_gene_list, ]))
Paul_Ery_rdi <- calculate_rdi(t(exprs(Paul_Ery)[valid_gene_list, order(Paul_Ery_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 7.702041 mins
Ery_t <- b -a ; 

# make the network 
Paul_DC_rdi_subset <- as.data.frame(Paul_DC_rdi[, 1:77]); dimnames(Paul_DC_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 
Paul_Neu_Eos_rdi_subset <- as.data.frame(Paul_Neu_Eos_rdi[, 1:77]); dimnames(Paul_Neu_Eos_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 
Paul_Bas_rdi_subset <- as.data.frame(Paul_Bas_rdi[, 1:77]); dimnames(Paul_Bas_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 
Paul_Mono_rdi_subset <- as.data.frame(Paul_Mono_rdi[, 1:77]); dimnames(Paul_Mono_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 
Paul_MK_rdi_subset <- as.data.frame(Paul_MK_rdi[, 1:77]); dimnames(Paul_MK_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 
Paul_Ery_rdi_subset <- as.data.frame(Paul_Ery_rdi[, 1:77]); dimnames(Paul_Ery_rdi_subset) <- list(row.names(Paul_Ery[gene_list, ]), row.names(Paul_Ery[gene_list, ])) 

Paul_DC_quantile_res <- quantile_selection_network(Paul_DC_rdi_subset, experiment = 'Paul_DC')
Paul_Neu_Eos_quantile_res <- quantile_selection_network(Paul_Neu_Eos_rdi_subset, experiment = 'Paul_Neu_Eos')
Paul_Bas_quantile_res <- quantile_selection_network(Paul_Bas_rdi_subset, experiment = 'Paul_Bas')
Paul_Mono_quantile_res <- quantile_selection_network(Paul_Mono_rdi_subset, experiment = 'Paul_Mono')
Paul_MK_quantile_res <- quantile_selection_network(Paul_MK_rdi_subset, experiment = 'Paul_MK')
Paul_Ery_quantile_res <- quantile_selection_network(Paul_Ery_rdi_subset, experiment = 'Paul_Ery')
                                                       
all_e <- Reduce(rbind, list(Paul_DC_quantile_res, Paul_Neu_Eos_quantile_res, Paul_Bas_quantile_res, Paul_Mono_quantile_res, Paul_MK_quantile_res, Paul_Ery_quantile_res))
all_e$type[duplicated(all_e[, 1:2])] <- 'all'
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/all_e_Paul.txt', all_e, sep = '\t', quote = F, col.names = T, row.names = F)

# ================================================================================================================================================
# Pancreas dataset
# ================================================================================================================================================
exprs(Pancreas_epsilon) <- as.matrix(exprs(Pancreas_epsilon))
exprs(Pancreas_alpha) <- as.matrix(exprs(Pancreas_alpha))
exprs(Pancreas_beta) <- as.matrix(exprs(Pancreas_beta))

Pancreas_epsilon_dpt_res <- run_new_dpt(Pancreas_epsilon)
Pancreas_alpha_dpt_res <- run_new_dpt(Pancreas_alpha)
Pancreas_beta_dpt_res <- run_new_dpt(Pancreas_beta)

# load the Pancreas network here 

pancreas_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/endocrine_progenitor_network', sep = '\t', header = T)
adult_beta_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/adule_beta_cell_network', sep = '\t', header = T)
immature_beta_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/immature_beta_cell_network', sep = '\t', header = T)

#check wether or not the gene list is included in the paper: 
gene_pairs1 <- pancreas_network[, 2:3]
gene_pairs2 <- adult_beta_network[, 2:3]
gene_pairs3 <- immature_beta_network[, 2:3]

gene_list <- c(as.character(gene_pairs1$Source..regulates.), as.character(gene_pairs1$Target..regulated.),
               as.character(gene_pairs2$Source..regulates.), as.character(gene_pairs2$Target..regulated.),
               as.character(gene_pairs3$Source..regulates.), as.character(gene_pairs3$Target..regulated.))
as.character(gene_list) %in% 
  fData(panc_cds_valid_cells)$gene_short_name

#gene missing
unique(gene_list[!(as.character(gene_list) %in% fData(panc_cds_valid_cells)$gene_short_name)])
# "Nkx2.2" "Nkx6.1" "Nkx6.2" "cMyc"   "Glut2"  "Dnmt1a" "NFATc1" "CcnA2"  "ChgA"   "ChgB"   "Ia2"    "Tnfa"

#updated: 
# "Nkx2-2" "Nkx6-1" "Nkx6-2" "Myc"   "Slc2a2"  "Dnmt1" "Nfatc1" "Ccna2"  "Chga"   "Chgb"   "Ptprn"    "Tnf"  

c("Nkx2-2", "Nkx6-1", "Nkx6-2", "Myc", "Slc2a2", "Dnmt1", "Nfatc1", "Ccna2", "Chga", "Chgb", "Ptprn", "Tnf")
#find the missing gene name and correct the gene regulatory network
pancreas_network$Source..regulates. <- revalue(pancreas_network$Source..regulates., 
                                               c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                 'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                 'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
pancreas_network$Target..regulated. <- revalue(pancreas_network$Target..regulated., 
                                               c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                 'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                 'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
adult_beta_network$Source..regulates. <- revalue(adult_beta_network$Source..regulates., 
                                                 c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                   'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                   'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
adult_beta_network$Target..regulated. <- revalue(adult_beta_network$Target..regulated., 
                                                 c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                   'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                   'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
immature_beta_network$Source..regulates. <- revalue(immature_beta_network$Source..regulates., 
                                                    c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                      'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                      'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
immature_beta_network$Target..regulated. <- revalue(immature_beta_network$Target..regulated., 
                                                    c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
                                                      'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
                                                      'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
gene_list_update <- c(as.character(immature_beta_network$Source..regulates.), as.character(immature_beta_network$Target..regulated.),
                      as.character(adult_beta_network$Source..regulates.), as.character(adult_beta_network$Target..regulated.),
                      as.character(pancreas_network$Source..regulates.), as.character(pancreas_network$Target..regulated.))

unique_gene_list_update <- row.names(subset(fData(Pancreas_epsilon), gene_short_name %in% unique(gene_list_update)))
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Pancreas_epsilon[unique_gene_list_update, ]) * ncol(Pancreas_epsilon)), nrow = ncol(Pancreas_epsilon[unique_gene_list_update, ]))
Pancreas_epsilon_rdi <- calculate_rdi(t(exprs(Pancreas_epsilon)[unique_gene_list_update, order(Pancreas_epsilon_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 1.418367 mins
Epsilon_t <- b -a; 

# there are duplicated points consider that 
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Pancreas_alpha[unique_gene_list_update, ]) * ncol(Pancreas_alpha)), nrow = ncol(Pancreas_alpha[unique_gene_list_update, ]))
Pancreas_alpha_rdi <- calculate_rdi(t(exprs(Pancreas_alpha)[unique_gene_list_update, order(Pancreas_alpha_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
Alpha_t <- b - a; 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Pancreas_beta[unique_gene_list_update, ]) * ncol(Pancreas_beta)), nrow = ncol(Pancreas_beta[unique_gene_list_update, ]))
Pancreas_epsilon_rdi <- calculate_rdi(t(exprs(Pancreas_beta)[unique_gene_list_update, order(Pancreas_beta_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 2.363493
Beta_t <- b - a; 


# ================================================================================================================================================
# Other datasets: Lung dataset, LPS dataset, the KO dataset, other datasets we studied before 
# ================================================================================================================================================
# test on lung dataset 
# ================================================================================================================================================

lung <- load_lung()
AT1_cds <- lung[, pData(lung)$State %in% c(1, 3)]
AT2_cds <- lung[, pData(lung)$State %in% c(1, 2)]

AT1_dpt_res <- run_new_dpt(AT1_cds)
AT2_dpt_res <- run_new_dpt(AT2_cds)

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(AT1_cds) * ncol(AT1_cds)), nrow = ncol(AT1_cds))
AT1_rdi <- calculate_rdi(t(exprs(AT1_cds)[, order(AT1_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
AT1_time <- b - a; 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(AT2_cds) * ncol(AT2_cds)), nrow = ncol(AT2_cds))
AT2_rdi <- calculate_rdi(t(exprs(AT2_cds)[, order(AT2_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 3.16208 mins
AT2_time <- b - a; 

# ================================================================================================================================================
# test on LPS dataset 
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/Shalek_abs_subset_ko_LPS_new') # load the LPS dataset
# ================================================================================================================================================
exprs(Shalek_abs_subset_ko_LPS_new) <- as.matrix(exprs(Shalek_abs_subset_ko_LPS_new))

grn_fig4a <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Rbl1", "Usp25", "Daxx", "Cd40", "Atm", "Irf1", "Ligp2", "Mertk", "Cxcl11", "Trim12a", "Trim21", "NfkbIz")
grn_fig4b <- c("NFKBIZ", "ATF4", "ATF4", "Ilf2b", "FUS", "RBL1", "RBL1", "ligp1", "CBX4", "DNMT3A", "DNMT3A", "Ifnb1", "NFKBIZ", "FOS", "FOS", "Il12b", "JUN", "FUS", "FUS", "IFNB1", "FUS", "NFkbIz", "NFKBIZ", "FOS", "CBX4", "STAT1", "STAT1", "IFnb1", "CEBPZ", "HHEX", "HHEX", "IL12b")
grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")

grn_all_genes <- c(grn_fig4a, grn_fig4b, grn_fig4c) 
LPS_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_network', header = T)

grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(grn_all_genes)))
missing_genes <- grn_all_genes[!(toupper(grn_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS_new)$gene_short_name))]

all_network_genes <- c(as.character(LPS_network$Source), as.character(LPS_network$Target))
network_missing_genes <- all_network_genes[!(toupper(c(all_network_genes)) %in% toupper(fData(Shalek_abs_subset_ko_LPS_new)$gene_short_name))]

top_group <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "FUS")
bottom_group <- c("Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Usp25", "Daxx", "Cd40", "Atm", "Lrf1", "Lgp2", "Mertk", "Cxcl11", "Trim12", "Trim21")

top_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(top_group)))
fData(Shalek_abs_subset_ko_LPS_new)[grn_ids, 'gene_short_name']
bottom_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(bottom_group)))
fData(Shalek_abs_subset_ko_LPS_new)[bottom_group_ids, 'gene_short_name']

# run_dpt_new: 
grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV8", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")
fig4c_layer1 <- c("Tlr2", "Tlr3", "Tlr4")
fig4c_layer2.1 <- c("STAT1", "STAT2", "IRF8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1")
fig4c_layer2.2 <- c("PLAGL2", "NFKB1", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2")
fig4c_layer3.1 <- c("HMGN3", "FUS", "SAP30")
fig4c_layer3.2 <- c("NFE2L2", "IRF4", "FOS")
fig4c_layer4.1 <- c("CXCL10", "Ifnb1", "IL15")
fig4c_layer4.2 <- c("IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3")

#only the small network: 
LPS_subset_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_subset_network', header = T)

grn_subset_all_genes <- c(as.character(LPS_subset_network$Source), as.character(LPS_subset_network$Target))
subset_grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(grn_subset_all_genes)))
missing_genes <- grn_subset_all_genes[!(toupper(grn_subset_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS_new)$gene_short_name))]

order_LPS_subset_mat <- as.matrix(exprs(Shalek_abs_subset_ko_LPS_new)[subset_grn_ids, order(pData(Shalek_abs_subset_ko_LPS_new)$Pseudotime)])
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_LPS_subset_mat.txt', order_LPS_subset_mat, col.names = T, sep = '\t', row.names = T, quote = F)

plot_genes_in_pseudotime(Shalek_abs_subset_ko_LPS_new[top_group_ids, ])

################################################################################################################################################################
# use the new network 
################################################################################################################################################################
TF_hiearchy <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/TF_hiearchy.txt', header = T, row.names = 1)

gene_names <- colnames(TF_hiearchy)
gene_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), gene_short_name %in% gene_names))
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), gene_short_name %in% gene_id1))), 
                     Gene_1_NAME = c(gene_id1), Gene_2_ID = c(row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), gene_short_name %in% gene_id2))),
                     Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     HT_seq = TF_hiearchy[gene_id1, gene_id2] )
    write.table(file = 'TF_hiearchy_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

ht_chip_order_LPS_mat <- as.matrix(exprs(Shalek_abs_subset_ko_LPS_new)[gene_ids, order(pData(Shalek_abs_subset_ko_LPS_new)$Pseudotime)])
fd <- fData(Shalek_abs_subset_ko_LPS_new[gene_ids, ])

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_order_LPS_mat.txt', ht_chip_order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)

################################################################################################################################################################
# Run the RDI on the genes 
################################################################################################################################################################
Normal_cells <- Shalek_abs_subset_ko_LPS_new[, pData(Shalek_abs_subset_ko_LPS_new)$State %in% c(1, 3)]
KO_cells <- Shalek_abs_subset_ko_LPS_new[, pData(Shalek_abs_subset_ko_LPS_new)$State %in% c(2, 3)]

Normal_cells_dpt_res <- run_new_dpt(Normal_cells)
KO_cells_dpt_res <- run_new_dpt(KO_cells)

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Normal_cells[gene_ids, ]) * ncol(Normal_cells)), nrow = ncol(Normal_cells[gene_ids, ]))
Normal_rdi <- calculate_rdi(t(exprs(Normal_cells)[gene_ids, order(Normal_cells_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 28.74997 secs
Normal_cells_time <- b - a 

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(KO_cells[gene_ids, ]) * ncol(KO_cells)), nrow = ncol(KO_cells[gene_ids, ]))
KO_rdi <- calculate_rdi(t(exprs(KO_cells)[gene_ids, order(KO_cells_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 22.30035 secs
KO_cells_time <- b - a 

Normal_rdi_subset <- as.data.frame(Normal_rdi[, 1:23]); dimnames(Normal_rdi_subset) <- list(as.character(fData(Normal_cells[gene_ids, ])$gene_short_name), as.character(fData(Normal_cells[gene_ids, ])$gene_short_name)) 
Normal_rdi_quantile_res <- quantile_selection_network(Normal_rdi_subset, experiment = 'Normal_LPS_rdi')
KO_rdi_subset <- as.data.frame(KO_rdi[, 1:23]); dimnames(Normal_rdi_subset) <- list(as.character(fData(Normal_cells[gene_ids, ])$gene_short_name), as.character(fData(Normal_cells[gene_ids, ])$gene_short_name)) 
Normal_rdi_quantile_res <- quantile_selection_network(Normal_rdi_subset, experiment = 'Normal_LPS_rdi')

all_e <- Reduce(rbind, list(Normal_rdi_quantile_res, Normal_rdi_quantile_res))
all_e$type[duplicated(all_e[, 1:2])] <- 'all'
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/all_e_LPS.txt', all_e, sep = '\t', quote = F, col.names = T, row.names = F)

################################################################################################################################################################
# analyze HSMM dataset 
################################################################################################################################################################


################################################################################################################################################################
# analyze BJ-myo dataset 
################################################################################################################################################################


################################################################################################################################################################
# analyze the pseudospatial dataset  
################################################################################################################################################################


# ================================================================================================================================================
# Save other datasets
# ================================================================================================================================================

save.image('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/test_scRNA_seq.RData')

