######################################################################################################################################
rm(list = ls())
#######################################################################################################################################

# analysis for other lineages:
# AB; MS, E; C, (D, P4)

# this script is used to do a detailed analysis for the E lineage
library(Scribe)
library(igraph)
library(monocle)
library(reshape2)
library(ggraph)
library(extrafont)
font_import() # create the line network plot with ggraph
loadfonts()
library(plyr)
library(dplyr)

# convert gene name to conventional names:
convert_to_true_ids <- function(x) {
  splited <- stringr::str_split_fixed(x, '\\.', 2) # tools::toTitleCase()
  paste0(splited[, 1], '-', splited[, 2])
}

# load('./RData/analysis_c_elegans.RData')
# load('./RData/fig_6_worm.RData')

load('./RData/fig6.RData')
#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################
c_elegans_data_ori_dup2 <- abs(min(c_elegans_data_ori_dup)) + c_elegans_data_ori_dup + 1 # remove NaN values
pd <- new("AnnotatedDataFrame", data = pData(c_elegans_cds))
fd <- new("AnnotatedDataFrame", data = fData(c_elegans_cds))

# use for creating the response, causality and combinatorial logic plot
c_elegans_data_ori_dup2_norm <- apply(c_elegans_data_ori_dup2, 1, function(x) (x - min(x)) / (max(x) - min(x)))
c_elegans_data_ori_dup2_norm[!is.finite(c_elegans_data_ori_dup2_norm)] <- 0
c_elegans_cds2 <- newCellDataSet(as(c_elegans_data_ori_dup2_norm, 'sparseMatrix'),
                                phenoData = pd,
                                featureData = fd,
                                lowerDetectionLimit=1,
                                expressionFamily=gaussianff())
####################################################################################################################################################################################
# visualize the AB, MS, E, C, P, D lineage master genes as well as the regulatory network
# add the same analysis as in figure 6 for the D lineage
####################################################################################################################################################################################
# show the cell type distribution across lineages
pdf(paste0(SI_fig_dir, 'cell_type_lineage.pdf'), width =  7, height = 5)
pheatmap::pheatmap(t(log(table(pData(c_elegans_cds)[, c('founder_cell', 'cell.type')]) + 1)), cluster_cols = F, cluster_rows = F)
dev.off()

muscle_genes <- c('hnd.1', 'unc.120', 'hlh.1')
intestine_gene <- c('end.3', 'end.1', 'elt.2', 'elt.7', 'elt.1')

epidermal_gene <- c('elt.1', 'lin.26', 'elt.3', 'nhr.25', 'mab.21')
valid_epidermal_gene <- epidermal_gene[epidermal_gene %in% row.names(c_elegans_cds2) ]

post_pharynx <- c('pha.4', 'hlh.6', 'ceh.22', 'peb.1')
valid_post_pharynx <- post_pharynx[post_pharynx %in% row.names(c_elegans_cds2) ]

MS_genes <- c('med.1', 'med.2', 'tbx.35', 'pha.4', 'hlh.1', 'ceh.51', 'ceh.22', 'hlh.6', 'myo.2', 'end.1', 'end.3', 'wee.1.1', 'hnd.1', 'myo.3', 'unc.120')
valid_MS_genes <- MS_genes[MS_genes %in% row.names(c_elegans_cds2) ]

AB <- c('tbx.37', 'tbx.38', 'glp.1', 'pha.4', 'tbx.2', 'ceh.22', 'myo.2')
valid_AB_genes <- AB[AB %in% row.names(c_elegans_cds2) ]

early_embryogenesis <- c('mex.3', 'mex.1', 'gld.1', 'skn.1', 'zif.1', 'oma.1', 'gsk.3', 'mbk.2', 'cdk.1', 'kin.19', 'pie.1', 'pos.1', 'med.1', 'med.2', 'pop.1', 'spn.4', 'mom.2', 'wrm.1', 'lit.1')
valid_early_embryogenesis_genes <- early_embryogenesis[early_embryogenesis %in% row.names(c_elegans_cds2) ]

table(pData(c_elegans_cds2)[, 'cell.type'])

plot_three_set_causality_figs <- function(cell_type, cell.type, gene_list, response_mat, causality_mat, combinatorial_mat,
                                          width_vec = c(1, 1, 1), height_vec = c(1.5, 1.5, 1), select_type = 'cell.type') {
  message('response plot ...')
  pdf(paste0(SI_fig_dir, cell_type, '_response.pdf'), width =  width_vec[1], height = height_vec[1])
  print(plot_lagged_drevi(c_elegans_cds2[gene_list, which(pData(c_elegans_cds2)[, select_type] == cell.type)],
                    gene_pairs_mat = response_mat, grid_num = 40, log = T) +
    xacHelper::nm_theme())
  dev.off()

  message('caussality plot ...')
  pdf(paste0(SI_fig_dir,  cell_type, '_causality.pdf'), width =  width_vec[2], height = height_vec[2])
  print(plot_gene_pairs_causality(c_elegans_cds2[gene_list, which(pData(c_elegans_cds2)[, select_type] == cell.type)],
                            gene_pairs_mat = causality_mat, grid_num = 25, log = F) +
    theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9)) +
    xacHelper::nm_theme())
  dev.off()

  message('combinatorial logic plot ...')
  pdf(paste0(SI_fig_dir, cell_type, '_combinatorial.pdf'), width =  width_vec[3], height = height_vec[3])
  print(plot_comb_logic(c_elegans_cds2[gene_list, which(pData(c_elegans_cds2)[, select_type] == cell.type)],
                  gene_pairs_target_mat = combinatorial_mat, grid_num = 25, log = F) +
    xacHelper::nm_theme() +
    theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9)))
  dev.off()
}

# muscle
plot_three_set_causality_figs('muscle', 'body muscle', muscle_genes,
                              response_mat = matrix(c('hnd.1', 'unc.120', 'hlh.1', 'unc.120'), nrow = 2, byrow = T),
                              causality_mat = matrix(c('hnd.1', 'unc.120', 'hlh.1', 'unc.120'), nrow = 2, byrow = T),
                              combinatorial_mat = matrix(c('hnd.1', 'hlh.1', 'unc.120'), nrow = 1))

# intestine
plot_three_set_causality_figs('intestine', 'intestine', c('end.1', 'end.3', 'elt.2', 'elt.7'),
                              response_mat = matrix(c('end.1', 'elt.2', 'end.3', 'elt.7'), nrow = 2, byrow = T),
                              causality_mat = matrix(c('end.1', 'elt.2', 'end.3', 'elt.7'), nrow = 2, byrow = T),
                              combinatorial_mat = matrix(c('end.1', 'end.3', 'elt.2', 'end.1', 'end.3', 'elt.7'), nrow = 2, byrow = T),
                              width_vec = c(1, 1, 1),
                              height_vec = c(1.5, 1.5, 1.5))
# epidermal
plot_three_set_causality_figs('hypodermis', 'hypodermis', c('elt.1', 'elt.3', 'nhr.25'),
                              response_mat = matrix(c('elt.1', 'elt.3', 'elt.1', 'nhr.25'), nrow = 2, byrow = T),
                              causality_mat = matrix(c('elt.1', 'elt.3', 'elt.1', 'nhr.25'), nrow = 2, byrow = T),
                              combinatorial_mat = matrix(c('elt.1', 'elt.3', 'nhr.25'), nrow = 1, byrow = T),
                              width_vec = c(1, 1, 1),
                              height_vec = c(1.5, 1.5, 1))

# MS
plot_three_set_causality_figs('MS', 'MS', c('tbx.35', 'pha.4', 'ceh.22', 'hlh.1'),
                              response_mat = matrix(c('tbx.35', 'pha.4', 'tbx.35', 'ceh.22'), nrow = 2, byrow = T),
                              causality_mat = matrix(c('tbx.35', 'pha.4', 'tbx.35', 'ceh.22'), nrow = 2, byrow = T),
                              combinatorial_mat = matrix(c('tbx.35', 'pha.4', 'hlh.1'), nrow = 1, byrow = T),
                              width_vec = c(1, 1, 1),
                              height_vec = c(1.5, 1.5, 1), select_type = 'founder_cell')

# AB
plot_three_set_causality_figs('AB', 'AB', valid_AB_genes,
                              response_mat = matrix(c('tbx.37', 'pha.4', 'tbx.38', 'pha.4', 'pha.4', 'tbx.2', 'pha.4', 'ceh.22'), ncol = 2, byrow = T),
                              causality_mat = matrix(c('tbx.37', 'pha.4', 'tbx.38', 'pha.4', 'pha.4', 'tbx.2', 'pha.4', 'ceh.22'), ncol = 2, byrow = T),
                              combinatorial_mat = matrix(c('tbx.37', 'tbx.38', 'pha.4', 'pha.4', 'tbx.2', 'ceh.22'), ncol = 3, byrow = T),
                              width_vec = c(1, 1, 1),
                              height_vec = c(3, 3, 1.5), select_type = 'founder_cell')

# early embryogenesis
# plot_three_set_causality_figs('early embryogenesis', 'MS', c('tbx.35', 'pha.4', 'ceh.22', 'hlh.1'),
#                               response_mat = matrix(c('tbx.35', 'pha.4', 'tbx.35', 'ceh.22'), nrow = 2, byrow = T),
#                               causality_mat = matrix(c('tbx.35', 'pha.4', 'tbx.35', 'tbx.35'), nrow = 2, byrow = T),
#                               combinatorial_mat = matrix(c('tbx.37', 'tbx.38', 'pha.4', 'pha.4', 'tbx.2', 'ceh.22'), ncol = 3, byrow = T),
#                               width_vec = c(1, 1, 1),
#                               height_vec = c(1.5, 1.5, 1), select_type = 'founder_cell')

plot_lagged_drevi(c_elegans_cds2[valid_early_embryogenesis_genes, which(pData(c_elegans_cds2)[, 'time'] < 50)], gene_pairs_mat = matrix(c('med.2', 'wrm.1'), ncol = 2, byrow = T), grid_num = 40, log = T)
plot_gene_pairs_causality(c_elegans_cds2[valid_early_embryogenesis_genes, which(pData(c_elegans_cds2)[, 'time'] < 50)], gene_pairs_mat = matrix(c('med.2', 'wrm.1'), ncol = 2, byrow = T), grid_num = 25, log = F)
# plot_comb_logic(c_elegans_cds2[valid_MS_genes, which(pData(c_elegans_cds2)[, 'time'] < 30)], gene_pairs_target_mat =  matrix(c('tbx.35', 'hnd.1', 'hlh.1'), ncol = 3, byrow = T), grid_num = 25, log = F)

####################################################################################################################################################################################
# 1. end. 1/3; elt2/7 to show the causality
####################################################################################################################################################################################

# df1 %>% arrange(grp, -x)
# df1 %>% arrange(grp, desc(x))

plot_kinetic_curves_marker_genes <- function(current_gene, cur_cell_types, cell.type, select_type = 'founder_cell') {
  curr_cell_vec <- as.character(unique(pData(c_elegans_cds2)[which(pData(c_elegans_cds2)[, select_type] == cell.type), "cell"]))
  valid_muscle_cell_id <- which(expressed_cnt2$cell %in% curr_cell_vec)
  sorted_expressed_cnt2 <- expressed_cnt2[valid_muscle_cell_id, ] %>% arrange(desc(eval(parse(text = current_gene[1]))),
                                                                              desc(eval(parse(text = current_gene[2]))),
                                                                              desc(eval(parse(text = current_gene[3])))) # valid_muscle_cell_id

  good_gene_lineages <- as.character(sorted_expressed_cnt2[, 'cell'][[1]])

  cell_id <-  good_gene_lineages[1] #'Capaaa' #Muscle: 5, 6, 8
  message('cell_id is: ', cell_id)
  # cell_id <-  "MSpapaapap" #"Capaa" #

  get_cell_lineage <- function(cell_id) {
    cell_id_vec <- strsplit(cell_id, "")[[1]]

    cell_lineage_vec <- c()
    for(i in 1:length(cell_id_vec)) {
      cell_lineage_vec <- c(cell_lineage_vec, paste0(cell_id_vec[1:i], collapse = ''))
    }
    return(cell_lineage_vec)
  }

  cell_lineage_ids <- get_cell_lineage(cell_id)

  if(length(grep('E', cell_lineage_ids)) > 0 | length(grep('M', cell_lineage_ids))> 0 ) {
    cell_lineage_ids <- c(c('P0', 'P1', 'EMS'), cell_lineage_ids)
  } else {
    cell_lineage_ids <- cell_lineage_ids
  }

  test_c_elegans_data_ori <- subset(c_elegans_data, cell == cell_id)
  test_c_elegans_data_ori <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids) # === cell_id

  test_c_elegans_data <- t(test_c_elegans_data_ori[, -c(1:6)])
  colnames(test_c_elegans_data) <- subset(c_elegans_data, cell %in% cell_lineage_ids)[, 'time']

  qplot(1:ncol(test_c_elegans_data), test_c_elegans_data[1, ])

  # xacHelper::multiplot(plotlist = list(p1, p2, p3))

  min_time <- min(subset(test_c_elegans_data_ori, is.finite(eval(parse(text = current_gene[1]))) & is.finite(eval(parse(text = current_gene[2]))) & is.finite(eval(parse(text = current_gene[3]))))[, 'time'])
  max_time <- max(subset(test_c_elegans_data_ori, is.finite(eval(parse(text = current_gene[1]))) & is.finite(eval(parse(text = current_gene[2]))) & is.finite(eval(parse(text = current_gene[3]))))[, 'time'])

  # test_c_elegans_data <- subset(test_c_elegans_data_ori, time > min_time & time < max_time)

  Expression <- c()
  for(iter_gene in current_gene) {
    iter_rng <- range(test_c_elegans_data[iter_gene, ], na.rm = T)
    Expression <- c(Expression, c(test_c_elegans_data[iter_gene, ] - iter_rng[1]) / diff(iter_rng))
  }

  panel_a_df <- data.frame(Time = test_c_elegans_data_ori$time,
                           Expression = Expression, #
                           gene_short_name = c(rep(current_gene, each = nrow(test_c_elegans_data_ori))))

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_plot_kinetics.pdf'), width =  1, height = 1)
  print(ggplot(aes(Time, Expression), data = panel_a_df) + geom_smooth(aes(color = gene_short_name), size = 0.5) +
          xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)) + xlim(min_time, max_time)) #+ ylim(0, 1)
  dev.off()

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_plot_kinetics_ori.pdf'), width =  1, height = 1)
  print(ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) +
          xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)) + xlim(min_time, max_time))
  dev.off()

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_plot_kinetics_helper.pdf'))
  print(ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) +
          xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)))
  dev.off()

  # function to create a time series starting from the very beginning:
  pData <- test_c_elegans_data_ori[, 1:6]
  row.names(pData) <- test_c_elegans_data_ori$time
  pData$Pseudotime <- pData$time
  pd <- new("AnnotatedDataFrame", data = pData)
  fData <- data.frame(gene_short_name = row.names(test_c_elegans_data), row.names = row.names(test_c_elegans_data))
  fd <- new("AnnotatedDataFrame", data = fData)

  # Now, make a new CellDataSet using the RNA counts
  test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0 # remove NaN values
  test_cds <- newCellDataSet(test_c_elegans_data,
                             phenoData = pd,
                             featureData = fd,
                             lowerDetectionLimit=1,
                             expressionFamily=gaussianff())

  test_cds <- test_cds[, pData(test_cds)$time < 250]
  test_urdi_res <- calculate_rdi(test_cds[current_gene, ], delays = c(1:5), uniformalize = T, log = F, pseudo_cnt = 0) #
  test_rdi_res <- calculate_rdi(test_cds[current_gene, ], delays = c(1:5), uniformalize = F, log = F, pseudo_cnt = 0) #

  test_umi_res <- calculate_umi(test_cds[current_gene, ], log = F)

  test_rdi_res <- calculate_rdi(test_cds[current_gene, ], delays = c(1:5), uniformalize = F, log = F) #muscle_genes
  con_test_rdi_res <- calculate_conditioned_rdi(test_cds[current_gene, ], rdi_list = test_rdi_res, uniformalize = T, top_incoming_k = 2, log = F) #muscle_genes

  inflection_points <- apply(exprs(test_cds)[current_gene, ], 1, function(data) {
    inflection_point <- inflection::bede(1:length(data), data, 0)
    if (!is.finite(inflection_point$iplast))
      inflection_point <- inflection::bede(1:length(data), data,
                                           1)
    round(inflection_point$iplast)
  })

  p1 <- qplot(pData(test_cds)$time, exprs(test_cds)[current_gene[1], ]) + xlab('Time') + ylab(current_gene[1]) + ggtitle(paste('Cell name:', cell_id)) +
    geom_vline(xintercept = inflection_points[1] + min(pData(test_cds)$time))
  p2 <- qplot(pData(test_cds)$time, exprs(test_cds)[current_gene[2], ]) + xlab('Time') + ylab(current_gene[2]) + ggtitle(paste('Cell name:', cell_id)) +
    geom_vline(xintercept = inflection_points[2] + min(pData(test_cds)$time))
  p3 <- qplot(pData(test_cds)$time, exprs(test_cds)[current_gene[3], ]) + xlab('Time') + ylab(current_gene[3]) + ggtitle(paste('Cell name:', cell_id)) +
    geom_vline(xintercept = inflection_points[3] + min(pData(test_cds)$time))

  # xacHelper::multiplot(plotlist = list(p1, p2, p3))

  dimnames(test_rdi_res$max_rdi_value) <- list(convert_to_true_ids(current_gene), convert_to_true_ids(current_gene))
  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_plot.pdf'), width =  1, height = 1)
  pheatmap::pheatmap(test_rdi_res$max_rdi_value[convert_to_true_ids(current_gene), convert_to_true_ids(current_gene)], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = F, border_color = NA)
  dev.off()

  dimnames(test_urdi_res$max_rdi_value) <- list(convert_to_true_ids(current_gene), convert_to_true_ids(current_gene))
  pheatmap::pheatmap(test_urdi_res$max_rdi_value[convert_to_true_ids(current_gene), convert_to_true_ids(current_gene)], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_uMI_plot.pdf'), width =  1, height = 1)
  pheatmap::pheatmap(test_urdi_res$max_rdi_value[convert_to_true_ids(current_gene), convert_to_true_ids(current_gene)], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)
  dev.off()

  adj_mat <- test_rdi_res$max_rdi_value
  diag(adj_mat) <- 0
  # adj_mat[adj_mat < t(adj_mat)] <- 0

  adj_mat_cp <- adj_mat
  # adj_mat_cp[adj_mat_cp != 0] <- 0
  #
  col_means <- colMeans(adj_mat_cp)
  col_sd <- apply(adj_mat_cp, 2, sd)
  col_sd[col_sd == 0] <- 1e-4

  adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
    row_i <- adj_mat_cp[x, ]
    row_sd <- sd(row_i)
    row_sd[row_sd == 0] <- 1e-4
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd)

    sqrt(s_i_vec^2 + s_j_vec^2)
  })

  adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp)
  dimnames(adj_mat_cp2) <- dimnames(adj_mat)
  # visualize TF network with the top genes
  z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])

  if(nrow(adj_mat_cp2) > 8) {
    z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
    z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)

  }
  adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0

  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)

  # remove zero-input/out-genes:
  adj_col_sum <- colSums(adj_mat_cp2)
  adj_row_sum <- rowSums(adj_mat_cp2)
  olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
  if(length(olphan_genes) > 0)
    adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]

  # keep the largest edge between two genes
  adj_mat_cp2[adj_mat_cp2 < t(adj_mat_cp2)] <- 0

  g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
  V(g)$name <- convert_to_true_ids(V(g)$name)

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_lineage_net.pdf')) # paste0(SI_fig_dir, 'worm_', cur_cell_types, '_uMI_plot.pdf')
  plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
  dev.off()

  V(g)$hubness <- hub_score(g)$vector

  pdf(paste0(SI_fig_dir, 'worm_', cur_cell_types, '_lineage_net.pdf'), height = 4, width = 8)
  print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
          geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                        ends = "last", type = "open")) +
          scale_edge_width(range = c(0.2, 2)) +
          geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
          labs(edge_width = "Causality") +
          theme_graph())
  dev.off()

  # half-max plot
  norm_test_c_elegans_data <- apply(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) > 100 & as.numeric(colnames(test_c_elegans_data)) < 250], 1, function(x) {
    x_rng <- range(x)
    norm_x <- (x - x_rng[1])/ (diff(x_rng))

    df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) > 100 & as.numeric(colnames(test_c_elegans_data)) < 250])),
                     val = norm_x)
    l_model <- loess(val ~ Time, df)
    res <- predict(l_model)

    return(res)
  })


  curves <- t(norm_test_c_elegans_data)

  hm_mat <- as.matrix(curves)
  hm_mat_scaled <- hm_mat
  # hm_mat_scaled <- hm_mat - apply(hm_mat, 1, min)
  # hm_mat_scaled <- hm_mat_scaled / apply(hm_mat_scaled, 1, max)

  hm_mat_scaled_z <- t(scale(t(hm_mat)))
  temp <- hm_mat_scaled_z < 0
  #temp <- temp[,10:90]
  transient <- apply(temp, 1, function(x) {
    current <- x[1]
    count <- 0
    for(y in x) {
      if (y != current) {
        count <- count + 1
        current <- y
      }
    }
    count
  })

  trans_max <- apply(hm_mat_scaled, 1, which.max)
  trans <- hm_mat_scaled[transient > 1 & !trans_max %in% c(1:5, (dim(hm_mat_scaled) - 5):(dim(hm_mat_scaled))),]

  row_dist <- as.dist((1 - cor(Matrix::t(trans)))) #/2
  row_dist[is.na(row_dist)] <- 1
  clust <- pheatmap::pheatmap(trans, cluster_cols = FALSE, clustering_distance_rows = row_dist, clustering_method="ward.D2",scale="none", show_rownames = FALSE, silent=TRUE, show_colnames = FALSE)

  anno_row <- as.data.frame(cutree(clust$tree_row, 12))
  names(anno_row)<- "cluster"
  anno_row$cluster <- as.factor(anno_row$cluster)

  pheatmap::pheatmap(trans, cluster_cols = FALSE, scale="none",clustering_method="ward.D2", show_rownames = FALSE, annotation_row = anno_row, show_colnames = FALSE) # filename = "find_transient.pdf",

  trans_list <- row.names(trans)

  nt <- hm_mat_scaled[!row.names(hm_mat_scaled) %in% trans_list,]
  up <- nt[nt[,1] < nt[,ncol(hm_mat_scaled)],]
  down <- nt[nt[,1] > nt[,ncol(hm_mat_scaled)],]

  up_cp <- apply(up, 1, function(x) which.min(abs(x - 0.5)) )
  up <- up[order(up_cp),]

  down_cp <- apply(down, 1, function(x) which.min(abs(x - 0.5)) )
  down <- down[order(down_cp),]

  all <- rbind(up, down)

  trans_cp <- apply(trans, 1, function(x) which.min(abs(x - 0.5)))
  trans <- trans[order(trans_cp),]

  all <- rbind(all, trans)
  clusts <-  pheatmap::pheatmap(all,
                                color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                                fontsize = 6,
                                scale = "none",
                                width=2,
                                height=3,
                                gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                                cluster_cols = FALSE,
                                cluster_rows = FALSE,
                                show_colnames = FALSE,
                                show_rownames = FALSE)
  pheatmap::pheatmap(all, legend = FALSE,
                     #annotation_colors = list(Type = c(Proximal = "#241023", `Other Distal` = "#47A025", `Distal Enhancer` = "#735CDD")),
                     color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                     fontsize = 6,
                     scale = "none",
                     width=2.8,
                     height=3.3,
                     gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                     cluster_cols = FALSE,
                     cluster_rows = FALSE,
                     show_colnames = FALSE,
                     show_rownames = FALSE)

  if(!exists("cur_cell_types")) {
    cur_cell_types <- cell_types[2]
  }

  pdf(paste0(SI_fig_dir, 'c_elegans_', cur_cell_types, '_heatmap.pdf'), width =  1, height = 2)
  pheatmap::pheatmap(all,
                     #color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                     fontsize = 6,
                     scale = "none",
                     width=2,
                     height=3,
                     gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                     cluster_cols = FALSE,
                     cluster_rows = FALSE,
                     show_colnames = FALSE,
                     legend = F,
                     border_color = NA,
                     show_rownames = FALSE)
  dev.off()

  #
}

cell_types <- c("muscle", "intestine", "epidermal", "post_pharynx", "MS", "AB", "early_embryogenesis")
# muscle_genes, intestine_gene valid_epidermal_gene valid_post_pharynx valid_MS_genes valid_AB_genes valid_early_embryogenesis_genes

current_gene <- muscle_genes
cell_types <- c("body muscle", "intestine", "hypodermis", "MS", "AB") # "post_pharynx", , "early_embryogenesis"

plot_kinetic_curves_marker_genes(muscle_genes, 'muscle', 'body muscle', 'cell.type') # MSpappa
plot_kinetic_curves_marker_genes(intestine_gene, 'intestine', 'intestine', 'cell.type') # Eplp
plot_kinetic_curves_marker_genes(valid_epidermal_gene, 'epidermal', 'hypodermis', 'cell.type') # Cpapa
plot_kinetic_curves_marker_genes(valid_MS_genes, 'MS', 'MS', 'founder_cell') # MSaaapp
plot_kinetic_curves_marker_genes(valid_AB_genes, 'AB', 'AB', 'founder_cell') # ABarppapa

####################################################################################################################################################################################
# make the causality network plot with a graph
####################################################################################################################################################################################

# E
E_valid_cells <- c('E', 'Ea', 'Eal', 'Eala', 'Ealp', 'Ear', 'Eara', 'Earp', 'Ep', 'Epl', 'Epla', 'Eplp', 'Epr', 'Epra', 'Eprp')
# MS
MS_valid_cells <- c('MS', 'MSa', 'MSaa', 'MSaaa', 'MSaap', 'MSp', 'MSpa', 'MSpaa', 'MSpap', 'MSap', 'MSapa', 'MSapp', 'MSppa', 'MSppp', 'MSpp')
# C
C_valid_cells <- c('MS', 'MSa', 'MSaa', 'MSaaa', 'MSaap', 'MSp', 'MSpa', 'MSpaa', 'MSpap', 'MSap', 'MSapa', 'MSapp', 'MSppa', 'MSppp', 'MSpp')
# D
# AB ... ?

##################################################################################################################################################################
# Create the systematic network

# create kinetic curves for muscle genes 
##########################################################################################################################################################
# sort the counts for the body muscle cells:  
##########################################################################################################################################################
# body muscle gene: Hnd-1 -> Unc-120 -> Hlh-1
body_muscle <- c("Cpppppv", "Cpppppd", "Cppppap", "Cppppaa", "Cpppapp", "Cpppapa", "Cppappp", "Cppappa", "Cppapap", "Cppapaa", "Cppaapp", "Cppaapa", "Cppaaap", "Cppaaaa",
                 "Cappppv", "Cappppd", "Capppap", "Capppaa", "Cappapp", "Cappapa", "Cappaap", "Cappaaa", "Capappp", "Capappa", "Capapap", "Capapaa", "Capaapp", "Capaapa", "Capaaap", "Capaaaa",
                 "Dppppp", "Dppppa", "Dpppap", "Dpppaa", "Dppap", "Dppaa", "Dpapp", "Dpapa", "Dpaap", "Dpaaa", "Dapppp", "Dapppa", "Dappap", "Dappaa", "Dapap", "Dapaa", "Daapp", "Daapa", "Daaap", "Daaaa",
                 "MSpppppp", "MSpppppa", "MSppppap", "MSppppaa", "MSpppapp", 
                 "MSpappppp", "MSpppppa", "MSppppap", "MSppppaa")
muscle_genes <- c('hnd.1', 'unc.120', 'hlh.1')
cell_id <-  "MSpappppp" #"Capaa" #

cell_lineage_ids <- get_cell_lineage(cell_id)  
test_c_elegans_data_ori <- subset(c_elegans_data, cell == cell_id)
cell_lineage_ids <- c(c('P0', 'P1', 'EMS'), cell_lineage_ids)
test_c_elegans_data_ori <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids & time > 40 & time < 250) # === cell_id

test_c_elegans_data <- t(test_c_elegans_data_ori[, -c(1:6)])
colnames(test_c_elegans_data) <- subset(test_c_elegans_data_ori, cell %in% cell_lineage_ids)[, 'time']
test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0

rng_hnd <- range(test_c_elegans_data['hnd.1', ]) 
rng_hlh <- range(test_c_elegans_data['hlh.1', ]) 
rng_unc <- range(test_c_elegans_data['unc.120', ]) 

panel_a_df <- data.frame(Time = test_c_elegans_data_ori$time, 
                         Expression = c((test_c_elegans_data['hnd.1', ] - rng_hnd[1])/ diff(rng_hnd), #
                                        (test_c_elegans_data['hlh.1', ] - rng_hlh[1])  / diff(rng_hlh) , #
                                        (test_c_elegans_data['unc.120', ] - rng_unc[1]) / diff(rng_unc)), #  
                         gene_short_name = c(rep(c('Hnd-1', 'Hlh-1', 'Unc-120'), each = nrow(test_c_elegans_data_ori))))

pdf(paste0(SI_fig_dir, 'worm_muscle_plot_kinetics.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df)  + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)) # + geom_point(aes(color = gene_short_name), size = I(0.01))
dev.off()

pdf(paste0(SI_fig_dir, 'worm_muscle_plot_kinetics_helper.pdf'))
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xlab('Minutes') + theme(axis.text.x = element_text(angle = 30))
dev.off()

##########################################################################################################################################################
# create a test cds and start to analyze the data 
##########################################################################################################################################################

# function to create a time series starting from the very beginning: 

pData <- test_c_elegans_data_ori[, 1:6]
row.names(pData) <- test_c_elegans_data_ori$time
pData$Pseudotime <- pData$time
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(test_c_elegans_data_ori)[-c(1:6)], row.names = colnames(test_c_elegans_data_ori)[-c(1:6)])
fd <- new("AnnotatedDataFrame", data = fData)

# Now, make a new CellDataSet using the RNA counts
test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0 # remove NaN values
test_cds <- newCellDataSet(test_c_elegans_data, 
                           phenoData = pd,
                           featureData = fd,
                           lowerDetectionLimit=1,
                           expressionFamily=gaussianff())

# get the causal network 
test_rdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(1:5), uniformalize = F, log = F) #
test_urdi_res <- calculate_rdi(test_cds[muscle_genes, ], delays = c(1:5), uniformalize = T, log = F) #
test_umi_res <- calculate_umi(test_cds[muscle_genes, ], log = F)

dimnames(test_rdi_res$max_rdi_value) <- list(c("hnd-1", "unc-120", "hlh-1"), c("hnd-1", "unc-120", "hlh-1"))
pdf(paste0(SI_fig_dir, 'worm_muscle_plot.pdf'), width =  1, height = 1)
pheatmap::pheatmap(clr_directed_R(test_rdi_res$max_rdi_value[c("hnd-1", "hlh-1", "unc-120"), c("hnd-1", "hlh-1", "unc-120")]), cluster_rows = F, cluster_cols = F, fontsize = 6, legend = F, border_color = NA)
dev.off()

# get the heatmap 
# half-max plot
norm_test_c_elegans_data <- apply(test_c_elegans_data, 1, function(x) {
  x_rng <- range(x)
  norm_x <- (x - x_rng[1])/ (diff(x_rng))
  df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data)), 
                   val = norm_x)
  l_model <- loess(val ~ Time, df)
  res <- predict(l_model)
  return(res)
})

cur_cell_types <- cell_id

curves <- t(norm_test_c_elegans_data)

hm_mat <- as.matrix(curves)
hm_mat_scaled <- hm_mat
# hm_mat_scaled <- hm_mat - apply(hm_mat, 1, min)
# hm_mat_scaled <- hm_mat_scaled / apply(hm_mat_scaled, 1, max)

hm_mat_scaled_z <- t(scale(t(hm_mat)))
temp <- hm_mat_scaled_z < 0
#temp <- temp[,10:90]
transient <- apply(temp, 1, function(x) {
  current <- x[1]
  count <- 0
  for(y in x) {
    if (y != current) {
      count <- count + 1
      current <- y
    }
  }
  count
})

trans_max <- apply(hm_mat_scaled, 1, which.max)
trans <- hm_mat_scaled[transient > 1 & !trans_max %in% c(1:5, (dim(hm_mat_scaled) - 5):(dim(hm_mat_scaled))),]

row_dist <- as.dist((1 - cor(Matrix::t(trans)))) #/2
row_dist[is.na(row_dist)] <- 1
clust <- pheatmap::pheatmap(trans, cluster_cols = FALSE, clustering_distance_rows = row_dist, clustering_method="ward.D2",scale="none", show_rownames = FALSE, silent=TRUE, show_colnames = FALSE)

anno_row <- as.data.frame(cutree(clust$tree_row, 12))
names(anno_row)<- "cluster"
anno_row$cluster <- as.factor(anno_row$cluster)

pheatmap::pheatmap(trans, cluster_cols = FALSE, scale="none",clustering_method="ward.D2", show_rownames = FALSE, annotation_row = anno_row, show_colnames = FALSE) # filename = "find_transient.pdf",

trans_list <- row.names(trans)

nt <- hm_mat_scaled[!row.names(hm_mat_scaled) %in% trans_list,]
up <- nt[nt[,1] < nt[,ncol(hm_mat_scaled)],]
down <- nt[nt[,1] > nt[,ncol(hm_mat_scaled)],]

up_cp <- apply(up, 1, function(x) which.min(abs(x - 0.5)) )
up <- up[order(up_cp),]

down_cp <- apply(down, 1, function(x) which.min(abs(x - 0.5)) )
down <- down[order(down_cp),]

all <- rbind(up, down)

trans_cp <- apply(trans, 1, function(x) which.min(abs(x - 0.5)))
trans <- trans[order(trans_cp),]

all <- rbind(all, trans)
clusts <-  pheatmap::pheatmap(all,
                              color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                              fontsize = 6,
                              scale = "none",
                              width=2,
                              height=3,
                              gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                              cluster_cols = FALSE,
                              cluster_rows = FALSE,
                              show_colnames = FALSE,
                              show_rownames = FALSE)
pheatmap::pheatmap(all, legend = FALSE,
                   #annotation_colors = list(Type = c(Proximal = "#241023", `Other Distal` = "#47A025", `Distal Enhancer` = "#735CDD")),
                   color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                   fontsize = 6,
                   scale = "none",
                   width=2.8,
                   height=3.3,
                   gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                   cluster_cols = FALSE,
                   cluster_rows = FALSE,
                   show_colnames = FALSE,
                   show_rownames = FALSE)

if(!exists("cur_cell_types")) {
  cur_cell_types <- cell_types[2]
}

pdf(paste0(SI_fig_dir, 'c_elegans_', cur_cell_types, '_heatmap.pdf'), width =  1, height = 2)
pheatmap::pheatmap(all,
                   #color = colorRampPalette(c("#3C1642",  "#1DD3B0", "#AFFC41"), space = "Lab")(100),
                   fontsize = 6,
                   scale = "none",
                   width=2,
                   height=3,
                   gaps_row=c(nrow(up), (nrow(up) + nrow(down))),
                   cluster_cols = FALSE,
                   cluster_rows = FALSE,
                   show_colnames = FALSE,
                   legend = F,
                   border_color = NA,
                   show_rownames = FALSE)
dev.off()
####################################################################################################################################################################################
# add the maintenance and specification network
# a. lineage network (MI + RDI for data points in the same cell)
# b. committment network (MI + RDI for data points from progenitors to the daughters)
##################################################################################################################################################################

table(pData(c_elegans_cds)$cell[pData(c_elegans_cds)$cell %in% MS_valid_cells])

MS_uMI_res <- calculate_cell_uMI(c_elegans_cds, 'MS', lineage_tree = lineage_coord$lineage_tree, verbose = T)

plot_lineage_commitment_nets <- function(valid_cells, uMI_res, expr_threshold = NULL) {

  # uMI_res <- calculate_cell_uMI(c_elegans_cds, valid_cells[1], lineage_tree = lineage_coord$lineage_tree, verbose = T)
  
  for(curr_cell in valid_cells) {
    message('current_cell is ', curr_cell)
    if(is.null(expr_threshold)) {
      subset_cell_res <- subset(uMI_res, uMI > 1 & current_cell == curr_cell)
    } else {
      subset_cell_res <- subset(uMI_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell)
    }
    
    # qplot(as.numeric(exprs(c_elegans_cds['sea.1', pData(c_elegans_cds)$cell == 'Ea'])), as.numeric(exprs(c_elegans_cds['aly.1', pData(c_elegans_cds)$cell == 'Ea'])))
    # df <- data.frame(time = pData(c_elegans_cds[, pData(c_elegans_cds)$cell == curr_cell])$time, 
    #                  source = as.numeric(exprs(c_elegans_cds['sea.1', pData(c_elegans_cds)$cell == curr_cell])),
    #                  target = as.numeric(exprs(c_elegans_cds['aly.1', pData(c_elegans_cds)$cell == curr_cell])))
    # qplot(time, source, data = df, color = I('red')) + geom_point(aes(time, target), color = 'blue')
    subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == curr_cell]
    cur_gene_gene_pairs <- unique(as.character(subset_cell_res$source, subset_cell_cds$target))
    causality_res <- calculate_rdi(subset_cell_cds[cur_gene_gene_pairs, ], delays = 1:5, log = F)
    
    adj_mat <- causality_res$max_rdi_value
    diag(adj_mat) <- 0
    # adj_mat[adj_mat < t(adj_mat)] <- 0
    
    adj_mat_cp <- adj_mat
    adj_mat_cp[adj_mat_cp != 0] <- 0
    
    for(i in 1:nrow(subset_cell_res)) { 
      source <- as.character(subset_cell_res[i, 'source'])
      target <- as.character(subset_cell_res[i, 'target'])
      
      adj_mat_cp[source, target] <- adj_mat[source, target]
    }
    
    col_means <- colMeans(adj_mat_cp)
    col_sd <- apply(adj_mat_cp, 2, sd)
    col_sd[col_sd == 0] <- 1e-4
    
    adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
      row_i <- adj_mat_cp[x, ]
      row_sd <- sd(row_i) 
      row_sd[row_sd == 0] <- 1e-4
      s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
      s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
      
      sqrt(s_i_vec^2 + s_j_vec^2)
    })
    
    adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
    dimnames(adj_mat_cp2) <- dimnames(adj_mat)
    # visualize TF network with the top genes 
    z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
    
    if(nrow(adj_mat_cp2) > 8) {
      z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
      z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
      
    }
    adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
    
    dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
    
    # remove zero-input/out-genes: 
    adj_col_sum <- colSums(adj_mat_cp2)
    adj_row_sum <- rowSums(adj_mat_cp2)
    olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
    if(length(olphan_genes) > 0)
      adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
    
    g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
    V(g)$name <- convert_to_true_ids(V(g)$name)
    
    pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'))
    plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
    dev.off()
    
    V(g)$hubness <- hub_score(g)$vector 
    
    pdf(paste0(SI_fig_dir, curr_cell, '_lineage_net.pdf'), width =  15, height = 15)
    print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
            geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                          ends = "last", type = "open")) + 
            scale_edge_width(range = c(0.2, 2)) +
            geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
            labs(edge_width = "Causality") +
            theme_graph())
    dev.off()
  }
  
  # b. committment network (MI + RDI for data points from progenitors to the daughters)
  for(curr_cell in valid_cells) {
    message('current_cell is ', curr_cell)
    reachable_cells <- V(graph.neighborhood(lineage_tree, 1, nodes = curr_cell, 'out')[[1]])$name
    
    p_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[1]))
    a_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[2]))
    b_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[3]))
    
    subset_cds <- c_elegans_cds[, c(p_mathced_cells, a_mathced_cells, b_mathced_cells)] #
    
    pData(subset_cds)[p_mathced_cells[seq(1, length(p_mathced_cells), 2)], 'Lineage'] <- 'A'
    pData(subset_cds)[p_mathced_cells[seq(2, length(p_mathced_cells), 2)], 'Lineage'] <- 'B'
    pData(subset_cds)[a_mathced_cells, 'Lineage'] <- 'A'
    pData(subset_cds)[b_mathced_cells, 'Lineage'] <- 'B'
    
    exprs_mat <- log(as.matrix(exprs(subset_cds)) + abs(min(exprs(subset_cds))) + 1)
    pd <- new("AnnotatedDataFrame", data = pData(subset_cds))
    fd <- new("AnnotatedDataFrame", data = fData(subset_cds))
    
    # Now, make a new CellDataSet using the RNA counts
    subset_cds <- newCellDataSet(as(exprs_mat, 'sparseMatrix'), 
                                 phenoData = pd,
                                 featureData = fd,
                                 lowerDetectionLimit=0,
                                 expressionFamily=gaussianff())
    
    res <- differentialGeneTest(subset_cds, fullModelFormulaStr = "~sm.ns(time, df = 3) * Lineage", reducedModelFormulaStr = "~sm.ns(time, df = 3)")
    
    ############################## first daugther commitment ##############################
    
    subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == reachable_cells[1:2]]
    cur_genes <- row.names(subset(res, qval < 0.1))
    causality_res <- calculate_rdi(subset_cell_cds[cur_genes, ], delays = 1:5, log = F)
    
    adj_mat <- causality_res$max_rdi_value
    diag(adj_mat) <- 0
    # adj_mat[adj_mat < t(adj_mat)] <- 0 # do not use this normalization 
    
    adj_mat_cp <- adj_mat
    adj_mat_cp[adj_mat_cp != 0] <- 0
    
    umi_res <- parmigene::knnmi.all(as.matrix(exprs(subset_cell_cds[cur_genes, ])))
    mlt_umi_res <- melt(umi_res)
    colnames(mlt_umi_res) <- c('source', 'target', 'uMI')
    
    mlt_umi_res$current_cell <- curr_cell
    
    avg_exprs <- rowMeans(as.matrix(exprs(subset_cds))) 
    mlt_umi_res$avg_source <- avg_exprs[mlt_umi_res$source]
    mlt_umi_res$avg_target <- avg_exprs[mlt_umi_res$target]
    
    if(is.null(expr_threshold)) {
      subset_cell_res <- subset(mlt_umi_res, uMI > 1 & current_cell == curr_cell)
    } else {
      subset_cell_res <- subset(mlt_umi_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell)
    }
    
    for(i in 1:nrow(mlt_umi_res)) { 
      source <- as.character(mlt_umi_res[i, 'source'])
      target <- as.character(mlt_umi_res[i, 'target'])
      
      adj_mat_cp[source, target] <- adj_mat[source, target]
    }
    
    col_means <- colMeans(adj_mat_cp)
    col_sd <- apply(adj_mat_cp, 2, sd)
    col_sd[col_sd == 0] <- 1e-4
    
    adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
      row_i <- adj_mat_cp[x, ]
      row_sd <- sd(row_i) 
      row_sd[row_sd == 0] <- 1e-4
      s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
      s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
      
      sqrt(s_i_vec^2 + s_j_vec^2)
    })
    
    adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
    dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
    # visualize TF network with the top genes 
    z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
    if(nrow(adj_mat_cp2) > 8) {
      z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
      z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
    }
    adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
    
    dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
    
    # remove zero-input/out-genes: 
    adj_col_sum <- colSums(adj_mat_cp2)
    adj_row_sum <- rowSums(adj_mat_cp2)
    olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
    if(length(olphan_genes) > 0)
      adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
    
    g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
    V(g)$name <- convert_to_true_ids(V(g)$name)
    
    pdf(paste0(SI_fig_dir, reachable_cells[2], '_fate_net.pdf'))
    plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
    dev.off()
    
    V(g)$hubness <- -hub_score(g)$vector 
    message('before ggraph')
    
    pdf(paste0(SI_fig_dir, reachable_cells[2], '_fate_net.pdf'), height = 15, width = 15)
    print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
            geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                          ends = "last", type = "open")) + 
            scale_edge_width(range = c(0.2, 2)) +
            geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
            labs(edge_width = "Causality") +
            theme_graph())
    dev.off()
    
    ############################## second daugther commitment ##############################
    
    subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == reachable_cells[c(1, 3)]]
    cur_genes <- row.names(subset(res, qval < 0.1))
    causality_res <- calculate_rdi(subset_cell_cds[cur_genes, ], delays = 1:5, log = F)
    
    adj_mat <- causality_res$max_rdi_value
    diag(adj_mat) <- 0
    # adj_mat[adj_mat < t(adj_mat)] <- 0
    
    adj_mat_cp <- adj_mat
    adj_mat_cp[adj_mat_cp != 0] <- 0
    
    umi_res <- parmigene::knnmi.all(as.matrix(exprs(subset_cell_cds[cur_genes, ])))
    mlt_umi_res <- melt(umi_res)
    colnames(mlt_umi_res) <- c('source', 'target', 'uMI')
    
    mlt_umi_res$current_cell <- curr_cell
    
    avg_exprs <- rowMeans(as.matrix(exprs(subset_cds))) 
    mlt_umi_res$avg_source <- avg_exprs[mlt_umi_res$source]
    mlt_umi_res$avg_target <- avg_exprs[mlt_umi_res$target]
    
    if(is.null(expr_threshold)) {
      subset_cell_res <- subset(mlt_umi_res, uMI > 1 & current_cell == curr_cell)
    } else {
      subset_cell_res <- subset(mlt_umi_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell)
    }
    
    for(i in 1:nrow(mlt_umi_res)) { 
      source <- as.character(mlt_umi_res[i, 'source'])
      target <- as.character(mlt_umi_res[i, 'target'])
      
      adj_mat_cp[source, target] <- adj_mat[source, target]
    }
    
    col_means <- colMeans(adj_mat_cp)
    col_sd <- apply(adj_mat_cp, 2, sd)
    col_sd[col_sd == 0] <- 1e-4
    
    adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
      row_i <- adj_mat_cp[x,]
      row_sd <- sd(row_i) 
      row_sd[row_sd == 0] <- 1e-4
      s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
      s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
      
      sqrt(s_i_vec^2 + s_j_vec^2)
    })
    
    adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
    dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
    # visualize TF network with the top genes 
    z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
    if(nrow(adj_mat_cp2) > 8) {
      z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
      z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
      
      # 
    }
    adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
    
    dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
    
    # remove zero-input/out-genes: 
    adj_col_sum <- colSums(adj_mat_cp2)
    adj_row_sum <- rowSums(adj_mat_cp2)
    olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
    if(length(olphan_genes) > 0)
      adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
    
    g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
    V(g)$name <- convert_to_true_ids(V(g)$name)
    
    pdf(paste0(SI_fig_dir, reachable_cells[3], '_fate_net.pdf'))
    plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
    dev.off()
    
    V(g)$hubness <- -hub_score(g)$vector 
    message('before ggraph')
    
    pdf(paste0(SI_fig_dir, reachable_cells[3], '_fate_net.pdf'), height = 15, width = 15)
    print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
            geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                          ends = "last", type = "open")) + 
            scale_edge_width(range = c(0.2, 2)) +
            geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
            labs(edge_width = "Causality") +
            theme_graph())
    dev.off()
    # res <- differentialGeneTest(subset_cds, fullModelFormulaStr = "~Lineage", reducedModelFormulaStr = "~1")
    
    # df <- data.frame(lineage = pData(subset_cds)[, 'Lineage'], 
    #                  expression = c(exprs(subset_cds)["F37B4.10", ]),
    #                  time = pData(subset_cds)[, 'time']
    #                  )
    # qplot(time, expression, data = df, color = lineage, facets = "~lineage")
    # qplot(time, expression, data = df, color = lineage)
  }
}

plot_lineage_commitment_nets(MS_valid_cells, MS_uMI_res)

##################################################################################################################################################################
save.image('./RData/figSI6.RData')
##################################################################################################################################################################