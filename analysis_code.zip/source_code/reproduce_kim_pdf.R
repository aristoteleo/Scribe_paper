library(plyr) 
library(minpack.lm) 
library(ggplot2) 
library(DESeq)

source("noise_decomposition_function.R")

erccNumber = read.table("ercc_counts.txt", stringsAsFactors = FALSE, header=TRUE) 
rownames(erccNumber) = erccNumber[,1]
erccSeqID = sort(rownames(erccNumber))
head(erccNumber)

erccCount = read.table("ercc_cell_counts.txt", stringsAsFactors = FALSE, header=TRUE) 
rownames(erccCount) = erccCount[,1]
erccCount = erccCount[,-1]
head(erccCount[1:5, 1:6])

countGenes = read.table("gene_cell_counts.txt", stringsAsFactors = FALSE, header=TRUE)

countGenes[6223,1] = "Mar-02-1" 
nameGenes = countGenes[,1] 
countGenes = countGenes[,-1] 
rownames(countGenes) = nameGenes

removeCells = colSums(erccCount)>500 & colSums(countGenes)>10000 
erccCount = erccCount[, removeCells]
countGenes = countGenes[, removeCells]
head(countGenes[1:5, 1:6])

cellCondition = "SC_2i"
nCount = selectCells(erccCount, countGenes, cellCondition, 1, 40, erccSeqID, erccNumber) 
nCountSpikes = nCount[[1]]
numberSpikes = nCount[[2]]
nCountGenes = nCount[[3]]
sizeFactorMatrix = matrix(1, nrow=nrow(nCountSpikes), ncol=ncol(nCountSpikes)) 
gammaThetaEstimate = estimateGammaTheta(nCountSpikes, numberSpikes, sizeFactorMatrix) 
EGammaThetaSC2i1 = gammaThetaEstimate$gammaTheta[[1]]
nCountGenesSC2i1 = nCountGenes / EGammaThetaSC2i1
nCountSpikesSC2i1 = nCountSpikes / EGammaThetaSC2i1
cellCondition = "SC_2i"
nCount = selectCells(erccCount, countGenes, cellCondition, 41, 80, erccSeqID, erccNumber) 
nCountSpikes = nCount[[1]]
numberSpikes = nCount[[2]]
nCountGenes = nCount[[3]]
sizeFactorMatrix = matrix(1, nrow=nrow(nCountSpikes), ncol=ncol(nCountSpikes)) 
gammaThetaEstimate = estimateGammaTheta(nCountSpikes, numberSpikes, sizeFactorMatrix) 
EGammaThetaSC2i2 = gammaThetaEstimate$gammaTheta[[1]]
nCountGenesSC2i2 = nCountGenes / EGammaThetaSC2i2
nCountSpikesSC2i2 = nCountSpikes / EGammaThetaSC2i2

nCountSpikesSC2i = cbind(nCountSpikesSC2i1, nCountSpikesSC2i2) 
nCountGenesSC2i = cbind(nCountGenesSC2i1, nCountGenesSC2i2) 
sizeFactorMatrixSC2i = matrix(1, nrow=nrow(nCountSpikesSC2i),
                              ncol=ncol(nCountSpikesSC2i))
sizeFactorMatrixSC2iGenes = matrix(1, nrow=nrow(nCountGenesSC2i),
                                   ncol=ncol(nCountGenesSC2i))
noiseEstimateSC2i = estimateBiologicalVariance(nCountGenesSC2i, nCountSpikesSC2i,
                                               sizeFactorMatrixSC2i, numberSpikes,
                                               sizeFactorMatrixSC2iGenes)
head(noiseEstimateSC2i)

EVGammaThetaEstimate = estimateEVGammaTheta(nCountSpikesSC2i,
                                            numberSpikes, sizeFactorMatrixSC2i)
EGamma = EVGammaThetaEstimate$EGamma
ETheta = EVGammaThetaEstimate$ETheta
E2Gamma = EVGammaThetaEstimate$E2Gamma
E2Theta = EVGammaThetaEstimate$E2Theta
VGamma = EVGammaThetaEstimate$VGamma
VTheta = EVGammaThetaEstimate$VTheta

par(cex.axis=1, cex.lab=1) 
plot( NULL, xaxt="n",log="xy", xlim = c( 1e-2, 1e5 ), ylim = c(0.01, 100),
      xlab = "Estimated number of transcripts per cell", ylab = "Squared CV" ) 
axis( 1, 10^(-2:5), c("0.01", "0.1", "1", "10", "100", "1000",
                      expression(10^4), expression(10^5)) ) 
points(rowMeans(nCountGenesSC2i) / (EGamma*ETheta),
       apply(nCountGenesSC2i, 1, var)/rowMeans(nCountGenesSC2i)^2,
       pch=20, cex=0.7, col="darkgray")
points(numberSpikes[,1], apply(nCountSpikesSC2i, 1, var)/rowMeans(nCountSpikesSC2i)^2,
       pch=20, cex=0.7, col="darkblue")
xg = 10^seq(-2, 5, length.out=1000)
predictedVariance = EGamma*ETheta*xg + (VGamma+E2Gamma)*(ETheta-(E2Theta+VTheta))*xg +
  (VGamma+E2Gamma)*VTheta*xg^2 + (E2Theta*VGamma)*xg^2
lines(xg, predictedVariance/(xg*EGamma*ETheta )^2, col="indianred", lwd=3)

par(cex.axis=1, cex.lab=1)
plot( NULL, xaxt="n",
      log="xy", xlim = c( 1e-2, 1e5 ), ylim = c(1, 10000),
      xlab = "Estimated number of transcripts per cell", ylab = "Fano factor" )
axis( 1, 10^(-2:5), c("0.01", "0.1", "1", "10", "100", "1000",
                      expression(10^4), expression(10^5)) )
points(rowMeans(nCountGenesSC2i) / (EGamma*ETheta),
       apply(nCountGenesSC2i, 1, var)/rowMeans(nCountGenesSC2i),
       pch=20, cex=0.7, col="darkgray")
points(numberSpikes[,1], apply(nCountSpikesSC2i, 1, var)/rowMeans(nCountSpikesSC2i),
       pch=20, cex=0.7, col="darkblue")
xg = 10^seq(-2, 5, length.out=1000)
predictedVariance = EGamma*ETheta*xg + (VGamma+E2Gamma)*(ETheta-(E2Theta+VTheta))*xg +
  (VGamma+E2Gamma)*VTheta*xg^2 + (E2Theta*VGamma)*xg^2
lines(xg, predictedVariance/(xg*EGamma*ETheta ), col="indianred", lwd=3)

meanMoleculesGenes2i = noiseEstimateSC2i$predictedCount
simulatedCountSpikes2i = simulateCountGenes(meanMoleculesGenes2i, ETheta, VTheta,
                                            EGamma, VGamma, sizeFactorMatrixSC2iGenes,
                                            ncol(nCountGenesSC2i), 0*noiseEstimateSC2i[,2])

simulatedCountGenes2i = simulateCountGenes(meanMoleculesGenes2i, ETheta, VTheta,
                                           EGamma, VGamma, sizeFactorMatrixSC2iGenes,
                                           ncol(nCountGenesSC2i), noiseEstimateSC2i[,2])

par(mar=c(5,5,1,1), cex.axis=1, cex.lab=1)
plot( NULL, xaxt="n",
      log="xy", xlim = c( 1e-2, 1e5 ), ylim = c(1e-4, 100),
      xlab = "Estimated number of transcripts per cell", ylab = "Squared CV" )
axis( 1, 10^(-2:5), c("0.01", "0.1", "1", "10", "100", "1000",
                      expression(10^4), expression(10^5)) )
points(rowMeans(simulatedCountGenes2i) / (EGamma*ETheta),
       apply(simulatedCountGenes2i, 1, var)/rowMeans(simulatedCountGenes2i)^2,
       pch=20, cex=0.7, col="darkgray")
points(rowMeans(simulatedCountSpikes2i) / (EGamma*ETheta),
       apply(simulatedCountSpikes2i, 1, var)/rowMeans(simulatedCountSpikes2i)^2,
       pch=20, cex=0.7, col="darkblue")
xg <- 10^seq(-2, 5, length.out=1000)
predictedVariance = EGamma*ETheta*xg + (VGamma+E2Gamma)*(ETheta-(E2Theta+VTheta))*xg +
  (VGamma+E2Gamma)*VTheta*xg^2 + (E2Theta*VGamma)*xg^2
lines(xg, predictedVariance/(xg*EGamma*ETheta )^2, col="indianred", lwd=3)
legend(0.01, 0.01, legend=c("Genes with T+B", "Genes with T",
                            "Technical noise fit by ERCC spike-ins"),
       pch=c(20, 20, NA), lty=c(NA, NA, 1), lwd=c(NA, NA, 3),
       col=c("darkgray", "darkblue", "indianred"), bty="n", cex=0.7)

# 3 Estimating biological noise from read-based scRNA-seq



