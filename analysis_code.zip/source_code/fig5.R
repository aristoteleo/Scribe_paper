##################################################################################################################################################################
# this script is from analysis_chromaffin_cell.R
##################################################################################################################################################################

# analyze Schwann cells
# look also at the zebrafish shawnn cells

################################################################################################################################################################
# do the same procedure for the Chromaffin cells
################################################################################################################################################################
# load data and packages
################################################################################################################################################################
rm(list = ls())

load('./RData/chromaffin.RData')
library(velocyto.R)
library(monocle)
library(destiny)
library(igraph)
library(pagoda2)
library(mclust)
library(Scribe)
library(netbiov)
library(piano)
library(xacHelper)
library(phater)
library(ggraph)
library(arcdiagram)
library(extrafont)
library(ROCR)
font_import()
loadfonts()
library(pbapply)
library(rEDM)
library(plyr)
library(dplyr)

cell_types_color <- unique(cell.colors)
names(cell_types_color) <- c(2, 5, 3, 1, 4)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

#################################################################################################################################################################
# kinetic curves
# GO enrichment
#################################################################################################################################################################
load('./RData/analysis_chromaffin_cells.RData')
#################################################################################################################################################################
root_directory <- "/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Shared Data"
mouse_go_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_bp_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc$gsc) <- str_split_fixed(names(mouse_go_gsc$gsc), "%", 2)[,1]

mouse_reactome_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Reactome_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
names(mouse_reactome_gsc$gsc) <- str_split_fixed(names(mouse_reactome_gsc$gsc), "%", 2)[,1]

mouse_kegg_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Human_KEGG_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
names(mouse_kegg_gsc$gsc) <- str_split_fixed(names(mouse_kegg_gsc$gsc), "%", 2)[,1]

mouse_go_gsc_cc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_cc_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc_cc$gsc) <- str_split_fixed(names(mouse_go_gsc_cc$gsc), "%", 2)[,1]
mouse_go_gsc_mf <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_mf_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc_mf$gsc) <- str_split_fixed(names(mouse_go_gsc_mf$gsc), "%", 2)[,1]

#################################################################################################################################################################
# create the PHATE (DDRTree) plot with RNA velocity
#################################################################################################################################################################
chromaffin.phate <- phate(as.matrix(t(rvel$current)), 20, 15, 20, pca.method = 'none', mds.method = 'mmds')

plot(chromaffin.phate$embedding[,1], chromaffin.phate$embedding[,2], col = cell.colors, xlab = "phate1", ylab = "phate2")

pData <- data.frame(cell = colnames(rvel$current), row.names = colnames(rvel$current))
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = row.names(rvel$current), row.names = row.names(rvel$current))
fd <- new("AnnotatedDataFrame", data = fData)

current_cds <- newCellDataSet(as(as.matrix(log(rvel$current + 1)), 'sparseMatrix'),
                              phenoData = pd,
                              featureData = fd,
                              lowerDetectionLimit=1,
                              expressionFamily=gaussianff())

current_cds <- monocle::reduceDimension(current_cds, norm_method = 'none', pseudo_expr = 0, verbose = T)
current_cds <- orderCells(current_cds)
plot_cell_trajectory(current_cds)

current_cds <- orderCells(current_cds, root_state = 3)
plot_cell_trajectory(current_cds, color_by = 'Pseudotime')

# add the annotation for each cell
pData(current_cds)$Cell_type <- cell.colors[colnames(current_cds)]
plot_cell_trajectory(current_cds, color_by = 'Cell_type')

qplot(current_cds@reducedDimS[1, ], current_cds@reducedDimS[2, ], color = cell.colors[colnames(current_cds)], alpha = 0.5)

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/RNA_velocity.pdf') # , width = 1, height = 1
show.velocity.on.embedding.cor(t(current_cds@reducedDimS),vel,n=100,scale='sqrt',cell.colors=ac(cell.colors,alpha=cell.alpha),cex=cell.cex,arrow.scale=arrow.scale,show.grid.flow=TRUE,min.grid.cell.mass=0.5,grid.n=10,arrow.lwd=1)
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/RNA_velocity_cell_wise.pdf') # , width = 1, height = 1
show.velocity.on.embedding.cor(t(current_cds@reducedDimS),vel,n=100,scale='sqrt',cell.colors=ac(cell.colors,alpha=cell.alpha),cex=cell.cex,arrow.scale=arrow.scale,show.grid.flow=F,min.grid.cell.mass=0.5,grid.n=20,arrow.lwd=1)
dev.off()

# lapply(1:nrow(emb), function(i) {
#   di <- t(t(emb) - emb[i, ])
#   di <- di/sqrt(Matrix::rowSums(di^2)) * arrow.scale
#   di[i, ] <- 0
#   di <- Matrix::colSums(di * tp[, i]) - Matrix::colSums(di *
#                                                           (tp[, i] > 0)/sum(tp[, i] > 0))
#   if (fixed.arrow.length) {
#     suppressWarnings(arrows(emb[colnames(em)[i],
#                                 1], emb[colnames(em)[i], 2], emb[colnames(em)[i],
#                                                                  1] + di[1], emb[colnames(em)[i], 2] + di[2],
#                             length = 0.05, lwd = arrow.lwd))
#   }
#   else {
#     ali <- sqrt((di[1] * par("pin")[1]/diff(par("usr")[c(1,
#                                                          2)]))^2 + (di[2] * par("pin")[2]/diff(par("usr")[c(3,
#                                                                                                             4)]))^2)
#     suppressWarnings(arrows(emb[colnames(em)[i],
#                                 1], emb[colnames(em)[i], 2], emb[colnames(em)[i],
#                                                                  1] + di[1], emb[colnames(em)[i], 2] + di[2],
#                             length = min(0.05, ali), lwd = arrow.lwd))
#   }
# })

load('./di_res')
delta_res <- do.call(rbind, di_res)
arrow_df <- data.frame(x = t(current_cds@reducedDimS)[, 1],
                       xend = t(current_cds@reducedDimS)[, 1] + delta_res[, 1],
                       y = t(current_cds@reducedDimS)[, 2],
                       yend = t(current_cds@reducedDimS)[, 2] + delta_res[, 2])

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/RNA_velocity_cell_wise.pdf', width = 1, height = 1)
ggplot(arrow_df, aes(x=x, y=y)) +
  geom_point(size=(0.5), aes(colour=I(pData(current_cds)$Cell_type)), alpha = 0.5) + #
  geom_segment(data = arrow_df[seq(1, nrow(arrow_df), by =30), ],
               aes(x=x, xend=xend, y=y, yend=yend), size = 0.2,
               arrow = arrow(length = unit(0.1, "cm")), alpha = 0.8) + xacHelper::nm_theme()
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/RNA_velocity_cell_wise_helper.pdf')
ggplot(arrow_df, aes(x=x, y=y)) +
  geom_point(size=(0.5), aes(colour=I(pData(current_cds)$Cell_type)), alpha = 0.5) + #
  geom_segment(data = arrow_df[seq(1, nrow(arrow_df), by =30), ],
               aes(x=x, xend=xend, y=y, yend=yend), size = 0.2,
               arrow = arrow(length = unit(0.1, "cm")), alpha = 0.8)
dev.off()


qplot(data = arrow_df, x=x, y=y, colour=I(pData(current_cds)$Cell_type))

#################################################################################################################################################################
# gene expression over the two paths (example genes): a branched heatmap
#################################################################################################################################################################

# 1. make heatmap
BEAM_res <- BEAM(current_cds, cores = detectCores() / 2)

inter_genes <- row.names(subset(BEAM_res, qval < 1e-2))
pdf('./Figures/main_figures/chromaffin_branch_heatmap.pdf', height = 8, width = 7)
plot_genes_branched_heatmap(current_cds[inter_genes, ])
dev.off()

# # 2. identify important regulators (divergence between two paths > 95% of the data)
# cor_res <- lapply(inter_genes, function(x) {
#   cor(myelinating_smoothed_exprs[x, ], unknown_smoothed_exprs[x, ])
# })

# 3. overlap with the TF list
mouse_TFs <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/mouse_TF_list.csv', header = F)

mouse_TFs$V1 %in% fData(current_cds)[inter_genes, 'gene_short_name']

# run RDI on the TFs and RDI between TFs and the target genes
cluster_TFs <- T
cluster_targets <- T
scale <- T
smoothing <- F
cluster_num_method <- "mcclust"
delays <- c(5)
include_conditioning <- F
cluster_TFs_num = 2
cluster_targets_num = 10
scale_max <- 3
scale_min <- -3
hclust_method = "ward.D2"
norm_method <- 'none'

informative_genes <- inter_genes; TF <- row.names(subset(fData(current_cds), gene_short_name %in% mouse_TFs$V1))
pseudocount <- 1
TF_vec_names <- intersect(TF, informative_genes)
target_vec_names <- setdiff(informative_genes, TF)
unique_gene <- unique(c(TF, informative_genes))
gene_name_ids <- intersect(row.names(current_cds), unique_gene)
if (length(unique_gene) != length(gene_name_ids)) {
  stop("The current_cds you provided doesn't include all genes from the TF and informative_genes vector!")
}
cds_subset <- current_cds[gene_name_ids, pData(current_cds)$State %in% c(1, 3)] # 3: progenitor; 1: chromaffin cells
pData(cds_subset)$Pseudotime <- order(pData(cds_subset)$Pseudotime)
exprs_data <- exprs(cds_subset)[, pData(cds_subset)$Pseudotime]
if (norm_method == "vstExprs" && is.null(cds_subset@dispFitInfo[["blind"]]$disp_func) ==
    FALSE) {
  exprs_data = vstExprs(cds_subset, expr_matrix = exprs_data)
} else if (norm_method == "log") {
  exprs_data = log10(exprs_data + pseudocount)
}
annotation_TF_cluster = NULL
annotation_target_cluster = NULL
cRDI <- NULL
if (cluster_TFs | cluster_targets) {
  if (smoothing) {
    for (i in 1:ncol(exprs_data)) {
      df <- data.frame(Pseudotime = 1:ncol(exprs_data),
                       Expression = exprs_data[i, ])
      test <- loess(Expression ~ Pseudotime, df)
      exprs_data[i, ] <- predict(test)
    }
  }
  cds_subset@assayData$exprs <- exprs_data
  m <- exprs_data
  m = m[!apply(m, 1, sd) == 0, ]
  if (scale) {
    m = Matrix::t(scale(Matrix::t(m), center = TRUE))
    m = m[is.na(row.names(m)) == FALSE, ]
    m[is.nan(m)] = 0
    m[m > scale_max] = scale_max
    m[m < scale_min] = scale_min
  }
  TF_vec_names <- intersect(TF_vec_names, row.names(m))
  target_vec_names <- intersect(target_vec_names, row.names(m))
  m_tfs <- m[TF_vec_names, ]
  m_targets <- m[target_vec_names, ]
  # if (cluster_num_method == "mcclust") {
  #   clust_num_check_tfs <- Mclust(t(m_tfs), G = 1:min(10,
  #                                                     length(TF_vec_names)/2))
  #   cluster_TFs_num <- dim(clust_num_check_tfs$z)[2]
  #   clust_num_check_targets <- Mclust(t(m_targets),
  #                                     G = 1:min(10, length(target_vec_names)/2))
  #   cluster_targets_num <- dim(clust_num_check_targets$z)[2]
  #   cat("model-based optimal number of clusters: TF: ",
  #       cluster_TFs_num, ", targets: ", cluster_targets_num,
  #       "\n")
  # }
  # else if (cluster_num_method == "pamk") {
  #   dissimilarity_mat_tfs <- 1 - cor(t(m_tfs))
  #   dissimilarity_mat_targets <- 1 - cor(t(m_targets))
  #   clust_num_check_tfs <- fpc::pamk(dissimilarity_mat_tfs,
  #                                    diss = T)
  #   clust_num_check_targets <- fpc::pamk(dissimilarity_mat_targets,
  #                                        diss = T)
  #   cluster_TFs_num <- clust_num_check_tfs$nc
  #   cluster_targets_num <- clust_num_check_targets$nc
  #   cat("number of clusters estimated by optimum average silhouette width: TF: ",
  #       cluster_TFs_num, ", targets: ", cluster_targets_num,
  #       "\n")
  # }
  if (cluster_TFs) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_tfs)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_TF_cluster <- data.frame(Cluster = factor(cutree(m_hclust,
                                                                cluster_TFs_num)), row.names = row.names(m_tfs))
    m_TFs_clusters <- matrix(nrow = ncol(cds_subset),
                             ncol = cluster_TFs_num)
    for (cluster_ind in 1:cluster_TFs_num) {
      gene_inds <- annotation_TF_cluster$Cluster ==
        cluster_ind

      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_tfs[gene_inds, ])) # as.vector(t(exprs_data[row.names(annotation_TF_cluster)[gene_inds], ]))
      test <- loess(Expression ~ Pseudotime, df)
      m_TFs_clusters[, cluster_ind] <- predict(test) #
    }
    colnames(m_TFs_clusters) <- paste0("TFs_", 1:cluster_TFs_num)

    pdf('./Figures/main_figures/chromaffin_m_tf_cluster.pdf', height = 8, width = 7)
    pheatmap(m_tfs, useRaster = T, cluster_cols = FALSE,
             cluster_rows = TRUE, show_rownames = F, show_colnames = F,
             clustering_distance_rows = row_dist, clustering_method = hclust_method,
             cutree_rows = cluster_TFs_num, silent = FALSE, filename = NA) # ,  breaks = bks, color = hmcols
    dev.off()

    ph <- pheatmap(m_tfs, useRaster = T, cluster_cols = FALSE,
                   cluster_rows = TRUE, show_rownames = F, show_colnames = F,
                   clustering_distance_rows = row_dist, clustering_method = hclust_method,
                   cutree_rows = cluster_targets_num, silent = T, filename = NA)

    annotation_row <- data.frame(Cluster = factor(cutree(ph$tree_row,
                                                         cluster_targets_num)))

    # identify the enriched terms for each clusters, etc.
    # Get hyper geometric GSA test results for different enrichment sets (GO, KEGG, reactome, etc.)
    Chromaffin_m_tfs_clusters <- as.numeric(annotation_row$Cluster)
    names(Chromaffin_m_tfs_clusters) = row.names(m_tfs)

    Chromaffin_m_tfs_hyper_geometric_results_reactome <- xacHelper::collect_gsa_hyper_results(current_cds, gsc = mouse_reactome_gsc, Chromaffin_m_tfs_clusters)
    Chromaffin_m_tfs_hyper_geometric_results_kegg <- collect_gsa_hyper_results(current_cds, gsc = mouse_kegg_gsc, Chromaffin_m_tfs_clusters)
    Chromaffin_m_tfs_hyper_geometric_results_go <- collect_gsa_hyper_results(current_cds, gsc = mouse_go_gsc, Chromaffin_m_tfs_clusters)

    plot_gsa_hyper_heatmap <- function (cds, gsa_results, significance = 0.05, sign_type = "qval")
    {
      hyper_df <- ldply(gsa_results, function(gsa_res) {
        data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues,
                   qval = gsa_res$p.adj)
      })
      hyper_df$qval <- p.adjust(hyper_df$pval, method = 'fdr')
      colnames(hyper_df)[1] <- "cluster_id"
      hyper_df <- subset(hyper_df, hyper_df[, sign_type] <= significance)
      hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set),
                                        function(x) {
                                          nrow(x)
                                        }), by = "gene_set")
      save(hyper_df, file = "hyper_df")
      hyper_df$gene_set <- factor(hyper_df$gene_set, levels = unique(arrange(hyper_df,
                                                                             V1, cluster_id)$gene_set))
      qplot(cluster_id, gene_set, fill = -log10(qval), geom = "tile",
            data = hyper_df) + scale_fill_gradientn(colours = rainbow(7))
    }

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_tfs_reactome.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_tfs_hyper_geometric_results_reactome, significance=1e-1) + nm_theme())
    dev.off()

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_tfs_kegg.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_tfs_hyper_geometric_results_kegg, significance=1e-1) + nm_theme())
    dev.off()

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_tfs_go.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_tfs_hyper_geometric_results_go, significance=1e-2) + nm_theme())
    dev.off()

  } else {
    m_TFs_clusters <- m_tfs
  }
  if (cluster_targets) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_targets)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_target_cluster <- data.frame(Cluster = factor(cutree(m_hclust,
                                                                    cluster_targets_num)), row.names = row.names(m_targets))
    m_targets_clusters <- matrix(nrow = ncol(cds_subset),
                                 ncol = cluster_targets_num)
    for (cluster_ind in 1:cluster_targets_num) {
      gene_inds <- annotation_target_cluster$Cluster ==
        cluster_ind
      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_targets[gene_inds, ])) # as.vector(t(exprs_data[gene_inds, ]))
      test <- loess(Expression ~ Pseudotime, df)

      m_targets_clusters[, cluster_ind] <- predict(test)
    }
    colnames(m_targets_clusters) <- paste0("target_",
                                           1:cluster_targets_num)

    ph <- pheatmap(m_targets, useRaster = T, cluster_cols = FALSE,
                   cluster_rows = TRUE, show_rownames = F, show_colnames = F,
                   clustering_distance_rows = row_dist, clustering_method = hclust_method,
                   cutree_rows = cluster_targets_num, silent = T, filename = NA)

    pdf('./Figures/main_figures/chromaffin_m_targets_cluster.pdf', height = 8, width = 7)
    pheatmap(m_targets, useRaster = T, cluster_cols = FALSE,
             cluster_rows = TRUE, show_rownames = F, show_colnames = F,
             clustering_distance_rows = row_dist, clustering_method = hclust_method,
             cutree_rows = cluster_targets_num, silent = F, filename = NA) # ,  breaks = bks, color = hmcols
    dev.off()

    annotation_row <- data.frame(Cluster = factor(cutree(ph$tree_row,
                                                         cluster_targets_num)))

    pdf('./Figures/main_figures/chromaffin_m_targets_cluster_with_ids.pdf', height = 8, width = 7)
    pheatmap(m_targets[, ], useRaster = T, cluster_cols = FALSE,
             cluster_rows = TRUE, show_rownames = F, show_colnames = F,
             clustering_distance_rows = row_dist, clustering_method = hclust_method,
             cutree_rows = cluster_targets_num, annotation_row = annotation_row,
             # annotation_col = annotation_col, annotation_colors = annotation_colors,
             # gaps_col = col_gap_ind,
             treeheight_row = 20, #breaks = bks,
             fontsize = 6, #color = hmcols,
             border_color = NA, silent = F)
    dev.off()

    # identify the enriched terms for each clusters, etc.
    # Get hyper geometric GSA test results for different enrichment sets (GO, KEGG, reactome, etc.)
    Chromaffin_m_targets_clusters <- as.numeric(annotation_row$Cluster)
    names(Chromaffin_m_targets_clusters) = row.names(m_targets)

    Chromaffin_m_targets_hyper_geometric_results_reactome <- xacHelper::collect_gsa_hyper_results(current_cds, gsc = mouse_reactome_gsc, Chromaffin_m_targets_clusters)
    Chromaffin_m_targets_hyper_geometric_results_kegg <- collect_gsa_hyper_results(current_cds, gsc = mouse_kegg_gsc, Chromaffin_m_targets_clusters)
    Chromaffin_m_targets_hyper_geometric_results_go <- collect_gsa_hyper_results(current_cds, gsc = mouse_go_gsc, Chromaffin_m_targets_clusters)

    plot_gsa_hyper_heatmap <- function (cds, gsa_results, significance = 0.05, sign_type = "qval")
    {
      hyper_df <- ldply(gsa_results, function(gsa_res) {
        data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues,
                   qval = gsa_res$p.adj)
      })
      hyper_df$qval <- p.adjust(hyper_df$pval, method = 'fdr')
      colnames(hyper_df)[1] <- "cluster_id"
      hyper_df <- subset(hyper_df, hyper_df[, sign_type] <= significance)
      hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set),
                                        function(x) {
                                          nrow(x)
                                        }), by = "gene_set")
      save(hyper_df, file = "hyper_df")
      hyper_df$gene_set <- factor(hyper_df$gene_set, levels = unique(arrange(hyper_df,
                                                                             V1, cluster_id)$gene_set))
      qplot(cluster_id, gene_set, fill = -log10(qval), geom = "tile",
            data = hyper_df) + scale_fill_gradientn(colours = rainbow(7))
    }

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_targets_reactome.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_targets_hyper_geometric_results_reactome, significance=1e-1) + nm_theme())
    dev.off()

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_targets_kegg.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_targets_hyper_geometric_results_kegg, significance=1e-1) + nm_theme())
    dev.off()

    pdf(file =paste(SI_fig_dir, 'Chromaffin_m_targets_go.pdf', sep = ''), height = 15, width = 7)
    print(plot_gsa_hyper_heatmap(current_cds, Chromaffin_m_targets_hyper_geometric_results_go, significance=1e-2) + nm_theme())
    dev.off()

  } else {
    m_targets_clusters <- m_targets
  }
  TF_vec_names <- colnames(m_TFs_clusters)
  target_vec_names <- colnames(m_targets_clusters)
  exprs_data <- cbind(m_TFs_clusters, m_targets_clusters)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names,
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi_cpp_wrap(as.matrix(exprs_data),
                                    delays = delays, super_graph = as.matrix(all_pairwise_gene),
                                    turning_points = 0, method = 1, uniformalize = F)
  if (include_conditioning)
    cRDI_res <- calculate_conditioned_rdi_cpp_wrap(as.matrix(exprs_data),
                                                   super_graph = as.matrix(all_pairwise_gene), max_rdi_value = RDI_res$max_rdi_value,
                                                   max_rdi_delays = RDI_res$max_rdi_delays, k = 1,
                                                   uniformalize = FALSE)
} else {
  cds_subset@assayData$exprs <- exprs_data
  exprs_data <- t(exprs_data)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names,
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi(cds_subset, delays = delays,
                           super_graph = all_pairwise_gene, log = FALSE, ...)
  if (include_conditioning)
    cRDI_res <- calculate_conditioned_rdi(exprs_data,
                                          rdi_list = RDI_res, ...)
}

# return(list(RDI_res = RDI_res, cRDI = cRDI, annotation_TF_cluster = annotation_TF_cluster,
#             annotation_target_cluster = annotation_target_cluster))

# visualize the result
# 1. draw the smooth average curve for each TF or target cluster
pdf('./Figures/main_figures/chromaffin_TF_clust1.pdf', height = 1, width = 1)
qplot(1:nrow(m_TFs_clusters), m_TFs_clusters[, 1], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
dev.off()
pdf('./Figures/main_figures/chromaffin_TF_clust2.pdf', height = 1, width = 1)
qplot(1:nrow(m_TFs_clusters), m_TFs_clusters[, 2], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
dev.off()

for(cur_target in target_vec_names) {
  q <- qplot(1:nrow(m_TFs_clusters), m_targets_clusters[, cur_target], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
  pdf(paste0('./Figures/main_figures/chromaffin_', cur_target, '.pdf'), height = 1, width = 1)
  print(q)
  dev.off()
}
#################################################################################################################################################################
# add heatmap for the TF and target clusters
#################################################################################################################################################################
# added in the above loop function 

#################################################################################################################################################################
# perform causal network inference on all the important regulators for two different approaches
#################################################################################################################################################################
# 1. calculate the TF to target network
# 2. visualize a few important genes
max_rdi_value <- apply(RDI_res$max_rdi_value, 2, function(x) {
  y <- rep(0, length(x))
  y[which.max(x)] <- x[which.max(x)]
  y
})
dimnames(max_rdi_value) <- list(colnames(exprs_data), colnames(exprs_data))

g <- igraph::graph_from_adjacency_matrix(as.matrix(max_rdi_value), weighted = T, mode = "direct")

res <- level.plot(g)

res$layout[, 2] <- c(0, 0, rep(-1, 10))
res$layout[, 1] <- c(-1, 1, seq(-5, 5, length.out = 10))
pdf('./Figures/main_figures/chromaffin_TF_target_cluster_network_hiearchy.pdf', height = 7, width = 7)
plot.igraph(g, edge.width=E(g)$weight * 10, edge.curved=F, layout = res$layout)
dev.off()

#################################################################################################################################################################
# do a large scale regulatory network inference (apply the network sparsifier -- use directed CLR)
#################################################################################################################################################################
informative_genes_name <- intersect(fData(current_cds[informative_genes, ])$gene_short_name, row.names(rvel$current))
informative_genes <- informative_genes_name; TF <- informative_genes_name[informative_genes_name %in% mouse_TFs$V1]
pseudocount <- 1
TF_vec_names <- intersect(TF, informative_genes)
target_vec_names <- setdiff(informative_genes, TF)
unique_gene <- unique(c(TF, informative_genes))

TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
TF_target_pair <- expand.grid(TF_vec_names, target_vec_names,
                              stringsAsFactors = F)
tmp <- rbind(TF_pair, TF_target_pair)
all_pairwise_gene <- tmp
all_pairwise_gene[, 1] <- match(tmp[, 1], row.names(rvel$current))
all_pairwise_gene[, 2] <- match(tmp[, 2], row.names(rvel$current))
all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1

# cmi: I(x(t - 1), y (t) | y(t - 1) )
current_n <- as.matrix(rvel$current[, ]) # valid_cells
projected <- as.matrix(rvel$projected[, ]) # valid_cells
delta_E <- as.matrix(rvel$deltaE)

chromaffin_cmi_res <- pbapply(all_pairwise_gene, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 10, normalize = F)$cmi_res
})

#################################################################################################################################################################
# perform network inference on the gene set from the Science paper
#################################################################################################################################################################
# Fig5
fig5c <- c("Sox10", "Htr3a", "Th", "Erbb3", "Dll3", "Chgb", "Foxd3", "Thbd", "Foxq1", "Cartpt")
fig5d <- c("Sox10", "Erbb3", "Ascl1", "Htr3a", "Th", "Chga")

# Fig6
fig6a <- c("Igfbp3", "Lrig1", "Tubb6", "Cyp2j9", "E130114P18Rik", "Samd5", "Nrarp", "Fndc3c1", "Nme4", "Hmcn1", "Sox2", "Slc39a8", "Rgs16", "Igfbp2", "Chek1", "Shmt1", "Tpx2", "Prim1", "Ncapg", "Bub1", "Cdca8", "Arvcf", "Spag5", "Thbd", "Kit", "Ier5", "Tbx2", "Shcbp1", "Tyms", "Ckb", "Kntc1", "Cenpe", "Mns1", "Pbk", "Jam2", "Pde5a", "Id2", "Tk1", "Top2a", "Cenpf", "Csrp2", "Ascl1", "Cdkn1c", "Rftn2", "Fanca", "Fat1", "Tlx2", "Cenpk", "Dqx1", "Sct", "Ube2c", "Rrm2", "Melk", "Phox2b", "Cenpm", "Sox11", "Htr3b", "Htr3a", "Rtn4r", "Dll3", "Mfng", "Gadd45g", "Igsf9", "Gcnt2", "Hes6", "Plxna2", "Fam110a", "Setbp1", "Phf21b", "Pdlim3", "Tbx20", "Cttnbp2", "Kcnj12", "Nefm", "Tagln3", "Nef1", "Fbrsl1", "Stra6", "Hipk2", "Brsk2", "Efnb2", "Slc10a4", "Cdc25b", "Pde2a", "Dpysl3", "Grik3", "Mapk11", "Ank", "Miat", "Glt28d2", "C1ql1", "Adcy", "Msrb2", "Dlgap2", "Igsf21", "Sept3", "Adamts19", "Dlg2", "Tmem179")

# FigSI7
figSI7a <- c("Foxq1", "Igfbp5", "Pdk1", "Pcx", "Dll1", "Ascl1", "Sox11", "Sct", "Htr3a", "Mfng", "Dll3", "Cdkn1c", "Cnr1", "Stmn4", "Lin7a", "Prph", "Chat", "Vip", "Uchl1", "Stmn3", "Chga", "Kif1a", "Nefm", "Nefl", "Ndn", "Th", "Dgkk", "Nrk", "Syt1", "Sun2", "Cdk1", "Ccna2", "Cdca8", "Cdc20", "Cenpe", "Cenpa", "Erbb3", "Sox8", "Postn", "Ets1", "Sox10", "Mest")

# some of them are too blurry", "cannot see the result
figSI7b <- c()
figSI7c <- c("Cdkn1c", "Phox2b", "Ascl1", "Myc", "Mycn", "Isl1", "Sox1", "Bhlhe40", "Adora2a", "Chat", "Slc18a3", "Prph")
figSI7d <- c()

# FigSI8:
figSI8b <- c("Dhh", "Sox2", "Lama4", "Lama2", "Lama1", "S100b", "Sh3tc2", "Mpz", "Fabp7", "Prx", "Lgi4")
figSI8c <- c("Dhh", "Mal", "Pou3f1", "Mag", "Lama4", "Lama2", "Lamb1", "Lamb2", "S100b", "Sh31c2", "Arhget10", "Lgi4", "Mpz", "Fabp7", "Sox2", "Prx")

# from text:
text_SCP <- c("Foxd3", "Sox10", "Plp1", "Erbb3", "Pou3f1", "Sh3tc2", "Lgi4", "Dhh", "Mal", "Fabp7", "Mpz", "S100beta", "Mag")
text_sympathoblasts <- c("Slc18a3", "Cartpt", "Th")
text_chromaffin <- c("Th", "Phax2b", "Chgb", "Chga", "Slc18a3", "Cartpt")

text_chromaffin_TF <- c("Sox11", "Hes6", "Hipk2", "Ascl1", "Btg2", "Aes", "Tcf3", "Smo", "Id3", "Ybx1", "Sox4", "Hand1", "Hand2", "Phox2a", "Eya1", "Thra", "Gata3", "Insm1", "Tbox20", "Tlx")
text_chromaffin_signal <- c("Notch1", "Fzd2", "Ptk7", "PlxnA3", "Dll4", "Amer2", "Cxxc4")

# all_fig_genes <- unique(c(fig5c, fig5d, fig6a, figSI7a, figSI7b, figSI7c, figSI7d, figSI8b, figSI8c))
all_fig_genes <- unique(c(text_SCP, text_sympathoblasts, text_chromaffin, text_chromaffin_TF, text_chromaffin_signal))
valid_all_fig_genes <- intersect(row.names(current_cds), all_fig_genes)

tmp <- expand.grid(valid_all_fig_genes, valid_all_fig_genes, stringsAsFactors = F)
valid_all_fig_genes_pair <- tmp
valid_all_fig_genes_pair[, 1] <- match(tmp[, 1], row.names(rvel$current))
valid_all_fig_genes_pair[, 2] <- match(tmp[, 2], row.names(rvel$current))
valid_all_fig_genes_pair <- valid_all_fig_genes_pair[valid_all_fig_genes_pair[, 1] != valid_all_fig_genes_pair[, 2], ] - 1

chromaffin_lineage_cells <- names(cell.colors)[cell.colors %in% cell_types_color[c("1", "2", "3")]]
paper_genes_chromaffin_cmi_res <- pbapply(valid_all_fig_genes_pair, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], chromaffin_lineage_cells]), as.matrix(projected[x[2], chromaffin_lineage_cells]), as.matrix(current_n[x[2], chromaffin_lineage_cells]), k = 5, normalize = T)$cmi_res
})

paper_genes_chromaffin_cmi_res2 <- pbapply(valid_all_fig_genes_pair, 1, function(x) {
  Scribe::cmi(scale(as.matrix(current_n[x[1], chromaffin_lineage_cells])), 
              scale(as.matrix(delta_E[x[2], chromaffin_lineage_cells])), 
              scale(as.matrix(current_n[x[2], chromaffin_lineage_cells])), k = 5, normalize = T)$cmi_res
})

#################################################################################################################################################################
# pseudotime based network: 
cds_subset2 <- current_cds[valid_all_fig_genes, pData(current_cds)$State %in% c(1, 3)] # 3: progenitor; 1: chromaffin cells
paper_genes_chromaffin_cmi_res_pseudotime <- calculate_rdi(cds_subset2, delays = c(1, 20, 41), log = F) # super_graph = tmp,

# calculate the pearson correlation: 
unlist(paper_genes_chromaffin_cmi_res)

#################################################################################################################################################################
# check the result of the network
#################################################################################################################################################################
# visualize the network
#################################################################################################################################################################
# run CLR algorithm
# chromaffin_causality_res <- cbind(all_pairwise_gene, chromaffin_cmi_res) # all the TFs 
chromaffin_causality_res <- cbind(valid_all_fig_genes_pair, paper_genes_chromaffin_cmi_res) # genes from the paper 
chromaffin_causality_res2 <- cbind(valid_all_fig_genes_pair, paper_genes_chromaffin_cmi_res2) # genes from the paper 

chromaffin_adj_mat <- reshape2::dcast(chromaffin_causality_res, Var1 ~ Var2)
gene_name <- row.names(rvel$current)[chromaffin_adj_mat[, 1] + 1]
chromaffin_adj_mat <- chromaffin_adj_mat[, -1]
diag(chromaffin_adj_mat) <- 0
dimnames(chromaffin_adj_mat) <- list(gene_name, gene_name)

chromaffin_adj_mat2 <- reshape2::dcast(chromaffin_causality_res2, Var1 ~ Var2)
gene_name <- row.names(rvel$current)[chromaffin_adj_mat2[, 1] + 1]
chromaffin_adj_mat2 <- chromaffin_adj_mat2[, -1]
diag(chromaffin_adj_mat2) <- 0
dimnames(chromaffin_adj_mat2) <- list(gene_name, gene_name)
#################################################################################################################################################################
# calculate the pearson correlation: 
cor(unlist(chromaffin_adj_mat), unlist(as.data.frame(paper_genes_chromaffin_cmi_res_pseudotime$max_rdi_value)))
cor(unlist(chromaffin_adj_mat), unlist(chromaffin_adj_mat2))

#################################################################################################################################################################

chromaffin_clr_res <- clr(as.matrix(chromaffin_adj_mat))
for(type in c('pseudotime', 'velocity', 'delta')) {
  if(type == "pseudotime") {
    chromaffin_adj_mat <- as.data.frame(paper_genes_chromaffin_cmi_res_pseudotime$max_rdi_value)
  } else if(type == 'delta') {
    chromaffin_adj_mat <- chromaffin_adj_mat2
  }
  
  col_means <- colMeans(chromaffin_adj_mat)
  col_sd <- apply(chromaffin_adj_mat, 2, sd)
  
  chromaffin_clr_res2_tmp <- lapply(1:nrow(chromaffin_adj_mat), function(x) {
    row_i <- chromaffin_adj_mat[x, drop = F][, 1]
    message(row_i)
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / sd(row_i))
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
    
    sqrt(s_i_vec^2 + s_j_vec^2)
  })
  
  chromaffin_clr_res2 <- do.call(rbind, chromaffin_clr_res2_tmp) 
  dimnames(chromaffin_clr_res2) <- list(gene_name, gene_name)
  # visualize TF network with the top genes 
  z_threshold <- 2
  chromaffin_clr_res2[chromaffin_clr_res2 < z_threshold] <- 0
  g <- igraph::graph_from_adjacency_matrix(as.matrix(chromaffin_clr_res2), weighted = T, mode = "direct")
  
  subset_g <- subgraph(g, intersect(V(g)$name, fig6a))
  pdf('./Figures/main_figures/chromaffin_global_network_gggraph.pdf', height = 2, width = 2)
  print(ggraph(g, layout = "linear") + 
    geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                  ends = "last", type = "open")) + 
    scale_edge_width(range = c(0.2, 2)) +
    geom_node_text(aes(label = V(subset_g)$name), check_overlap = T, size = 3,repel = T) +
    labs(edge_width = "Causality") +
    theme_graph())
  dev.off()
  
  V(g)$hubness <- -hub_score(g)$vector 
  if(type == 'pseudotime') {
    pdf('./Figures/main_figures/chromaffin_global_network_gggraph_pseudotime.pdf', height = 5, width = 11)
    print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
      geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                    ends = "last", type = "open")) + 
      scale_edge_width(range = c(0.2, 2)) +
      geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
      labs(edge_width = "Causality") +
      theme_graph())
    dev.off()
  } else if(type == 'velocity') {
      pdf('./Figures/main_figures/chromaffin_global_network_gggraph.pdf', height = 5, width = 11)
      print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
        geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                      ends = "last", type = "open")) +
        scale_edge_width(range = c(0.2, 2)) +
        geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
        labs(edge_width = "Causality") +
        theme_graph())
      dev.off()
  } else if(type == 'delta') {
    pdf('./Figures/main_figures/chromaffin_global_network_gggraph_delta.pdf', height = 5, width = 11)
    print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
      geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                    ends = "last", type = "open")) +
      scale_edge_width(range = c(0.2, 2)) +
      geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
      labs(edge_width = "Causality") +
      theme_graph())
    dev.off()
  }
}

edge <- get.edgelist(subset_g)

# arcplot(edge, ordering=sort(unique(c(edge[, 1], edge[, 2]))), 
#         horizontal=TRUE,
#         #labels=paste("node",1:10,sep="-"),
#         #lwd.arcs=4*runif(10,.5,2), 
#         col.arcs=hsv(runif(9,0.6,0.8),alpha=0.4),
#         show.nodes=TRUE, pch.nodes=21, cex.nodes=runif(10,1,3), 
#         col.nodes="gray80", bg.nodes="gray90", lwd.nodes=2)  
# also follows the pseudotime order 
# > which(c("Kntc1", "Dqx1") %in% fig6a )
# [1] 1 2
# > which(fig6a %in% c("Kntc1", "Dqx1"))
# [1] 31 49
# > fig6a[31]
# [1] "Kntc1"
# > fig6a[49]
# [1] "Dqx1"
# > which(fig6a %in% c("Melk", "Sept3"))
# [1] 53 96
# > fig6a[53]
# [1] "Melk"
# > which(fig6a %in% c("Spag5", "Fanca"))
# [1] 23 45
# > fig6a[23]
# [1] "Spag5
# level.plot 
# res <- level.plot(g)
# # spiral-view: nodes are ranked using reingold-tilford algorithm
# plot.spiral.graph(g, tp=90,vertex.color="blue",e.col="gold",rank.function=layout.reingold.tilford)
# # spiral-view: starting with the highest degree node
# data("color_list")
# plot.spiral.graph(g, tp=60,vertex.color=sample(color.list$bright))
# plot.spiral.graph(g, tp=179,vertex.color=sample(color.list$bright) )
# # 3
# fn <- function(g)plot.spiral.graph(g,12)$layout
# plot.modules(g, layout.function=fn, layout.overall=layout.fruchterman.reingold,sf=20, v.size=1, color.random=TRUE)
# 
# # star-like global view of a scale free network starting with the five highest degree nodes 
# plot.NetworkSperical.startSet(g, mo = "in", nc = 5)
# # Global view
# plot.NetworkSperical(g, mo="in", v.lab=FALSE, tkplot = FALSE,v.size=1 )
# 
# # Modular layout with hierarchical plots for the modules
# plot.modules(g, layout.function = layout.reingold.tilford, col.grad=list(color.list$citynight), tkplot=FALSE)
# 
# # Modular layout (has errors)
# exp <- rnorm(vcount(g))
# plot.modules(g, modules.color="grey", expression = exp, exp.by.module = c(1,2,5), tkplot=FALSE)
# plot.modules(g1, expression = exp, tkplot=FALSE)
# cl <- list(rainbow(40), heat.colors(40) ); plot.modules(g, col.grad=cl , tkplot=FALSE)
# plot.modules(g, layout.function = c(layout.fruchterman.reingold, layout.star,layout.reingold.tilford, layout.graphopt,layout.kamada.kawai), modules.color = sample(color.list$bright), sf=40, tkplot=FALSE)
# plot.modules(g, layout.function = c(layout.fruchterman.reingold), modules.color = sample(color.list$bright),layout.overall = layout.star,sf=40, tkplot=FALSE)
# plot.modules(g,mod.list=lm,layout.function=c(layout.fruchterman.reingold), modules.color="grey", mod.edge.col = sample(color.list$bright), tkplot=FALSE)
# plot.modules(g, mod.list = lm, layout.function = layout.graphopt, modules.color = cl,mod.edge.col=c("green","darkgreen"), tkplot=FALSE, ed.color = c("blue"),sf=-25)
# plot.modules(g, layout.function = layout.graphopt, modules.color = cl, mod.edge.col=c("green","darkgreen") , tkplot=FALSE, ed.color = c("blue"),sf=-25)
# plot.modules(g, modules.color=cl, mod.edge.col=cl,
#              sf=5, nodeset=c(2,5,44,34),
#              mod.lab=TRUE, v.size=.9,
#              path.col=c("blue", "purple", "green"),
#              col.s1 = c("yellow", "pink"),
#              col.s2 = c("orange", "white" ),
#              e.path.width=c(1.5,3.5), v.size.path=.9)
# plot.modules(g, color.random=TRUE, v.size=1, layout.function=layout.graphopt)
# 
# # MST plot: Global layout style: Kamada-Kawai
# mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE, layout.function=layout.kamada.kawai)
# mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE,layout.function=layout.fruchterman.reingold)
# ecl <- rgb(r=0, g=1, b=1, alpha=.6)
# ppx <- mst.plot.mod(g, v.size=degree(g),e.size=.5,
#                     colors=ecl,mst.e.size=1.2,expression=degree(g),
#                     mst.edge.col="white", sf=-10, v.sf=6)
# 
# hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
# cl <- rgb(r=1, b=.7, g=0, alpha=.1)
# fn <- function(x){layout.reingold.tilford(x, circular=TRUE,
#                                           root=which.max(degree(x)))}
# mst.plot.mod(g, vertex.color=cl, v.size=1, sf=30,
#              colors=hc, e.size=.5, mst.e.size=.75,
#              layout.function=fn, layout.overall=layout.kamada.kawai)
# 
# hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
# cl <- rgb(r=0, b=.7, g=1, alpha=.05)
# mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
#              colors=hc, e.size=.5, mst.e.size=.75,
#              layout.function=layout.fruchterman.reingold)
# 
# #Abstract modular view of a component 
# plot.abstract.nodes(g, v.sf=-35,layout.function=layout.fruchterman.reingold, lab.color="white",lab.cex=.75)
# plot.abstract.nodes(g, layout.function=layout.fruchterman.reingold, v.sf=-30, lab.color="green")
# # Information flow layout
# 
# # information flow: 
# level.plot(g, tkplot=FALSE, level.spread=FALSE, layout.function=layout.fruchterman.reingold)
# cl <- rgb(r=.6, g=.6, b=.6, alpha=.5)
# level.plot(g, init_nodes=20,tkplot=FALSE, level.spread=TRUE,
#            order_degree=NULL, v.size=1, edge.col=c(cl, cl, "green", cl),
#            vertex.colors=c("red", "red", "red"), e.size=.5, e.curve=.25)
# 
# # abstract module 
# plot.abstract.nodes(g, nodes.color ="grey",layout.function=layout.star, edge.colors= sample(color.list$bright), tkplot =FALSE,lab.color = "red")
# # module view: (don't work for directed graph)
# splitg.mst(g, vertex.color = sample(color.list$bright), colors = color.list$warm[1:30], tkplot = FALSE)
# # abstract module: (don't work for directed graph)
# plot.abstract.module(g, tkplot = FALSE, layout.function=layout.star)
# 
# plot.igraph(g, edge.width=E(g)$weight, edge.curved=F, layout = layout_with_fr(g))
# 
# pdf('./Figures/main_figures/chromaffin_global_network.pdf', height = 7, width = 7)
# hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=1)
# cl <- rgb(r=0, b=.7, g=1, alpha=.05)
# mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
#              bg = "white",
#              colors=hc, e.size=.5, mst.e.size=.75,
#              layout.function=layout.fruchterman.reingold)
# dev.off()
# 
# ################################################################################################################################################################# 
# # Calculate the centrality of the vertex for ranking genes  
# ################################################################################################################################################################# 
# # identify the hub genes / motifs, etc. 
# # degree centrality
# degree(g, mode="out")
# centr_degree(g, mode="out", normalized=T)
# closeness(g, mode="all")
# centr_clo(g, mode="all", normalized=T)
# eigen_centrality(g, directed=T)
# centr_eigen(g, directed=T, normalized=T)
# 
# betweenness(g, directed=T)
# edge_betweenness(g, directed=T)
# centr_betw(g, directed=T, normalized=T)
# 
# hs <- hub_score(g)$vector
# as <- authority_score(g)$vector
# plot(g, vertex.size=hs*50, main="Hubs")
# plot(g, vertex.size=as*30, main="Authorities")
# 
# page_rank(g)
# # centralization 
# # closeness 
# # eigenvector 
# # betweeness 
# # pageRank 
# ################################################################################################################################################################# 
# # Ranking genes 
# ################################################################################################################################################################# 
# gene_list <- c("sox10", 'sce', 'pou3f1', 'mse', 'erg2b', 'mpz',
#                "fabp7", "erbb3", "plp1", "dhh", "ngfr", "mag", "sox2", "sh3tc2", "prrx", "arhgef10", "foxd3", 
#                "lamb2", "lamb1", "lama2", "lama4", "mal", "s100b", "lgi4",
#                "nfkbiaa", "brn2", "sox2", 'MO2-jun', 'srebp', 'hmg', 'coa', 'mbpa', 'cx32')
# 
# Schwann_gene <- c("sox10", "mpz", "egr2b", "pou3f1", "xox9", "tfap2a", "pax3", "nfatc4", "sox2", "egr1", "jun", "pou3f1", "yy1", "brn2")
# other_genes <- c("pax3a", "pax3b", "etv5", "etv6", "yy1a", "yy1b", "egr2a", "egr2b")
# all_genes <- tools::toTitleCase(c(gene_list, Schwann_gene, other_genes))
# sort(page_rank(g)$vector)[all_genes]
# 
# hs <- hub_score(subset_g)$vector
# hs <- hub_score(g)$vector
# hs <- sort(hs, decreasing = T)
# 
# df <- data.frame(Order = 1:length(hs), name = names(hs), hub_score = hs)
# # df$name[df$hub_score < 0.1] <- NA
# 
# pdf('./Figures/main_figures/chromaffin_network_centrality.pdf', height = 1, width = 1) #, aes(color = hub_score > 0.5)
# ggplot(aes(Order, hub_score, label = name), data = df) + geom_point(size = 0.25)  + geom_text(hjust = -0.5, vjust = 0.5, check_overlap = TRUE, size = I(2)) + 
#   ylab('Hub centrality') + xlab('') + ylab('') + xlim(0, 30) + xacHelper::nm_theme() +
#   theme(axis.title.x=element_blank(),
#         axis.text.x=element_blank(),
#         axis.ticks.x=element_blank(),
#         axis.title.y=element_blank(),
#         axis.text.y=element_blank(),
#         axis.ticks.y=element_blank()) #+ scale_color_manual(values = c('black', 'red'))
# dev.off()
# 
# transition_df <- df[intersect(fig6a, V(subset_g)$name),]
# transition_df$pseudotime_order <- 1:nrow(transition_df)
# qplot(Order, pseudotime_order, data = transition_df)
# 
# ## Not run: 
# gene_pairs_mat <- matrix(c("Melk", "Sept3"), ncol = 2)
# plot_gene_pairs_in_pseudotime(current_cds[, pData(current_cds)$State %in% c(1, 3)], gene_pairs_mat)
# 
# df <- data.frame(exprs = c(exprs(current_cds)['Melk', ], exprs(current_cds)['Sept3', ]),
#                  time = pData(current_cds)$Pseudotime,
#                  gene = rep(c('Melk', 'Sept3'), each = ncol(current_cds)))
# qplot(time, exprs, color = gene, data = df) + geom_smooth() 
################################################################################################################################################################# 
# save the data 
################################################################################################################################################################# 
# save.image('./RData/analysis_chromaffin_cells.RData')
save.image('./RData/fig5.RData')
