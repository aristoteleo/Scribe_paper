import numpy as np
from random import gauss
from numpy.random import uniform

# Gene transition function
# The input and output arguments are dictionaries

##########################################################################

# Define the summation of dictionaries.
# A is a list of dicts
# All the dictionaries have to have same keys

def sum_dict(A):

    result = {}
    for key in A[0].keys():
        result[key] = 0
        for a in A: result[key] += a[key]

    return result

#########################################################################


def gene_trans_func ( x_old, dt ) :

    x_new = {}

    mature_mu = 0
    n = 4
    k = 1
    a = 4
    eta = 0.25
    eta_m = 0.125
    eta_b = 0.1
    a_s = 2.2
    a_e = 6
    mx = 10

    x_new["1"] = a_s * 1 / (1 + eta**n*(x_old["6"]+x_old["12"]+x_old["9"])**n * x_old["15"]**n ) - k * x_old["1"]
    x_new["2"] = a * ( x_old["1"]**n ) / (1 + x_old["1"]**n + x_old["7"]**n) - k * x_old["2"]
    x_new["3"] = a * ( x_old["2"]**n ) / (1 + x_old["2"]**n) - k * x_old["3"]
    x_new["5"] = a * ( x_old["2"]**n ) / (1 + x_old["2"]**n) - k * x_old["5"]
    x_new["6"] = a_e * ( x_old["3"]**n + x_old["5"]**n + x_old["11"]**n ) / (1 + x_old["3"]**n + x_old["5"]**n + x_old["11"]**n) - k*x_old["6"]
    x_new["7"] = a * ( x_old["1"]**n ) / (1 +  x_old["1"]**n + x_old["2"]**n)  - k * x_old["7"]
    x_new["8"] = a_e * ( eta**n * x_old["7"]**n ) / (1 + eta ** n * x_old["7"]**n + x_old["9"]**n) - k * x_old["8"]
    x_new["9"] = a_e * ( (eta * x_old["7"])**n ) / (1 + (x_old["8"])**n + (eta * x_old["7"])**n  ) - k * x_old["9"]
    x_new["10"] = a * ( eta**n * x_old["7"]**n * x_old["8"]**n ) / (1 + eta**n * x_old["7"]**n * x_old["8"]**n ) - k * x_old["10"]
    x_new["11"] = a * ( x_old["9"]**n ) / (1 + x_old["9"]**n) - k * x_old["11"]
    x_new["12"] = a_e * ( x_old["10"]**n ) / (1 + x_old["10"]**n) - k * x_old["12"]
    x_new["14"] = a * ( eta_m**n * x_old["9"]**n ) / (1 + eta_m**n * x_old["9"]**n) - k * x_old["14"]
    x_new["15"] = mature_mu * (1 - x_old["15"] / mx)

    for key in x_new.keys(): x_new[key] = x_new[key] *dt

    return x_new

################################################################################


def create_initialize_simulation_results( steps_no, runs_no):

    simulation_results = [[ {} for step in range(steps_no+1) ] for run in range(runs_no)]

    # Initialization
    for run in range(runs_no):
        simulation_results[run][0]["1"] = 2
        simulation_results[run][0]["2"] = 0
        simulation_results[run][0]["3"] = 0
        simulation_results[run][0]["5"] = 0
        simulation_results[run][0]["6"] = 0
        simulation_results[run][0]["7"] = 0
        simulation_results[run][0]["8"] = 0
        simulation_results[run][0]["9"] = 0
        simulation_results[run][0]["10"] = 0
        simulation_results[run][0]["11"] = 0
        simulation_results[run][0]["12"] = 0
        simulation_results[run][0]["14"] = 0
        simulation_results[run][0]["15"] = 0

    return simulation_results

#####################################################################


def generate_noise(x, type):

    noisy_x = {}
    if type.lower() == 'additive':
        for key in x.keys(): noisy_x[key] = x[key] + gauss(0, .1)
    elif type.lower() == 'multiplicative':
        for key in x.keys(): noisy_x[key] = x[key] * uniform(.75,1.25)
    return noisy_x

#####################################################################


def gene_simulation ( steps_no =200, runs_no=20 ):

    simulation_results = create_initialize_simulation_results( steps_no, runs_no)

    N_end = 100
    dt = N_end / steps_no

    # d: 1 * 12 * step_no  (randn)
    # D: 12 * 12 * step_no (covariance matrix: D(:, :, sh) = (d(:, :, step)' * d(:, :, step))
    # mu: step_no * 12 (all zero)
    # noise: step_no * 12 (mvnrnd: Multivariate normal random numbers)

    d = np.random.randn(1, 12, steps_no) / 10
    D = np.zeros((12, 12, steps_no))

    mu =  [0] * 12
    noise = np.zeros((steps_no, 12))
    for sh in range(steps_no):
        D[:,:,sh] = (d[:, :, sh]).T * d[:, :, sh];   #diffusion matrix
        noise[sh,:] = np.random.multivariate_normal(mu, 2 * D[:,:,sh], (1))

    for run in range(runs_no):
        for step in range(1,steps_no+1):
            simulation_results[run][step] = sum_dict([ simulation_results[run][step-1],
                                                       gene_trans_func( simulation_results[run][step-1], dt)])
            simulation_results[run][step] = generate_noise(simulation_results[run][step],"additive")
            for gene in simulation_results[run][step].keys(): simulation_results[run][step][gene] = max( 0, simulation_results[run][step][gene])
        print "{0}\r", run+1, "out of", runs_no,

    return simulation_results

#####################################################################

def write_genes_output(simulation_results, genes_id_list=["1","2","3","5","6","7","8","9","10","11","12","14","15"]):


    # Writing genes' data
    output_file = open("simulation_expr_mat.txt", "w")
    output_file.write("GENE_ID\tRUN_ID\n")
    for gene in genes_id_list:
        for run in range( len(simulation_results) ):
            output_file.write("G" + gene + "\t" + "R" + str(run+1))
            for step in range( len(simulation_results[run]) ): output_file.write( "\t" + str(simulation_results[run][step][gene]) )
            output_file.write("\n")
    output_file.close()

    # Writing genes feature file
    output_file = open("simulation_gene_feature.txt", "w")
    output_file.write("GENE_ID\tGENE_NAME")
    for gene in genes_id_list:
        output_file.write("\n")
        output_file.write("G"+gene+"\t"+"G"+gene)
    output_file.close()

    output_file.close()

######################################################################
######################################################################


simulation_results = gene_simulation()
write_genes_output(simulation_results)