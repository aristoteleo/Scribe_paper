# process_scRNA_seq 

# run RDI on the analyzed RT-PCR dataset 
library(lmtest)
library(rEDM)
library(monocle)
library(destiny)
library(reshape2)
library(di)
library(PRROC)

# load the dataset: 
load('./RData/analysis_scRNA_seq.RData')

#######################################################################################################################################################################################
# Olsson dataset: 
#######################################################################################################################################################################################
load('./RData/analysis_scRNA_seq_Olsson.RData')

start <- Sys.time()
GMP_branch_RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(exprs(Olsson_MEP_cds[fData(Olsson_MEP_cds)$use_for_ordering, ])), delays = c(10, 15, 20), cores = detectCores() - 2, verbose = T)
end <- Sys.time()

start <- Sys.time()
GMP_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(GMP_branch)[, unique(GMP_branch_RDI_parallel_res$id_1)], GMP_branch_RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)
end <- Sys.time()

MEP_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_MEP_cds)[fData(Olsson_MEP_cds)$use_for_ordering, ] + 1))))
MEP_dpt_res <- just_DPT(MEP_dm)

monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
monocyte_dpt_res <- just_DPT(monocyte_dm)

granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
granulocyte_dpt_res <- just_DPT(granulocyte_dm)

#######################################################################################################################################################################################
# Paul dataset: 
#######################################################################################################################################################################################
load('./RData/analysis_scRNA_seq_Paul.RData')

start <- Sys.time()
GMP_branch_RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(exprs(Olsson_MEP_cds[fData(Olsson_MEP_cds)$use_for_ordering, ])), delays = c(10, 15, 20), cores = detectCores() - 2, verbose = T)
end <- Sys.time()

start <- Sys.time()
GMP_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(GMP_branch)[, unique(GMP_branch_RDI_parallel_res$id_1)], GMP_branch_RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)
end <- Sys.time()

MEP_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_MEP_cds)[fData(Olsson_MEP_cds)$use_for_ordering, ] + 1))))
MEP_dpt_res <- just_DPT(MEP_dm)

monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
monocyte_dpt_res <- just_DPT(monocyte_dm)

granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
granulocyte_dpt_res <- just_DPT(granulocyte_dm)

#######################################################################################################################################################################################
# Pancreas dataset: 
#######################################################################################################################################################################################
load('./RData/analysis_scRNA_seq_pancreas.RData')





#######################################################################################################################################################################################
# Save result: 
#######################################################################################################################################################################################





