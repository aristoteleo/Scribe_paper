library(monocle)
library(pheatmap)
library(reshape2)

#analyze the ranking of incoming / outgoing edges: 

#1. run KO test with my implmention 

#2. do the ranking by incoming / outcoming RDI values and make some statistical analysis as well as plots 
output_RDI <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/ko_small_k1_w20_d1to41/output_RDI.txt', sep = '\t', header = T)
output_RDI_conditioned <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/ko_small_k1_w20_d1to41/output_RDI_conditioned.txt', sep = '\t', header = T)

rdi_res_mat <- dcast(output_RDI_conditioned[, c(1, 3, 6)], Gene_1_ID ~ Gene_2_ID) # output_RDI[, c(1, 3, 8)]

row.names(rdi_res_mat) <- rdi_res_mat$Gene_1_ID
rdi_res_mat <- rdi_res_mat[, -1]

rdi_res_mat[!is.finite(as.matrix(rdi_res_mat))] <- 0
diag(rdi_res_mat) <- 0

#do clustering to identify the modules of the networks 
#pdf('lung_rdi.pdf', width = 30, height = 30)
pheatmap(rdi_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
#dev.off()

#get the directionality for each gene pair: higher RDI value will determine the directionality 
valid_ind <- which(rdi_res_mat - t(rdi_res_mat) < 0, arr.ind = T)
for(x in 1:nrow(valid_ind))
  rdi_res_mat[valid_ind[x, 1], valid_ind[x, 2]] <- 0

#b. network
# create a graph:
g1 <- graph_from_adjacency_matrix(as.matrix(rdi_res_mat), mode = "directed", weighted = T)
plot(g1, layout = layout_nicely(g1))

res <- level.plot(g1)
E(g1)

#only pick the highest RDI value

#incoming edge: 
incoming_edge_weight <- lapply(V(g1)$name, function(x) incident(g1, x, mode = c("in"))$weight)
outgoing_edge_weight <- lapply(V(g1)$name, function(x) incident(g1, x, mode = c('out'))$weight)
incoming_edge_weight <- do.call(rbind.data.frame, incoming_edge_weight)
outgoing_edge_weight <- do.call(rbind.data.frame, outgoing_edge_weight)

incoming_sum <- rowSums(incoming_edge_weight)
outgoing_sum <- rowSums(outgoing_edge_weight)
names(incoming_sum) <- V(g1)$name
names(outgoing_sum) <- V(g1)$name

ordered_outgoing_sum_df <- data.frame(Order = 1:length(outgoing_sum), sum_outgoing_RDI = sort(outgoing_sum, decreasing = T), gene = names(sort(outgoing_sum, decreasing = T)), stringsAsFactors = F)
ordered_incoming_sum_df <- data.frame(Order = 1:length(incoming_sum), sum_incoming_RDI = sort(incoming_sum, decreasing = T), gene = names(sort(incoming_sum, decreasing = T)), stringsAsFactors = F)

ordered_outgoing_sum_df$gene[!(ordered_outgoing_sum_df$gene %in% c('gfi1', 'irf8'))] <- ''
ordered_incoming_sum_df$gene[!(ordered_incoming_sum_df$gene %in% c('gfi1', 'irf8'))] <- ''

p1 <- qplot(Order, sum_outgoing_RDI, data = ordered_outgoing_sum_df) + geom_text(aes(label = gene), nudge_y = 0.5)
p2 <- qplot(Order, sum_incoming_RDI, data = ordered_incoming_sum_df) + geom_text(aes(label = gene), nudge_y = 0.5)

xacHelper::multiplot(p1, p2)

#get the RDI sum all the desents of a node 
neighborhood.size( g1, 2,  V(g1)$name, "out") #size of each gene's 2 order targets
neighborhood( g1, 2,  V(g1)$name, "out") #neighborhood of each gene's 2 order targets

#relationship with expression values to the RDI rank: 
average_exprs <- esApply(URMM_all_fig1b[V(res$g)$name, ], 1, mean)
names(average_exprs) <- tolower(names(average_exprs))

ordered_outgoing_sum_df$avg_expr <- average_exprs[names(sort(outgoing_sum, decreasing = T))]
ordered_incoming_sum_df$avg_expr <- average_exprs[names(sort(incoming_sum, decreasing = T))]

qplot(Order, avg_expr, data = ordered_outgoing_sum_df) + geom_text(aes(label = gene), nudge_y = 0.5)
qplot(Order, avg_expr, data = ordered_incoming_sum_df) + geom_text(aes(label = gene), nudge_y = 0.5)

#color the rank by the level: 
ordered_outgoing_sum_df$avg_expr <- average_exprs[names(sort(outgoing_sum, decreasing = T))]
ordered_incoming_sum_df$avg_expr <- average_exprs[names(sort(incoming_sum, decreasing = T))]

#do a GSEA analysis with rank from RDI outgoing edges 
gene_levels <- res$layout[, 2]
names(gene_levels) <- V(res$g)$name

ordered_outgoing_sum_df$gene_level <- gene_levels[names(sort(outgoing_sum, decreasing = T))]
ordered_incoming_sum_df$gene_level <- gene_levels[names(sort(incoming_sum, decreasing = T))]

qplot(Order, sum_outgoing_RDI, data = ordered_outgoing_sum_df, color = gene_level) + geom_text(aes(label = gene), nudge_y = 0.5)
qplot(Order, sum_incoming_RDI, data = ordered_incoming_sum_df, color = gene_level) + geom_text(aes(label = gene), nudge_y = 0.5)

#test on rescale and center data to see whether or not the results changes 
#center doesn't change the result but scale will as well as log 

#3. prepare the dataset for the microglial analysis


#4. run CCM and granger on the LPS dataset 

#5. use tensorflow 

#6. run the pancreas simulation 

g1 <- graph.ring(9, directed=TRUE)
g2 <- graph.star(10, center=9, mode="out")
g <- graph.union(g1, g2)
g <- add.edges(g, c(3,9))
E(g)$capacity <- sample(1:10, ecount(g), replace=TRUE)
E(g)[ 3 %--% 9 ]$capacity <- 5
id <- tkplot(g, layout=layout.kamada.kawai, edge.labels=E(g)$capacity)



