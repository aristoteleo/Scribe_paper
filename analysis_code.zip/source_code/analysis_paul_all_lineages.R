# run the RDI for the entire blood tree (Paul dataset)
rm(list = ls())
#######################################################################################################################################
# add the regularization method 
#######################################################################################################################################

# https://www.nature.com/ncb/journal/v19/n4/abs/ncb3493.html

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

library(Scribe)
library(monocle)
library(igraph)
library(destiny)
library(ggraph)
library(igraph)
library(reshape2)
library(netbiov)

source('./Scripts/function.R') 
load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/Jupyter_notebook/Paul_dataset_analysis_final.RData")

# loop through each lineage and run the RDI 
table(pData(valid_subset_GSE72857_cds2)$State)

plot_complex_cell_trajectory(valid_subset_GSE72857_cds2, color_by = 'cell_type2')

########################################################################################################################################################################
# Monocyte, granulocyte and erythrocyte in the Paul dataset
########################################################################################################################################################################

# # order the cell by dpt using pseudotime ordering:
# exprs(Olsson_MEP_cds) <- as.matrix(exprs(Olsson_MEP_cds)); exprs(Olsson_monocyte_cds) <- as.matrix(exprs(Olsson_monocyte_cds)); exprs(Olsson_granulocyte_cds) <- as.matrix(exprs(Olsson_granulocyte_cds));
# MEP_dpt_res <- run_new_dpt(Olsson_MEP_cds); monocyte_dpt_res <- run_new_dpt(Olsson_monocyte_cds); granulocyte_dpt_res <- run_new_dpt(Olsson_granulocyte_cds);

# plot the mono, gran and erythroid cell lineage specific network 

########################################################################################################################################################################
# perform DEG test to identify genes you would like to use for network reconstruction 
########################################################################################################################################################################
# 1. between MK and Ery 
Ery_MK_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 3, cores = 4)
Mono_gran_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 5, cores = 4)
Neu_Bas_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 2, cores = 4)
DC_Bas_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 1, cores = 4)

########################################################################################################################################################################
# select slice of cells 
# run monocle 2 with principal curve or use dpt 
# run Scribe to get the network 
# apply sparsifier? 
# visualize the network with Hive plot 
########################################################################################################################################################################
gene_list <- c(positive_score_genes, negtive_score_genes)
exprs(valid_subset_GSE72857_cds2) <- as.matrix(exprs(valid_subset_GSE72857_cds2))
########################################################################################################################################################################
# Erythroid
########################################################################################################################################################################
gene_list <- row.names(Ery_MK_beam_res[order(Ery_MK_beam_res$qval), ])[1:1000]

Ery_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 9)]
# Ery_cds <- reduceDimension(Ery_cds, reduction_method = 'SimplePPT') #  reduceDimension(Ery_cds, reduction_method = 'DDRTree', ncenter = NULL, verbose = T)
# Ery_cds <- orderCells(Ery_cds)
# plot_cell_trajectory(Ery_cds, color_by = 'Pseudotime')
# 
# Ery_cds_only <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(9)]
# Ery_cds_only <- reduceDimension(Ery_cds_only, reduction_method = 'SimplePPT')
# Ery_cds_only <- orderCells(Ery_cds_only)
# Ery_only_dpt_res <- run_new_dpt(Ery_cds_only) 
# plot_cell_trajectory(Ery_cds_only)

Ery_dpt_res <- run_new_dpt(Ery_cds) 
pData(Ery_cds)$Pseudotime <- order(Ery_dpt_res$pt)

start_time <- Sys.time()
Ery_list <- calculate_rdi(Ery_cds[gene_list, ], delays = c(5, 20, 40))
curr_time <- Sys.time()
curr_time - start_time
# Ery_list_cond <- calculate_conditioned_rdi(Ery_cds[gene_list, ], rdi_list = Ery_list)
# 
# tmp <- expand.grid(1:ncol(example_data), 1:ncol(example_data), stringsAsFactors = F)
# super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
# super_graph <- super_graph[, c(2, 1)]
# 
# message('current range index is ', i)
# run_vec <- rep(1, nrow(example_data))
# rdi_list <- calculate_rdi_multiple_run_cpp(as.matrix(example_data), delay = c(1:15), run_vec - 1, as.matrix(super_graph), method = 1, uniformalize = F) #* 100 + noise
# 
# con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(as.matrix(example_data), as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 6, uniformalize = F)  # conditional on all other genes 
# max_rdi_value_correct_edge <- as.matrix(rdi_list$max_rdi_value)
# dimnames(max_rdi_value_correct_edge) <- list(colnames(example_data), colnames(example_data))
# max_rdi_value_correct_edge[! (colnames(max_rdi_value_correct_edge) %in% c('Gfi1', "Irf8")), ] <- -1
# con_rdi_res_test_correct_edge <- calculate_conditioned_rdi_multiple_run_wrap(as.matrix(example_data), as.matrix(super_graph), max_rdi_value_correct_edge, as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 6, uniformalize = F)  # conditional on all other genes 
# 

########################################################################################################################################################################
# Megakaryocyte 
########################################################################################################################################################################
MK_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 11)]
# MK_cds <- reduceDimension(MK_cds, reduction_method = 'SimplePPT')
# plot_cell_trajectory(MK_cds)
# MK_cds <- orderCells(MK_cds)
# 
# plot_cell_trajectory(MK_cds)
# plot_cell_trajectory(MK_cds) + facet_wrap(~State)
# MK_cds <- orderCells(MK_cds, root_state = 6)

MK_dpt_res <- run_new_dpt(MK_cds) 
pData(MK_cds)$Pseudotime <- order(MK_dpt_res$pt)

MK_list <- calculate_rdi(MK_cds[gene_list, ], delays = c(5, 20, 40))

########################################################################################################################################################################
# Monocyte 
########################################################################################################################################################################
gene_list <- row.names(Mono_gran_beam_res[order(Mono_gran_beam_res$qval), ])[1:1000]
Mono_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(7, 6)]
# Mono_cds <- reduceDimension(Mono_cds, reduction_method = 'SimplePPT')
# plot_cell_trajectory(Mono_cds)
# Mono_cds <- orderCells(Mono_cds)
# 
# plot_cell_trajectory(Mono_cds)
# plot_cell_trajectory(MK_cds) + facet_wrap(~State)
# MK_cds <- orderCells(MK_cds, root_state = 1)

Mono_dpt_res <- run_new_dpt(Mono_cds) 
pData(Mono_cds)$Pseudotime <- order(Mono_dpt_res$pt)

Mono_list <- calculate_rdi(Mono_cds[gene_list, ], delays = c(5, 20, 40))
# Mono_list_cond <- calculate_conditioned_rdi(Mono_cds[gene_list, ], rdi_list = Mono_list)

########################################################################################################################################################################
# Neutrophil 
########################################################################################################################################################################
gene_list <- row.names(Neu_Bas_beam_res[order(Neu_Bas_beam_res$qval), ])[1:1000]
Neu_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(7, 1)]
# Neu_cds <- reduceDimension(Neu_cds, reduction_method = 'SimplePPT')
# plot_cell_trajectory(Neu_cds)
# Neu_cds <- orderCells(Neu_cds)
# 
# plot_cell_trajectory(Neu_cds)
# plot_cell_trajectory(Neu_cds) + facet_wrap(~State)
# Neu_cds <- orderCells(Neu_cds, root_state = 6)

Neu_dpt_res <- run_new_dpt(Neu_cds) 
pData(Neu_cds)$Pseudotime <- order(Neu_dpt_res$pt)

Neu_list <- calculate_rdi(Neu_cds[gene_list, ], delays = c(5, 20, 40))
# Neu_list_cond <- calculate_conditioned_rdi(Neu_cds[gene_list, ], rdi_list = Neu_list)

########################################################################################################################################################################
# Basophil / Eosphil 
########################################################################################################################################################################
gene_list <- row.names(Neu_Bas_beam_res[order(Neu_Bas_beam_res$qval), ])[1:1000]
BE_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(7, 4)]
# BE_cds <- reduceDimension(BE_cds, reduction_method = 'SimplePPT')
# plot_cell_trajectory(BE_cds)
# BE_cds <- orderCells(BE_cds)
# 
# plot_cell_trajectory(BE_cds)
# plot_cell_trajectory(BE_cds) + facet_wrap(~State)
# BE_cds <- orderCells(BE_cds, root_state = 6)

BE_dpt_res <- run_new_dpt(BE_cds) 
pData(BE_cds)$Pseudotime <- order(BE_dpt_res$pt)

BE_list <- calculate_rdi(BE_cds[gene_list, ], delays = c(5, 20, 40))
# BE_list_cond <- calculate_conditioned_rdi(Ery_cds[gene_list, ], rdi_list = BE_list)

########################################################################################################################################################################
# DC 
########################################################################################################################################################################
gene_list <- row.names(DC_Bas_beam_res[order(DC_Bas_beam_res$qval), ])[1:1000]
DC_cds <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(7, 3)]
# DC_cds <- reduceDimension(DC_cds, reduction_method = 'SimplePPT')
# plot_cell_trajectory(DC_cds)
# DC_cds <- orderCells(DC_cds)
#  
# plot_cell_trajectory(DC_cds)
# plot_cell_trajectory(DC_cds) + facet_wrap(~State)
# DC_cds <- orderCells(DC_cds, root_state = 7)

DC_dpt_res <- run_new_dpt(DC_cds) 
pData(DC_cds)$Pseudotime <- order(DC_dpt_res$pt)

DC_list <- calculate_rdi(DC_cds[gene_list, ], delays = c(5, 20, 40))
# DC_list_cond <- calculate_conditioned_rdi(DC_cds[gene_list, ], rdi_list = DC_list)

save.image(file = './RData/analysis_paul_all_lineage_tmp.RData')

########################################################################################################################################################################
# run the sparsifer algorithm 
########################################################################################################################################################################
# load('./RData/RDI_res_paul.RData')


########################################################################################################################################################################
# show the result in a hive plot 
########################################################################################################################################################################
# > nodes[1:5, ]
# id lab vals    radius axis     size   color
# 1  1   1    1  9.090909    1 1.523930 #ffffff
# 2  2   2    2 18.181818    1 1.913706 #ffffff
# 3  3   3    3 27.272727    1 1.780276 #ffffff
# 4  4   4    4 36.363636    1 1.646483 #ffffff
# 5  5   6    6 54.545455    1 1.730239 #ffffff
# > edges[1:5, ]
# id1 id2    price weight colorvals     color
# 81  12  22 3720.706 19.536 0.3037987 #7BFF0060
# 56  12  17 2597.550 15.612 0.0000000 #FF000060
# 76  12  21 3374.939 15.304 0.2102733 #F2FF0060
# 71  12  20 3889.335 12.460 0.3494104 #41FF0060
# 8    8  12 1802.821 12.272 0.1003321 #FF800060

cell_type_list <- c("Erythrocyte", "Megakaryocyte", "Monocyte", "Neutrophil", 'Basophil / Eosinophil', 'Dendritic cell')
cell_type_color <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#6A3D9A", "#A65628", "#F781BF")

rdi_list <- list(Ery_list$max_rdi_value, MK_list$max_rdi_value, Mono_list$max_rdi_value, Neu_list$max_rdi_value, BE_list$max_rdi_value, DC_list$max_rdi_value)
cds_list <- list(Ery_cds, MK_cds, Mono_cds, Neu_cds, BE_cds, DC_cds)

plot_lineage_network <- function(gene_list, rdi_list, cds_list, cell_type_list, cell_type_color, 
                           top_edge_num = 100, 
                           return_hive_plot_data = FALSE, 
                           axLab.gpar = gpar(col = "black", fontsize = 6, lwd = 0.5), 
                           bkgnd = "white",
                           verbose = FALSE,
                           ...) {
  gene_num <- length(gene_list)

  nodes2 <- c()
  edges2 <- c()
  
  cell_type_num <- length(rdi_list)
  
  for(cell_type_ind in 1:cell_type_num) {
    if(verbose)
      message('current cell_type_ind is ', cell_type_ind)
    
    nodes_tmp <- data.frame(id = 1:gene_num, lab = gene_list, vals = 1:gene_num, radius = (1:gene_num) * (100 / gene_num), 
                        axis = cell_type_ind, size = 1, color = "#00000000", stringsAsFactors = F)
    
    tmp <- expand.grid(1:gene_num, 1:gene_num, stringsAsFactors = F)
    super_graph <- tmp[tmp[, 1] != tmp[, 2], ]
    max_rdi_value <- rdi_list[[cell_type_ind]]
    
    weight_vec <- apply(super_graph, 1, function(x) 
      {
        max_rdi_value[gene_list[x[1]], gene_list[x[2]]]
      })
    
    valid_edge_id <- which(weight_vec >= sort(weight_vec, decreasing = T)[top_edge_num])
    weight_vec <- weight_vec[valid_edge_id]   # take only the top 100 edges
    weight_vec <- 2 * (weight_vec - min(weight_vec)) / (max(weight_vec) - min(weight_vec))  
    edges_tmp <- data.frame(id1 = super_graph[valid_edge_id, 1], id2 = super_graph[valid_edge_id, 2], 
                       weight = weight_vec, color = cell_type_color[cell_type_ind], stringsAsFactors = F)
    
    if(cell_type_ind == 1) {
      nodes_tmp$id <- as.integer(nodes_tmp$id)
      
      edges_tmp$id1 <- as.integer(edges_tmp$id1)
      edges_tmp$id2 <- as.integer(edges_tmp$id2 + (cell_type_num - 1) * gene_num)
      # 
      # edges_tmp$id1 <- as.integer(edges_tmp$id1 + cell_type_num * gene_num)
      # edges_tmp$id2 <- as.integer(edges_tmp$id2)
      
      nodes2 <- nodes_tmp
      edges2 <- edges_tmp
    } else {
      nodes_tmp$id <- as.integer(nodes_tmp$id + (cell_type_ind - 1) * gene_num)
      
      edges_tmp$id1 <- as.integer(edges_tmp$id1 + (cell_type_ind - 1) * gene_num)
      edges_tmp$id2 <- as.integer(edges_tmp$id2 + (cell_type_ind - 2) * gene_num)
      
      nodes2 <- rbind(nodes2, nodes_tmp)
      edges2 <- rbind(edges2, edges_tmp)
    }
  }
  
  hpd = list()
  hpd$nodes = nodes2
  hpd$edges = edges2
  hpd$type = "2D"
  hpd$desc = "Paul"
  hpd$axis.cols = rep('#ffffff', 6) # make invisible
  hpd$axLabs = cell_type_list #,"colour","clarity")
  class(hpd) = "HivePlotData"
  
  # Check data correctly formatted
  
  chkHPD(hpd, confirm = TRUE)
  
  if(return_hive_plot_data) {
    return(hpd)
  }
  else {
    plotHive(hpd, axLabs = hpd$axLabs, ch = 0.1, axLab.gpar = axLab.gpar, bkgnd = bkgnd, ...)
  }
}

pdf(paste0(main_fig_dir, 'Paul_hive_plot.pdf'), width =  2, height = 2)
plotHive(hpd, axLabs = hpd$axLabs, ch = 0.1)
dev.off()

########################################################################################################################################################################
# get a lineage specific network 
########################################################################################################################################################################
# 1. overlap with the TF list
mouse_TFs <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/mouse_TF_list.csv', header = F)


# 2. between MK and Ery 
# Ery_MK_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 3, cores = 4)
# Mono_gran_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 5, cores = 4)
# Neu_Bas_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 2, cores = 4)
# DC_Bas_beam_res <- BEAM(valid_subset_GSE72857_cds2, branch_point = 1, cores = 4)

# Ery - Meloid: Gata1 - Spi1; 
# Mega: Fli1 Gata2 ; Ery: Eklf - Klf1
# Gran: Gfi1 ; Macro: Nab2 / Egr / Egr2 
# B cell: Pax5 ; 
# T cell: Gata3; B lymphoid: Ebf1
# erythroid-myeloid: Gata1-Spi1 SPi1-Tal1 Fosb-E2f8 NFia-Spi1 Hes6-Klf4
# Gata3-Spib; Gata3-Aff3; Ebf1-Gata3 

# from paul paper: 
paul_Ery <-  c("Gata1", "Phf10", "Zfpm1", "Gfi1b", "Cited4", "Klf1", "Mbd2", "E2f4", "Tcf3", "Phb2", "Hmgb3")
paul_Mk <- c("Cited2", "Fli1", "Pbx1", "Mef2c", "Meis1") # Gata2
paul_Baso <- c("Lmo4", "Runx1")
paul_Eos_Neu <- "Cebpe"
paul_Neu <- "Gfi1" 
paul_Mono <- "Irf8"
paul_Dc <- "Id2" 
paul_GMP <- c("Chd3", "Sox4", "Stat3", "Etv6", "Pu.1", "Elf1", "Nfe2", "Cebpa", "Foxp1")

#TF from Paul paper: 
#Cebpe Calr Arid3a Gfi1 Lmo4 Cebpa Pu.1 Cux1 Scand1 Nfkbia Irf8 Id2 Chd3 Cbfa2t3 Etv6 Stat6 Pnrc1 Pbx1 Mef2c Fli1 Elf1 Lmo2 Cited2 Sox4 Runx1 Gata2 Nfe2 Mrb Foxp1 Zfpm1 Hmgb3 Klf1 Gfi1b Tcf3 Pa2g4 Mbd2 Gata1 Phf10 Phb2 Csda E2f4 Cited4 Ccne1  
#Target of Cebpa, Irf8, Klf1, Pu.1 from Paul paper: 
#Cebpa:  Abcb1b, Acot1, C3, Cnpy3, Dhrs7, Dtx4, Edem2, Etfb, Ftl1, Gadd45b, Herpud1, Hp, Il6ra, Lcn2, Lcp1, Lman2, Lrg1, Serpinf1, Snord49b, Tnfrsf1a, Tnfsf14, Trappc1, Trf, Xdh
#Irf8: Abcd1, Aif1, BC017643, Cbl, Ccdc109b, Ccl6, d68, d74, dc42se1, Cdca7, Csf3r, Ctss, Cybb, Cyp4f18, Dtx2, Entpd1, Ercc6l, Erp29, Fastkd3, Ftl1, Gda, Grn, H2-M3, Hexa, Hk3, Ide, Il6ra, Irf5, Lamp1, Ly86, Mtm1, Napsa, Ncf1, Osbpl3, Pdlim2, Phgdh, Pld4, Psmb10, Psmb8, Rgs2, Rod1, Snx10, Spop, Tapbp, Tapbpl, Tm6sf1, Trem2, Trem3, Wipf1, Xdh, Zfp296,
#Irf8 (2): 1100001G20Rik, 4732418C07Rik, 9230105E10Rik, AI504432, Acox3, Actb, Aif1, Akap13, Ap1s3, Arhgap30, Arid5a, Arsk, Ass1, Bcl9l, Bst2, Ccl5, Ccl6, Ccng2, Cd52, Cd74, Cited2, Ctss, Dapp1, Emp3, Erp29, Ets1, Fgd2, Gpr18, Gramd3, H2-K1, Hist4h4, Hk3, Irf5, Lsp1, Ly86, Ncf4, Parp8, Pdlim2, Pecam1, Psap, Psmb8, Ptpn18, S100a10, Shfm1, Sla, Socs1, Tmem50a, Trove2
#Klf1: 2010011I20Rik, 5730469M10Rik, Acsl6, Add2, Ank1, Arhgap23, Blvrb, C330018D20Rik, Ccdc23, Cd24a, Cd82, Ctbp1, Cyth3, Dnajb1, E2f4, Emilin2, Epn1, Fam132a, Fam53b, Gfi1b, Grina, Gypa, Hdgf, Hebp1, Hemgn, Hs6st1, Kel, Klf3, Lmna, Lsm4, Mgst3, Mrpl52, Nudt9, Pla2g16, Ppap2a, Prdx2, Prkab1, Samd14, Sepw1, Snx3, Srxn1, Ucp2, Vamp5, Zcchc6,
#Pu.1: 0910001L09Rik, 2310014H01Rik, 4632428N05Rik, Abcd1, Anxa2, Ap3s1, Arid3a, Arpc1b, Arpc2, Bola2, Calm1, Cfl1, Chd7, Cited2, Csf1r, Csf3r, Ctsc, Dnajb11, Dnajc3, Edem1, Emilin1, Eml4, Ero1lb, Fes, Fgd2, G6pc3, Gsr, H13, H47, Hexa, Hspa5, Hyou1, Ifngr2, Igfbp4, Il21r, Irf1, Kdelr2, Krtcap2, Lamp1, Lcp1, Lta4h, Ltb4r1, Man2b1, Manf, Myl12b, Myo1f, Napsa, Ncf2, Ncf4, Pdia3, Pkm2, Pld4, Prtn3, Psmb8, Pstpip1, Ptgs1, Ptpn18, Renbp, Sec61b, Sh2b2, Sirpa, Ssr4, Tkt, Tmbim6, Tmed9, Tnfrsf1a, Tyrobp, Unc93b1, Vav1

Ery_MK_tf <- sort(intersect(mouse_TFs$V1, row.names(Ery_MK_beam_res[order(Ery_MK_beam_res$qval), ])[1:1000]))
Mono_gran_tf <- sort(intersect(mouse_TFs$V1, row.names(Mono_gran_beam_res[order(Mono_gran_beam_res$qval), ])[1:1000]))
Neu_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(Neu_Bas_beam_res[order(Neu_Bas_beam_res$qval), ])[1:1000]))
DC_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(DC_Bas_beam_res[order(DC_Bas_beam_res$qval), ])[1:1000]))

# 1. draw network for different lineages first: 
# Ery_list MK_list Mono_list Neu_list BE_list DC_list 
# curr_cell_type

all_lineage_tfs <- list(paul_Ery, paul_Mk, paul_Baso, paul_Eos_Neu, paul_Neu, paul_Mono, paul_Dc, paul_GMP) 
for(curr_ind in 1:length(all_lineage_tfs)) { #Ery_MK_tf, Mono_gran_tf, Neu_Bas_tf, DC_Bas_tf
  message('curr_ind is ', curr_ind)
  if(curr_ind %in% 1:2) {
    known_tf <- intersect(all_lineage_tfs[[curr_ind]], Ery_MK_tf)
    if(curr_ind == 1) {
      net <- Ery_list$max_rdi_value[known_tf, known_tf]
      net_clr <- clr_directed_R(net)
      net_clr[net_clr < 0] <- 0    
      assign("Ery_net_clr", net_clr)
    }
    else {
      net <- MK_list$max_rdi_value[known_tf, known_tf]
      net_clr <- clr_directed_R(net)
      net_clr[net_clr < 0] <- 0    
      assign("MK_net_clr", net_clr)
    }
  } else if(curr_ind %in% c(6, 8)) {
    known_tf <- intersect(c(paul_GMP, all_lineage_tfs[[curr_ind]]), Mono_gran_tf)
    if(length(known_tf) > 1) {
      net <- Mono_list$max_rdi_value[known_tf, known_tf]
      net_clr <- clr_directed_R(net)
      net_clr[net_clr < 0] <- 0   
      assign("Mono_net_clr", net_clr)
    }
  } else if(curr_ind %in% c(3, 5)) {
    known_tf <- intersect(c(paul_GMP, all_lineage_tfs[[curr_ind]]), Neu_Bas_tf)
    if(length(known_tf) > 1) {
      net <- Neu_list$max_rdi_value[known_tf, known_tf]
      net_clr <- clr_directed_R(net)
      net_clr[net_clr < 0] <- 0   
      assign("Neu_net_clr", net_clr)
    }
  } else if(curr_ind %in% c(4, 7)) {
    if(curr_ind == 4) {
      known_tf <- intersect(c(paul_GMP, all_lineage_tfs[[curr_ind]]), DC_Bas_tf)
      if(length(known_tf) > 1) {
        net <- BE_list$max_rdi_value[known_tf, known_tf]
        net_clr <- clr_directed_R(net)
        net_clr[net_clr < 0] <- 0
        
        assign("BE_net_clr", net_clr)
      }
    } else if(curr_ind == 7) {
      known_tf <- intersect(c(paul_GMP, all_lineage_tfs[[curr_ind]]), DC_Bas_tf)
      if(length(known_tf) > 1) {
        net <- DC_list$max_rdi_value[known_tf, known_tf]
        net_clr <- clr_directed_R(net)
        net_clr[net_clr < 0] <- 0     
      }
      
      assign("DC_net_clr", net_clr)
    }
  
  }
}
curr_cell_type <- 'Ery'
net_clr <- Ery_net_clr
net_clr[net_clr < 1] <- 0     

# 
Ery_net_clr_df <- melt(Ery_net_clr); Ery_net_clr_df$type <- 'Ery'
MK_net_clr_df <- melt(MK_net_clr); MK_net_clr_df$type <- 'MK'
Mono_net_clr_df <- melt(Mono_net_clr); Mono_net_clr_df$type <- 'Mono'
Neu_net_clr_df <- melt(Neu_net_clr); Neu_net_clr_df$type <- 'Neu'
BE_net_clr_df <- melt(BE_net_clr); BE_net_clr_df$type <- 'BE'
DC_net_clr_df <- melt(DC_net_clr); DC_net_clr_df$type <- 'DC'
all_net_clr <- Reduce(rbind, list(Ery_net_clr_df, MK_net_clr_df, Mono_net_clr_df, Neu_net_clr_df, BE_net_clr_df, DC_net_clr_df))
all_net_clr_final <- rbind(all_net_clr, all_net_clr)
all_net_clr_final$x <- factor(c(as.character(all_net_clr$Var1), as.character(all_net_clr$Var2)), 
                              levels = c(paul_GMP, paul_Baso, paul_Eos_Neu, paul_Neu, paul_Mono, paul_Dc, paul_Ery, paul_Mk))
all_net_clr_final$y <- rep(c(1, 2), each = nrow(all_net_clr))
all_net_clr_final$edge <- paste0(all_net_clr_final$Var1, '_', all_net_clr_final$Var2)

all_net_clr_final$gene_cat <- as.character(all_net_clr_final$x)
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_GMP] <- 'GMP'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Ery] <- 'Ery'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Mk] <- 'Mk'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Baso] <- 'Baso'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Eos_Neu] <- 'Eos_Neu'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Neu] <- 'Neu'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Mono] <- 'Mono'
all_net_clr_final$gene_cat[all_net_clr_final$gene_cat %in% paul_Dc] <- 'Dc'

pdf('./Figures/main_figures/all_lineage_net_paul.pdf', width = 4.5, height = 1.5)
ggplot(aes(x = x, y = y, group = edge), 
       data = subset(all_net_clr_final, value > 0)) + geom_point(size = 3, aes(color = gene_cat)) + geom_line(aes(size = I(value), color = type), alpha = 0.5) + 
  xlab("Gene") + ylab("") + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))
dev.off()

subset_net <- subset(all_net_clr_final, value > 0 & gene_cat == 'Ery')
subset_net$type <- 'black'
subset_net$type[subset_net$edge %in% c('Gata1_Zfpm1', 'Gata1_Gfi1b', 'Gfi1b_Gata1', 'Gata1_Tcf3', 'Gata1_Klf1', 'Klf1_Zfpm1')] <- 'red'

pdf('./Figures/main_figures/all_lineage_net_paul.pdf', width = 2.5, height = 1.5)
ggplot(aes(x = x, y = y, group = edge), 
       data = subset_net) + geom_point(size = 1) + geom_line(aes(size = I(value) / 5, color = I(type)), alpha = 0.5) + 
  xlab("Gene") + ylab("") + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))
dev.off()

pdf('./Figures/main_figures/all_lineage_net_paul_helper.pdf')
ggplot(aes(x = x, y = y, group = edge), 
       data = subset(all_net_clr_final, value > 0)) + geom_point(size = 3, aes(color = gene_cat)) + geom_line(aes(size = I(value), color = type), alpha = 0.5) + 
  xlab("Gene") + ylab("") + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))
dev.off()

# + theme(axis.text.x = element_text(angle = 30))
# plot_tree_pairwise_cor
# function (std_tree_cds, absolute_tree_cds) 
# {
#   maturation_df <- data.frame(cell = rep(colnames(std_tree_cds), 
#                                          2), maturation_level = 100 * c(pData(std_tree_cds)$Pseudotime/max(pData(std_tree_cds)$Pseudotime), 
#                                                                         pData(absolute_tree_cds)$Pseudotime/max(pData(absolute_tree_cds)$Pseudotime)), 
#                               Type = rep(c("FPKM", "Transcript counts (vst)")), rownames = colnames(absolute_tree_cds))
#   cor.coeff <- cor(pData(absolute_tree_cds)$Pseudotime, pData(std_tree_cds)$Pseudotime, 
#                    method = "spearman")
#   p <- ggplot(aes(x = maturation_level, y = Type, group = cell), 
#               data = maturation_df) + geom_point(size = 1) + geom_line(color = "blue") + 
#     xlab("Maturation level") + ylab("Type of tree construction") + 
#     annotate("text", x = 80, y = 2.2, label = paste("Spearman correlation:", 
#                                                     round(cor.coeff, 2))) + monocle_theme_opts()
#   return(p)
# }
# 
# g <- igraph::graph_from_adjacency_matrix(as.matrix(net_clr), weighted = T, mode = "direct")
# 
# intersect(paul_Mk, Ery_MK_tf) 
# pdf(paste0('./Figures/main_figures/', curr_cell_type, '_lineage_net.pdf'))
# plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE)
# dev.off()
# 
# V(g)$hubness <- hub_score(g)$vector
# 
# pdf(paste0('./Figures/main_figures/', curr_cell_type, '_lineage_net_paul.pdf'), height = 15, width = 15)
# print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
#         geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
#                                                                       ends = "last", type = "open")) +
#         scale_edge_width(range = c(0.2, 2)) +
#         geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
#         labs(edge_width = "Causality") +
#         theme_graph())
# dev.off()

# make the network for each lineage and create the hiearchy 
# Ery_list MK_list Mono_list Neu_list BE_list DC_list 
Ery_MK_tf <- sort(intersect(mouse_TFs$V1, row.names(Ery_MK_beam_res[order(Ery_MK_beam_res$qval), ])[1:1000]))
Mono_gran_tf <- sort(intersect(mouse_TFs$V1, row.names(Mono_gran_beam_res[order(Mono_gran_beam_res$qval), ])[1:1000]))
Neu_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(Neu_Bas_beam_res[order(Neu_Bas_beam_res$qval), ])[1:1000]))
DC_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(DC_Bas_beam_res[order(DC_Bas_beam_res$qval), ])[1:1000]))

Ery_list_max <- Ery_list$max_rdi_value
MK_list_max <- MK_list$max_rdi_value
Mono_list_max <- Mono_list$max_rdi_value
Neu_list_max <- Neu_list$max_rdi_value
BE_list_max <- BE_list$max_rdi_value
DC_list_max <- DC_list$max_rdi_value

Ery_list_max[setdiff(row.names(Ery_list$max_rdi_value), Ery_MK_tf), setdiff(row.names(Ery_list$max_rdi_value), Ery_MK_tf)] <- 0
MK_list_max[setdiff(row.names(MK_list$max_rdi_value), Ery_MK_tf), setdiff(row.names(MK_list$max_rdi_value), Ery_MK_tf)] <- 0
Mono_list_max[setdiff(row.names(Mono_list$max_rdi_value), Mono_gran_tf), setdiff(row.names(Mono_list$max_rdi_value), Mono_gran_tf)] <- 0
Neu_list_max[setdiff(row.names(Neu_list$max_rdi_value), Neu_Bas_tf), setdiff(row.names(Neu_list$max_rdi_value), Neu_Bas_tf)] <- 0
BE_list_max[setdiff(row.names(BE_list$max_rdi_value), Neu_Bas_tf), setdiff(row.names(BE_list$max_rdi_value), Neu_Bas_tf)] <- 0
DC_list_max[setdiff(row.names(DC_list$max_rdi_value), DC_Bas_tf), setdiff(row.names(DC_list$max_rdi_value), DC_Bas_tf)] <- 0

Ery_list_max <- clr_directed_R(Ery_list_max)
Ery_list_max[Ery_list_max < 0] <- 0    
g <- igraph::graph_from_adjacency_matrix(as.matrix(Ery_list_max), weighted = T, mode = "direct")

res <- level.plot(g)
# spiral-view: nodes are ranked using reingold-tilford algorithm
plot.spiral.graph(g, tp=90,vertex.color="blue",e.col="gold",rank.function=layout.reingold.tilford)
# spiral-view: starting with the highest degree node
data("color_list")
plot.spiral.graph(g, tp=60,vertex.color=sample(color.list$bright))
plot.spiral.graph(g, tp=179,vertex.color=sample(color.list$bright) )
# 3
fn <- function(g)plot.spiral.graph(g,12)$layout
plot.modules(g, layout.function=fn, layout.overall=layout.fruchterman.reingold,sf=20, v.size=1, color.random=TRUE)

# star-like global view of a scale free network starting with the five highest degree nodes 
plot.NetworkSperical.startSet(g, mo = "in", nc = 5)
# Global view
plot.NetworkSperical(g, mo="in", v.lab=FALSE, tkplot = FALSE,v.size=1 )

# Modular layout with hierarchical plots for the modules
plot.modules(g, layout.function = layout.reingold.tilford, col.grad=list(color.list$citynight), tkplot=FALSE)

# Modular layout (has errors)
exp <- rnorm(vcount(g))
plot.modules(g, modules.color="grey", expression = exp, exp.by.module = c(1,2,5), tkplot=FALSE)
plot.modules(g1, expression = exp, tkplot=FALSE)
cl <- list(rainbow(40), heat.colors(40) ); plot.modules(g, col.grad=cl , tkplot=FALSE)
plot.modules(g, layout.function = c(layout.fruchterman.reingold, layout.star,layout.reingold.tilford, layout.graphopt,layout.kamada.kawai), modules.color = sample(color.list$bright), sf=40, tkplot=FALSE)
plot.modules(g, layout.function = c(layout.fruchterman.reingold), modules.color = sample(color.list$bright),layout.overall = layout.star,sf=40, tkplot=FALSE)
plot.modules(g,mod.list=lm,layout.function=c(layout.fruchterman.reingold), modules.color="grey", mod.edge.col = sample(color.list$bright), tkplot=FALSE)
plot.modules(g, mod.list = lm, layout.function = layout.graphopt, modules.color = cl,mod.edge.col=c("green","darkgreen"), tkplot=FALSE, ed.color = c("blue"),sf=-25)
plot.modules(g, layout.function = layout.graphopt, modules.color = cl, mod.edge.col=c("green","darkgreen") , tkplot=FALSE, ed.color = c("blue"),sf=-25)
plot.modules(g, modules.color=cl, mod.edge.col=cl,
             sf=5, nodeset=c(2,5,44,34),
             mod.lab=TRUE, v.size=.9,
             path.col=c("blue", "purple", "green"),
             col.s1 = c("yellow", "pink"),
             col.s2 = c("orange", "white" ),
             e.path.width=c(1.5,3.5), v.size.path=.9)
plot.modules(g, color.random=TRUE, v.size=1, layout.function=layout.graphopt)

# MST plot: Global layout style: Kamada-Kawai
mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE, layout.function=layout.kamada.kawai)
mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE,layout.function=layout.fruchterman.reingold)
ecl <- rgb(r=0, g=1, b=1, alpha=.6)
ppx <- mst.plot.mod(g, v.size=degree(g),e.size=.5,
                    colors=ecl,mst.e.size=1.2,expression=degree(g),
                    mst.edge.col="white", sf=-10, v.sf=6)

hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
cl <- rgb(r=1, b=.7, g=0, alpha=.1)
fn <- function(x){layout.reingold.tilford(x, circular=TRUE,
                                          root=which.max(degree(x)))}
mst.plot.mod(g, vertex.color=cl, v.size=1, sf=30,
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=fn, layout.overall=layout.kamada.kawai)

hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
cl <- rgb(r=0, b=.7, g=1, alpha=.05)
mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=layout.fruchterman.reingold)

#Abstract modular view of a component 
plot.abstract.nodes(g, v.sf=-35,layout.function=layout.fruchterman.reingold, lab.color="white",lab.cex=.75)
plot.abstract.nodes(g, layout.function=layout.fruchterman.reingold, v.sf=-30, lab.color="green")
# Information flow layout

# information flow: 
level.plot(g, tkplot=FALSE, level.spread=FALSE, layout.function=layout.fruchterman.reingold)
cl <- rgb(r=.6, g=.6, b=.6, alpha=.5)
level.plot(g, init_nodes=20,tkplot=FALSE, level.spread=TRUE,
           order_degree=NULL, v.size=1, edge.col=c(cl, cl, "green", cl),
           vertex.colors=c("red", "red", "red"), e.size=.5, e.curve=.25)

# abstract module 
plot.abstract.nodes(g, nodes.color ="grey",layout.function=layout.star, edge.colors= sample(color.list$bright), tkplot =FALSE,lab.color = "red")
# module view: (don't work for directed graph)
splitg.mst(g, vertex.color = sample(color.list$bright), colors = color.list$warm[1:30], tkplot = FALSE)
# abstract module: (don't work for directed graph)
plot.abstract.module(g, tkplot = FALSE, layout.function=layout.star)

plot.igraph(g, edge.width=E(g)$weight, edge.curved=F, layout = layout_with_fr(g))

pdf('./Figures/main_figures/chromaffin_global_network.pdf', height = 7, width = 7)
hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=1)
cl <- rgb(r=0, b=.7, g=1, alpha=.05)
mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
             bg = "white",
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=layout.fruchterman.reingold)
dev.off()
# 2. think about ideas to combining network from different lineages 

# 3. also combining bifurcation time analysis 

# 4. do this for the Olsson datasets 

save.image(file = './RData/analysis_paul_all_lineage.RData')

################################################################################################################################################################
# do the analysis suggested by Sreeram 
################################################################################################################################################################
Ery_MK_tf <- sort(intersect(mouse_TFs$V1, row.names(Ery_MK_beam_res[order(Ery_MK_beam_res$qval), ])[1:1000]))
Mono_gran_tf <- sort(intersect(mouse_TFs$V1, row.names(Mono_gran_beam_res[order(Mono_gran_beam_res$qval), ])[1:1000]))
Neu_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(Neu_Bas_beam_res[order(Neu_Bas_beam_res$qval), ])[1:1000]))
DC_Bas_tf <- sort(intersect(mouse_TFs$V1, row.names(DC_Bas_beam_res[order(DC_Bas_beam_res$qval), ])[1:1000]))

Ery_list_max <- clr_directed_R(Ery_list$max_rdi_value[Ery_MK_tf, Ery_MK_tf])

Ery_list_max <-Ery_list$max_rdi_value[Ery_MK_tf, Ery_MK_tf]

MK_list_max <- clr_directed_R(MK_list$max_rdi_value[Ery_MK_tf, Ery_MK_tf])
Mono_list_max <- clr_directed_R(Mono_list$max_rdi_value[Mono_gran_tf, Mono_gran_tf])
Neu_list_max <- clr_directed_R(Neu_list$max_rdi_value[Neu_Bas_tf, Neu_Bas_tf])
BE_list_max <- clr_directed_R(BE_list$max_rdi_value[Neu_Bas_tf, Neu_Bas_tf])
DC_list_max <- clr_directed_R(DC_list$max_rdi_value[DC_Bas_tf, DC_Bas_tf])

outgoing_Ery <- sort(apply(Ery_list_max, 1, sum), decreasing = T)
outgoing_MK <- sort(apply(MK_list_max, 1, sum), decreasing = T) 
outgoing_Mono <- sort(apply(Mono_list_max, 1, sum), decreasing = T)
outgoing_Neu <- sort(apply(Neu_list_max, 1, sum), decreasing = T)
outgoing_BE <- sort(apply(BE_list_max, 1, sum), decreasing = T)
outgoing_DC <- sort(apply(DC_list_max, 1, sum), decreasing = T)

cat(names(sort(outgoing_Ery, decreasing = T))[1:30], sep = '\n')
cat(names(sort(outgoing_MK, decreasing = T))[1:30], sep = '\n')
cat(names(sort(outgoing_Mono, decreasing = T))[1:30], sep = '\n')
cat(names(sort(outgoing_Neu, decreasing = T))[1:30], sep = '\n')
cat(names(sort(outgoing_BE, decreasing = T))[1:30], sep = '\n')
cat(names(sort(outgoing_DC, decreasing = T))[1:30], sep = '\n')

# paul_Ery <-  c("Gata1", "Phf10", "Zfpm1", "Gfi1b", "Cited4", "Klf1", "Mbd2", "E2f4", "Tcf3", "Phb2", "Hmgb3")
# paul_Mk <- c("Cited2", "Fli1", "Pbx1", "Mef2c", "Meis1", "Gata2", "Pf4", "Vwf") # Gata2
# paul_Baso <- c("Lmo4", "Runx1")
# paul_Eos_Neu <- "Cebpe"
# paul_Neu <- "Gfi1" 
# paul_Mono <- "Irf8"
# paul_Dc <- "Id2" 
# paul_GMP <- c("Chd3", "Sox4", "Stat3", "Etv6", "Pu.1", "Elf1", "Nfe2", "Cebpa", "Foxp1")

plot_ranking <- function(outgoing_vec, TF_vec) {
  df <- data.frame(TF = names(outgoing_vec), 
                   Order = order(outgoing_vec, decreasing = T),
                   total_outgoing_sum = outgoing_vec)
  df$lineage_gene_outgoing_sum_order <- names(sort(outgoing_vec, decreasing = T)) %in% TF_vec
  df <- df[df$Order, ]
  
  return(1 - which(names(sort(outgoing_vec, decreasing = T)) %in% TF_vec) / length(outgoing_vec))
  # 
  # p <- qplot(Order, total_outgoing_sum, color = lineage_gene_outgoing_sum_order, data = df) + ylab('Total outgoing RDI sum') + xacHelper::nm_theme()
  # 
  # print(p)
}

paul_Ery_rank <- plot_ranking(outgoing_Ery, paul_Ery)
paul_MK_rank <- plot_ranking(outgoing_MK, c(paul_Mk))
paul_Mono_rank <- plot_ranking(outgoing_Mono, paul_GMP)
paul_Neu_rank <- plot_ranking(outgoing_Neu, paul_GMP)
paul_BE_rank <- plot_ranking(outgoing_BE, paul_GMP)
paul_DC_rank <- plot_ranking(outgoing_DC, paul_GMP)

df <- data.frame(rank = c(paul_Ery_rank, paul_MK_rank, paul_Mono_rank, paul_Neu_rank, paul_BE_rank, paul_DC_rank), 
                 type = c(rep('Ery', length(paul_Ery_rank)),
                          rep('MK', length(paul_MK_rank)),
                          rep('Mono', length(paul_Mono_rank)),
                          rep('Neu', length(paul_Neu_rank)),
                          rep('BE', length(paul_BE_rank)),
                          rep('DC', length(paul_DC_rank)))) 

pdf(paste0(main_fig_dir, 'TF_ranking.pdf'), width =  2, height = 1.5)
ggplot(aes(type, rank), data = df[df$type != 'MK', ]) + geom_violin(aes(fill = type)) + ylim(0, 1) + xacHelper::nm_theme() + xlab('Cell type') + ylab('Normalized Rank') + viridis::scale_fill_viridis(discrete = T, option = 'D')# geom_jitter(aes(color = Time), size = 0.5) +
dev.off()















