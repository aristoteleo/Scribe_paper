# run RDI on the analyzed RT-PCR dataset 
library(lmtest)
library(rEDM)
library(monocle)
library(destiny)
library(reshape2)
library(PRROC)
library(InformationEstimator)

# load the dataset: 
load('./RData/analysis_RT_PCR.RData')
source("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R", echo = T)

main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'

#######################################################################################################################################################################################
# Moignard dataset: 
#######################################################################################################################################################################################

start <- Sys.time()
GMP_branch_RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(GMP_branch), delays = c(10, 15, 20), cores = detectCores() - 2, verbose = T)
end <- Sys.time()

start <- Sys.time()
GMP_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(GMP_branch)[, unique(GMP_branch_RDI_parallel_res$id_1)], GMP_branch_RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)
end <- Sys.time()

start <- Sys.time()
CLP_branch_RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(CLP_branch), delays = c(10, 15, 20), cores = detectCores() - 2, verbose = T)
end <- Sys.time()

start <- Sys.time()
CLP_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(CLP_branch)[, unique(CLP_branch_RDI_parallel_res$id_1)], CLP_branch_RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)
end <- Sys.time()

start <- Sys.time()
preMegE_branch_RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(preMegE_branch), delays = c(10, 15, 20), cores = detectCores() - 2, verbose = T)
end <- Sys.time()

start <- Sys.time()
preMegE_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(preMegE_branch)[, unique(preMegE_branch_RDI_parallel_res$id_1)], preMegE_branch_RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)
end <- Sys.time()

#######################################################################################################################################################################################
# Psaila dataset: 
#######################################################################################################################################################################################

#######################################################################################################################################################################################
# Guo dataset: 
#######################################################################################################################################################################################

#######################################################################################################################################################################################
# 3000 cells Moignard dataset: 
#######################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_RT_PCR.RData')
Moignard_data <- t(Moignard_blood_2015_mat$data)
row.names(Moignard_data) <- unlist(Moignard_blood_2015_mat$Genes.analysed)
colnames(Moignard_data) <- paste0("Cell_", 1:ncol(Moignard_data))

# run monocle on the data and get the branch, etc. 
qplot(Moignard_blood_2015_mat$phi[, 2], Moignard_blood_2015_mat$phi[, 3], color = as.factor(Moignard_blood_2015_mat$Branch))

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = row.names(Moignard_data), row.names = row.names(Moignard_data)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = colnames(Moignard_data), 
                                                  DPT = Moignard_blood_2015_mat$DPT,
                                                  Branch = Moignard_blood_2015_mat$Branch, 
                                                  row.names = colnames(Moignard_data)))
dm_data <- t(Moignard_blood_2015_mat$phi)[1:3, ]
colnames(dm_data) <- colnames(Moignard_data)
row.names(dm_data) <- paste0("dim_", 1:3)
fd <- new("AnnotatedDataFrame", data = as.data.frame(dm_data))
Moignard_blood_2015_cds <- newCellDataSet(as.matrix(dm_data), #as(as.matrix(dm_data), "sparseMatrix"),
                                          phenoData = pd, 
                                          featureData = fd, 
                                          expressionFamily=gaussianff(), 
                                          lowerDetectionLimit=1)
Moignard_blood_2015_cds <- reduceDimension(Moignard_blood_2015_cds, norm_method = 'none', pseudo_expr = 0, reduction_method = 'DDRTree', verbose = T)

# run RDI on this dataset: 
# state 3: tip branch 2; 
tip_branch_1_data <- Moignard_data[, order(Moignard_blood_2015_mat$DPT)][, Moignard_blood_2015_mat$Branch %in% c(1, 0, 2)]

tip_branch_1_data <- tip_branch_1_data + 11 # min(tip_branch_1_data) # change things into non-negative values 
a <- Sys.time()
rdi_res <- calculate_rdi(t(tip_branch_1_data)[, ], delays = c(5, 10, 15, 20, 25, 30)) # 1:500
b <- Sys.time()
b - a 

ca <- Sys.time()
conditional_res <- calculate_conditioned_rdi(t(tip_branch_1_data), super_graph = NULL, rdi_res, 1L)
cb <- Sys.time()

load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Moignard_blood_2015_rdi_res.RData')

# ROC curve result 
Moignard_net <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/Moignard_net.txt', stringsAsFactors = F)

#######################################################################################################################################################################################
gene_uniq <- unique(c(Moignard_net[, 1], Moignard_net[, 2]))
valid_gene_uniq <- intersect(gene_uniq, row.names(Moignard_data))
all_cmbns <- expand.grid(valid_gene_uniq, valid_gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste((valid_all_cmbns$Var1), (valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair

valid_Moignard_net <- subset(Moignard_net, V1 %in% valid_gene_uniq & V2 %in% valid_gene_uniq)
valid_all_cmbns_df[paste((valid_Moignard_net$V1), (valid_Moignard_net$V2), sep = '_'), 2] <- 1

network_result_df <- valid_all_cmbns_df

network_result_df$RDI <- apply(valid_all_cmbns, 1, function(x) rdi_res$RDI[x[1], x[2]])
network_result_df$cRDI <- apply(valid_all_cmbns, 1, function(x) conditional_res[x[1], x[2]])

reference_network_pvals <- valid_all_cmbns_df[, 2]
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(network_result_df[, 3:4]), function(x, reference_network_pvals_df = reference_network_pvals) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

pdf(paste(SI_fig_dir, "Moignard_ROC.pdf", sep = ''), height = 1, width = 1)
qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #
  xlim(c(0, 1.0)) + xacHelper::nm_theme()
dev.off()

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

pdf(paste(SI_fig_dir, "Moignard_ROCAUC.pdf", sep = ''), height = 1, width = 1)
ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1) + xacHelper::nm_theme()
dev.off()

#######################################################################################################################################################################################

#######################################################################################################################################################################################
# Moignard dataset (# 640 cells ): 
#######################################################################################################################################################################################

#######################################################################################################################################################################################
# 2000 cells Sui dataset (multiple) : we don't have a good network for those genes 
#######################################################################################################################################################################################




