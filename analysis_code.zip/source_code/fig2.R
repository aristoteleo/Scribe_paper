#fig 2 
# library(Scribe)
load_all("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe")
library(plyr)
library(monocle)
library(inflection)

data("neuron_network") # network data
data("neuron_sim_cds") # network data
data("na_sim_cds") # network data
data("example_graph") # network data

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

pdf(paste0(main_fig_dir, 'Brn2.pdf'), width =  3, height = 1)
qplot(pData(neuron_sim_cds)$Time, exprs(neuron_sim_cds)['Tuj1', ], size = I(0.25)) + xlab('Time') + ylab('Expression (Tuj1)') + xacHelper::nm_theme() 
dev.off()

pdf(paste0(main_fig_dir, 'Tuj1.pdf'), width =  3, height = 1)
qplot(pData(neuron_sim_cds)$Time, exprs(neuron_sim_cds)['Brn2', ], size = I(0.25)) + xlab('Time') + ylab('Expression (Brn2)') + xacHelper::nm_theme() 
dev.off()

df <- data.frame(Time = pData(neuron_sim_cds)$Time, 
                 Expression = c(exprs(neuron_sim_cds)['Tuj1', ], exprs(neuron_sim_cds)['Brn2', ]), 
                 Gene = rep(c('Tuj1', 'Brn2'), each = ncol(neuron_sim_cds)))
pdf(paste0(main_fig_dir, 'both.pdf'), width =  3, height = 1)
qplot(Time, Expression, color = Gene, size = I(0.25), data = df) + xlab('Time') + ylab('Expression (Brn2)') + 
  xacHelper::nm_theme() 
dev.off()

pData(neuron_sim_cds)$Pseudotime <- 1:400
pdf(paste0(main_fig_dir, 'gene_pairs_kinetic_curves.pdf'), width =  1.2, height = 2)
plot_gene_pairs_in_pseudotime(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]),
                              n_row = 2, n_col = 1, log = F, fitting_type = 'spline', cell_size = 0.5) + xacHelper::nm_theme() 
dev.off()
pdf(paste0(main_fig_dir, 'gene_pairs_kinetic_curves_a.pdf'), width =  1.2, height = 1)
plot_gene_pairs_in_pseudotime(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12), 1:2]),
                              n_row = 2, n_col = 1, log = F, fitting_type = 'spline', cell_size = 0.5) + xacHelper::nm_theme() 
dev.off()
pdf(paste0(main_fig_dir, 'gene_pairs_kinetic_curves_b.pdf'), width =  1.2, height = 1)
plot_gene_pairs_in_pseudotime(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(8), 1:2]),
                              n_row = 2, n_col = 1, log = F, fitting_type = 'spline', cell_size = 0.5) + xacHelper::nm_theme() 
dev.off()

pdf(paste0(main_fig_dir, 'lagged_drevi_plot.pdf'), width =  2, height = 1)
plot_lagged_drevi(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_lagged_drevi(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'lagged_drevi_plot_a.pdf'), width =  1, height = 1)
plot_lagged_drevi(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12), 1:2]), d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_lagged_drevi(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'lagged_drevi_plot_b.pdf'), width =  1, height = 1)
plot_lagged_drevi(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(8), 1:2]), d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_lagged_drevi(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'lagged_drevi_plot_b_helper.pdf'))
plot_lagged_drevi(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(8), 1:2]), d = 1, n_row = 1, n_col = 1)
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_causality_plot.pdf'), width =  2, height = 1)
plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_causality_plot_a.pdf'), width =  1, height = 1)
plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(12), 1:2]), d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_causality_plot_b.pdf'), width =  1, height = 1)
plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[c(8), 1:2]), d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

subset_combinatorial_net <- cbind(V0 = c('Pax6', 'Zic1'), neuron_network[c(12, 8), 1:2])
pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic.pdf'), width =  2, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  subset_combinatorial_net, d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_comb_logic(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic.pdf'), width =  2, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  subset_combinatorial_net, d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_comb_logic(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic_a.pdf'), width =  1, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  subset_combinatorial_net[1, ], d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_comb_logic(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic_a_helper.pdf'))
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  subset_combinatorial_net[1, ], d = 1, n_row = 1, n_col = 1)
dev.off()

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic_b.pdf'), width =  1, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  subset_combinatorial_net[2, ], d = 1, n_row = 1, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
# plot_comb_logic(cds_subset = neuron_sim_cds[, 1:200], gene_pairs_mat =  as.matrix(neuron_network[c(12, 8), 1:2]), d = 1, n_row = 1, n_col = 2) +
#   monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

Hes5_yt <- exprs(neuron_sim_cds)['Hes5', 2:400]
Hes5_yt_mins_1 <- exprs(neuron_sim_cds)['Hes5', 1:399]
Mash1_xt_mins_1 <- exprs(neuron_sim_cds)['Mash1', 1:399]

Tuj1_yt <- exprs(neuron_sim_cds)['Tuj1', 2:400]
Tuj1_yt_mins_1 <- exprs(neuron_sim_cds)['Tuj1', 1:399]
Brn2_xt_mins_1 <- exprs(neuron_sim_cds)['Brn2', 1:399]

data <- data.frame(Type = c(rep("Mash1 -> Hes5", 399), rep("Brn2 -> Tuj1", 399)), 
                   yt = c(Hes5_yt, Tuj1_yt), 
                   yt_mins_1 = c(Hes5_yt_mins_1, Tuj1_yt_mins_1),
                   xt_mins_1 = c(Mash1_xt_mins_1, Brn2_xt_mins_1))
pdf(paste0(main_fig_dir, 'Hes5_expression.pdf'), width =  1, height = 1)
qplot(yt_mins_1, yt, data = subset(data, Type == "Mash1 -> Hes5"), color = yt) + facet_wrap(~Type, scales = 'free') + 
  scale_color_gradientn("yt", colours = rev(c("#D53E4F", "#FC8D59", "#FEE08B", "#FFFFBF", "#E6F598", "#99D594", "#3288BD"))) + monocle:::monocle_theme_opts() + xacHelper::nm_theme() + 
  xlab( expression(paste("Hes5 (", "y", phantom()[{
    paste("t", phantom() - phantom(), 1)
  }], ")", ""))) + 
  ylab(expression(paste("Hes5 (", "y", phantom()[{
    paste("t")
  }], ")", "")))
dev.off()

pdf(paste0(main_fig_dir, 'Tuj1_expression.pdf'), width =  1, height = 1)
qplot(yt_mins_1, yt, data = subset(data, Type == "Brn2 -> Tuj1"), color = yt) + facet_wrap(~Type, scales = 'free') + 
  scale_color_gradientn("yt", colours = rev(c("#D53E4F", "#FC8D59", "#FEE08B", "#FFFFBF", "#E6F598", "#99D594", "#3288BD"))) + monocle:::monocle_theme_opts() + xacHelper::nm_theme() + 
  xlab( expression(paste("Tuj1 (", "y", phantom()[{
    paste("t", phantom() - phantom(), 1)
  }], ")", ""))) + 
  ylab(expression(paste("Tuj1 (", "y", phantom()[{
    paste("t")
  }], ")", "")))
dev.off()

pdf(paste0(main_fig_dir, 'Hes5_expression_xmin_1.pdf'), width =  1, height = 1)
qplot(xt_mins_1, yt, data = subset(data, Type == "Mash1 -> Hes5"), color = yt) + facet_wrap(~Type, scales = 'free') + 
  scale_color_gradientn("yt", colours = rev(c("#D53E4F", "#FC8D59", "#FEE08B", "#FFFFBF", "#E6F598", "#99D594", "#3288BD"))) + monocle:::monocle_theme_opts() + xacHelper::nm_theme() + 
  xlab( expression(paste("Mash1 (", "x", phantom()[{
    paste("t", phantom() - phantom(), 1)
  }], ")", ""))) + 
    ylab(expression(paste("Hes5 (", "y", phantom()[{
      paste("t")
    }], ")", "")))
dev.off()

pdf(paste0(main_fig_dir, 'Tuj1_expression_xmin_1.pdf'), width =  1, height = 1)
qplot(xt_mins_1, yt, data = subset(data, Type == "Brn2 -> Tuj1"), color = yt) + facet_wrap(~Type, scales = 'free') + 
  scale_color_gradientn("yt", colours = rev(c("#D53E4F", "#FC8D59", "#FEE08B", "#FFFFBF", "#E6F598", "#99D594", "#3288BD"))) + monocle:::monocle_theme_opts() + xacHelper::nm_theme() + 
  xlab( expression(paste("Brn2 (", "x", phantom()[{
    paste("t", phantom() - phantom(), 1)
  }], ")", ""))) + 
  ylab(expression(paste("Tuj1 (", "y", phantom()[{
    paste("t")
  }], ")", "")))
dev.off()

theme(axis.text.x = element_text(angle = 30, hjust = 1))
#######################################################################################################################################
# plot all the response plot and causality as well as combinatorial logic plots; use them as supplementary figure 2
#######################################################################################################################################
pdf(paste0(SI_fig_dir, 'gallery_response.pdf'), width =  6, height = 4)
plot_lagged_drevi(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[, 1:2]), d = 1, n_row = 4, n_col = 6) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = 1))
dev.off()

pdf(paste0(SI_fig_dir, 'gallery_causality.pdf'), width =  6, height = 4)
plot_gene_pairs_causality(cds_subset = neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[, 1:2]), d = 1, n_row = 4, n_col = 6) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = 1))
dev.off()

combinatorial_net <- cbind(V0 = c('Pax6', 'Pax6', 'Zic1', 'Zic1', 'Hes5', 'Hes5'), 
                           V1 = c('Hes5', 'Mash1', 'Brn2', 'Olig2', 'Scl', 'Olig2'), 
                           V2 = c('Mash1', 'Hes5', 'Tuj1', 'Brn2', 'Olig2', 'Scl'))
pdf(paste0(SI_fig_dir, 'gallery_combinatorial_logic.pdf'), width =  3.5, height = 3)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  combinatorial_net, d = 1, n_row = 2, n_col = 3) +
     monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

#######################################################################################################################################
# probably also provide all possible two gene or three gene regulatory networks 
#######################################################################################################################################

#######################################################################################################################################
# In addition, we need to add a combinatorial plot to show the interactions for genes in a regulatory chain, 
# like Mash1 -> Zic1 -> Tuj1; and genes not in a chain: Mash1 - Hes5 and Zic1 
#######################################################################################################################################
combinatorial_net_pathway <- cbind(V0 = c('Pax6', 'Mash1'), 
                                   V1 = c('Mash1', 'Hes5'), 
                                   V2 = c('Zic1', 'Zic1'))
pdf(paste0(main_fig_dir, 'gallery_combinatorial_logic_sreeram_1.pdf'), width =  1, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  combinatorial_net_pathway[1, , drop = F], d = 1, n_row = 2, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'gallery_combinatorial_logic_sreeram_2.pdf'), width =  1, height = 1)
plot_comb_logic(cds_subset = neuron_sim_cds[, ], gene_pairs_target_mat =  combinatorial_net_pathway[2, , drop = F], d = 1, n_row = 2, n_col = 1) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

#######################################################################################################################################
# save results 
#######################################################################################################################################
save.image('./RData/fig2.RData')


