simulation_expr_mat <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat.txt', sep = '\t', row.names = 1)

simulation_expr_mat <- simulation_expr_mat[, -c(1:2)]
row.names(simulation_expr_mat) <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')
colnames(simulation_expr_mat) <- seq(0, 100, length.out = 10000)

simulation_expr_df <- as.data.frame(t(simulation_expr_mat))
simulation_expr_df_mlt <- melt(simulation_expr_df)
simulation_expr_df_mlt$time <- rep(seq(0, 100, length.out = 10000), 13)

qplot(time, value, data = simulation_expr_df_mlt, color = 'variable')

qplot(time, value, data = subset(simulation_expr_df_mlt, variable %in% c('Mash1', 'Hes5', 'Pax6')), color = variable)

library(R.matlab)
cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')

#test on parallel verision for conditioned RDI:
single_run_simulation <- cell_simulate$cell.simulate[1:13, 1:1001, 1]

row.names(single_run_simulation) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')
rdi_res <- calculate_and_write_pairwise_dmi(t(single_run_simulation), delays = c(1, 2, 5, 10), cores = 2, verbose = T)
# save the result: 
write.table(file = 'neuron_simulation_rdi_res.txt', rdi_res, col.names = T, sep = '\t', quote = F, row.names = T)

con_rdi_res <- calculate_and_write_pairwise_dmi_conditioned(t(single_run_simulation)[, unique(rdi_res$id_1)], rdi_res, cores = 2, k = 1, verbose = T)
write.table(file = 'neuron_simulation_con_rdi_res.txt', con_rdi_res, col.names = T, sep = '\t', quote = F, row.names = T)

#########################################################################################################
# run ROC curve analysis: 
#########################################################################################################
library(ROCR)

generate_roc_df <-function(p_value, classification, type = 'fpr') {
  p_value[is.na(p_value)] <- 1
  pred_p_value <- prediction(p_value, classification)
  perf_tpr_fpr <- performance(pred_p_value, "tpr", "fpr")
  
  fpr = perf_tpr_fpr@x.values
  
  tpr = perf_tpr_fpr@y.values
  
  perf_auc <- performance(pred_p_value, "auc")
  auc <- perf_auc@y.values
  
  data.frame(tpr = tpr, fpr = fpr, auc = auc)
}


########################################################################################################################################################################
#make the ROC curves as well as the AUC barplot: 
########################################################################################################################################################################
#reference network: 
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- unique(c(as.character(neuron_network$V1), as.character(neuron_network$V2)))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
rdi_res_lower_case <- rdi_res; row.names(rdi_res_lower_case) <- tolower(row.names(rdi_res))
con_rdi_res_lower_case <- con_rdi_res; row.names(con_rdi_res_lower_case) <- tolower(row.names(con_rdi_res))

rdi_res_lower_case$maximum <- apply(rdi_res_lower_case[, 3:5], 1, max)
rdi_pvals_df <- data.frame(RDI_R = as.numeric(as.character(rdi_res_lower_case[row.names(valid_all_cmbns_df), 'maximum'])),
                           cRDI_R = as.numeric(as.character(con_rdi_res_lower_case[row.names(valid_all_cmbns_df), 'conditioned_rdi'])),
                           ccm = simulation_ccm_res_lower_case[row.names(valid_all_cmbns_df), 'V6'])
#use the spike-in as the gold standard

reference_network_pvals <- valid_all_cmbns_df[, 2] 
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(rdi_pvals_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- rdi_pvals_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 1
  reference_network_pvals[is.na(reference_network_pvals)] <- 1
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type, 
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') + 
  facet_wrap(~method) + 
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) + 
  xlab("") + ylim(0, 1)

# compare with the fixed smooth python result: 

########################################################################################################################################################################
# test on the simulation 
########################################################################################################################################################################
neuron_mat <- t(single_run_simulation)

neuron_simulation_parallel_res <- parallelCCM(ordered_exprs_mat = neuron_mat, cores = detectCores() / 2)
neuron_simulation_parallel_res_mat <- prepare_ccm_res(neuron_simulation_parallel_res)

gene_names <- colnames(neuron_simulation_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = neuron_simulation_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'neuron_simulation_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

simulation_ccm_res <- read.table('neuron_simulation_ccm_res.txt', sep = '\t', header = F)
simulation_ccm_res_lower_case <- simulation_ccm_res; row.names(simulation_ccm_res_lower_case) <- tolower(paste(simulation_ccm_res_lower_case$V1, simulation_ccm_res_lower_case$V3, sep = '_'))

########################################################################################################################################################################
# test on the simulation 
########################################################################################################################################################################
#run Arman's small simulation data simulation_expr_mat.txt (dt=1, noise std=.01, n=1)
simulation_expr_mat <- read.table('./simulation_expr_mat.txt', sep = '\t', header = F) #read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat.txt', sep = '\t', row.names = 1)

simulation_expr_mat <- simulation_expr_mat[, -c(1:2)]
process_simulation_expr_mat <- NULL; #matrix(NA, nrow = 13, ncol = 20 * 2001)
for(i in 1:13) {
  process_simulation_expr_mat <- rbind(process_simulation_expr_mat, as.vector(do.call(cbind, lapply(seq(i, 260, by = 13), function(x) simulation_expr_mat[x, ]))))
}
row.names(process_simulation_expr_mat) <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

process_simulation_expr_mat <- t(process_simulation_expr_mat)
arman_simulation_parallel_res <- parallelCCM(ordered_exprs_mat = process_simulation_expr_mat, cores = detectCores())
arman_simulation_parallel_res_mat <- prepare_ccm_res(arman_simulation_parallel_res)

gene_names <- colnames(process_simulation_expr_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = process_simulation_expr_mat[gene_id1, gene_id2] )
    write.table(file = 'arman_simulation_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

# simulation_ccm_res <- read.table('arman_simulation_ccm_res.txt', sep = '\t', header = F)
# simulation_ccm_res_lower_case <- simulation_ccm_res; row.names(simulation_ccm_res_lower_case) <- tolower(paste(simulation_ccm_res_lower_case$V1, simulation_ccm_res_lower_case$V3, sep = '_'))


########################################################################################################################################################################
# AUC for the correlation values 
########################################################################################################################################################################
cor_res <- cor(t(process_simulation_expr_mat))

library(ROCR)

generate_roc_df <-function(p_value, classification, type = 'fpr') {
  p_value[is.na(p_value)] <- 1
  pred_p_value <- prediction(p_value, classification)
  perf_tpr_fpr <- performance(pred_p_value, "tpr", "fpr")
  
  fpr = perf_tpr_fpr@x.values
  
  tpr = perf_tpr_fpr@y.values
  
  perf_auc <- performance(pred_p_value, "auc")
  auc <- perf_auc@y.values
  
  data.frame(tpr = tpr, fpr = fpr, auc = auc)
}

cor_roc_df_list <- lapply(colnames(cor_res), function(x) {
  print(x)
  
  perm_pvals <- permutation_lung_pval_df[select_genes, 3] #use the spike-in as the gold standard
  software_pvals <- lung_pval_df[select_genes, x] 
  
  perm_pvals[is.na(perm_pvals)] <- 1
  software_pvals[is.na(software_pvals)] <- 1
  res <- generate_roc_df(software_pvals, perm_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

reference_network_pvals <- valid_all_cmbns_df[, 2] 
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(rdi_pvals_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- rdi_pvals_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 1
  reference_network_pvals[is.na(reference_network_pvals)] <- 1
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})
































