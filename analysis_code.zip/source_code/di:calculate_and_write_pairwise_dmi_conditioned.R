di::calculate_and_write_pairwise_dmi_conditioned
function (genes_data, rdi_res, k = 1, supergraph = NULL, cores = 1, 
    verbose = F) 
{
    k <- min(k, nrow(genes_data) - 2)
    rdi_res$max_rdi <- apply(rdi_res[, 3:(ncol(rdi_res) - 1)], 
        1, max)
    max_rdi <- apply(rdi_res[, 3:(ncol(rdi_res) - 2)], 1, which.max)
    delays_max <- as.numeric(do.call(rbind.data.frame, strsplit(colnames(rdi_res)[3:(ncol(rdi_res) - 
        2)], " "))[[2]])[max_rdi]
    rdi_res$max_val_delay <- delays_max
    names(delays_max) <- row.names(rdi_res)
    target_gene_list <- unique(rdi_res[, "id_2"])
    top_k_plus_1_incoming_id_list <- lapply(target_gene_list, 
        function(x) {
            rdi_res_subset <- rdi_res[rdi_res$id_2 == x, ]
            nodes <- rdi_res_subset[order(rdi_res_subset$max_rdi, 
                decreasing = T)[1:(k + 1)], "id_1"]
            delay <- rdi_res_subset[order(rdi_res_subset$max_rdi, 
                decreasing = T)[1:(k + 1)], "max_val_delay"]
            names(delay) <- nodes
            return(delay)
        })
    names(top_k_plus_1_incoming_id_list) <- target_gene_list
    tmp <- expand.grid(colnames(genes_data), colnames(genes_data), 
        stringsAsFactors = F)
    all_pairwise_gene <- tmp[as.character(tmp[, 1]) != as.character(tmp[, 
        2]), ]
    if (!is.null(supergraph)) {
        all_pairwise_gene_paste <- paste(all_pairwise_gene[, 
            1], all_pairwise_gene[, 2])
        supergraph_paste <- paste(supergraph[, 1], supergraph[, 
            2])
        all_pairwise_gene <- all_pairwise_gene[all_pairwise_gene_paste %in% 
            supergraph_paste, ]
    }
    all_pairwise_gene_list <- split(all_pairwise_gene, row.names(all_pairwise_gene))
    res <- mclapply(all_pairwise_gene_list, function(gene_pair, 
        genes_data, delays, N_operations) {
        index_name <- paste(gene_pair[1], gene_pair[2], sep = "_")
        top_k_plus_1 <- top_k_plus_1_incoming_id_list[[gene_pair[[2]]]]
        valid_top_k <- top_k_plus_1[!(names(top_k_plus_1) %in% 
            gene_pair[[1]])][1:(length(top_k_plus_1) - 1)]
        calculate_conditioned_rdi(gene_pair[[1]], gene_pair[[2]], 
            genes_data, delays_max[index_name], valid_top_k, 
            N_operations)
    }, genes_data = genes_data, mc.cores = cores)
    res <- do.call(rbind.data.frame, res)
    row.names(res) <- paste(res$id_1, res$id_2, sep = "_")
    res$delay_max <- delays_max[row.names(res)]
    return(res)
}

di::calculate_conditioned_rdi
function (id1, id2, genes_data, d, top_k_genes_delay, N_operations, 
    verbose = F) 
{
    if (class(genes_data) != "list") {
        top_k_genes_data <- data.frame()
        for (id in names(top_k_genes_delay)) {
            top_k_genes_data <- rbind(top_k_genes_data, id = genes_data[, 
                id])
        }
        conditioned_rdi <- rdi_single_run_conditioned(genes_data[, 
            id1], genes_data[, id2], d = d, z = matrix(as.matrix(top_k_genes_data), 
            nrow = nrow(genes_data)), z_delays = top_k_genes_delay)
    }
    else {
        expr1_t = c()
        expr2_t = c()
        past = c()
        for (run_id in 1:length(genes_data)) {
            tau <- max(c(top_k_genes_delay, d))
            tot_len <- nrow(genes_data[run_id]) - tau
            expr1_t <- genes_data[run_id][id1, (tau - d + 1):(tau - 
                d + tot_len)]
            expr2_t <- genes_data[run_id][id2, (tau + 1):(tau + 
                tot_len)]
            past_tmp <- genes_data[run_id][id2, (tau):(tau - 
                1 + tot_len)]
            for (id in top_k_genes_delay) {
                past_tmp <- cbind(past_tmp, genes_data[run_id][id, 
                  (tau - top_k_genes_delay[id] + 1):(tau - top_k_genes_delay[id] + 
                    tot_len)])
            }
            past <- cbind(past, past_tmp)
        }
        conditioned_rdi <- cmi(matrix(expr1_t, nrow = 1), matrix(expr2_t, 
            nrow = 1), matrix(past, nrow = 1))
    }
    if (verbose == T) 
        print(c(paste(id, id2, sep = "\t"), conditioned_rdi))
    res <- as.data.frame(t(c(id1, id2, conditioned_rdi)))
    row.names(res) = paste(id1, id2, sep = "_")
    colnames(res) <- c("id_1", "id_2", "conditioned_rdi")
    return(res)
}



