library(InformationEstimator)
library(reshape2)
library(ggplot2)

# # analyze the network sparser approaches: 
# 
# load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/all_cell_simulation')
cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')

all_cell_simulation <- cell_simulate$cell.simulate[, 1:400, ]
subset_exprs_mat_noise <- all_cell_simulation[1:12, , 1] # select just one cell and ignore the Mature 
row.names(subset_exprs_mat_noise) <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8')

# run the network reconstruction method: 
a <- Sys.time()
RDI_parallel_res <- calculate_rdi(t(subset_exprs_mat_noise), delays = c(1, 5, 10))
b <- Sys.time()

a <- Sys.time()
cRDI_parallel_res <- calculate_conditioned_rdi(t(subset_exprs_mat_noise), rdi_list = RDI_parallel_res)
b <- Sys.time()

# save the network (rdi or cRDI) for Qi to benchmark his sparsity algorithm 
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/RDI_res_for_qi.txt', RDI_parallel_res$RDI, sep = '\t', quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/cRDI_res_for_qi.txt', cRDI_parallel_res, sep = '\t', quote = F)

########################################################################################################################################################################
# make AUC curves, etc.
########################################################################################################################################################################
#reference network:
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- unique(c(as.character(neuron_network[, 1]), as.character(neuron_network[, 2])))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
benchmark_res <- list(RDI = RDI_parallel_res$RDI, cRDI = cRDI_parallel_res)
process_data <- function(benchmark_res) {
  gene_uniq <- unique(c(as.character(neuron_network$V1), as.character(neuron_network$V2)))
  all_cmbns <- expand.grid(gene_uniq, gene_uniq)
  valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
  all_valid_gene_pairs <- paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_')
  
  mlt_RDI_benchmark_res <- melt(benchmark_res$RDI[1:12, 1:12])
  row.names(mlt_RDI_benchmark_res) <- paste(tolower(mlt_RDI_benchmark_res$Var1), tolower(mlt_RDI_benchmark_res$Var2), sep = '_')

  mlt_cRDI_benchmark_res <- melt(benchmark_res$cRDI[1:12, 1:12])
  row.names(mlt_cRDI_benchmark_res) <- paste(tolower(mlt_cRDI_benchmark_res$Var1), tolower(mlt_cRDI_benchmark_res$Var2), sep = '_')

  network_result_df <- data.frame(RDI = mlt_RDI_benchmark_res[all_valid_gene_pairs, 'value'],
                                  cRDI = mlt_cRDI_benchmark_res[all_valid_gene_pairs, 'value'])
}

network_result_df <- process_data(benchmark_res)
network_result_df <- network_result_df[, ]
#use the spike-in as the gold standard
reference_network_pvals <- valid_all_cmbns_df[, 2]
p_thrsld <- 0

# reference_network_pvals_df

source("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R")

rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)
# 
# # test Qi's result on this simulation network: 
# 
# # run the MI package and provide the result: 
# library(fastGeneMI)
# library(parmigene)
# 
# data("ecoli.expr.data")
# data("ecoli.gs.net")
# data("insilico.expr.data")
# data("insilico.gs.net")
# data("scerevisiae.expr.data")
# data("scerevisiae.gs.net")
# 
# a <- Sys.time()
# par_ecoli_res <- parmigene::knnmi.all(t(ecoli.expr.data))
# b <- Sys.time()
# 
# c <- Sys.time()
# par_ecoli_res <- parmigene::knnmi.all(t(ecoli.expr.data))
# d <- Sys.time()
# 
# c <- Sys.time()
# par_ecoli_res <- parmigene::knnmi.all(t(ecoli.expr.data))
# d <- Sys.time()
# 
# c <- Sys.time()
# par_ecoli_res <- parmigene::knnmi.all(t(ecoli.expr.data))
# d <- Sys.time()
# 
# load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_different_MI_estimator.RData')
# 
# debug(calStatistics)
# debug(process_data)
# 
# test_res <- calStatistics(same_cell_pseudotime[1:26, 1:250], reference_network_pvals)