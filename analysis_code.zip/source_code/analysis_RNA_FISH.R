library(Scribe)
library(monocle)
library(destiny)
library(igraph)
library(extrafont)
font_import()
loadfonts()

# analyze RNA-fish dataset: 
source('./Scripts/function.R')
# ################################################################################################################################################################################
# # no-drug data 
# ################################################################################################################################################################################
# WM9_noDrug_20150810 <- read.csv('./csv_data/forAbhi/WM9_noDrug_20150810.txt', header = T, sep = ',', row.names = 1)
# WM9_noDrug_20150618 <- read.csv('./csv_data/forAbhi/WM9_noDrug_20150618.txt', header = T, sep = ',', row.names = 1)
# 
# WM9_noDrug <- rbind(WM9_noDrug_20150810, WM9_noDrug_20150618[, colnames(WM9_noDrug_20150810)])
# 
# pData <- WM9_noDrug[, 1:2]
# row.names(pData) <- row.names(WM9_noDrug)
# pd <- new("AnnotatedDataFrame", data = pData)
# fData <- data.frame(gene_short_name = colnames(WM9_noDrug)[-c(1:2)], row.names = colnames(WM9_noDrug)[-c(1:2)])
# fd <- new("AnnotatedDataFrame", data = fData)
# 
# # Now, make a new CellDataSet using the RNA counts
# WM9_noDrug_20150810_mat <- as.matrix(WM9_noDrug[, -c(1:2)])
# WM9_noDrug_20150810_mat[!is.finite(WM9_noDrug_20150810_mat)] <- 0 # remove NaN values
# WM9_noDrug_20150810_cds <- newCellDataSet(as(t(WM9_noDrug_20150810_mat), 'sparseMatrix'), 
#                                 phenoData = pd,
#                                 featureData = fd,
#                                 lowerDetectionLimit=0,
#                                 expressionFamily=negbinomial.size())
# 
# WM9_noDrug_20150810_cds <- estimateSizeFactors(WM9_noDrug_20150810_cds)
# WM9_noDrug_20150810_cds <- estimateDispersions(WM9_noDrug_20150810_cds)
# 
# WM9_noDrug_20150810_cds <- reduceDimension(WM9_noDrug_20150810_cds)
# WM9_noDrug_20150810_cds <- orderCells(WM9_noDrug_20150810_cds)
# 
# plot_cell_trajectory(WM9_noDrug_20150810_cds)
# 
# WM9_noDrug_20150810_cds <- reduceDimension(WM9_noDrug_20150810_cds, reduction_method = 'tSNE')
# WM9_noDrug_20150810_cds <- clusterCells(WM9_noDrug_20150810_cds)
# plot_cell_clusters(WM9_noDrug_20150810_cds) 

all_edege_paper <- matrix(c('PDGFRB', 'SERPINE1', 
                            'SERPINE1', 'VEGFC',
                            'VEGFC', 'SERPINE1',
                            'VEGFC', 'AXL',
                            'AXL', 'VEGFC',
                            'AXL', 'NGFR',
                            'EGFR', 'SERPINE1', 
                            'EGFR', 'CCNA2', 
                            'NRG1', 'VEGFC',
                            'NRG1', 'JUN',
                            'NRG1', 'AXL',
                            'NRG1', 'LOXL2',
                            'NRG1', 'WNT5A',
                            'LOXL2', 'NGFR',
                            'LOXL2', 'CCNA2',
                            'NGFR', 'AXL', 
                            'NGFR', 'LOXL2',
                            'NGFR', 'GAPDH',
                            'CCNA2', 'GAPDH',
                            'RUNX2', 'AXL',
                            'RUNX2', 'LOXL2',
                            'RUNX2', 'CCNA2',
                            'RUNX2', 'FGFR1',
                            'RUNX2', 'WNT5A',
                            'RUNX2', 'GAPDH',
                            'RUNX2', 'SOX10', 
                            'GAPDH', 'SOX10',
                            'GAPDH', 'CCNA2',
                            'SOX10', 'GAPDH',
                            'SOX10', 'MITF',
                            'MITF', 'SOX10'), ncol = 2)
# plot_lagged_drevi(WM9_noDrug_20150810_cds, gene_pairs_mat = all_edege_paper, log = T, n_col = 6, n_row = 6)

################################################################################################################################################################################
# add the time-series analysis 
################################################################################################################################################################################
WM9_48hrs_20150624 <- read.csv('./csv_data/forAbhi/WM9_48hrs_20150624.txt', header = T, sep = ',', row.names = 1)
WM9_48hrs_20151023 <- read.csv('./csv_data/forAbhi/WM9_48hrs_20151023.txt', header = T, sep = ',', row.names = 1)
WM9_1week_20150715 <- read.csv('./csv_data/forAbhi/WM9_1week_20150715.txt', header = T, sep = ',', row.names = 1)
WM9_1week_20150821 <- read.csv('./csv_data/forAbhi/WM9_1week_20150821.txt', header = T, sep = ',', row.names = 1)
WM9_4weeks_20150701 <- read.csv('./csv_data/forAbhi/WM9_4weeks_20150701.txt', header = T, sep = ',', row.names = 1)
WM9_4weeks_20150831 <- read.csv('./csv_data/forAbhi/WM9_4weeks_20150831.txt', header = T, sep = ',', row.names = 1)

WM9_temp <- do.call(rbind, list(WM9_48hrs_20150624, 
                                  WM9_48hrs_20151023[, colnames(WM9_48hrs_20150624)],
                                  WM9_1week_20150715[, colnames(WM9_48hrs_20150624)],
                                  WM9_1week_20150821[, colnames(WM9_48hrs_20150624)],
                                  WM9_4weeks_20150701[, colnames(WM9_48hrs_20150624)],
                                  WM9_4weeks_20150831[, colnames(WM9_48hrs_20150624)]
))

pData <- WM9_temp[-which(duplicated(WM9_temp[, -c(1:2)])), 1:2]
row.names(pData) <- row.names(WM9_temp[-which(duplicated(WM9_temp[, -c(1:2)])), 1:2])
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(WM9_temp)[-c(1:2)], row.names = colnames(WM9_temp)[-c(1:2)])
fd <- new("AnnotatedDataFrame", data = fData)

# Now, make a new CellDataSet using the RNA counts
WM9_temp_mat <- as.matrix(WM9_temp[-which(duplicated(WM9_temp[, -c(1:2)])), -c(1:2)]) 
WM9_temp_mat[!is.finite(WM9_temp_mat)] <- 0 # remove NaN values
WM9_temp_cds <- newCellDataSet(as(t(WM9_temp_mat + 
                                      matrix(rnorm(mean = 0, sd = 1e-10, nrow(WM9_temp_mat) * ncol(WM9_temp_mat)), nrow = nrow(WM9_temp_mat))), 'sparseMatrix'), 
                                          phenoData = pd,
                                          featureData = fd,
                                          lowerDetectionLimit=0,
                                          expressionFamily=negbinomial.size())

WM9_temp_cds <- estimateSizeFactors(WM9_temp_cds)
pData(WM9_temp_cds)$Size_Factor <- 1

WM9_temp_cds <- estimateDispersions(WM9_temp_cds)

#duplicated(t(exprs(WM9_temp_cds)))
plot_lagged_drevi(WM9_temp_cds, gene_pairs_mat = all_edege_paper, log = T, n_col = 6, n_row = 6)

WM9_temp_cds <- reduceDimension(WM9_temp_cds, verbose = T)
WM9_temp_cds <- orderCells(WM9_temp_cds)

plot_cell_trajectory(WM9_temp_cds)

WM9_temp_cds <- reduceDimension(WM9_temp_cds, reduction_method = 'tSNE')
WM9_temp_cds <- clusterCells(WM9_temp_cds, method = 'louvain')
plot_cell_clusters(WM9_temp_cds) 
pData(WM9_temp_cds)$Time <- c(rep(48, nrow(WM9_48hrs_20150624) + nrow(WM9_48hrs_20151023)), 
                              rep('1wk', nrow(WM9_1week_20150715) + nrow(WM9_1week_20150821)),
                              rep('4wk', nrow(WM9_4weeks_20150701) + nrow(WM9_4weeks_20150831)))[-c(1:2)] #[-which(duplicated(WM9_temp_mat))]
plot_cell_clusters(WM9_temp_cds, color = 'Time') 


WM9_temp_cds_dpt_res <- run_new_dpt(WM9_temp_cds, root = "15110")

plot_lagged_drevi(WM9_temp_cds, gene_pairs_mat = all_edege_paper, log = T, n_col = 6, n_row = 6)

################################################################################################################################################################################
# run uCMI, RDI, etc. 
################################################################################################################################################################################
umi_res <- calculate_umi(WM9_temp_cds, super_graph = data.frame(source = all_edege_paper[, 1], target = all_edege_paper[, 2], stringsAsFactors = F))
g <- igraph::graph_from_adjacency_matrix(as.matrix(umi_res), weighted = T, mode = "direct")
V(g)$name <- convert_to_true_ids(V(g)$name)

pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'))
plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
dev.off()

V(g)$hubness <- hub_score(g)$vector

pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'), height = 15, width = 15)
print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
        geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                      ends = "last", type = "open")) +
        scale_edge_width(range = c(0.2, 2)) +
        geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
        labs(edge_width = "Causality") +
        theme_graph())
dev.off()


################################################################################################################################################################################
# run causality for the pseudotime-ordered time-series 
################################################################################################################################################################################
load('./RData/WM9_temp_cds')
umi_res <- calculate_rdi(WM9_temp_cds, delays = c(5, 20, 41)) #  super_graph = data.frame(source = all_edege_paper[, 1], target = all_edege_paper[, 2], stringsAsFactors = F)
umi_res_1_4 <- calculate_rdi(WM9_temp_cds[, pData(WM9_temp_cds)$State %in% c(1, 4)], delays = c(5, 20, 41)) #  super_graph = data.frame(source = all_edege_paper[, 1], target = all_edege_paper[, 2], stringsAsFactors = F)
umi_res_5_4 <- calculate_rdi(WM9_temp_cds[, pData(WM9_temp_cds)$State %in% c(5, 4)], delays = c(5, 20, 41)) #  super_graph = data.frame(source = all_edege_paper[, 1], target = all_edege_paper[, 2], stringsAsFactors = F)

net <- umi_res_5_4$max_rdi_value
net_clr <- clr_directed_R(net)
net_clr[net_clr < 2] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(net_clr), weighted = T, mode = "direct")

pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'))
plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE)
dev.off()

V(g)$hubness <- hub_score(g)$vector

pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'), height = 15, width = 15)
print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) +
        geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                      ends = "last", type = "open")) +
        scale_edge_width(range = c(0.2, 2)) +
        geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
        labs(edge_width = "Causality") +
        theme_graph())
dev.off()

plot_cell_trajectory(WM9_temp_cds)
plot_cell_trajectory(WM9_temp_cds, color_by = 'Time')
plot_cell_trajectory(WM9_temp_cds, color_by = 'Pseudotime')
plot_cell_trajectory(WM9_temp_cds, color_by = 'Time') + facet_wrap(~State)

plot_genes_branched_heatmap(WM9_temp_cds, branch_states = c(1, 5), branch_labels = c('State 1', 'State 5'), show_rownames = T)
plot_genes_branched_pseudotime(WM9_temp_cds, branch_states = c(1, 5), ncol = 4, nrow = 5)
BEAM_res <- BEAM(WM9_temp_cds, branch_states = c(1, 5))

################################################################################################################################################################################
save.image('./RData/analysis_RNA_FISH.RData')


