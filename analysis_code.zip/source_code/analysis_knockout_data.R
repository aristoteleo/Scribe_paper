#########################################################################################################
# code for running the small dataset knockout 
#########################################################################################################

#smooth the data: 
order_hbp_mat <- as.matrix(exprs(URMM_all_fig1b)[, order(pData(URMM_all_fig1b)$Pseudotime)])
order_hbp_mat_state12 <- order_hbp_mat[V(res$g)$name, pData(URMM_all_fig1b)$State %in% c(1, 2)] 
order_hbp_mat_state13 <- order_hbp_mat[V(res$g)$name, pData(URMM_all_fig1b)$State %in% c(1, 3)] 

order_hbp_mat_state12_smooth <- smooth_genes(t(order_hbp_mat_state12), window_size = 20)
order_hbp_mat_state13_smooth <- smooth_genes(t(order_hbp_mat_state13), window_size = 20)

order_hbp_mat_states_smooth <- rbind(order_hbp_mat_state12_smooth, order_hbp_mat_state13_smooth)

#test on parallel verision for conditioned RDI:
rdi_res <- calculate_and_write_pairwise_dmi(order_hbp_mat_states_smooth, delays = c(1, 21, 41), cores = 2, verbose = T)
# save the result: 
write.table(file = 'hbp_rdi_res.txt', rdi_res, col.names = T, sep = '\t', quote = F, row.names = T)

con_rdi_res <- calculate_and_write_pairwise_dmi_conditioned(order_hbp_mat_states_smooth[, unique(rdi_res$id_1)], rdi_res, cores = 2, k = 1, verbose = T)
write.table(file = 'hbp_con_rdi_res.txt', con_rdi_res, col.names = T, sep = '\t', quote = F, row.names = T)

#compare with Arman's result: 
python_rdi <- read.table("/Users/xqiu/Downloads/output_RDI.txt", header = T)
python_rdi_conditioned <- read.table("/Users/xqiu/Downloads/output_RDI_conditioned.txt", header = T)

row.names(python_rdi) <- paste(python_rdi$Gene_1_ID, python_rdi$Gene_2_ID, sep = '_')
row.names(python_rdi_conditioned) <- paste(python_rdi_conditioned$Gene_1_ID, python_rdi_conditioned$Gene_2_ID, sep = '_')

rdi_res_lower_case <- rdi_res; row.names(rdi_res_lower_case) <- tolower(row.names(rdi_res))
con_rdi_res_lower_case <- con_rdi_res; row.names(con_rdi_res_lower_case) <- tolower(row.names(con_rdi_res))

#the results map up very well 
qplot(rdi_res_lower_case$`delays 1`, python_rdi[row.names(rdi_res_lower_case), 'DMI_for_d.1'])
qplot(rdi_res_lower_case$`delays 21`, python_rdi[row.names(rdi_res_lower_case), 'DMI_for_d.21'])
qplot(rdi_res_lower_case$`delays 41`, python_rdi[row.names(rdi_res_lower_case), 'DMI_for_d.41'])

qplot(as.numeric(as.character(con_rdi_res_lower_case$conditioned_rdi)), python_rdi_conditioned[row.names(con_rdi_res_lower_case), 'RDI'])

qplot(python_rdi[row.names(con_rdi_res_lower_case), 'MAXIMUM'], python_rdi_conditioned[row.names(con_rdi_res_lower_case), 'RDI'])
qplot(python_rdi[row.names(python_rdi), 'MAXIMUM'], python_rdi_conditioned[row.names(python_rdi_conditioned), 'RDI'])
#########################################################################################################
# run ROC curve analysis: 
#########################################################################################################
library(ROCR)

generate_roc_df <-function(p_value, classification, type = 'fpr') {
  p_value[is.na(p_value)] <- 1
  pred_p_value <- prediction(p_value, classification)
  perf_tpr_fpr <- performance(pred_p_value, "tpr", "fpr")
  
  fpr = perf_tpr_fpr@x.values
  
  tpr = perf_tpr_fpr@y.values
  
  perf_auc <- performance(pred_p_value, "auc")
  auc <- perf_auc@y.values
  
  data.frame(tpr = tpr, fpr = fpr, auc = auc)
}

cRDI_roc_df_list <- lapply(colnames(lung_pval_df), function(x) {
  print(x)
  
  perm_pvals <- permutation_lung_pval_df[select_genes, 3] #use the spike-in as the gold standard
  software_pvals <- lung_pval_df[select_genes, x] 
  
  perm_pvals[is.na(perm_pvals)] <- 1
  software_pvals[is.na(software_pvals)] <- 1
  res <- generate_roc_df(software_pvals, perm_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

########################################################################################################################################################################
#make the ROC curves as well as the AUC barplot: 
########################################################################################################################################################################

#reference network: 
fig1b_network <- read.table('./csv_data/true_small_ko_network.txt', header = F)

gene_uniq <- unique(c(as.character(fig1b_network$V1), as.character(fig1b_network$V2)))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(fig1b_network$V1), tolower(fig1b_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
rdi_res_lower_case$maximum <- apply(rdi_res_lower_case[, 3:5], 1, max)
rdi_pvals_df <- data.frame(RDI_R = as.numeric(as.character(rdi_res_lower_case[row.names(valid_all_cmbns_df), 'maximum'])),
                           cRDI_R = as.numeric(as.character(con_rdi_res_lower_case[row.names(valid_all_cmbns_df), 'conditioned_rdi'])), 
                           RDI_python = as.numeric(as.character(python_rdi[row.names(valid_all_cmbns_df), 'MAXIMUM'])), 
                           cRDI_python = as.numeric(as.character(python_rdi_conditioned[row.names(valid_all_cmbns_df), 'RDI'])),
                           RDI_python_fixed = as.numeric(as.character(python_rdi_fixed[row.names(valid_all_cmbns_df), 'MAXIMUM'])), 
                           cRDI_python_fixed = as.numeric(as.character(python_rdi_conditioned_fixed[row.names(valid_all_cmbns_df), 'RDI']))
) #use the spike-in as the gold standard

reference_network_pvals <- valid_all_cmbns_df[, 2] 
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(rdi_pvals_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- rdi_pvals_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 1
  reference_network_pvals[is.na(reference_network_pvals)] <- 1
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type, 
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') + 
  facet_wrap(~method) + 
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) + 
  xlab("") + ylim(0, 1)

# compare with the fixed smooth python result: 


#compare with Arman's result: 
python_rdi_fixed <- read.table("./csv_data/output_RDI_fixed_smooth_small_ko_dataset.txt", header = T)
python_rdi_conditioned_fixed <- read.table("./csv_data/output_RDI_conditioned_fixed_smooth_small_ko_dataset.txt", header = T)

row.names(python_rdi_fixed) <- paste(python_rdi_fixed$Gene_1_ID, python_rdi_fixed$Gene_2_ID, sep = '_')
row.names(python_rdi_conditioned_fixed) <- paste(python_rdi_conditioned_fixed$Gene_1_ID, python_rdi_conditioned_fixed$Gene_2_ID, sep = '_')

#the results map up very well 
qplot(rdi_res_lower_case$`delays 1`, python_rdi_fixed[row.names(rdi_res_lower_case), 'DMI_for_d.1'])
qplot(rdi_res_lower_case$`delays 21`, python_rdi_fixed[row.names(rdi_res_lower_case), 'DMI_for_d.21'])
qplot(rdi_res_lower_case$`delays 41`, python_rdi_fixed[row.names(rdi_res_lower_case), 'DMI_for_d.41'])

qplot(as.numeric(as.character(con_rdi_res_lower_case$conditioned_rdi)), python_rdi_conditioned[row.names(con_rdi_res_lower_case), 'RDI'])




