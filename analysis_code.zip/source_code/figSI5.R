# # analysis the Chromaffin cells
# rm(list = ls())
#
library(velocyto.R)
library(monocle)
library(destiny)
library(igraph)
library(pagoda2)
library(mclust)
library(Scribe)
library(netbiov)
library(stringr)
library(piano)
library(xacHelper) #loadGSCSafe
library(extrafont)
font_import()
loadfonts()
library(plyr)
library(dplyr)
library(ggraph)
library(arcdiagram)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

#################################################################################################################################################################
# kinetic curves
# GO enrichment
#################################################################################################################################################################
load('./RData/fig5.RDa') # analysis_chromaffin_cells.RData
#################################################################################################################################################################
root_directory <- "/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Shared Data"
mouse_go_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_bp_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc$gsc) <- str_split_fixed(names(mouse_go_gsc$gsc), "%", 2)[,1]

mouse_reactome_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Reactome_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
names(mouse_reactome_gsc$gsc) <- str_split_fixed(names(mouse_reactome_gsc$gsc), "%", 2)[,1]

mouse_kegg_gsc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Human_KEGG_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
names(mouse_kegg_gsc$gsc) <- str_split_fixed(names(mouse_kegg_gsc$gsc), "%", 2)[,1]

mouse_go_gsc_cc <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_cc_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc_cc$gsc) <- str_split_fixed(names(mouse_go_gsc_cc$gsc), "%", 2)[,1]
mouse_go_gsc_mf <- loadGSCSafe(paste(root_directory,"/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_mf_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
names(mouse_go_gsc_mf$gsc) <- str_split_fixed(names(mouse_go_gsc_mf$gsc), "%", 2)[,1]

#################################################################################################################################################################
# perform enrichment analysis on the beam heatmap
#################################################################################################################################################################
Chromaffin_heatmap_annotations = plot_genes_branched_heatmap(current_cds[inter_genes, ], return_heatmap = T)

# Get hyper geometric GSA test results for different enrichment sets (GO, KEGG, reactome, etc.)
Chromaffin_heatmap_clusters <- as.numeric(Chromaffin_heatmap_annotations$annotation_row$Cluster)
names(Chromaffin_heatmap_clusters) = fData(current_cds[row.names(Chromaffin_heatmap_annotations$annotation_row), ])$gene_short_name

Chromaffin_hyper_geometric_results_reactome <- collect_gsa_hyper_results(current_cds, gsc = mouse_reactome_gsc, Chromaffin_heatmap_clusters)
Chromaffin_hyper_geometric_results_kegg <- collect_gsa_hyper_results(current_cds, gsc = mouse_kegg_gsc, Chromaffin_heatmap_clusters)
Chromaffin_hyper_geometric_results_go <- collect_gsa_hyper_results(current_cds, gsc = mouse_go_gsc, Chromaffin_heatmap_clusters)

plot_gsa_hyper_heatmap <- function (cds, gsa_results, significance = 0.05, sign_type = "qval")
{
  hyper_df <- ldply(gsa_results, function(gsa_res) {
    data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues,
               qval = gsa_res$p.adj)
  })
  hyper_df$qval <- p.adjust(hyper_df$pval, method = 'fdr')
  colnames(hyper_df)[1] <- "cluster_id"
  hyper_df <- subset(hyper_df, hyper_df[, sign_type] <= significance)
  hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set),
                                    function(x) {
                                      nrow(x)
                                    }), by = "gene_set")
  save(hyper_df, file = "hyper_df")
  hyper_df$gene_set <- factor(hyper_df$gene_set, levels = unique(arrange(hyper_df,
                                                                         V1, cluster_id)$gene_set))
  qplot(cluster_id, gene_set, fill = -log10(qval), geom = "tile",
        data = hyper_df) + scale_fill_gradientn(colours = rainbow(7))
}

pdf(file =paste(SI_fig_dir, 'Chromaffin_reactome.pdf', sep = ''), height = 15, width = 7)
plot_gsa_hyper_heatmap(current_cds, Chromaffin_hyper_geometric_results_reactome, significance=1e-1) + nm_theme()
dev.off()

pdf(file =paste(SI_fig_dir, 'Chromaffin_kegg.pdf', sep = ''), height = 15, width = 7)
plot_gsa_hyper_heatmap(current_cds, Chromaffin_hyper_geometric_results_kegg, significance=1e-1) + nm_theme()
dev.off()

pdf(file =paste(SI_fig_dir, 'Chromaffin_go.pdf', sep = ''), height = 15, width = 7)
plot_gsa_hyper_heatmap(current_cds, Chromaffin_hyper_geometric_results_go, significance=1e-2) + nm_theme()
dev.off()

#
intersect_TFs <- intersect(as.character(mouse_TFs$V1), names(Chromaffin_heatmap_clusters))
all_fig_genes <- unique(c(fig5c, fig5d, fig6a, figSI7a, figSI7b, figSI7c, figSI7d, figSI8b, figSI8c, text_SCP, text_sympathoblasts, text_chromaffin, text_chromaffin_TF, text_chromaffin_signal))

Chromaffin_heatmap_clusters[intersect(intersect_TFs, all_fig_genes)]

#################################################################################################################################################################
# Kinetic curves for TFs
#################################################################################################################################################################
plot_genes_branched_pseudotime(current_cds[intersect(intersect_TFs, all_fig_genes), ], min_expr = 0.01)

pdf(file =paste(SI_fig_dir, 'Chromaffin_TFs.pdf', sep = ''), height = 2, width = 1.5)
plot_genes_branched_pseudotime(current_cds[c('Tbx2', 'Tcf3', 'Tbx20', 'Thra'), ], min_expr = 0.01, ncol = 2, nrow = 2, cell_size = 0.25) + nm_theme() +
  theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9))
dev.off()

pdf(file =paste(SI_fig_dir, 'Chromaffin_TFs_helper.pdf', sep = ''))
plot_genes_branched_pseudotime(current_cds[c('Tbx2', 'Tcf3', 'Tbx20', 'Thra'), ], min_expr = 0.01, ncol = 2, nrow = 2, cell_size = 0.25) +
  theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9))
dev.off()

#################################################################################################################################################################
# the network between TFs and the downstream targets without clustering (wired function?)
#################################################################################################################################################################

# run RDI on the TFs and RDI between TFs and the target genes
cluster_TFs <- F
cluster_targets <- F
scale <- T
smoothing <- F
cluster_num_method <- "mcclust"
delays <- c(5)
include_conditioning <- F
cluster_TFs_num = 2
cluster_targets_num = 10
scale_max <- 3
scale_min <- -3
hclust_method = "ward.D2"
norm_method <- 'log'

informative_genes <- inter_genes; TF <- row.names(subset(fData(current_cds), gene_short_name %in% mouse_TFs$V1))
pseudocount <- 1
TF_vec_names <- intersect(TF, informative_genes)
target_vec_names <- setdiff(informative_genes, TF)
unique_gene <- unique(c(TF, informative_genes))
gene_name_ids <- intersect(row.names(current_cds), unique_gene)
if (length(unique_gene) != length(gene_name_ids)) {
  stop("The current_cds you provided doesn't include all genes from the TF and informative_genes vector!")
}
cds_subset <- current_cds[gene_name_ids, ]
pData(cds_subset)$Pseudotime <- order(pData(cds_subset)$Pseudotime)
exprs_data <- exprs(cds_subset)[, pData(cds_subset)$Pseudotime]
if (norm_method == "vstExprs" && is.null(cds_subset@dispFitInfo[["blind"]]$disp_func) ==
    FALSE) {
  exprs_data = vstExprs(cds_subset, expr_matrix = exprs_data)
} else if (norm_method == "log") {
  exprs_data = log10(exprs_data + pseudocount)
}
annotation_TF_cluster = NULL
annotation_target_cluster = NULL
cRDI <- NULL
if (cluster_TFs | cluster_targets) {
  if (smoothing) {
    for (i in 1:ncol(exprs_data)) {
      df <- data.frame(Pseudotime = 1:ncol(exprs_data),
                       Expression = exprs_data[i, ])
      test <- loess(Expression ~ Pseudotime, df)
      exprs_data[i, ] <- predict(test)
    }
  }
  cds_subset@assayData$exprs <- exprs_data
  m <- exprs_data
  m = m[!apply(m, 1, sd) == 0, ]
  if (scale) {
    m = Matrix::t(scale(Matrix::t(m), center = TRUE))
    m = m[is.na(row.names(m)) == FALSE, ]
    m[is.nan(m)] = 0
    m[m > scale_max] = scale_max
    m[m < scale_min] = scale_min
  }
  TF_vec_names <- intersect(TF_vec_names, row.names(m))
  target_vec_names <- intersect(target_vec_names, row.names(m))
  m_tfs <- m[TF_vec_names, ]
  m_targets <- m[target_vec_names, ]
  # if (cluster_num_method == "mcclust") {
  #   clust_num_check_tfs <- Mclust(t(m_tfs), G = 1:min(10,
  #                                                     length(TF_vec_names)/2))
  #   cluster_TFs_num <- dim(clust_num_check_tfs$z)[2]
  #   clust_num_check_targets <- Mclust(t(m_targets),
  #                                     G = 1:min(10, length(target_vec_names)/2))
  #   cluster_targets_num <- dim(clust_num_check_targets$z)[2]
  #   cat("model-based optimal number of clusters: TF: ",
  #       cluster_TFs_num, ", targets: ", cluster_targets_num,
  #       "\n")
  # }
  # else if (cluster_num_method == "pamk") {
  #   dissimilarity_mat_tfs <- 1 - cor(t(m_tfs))
  #   dissimilarity_mat_targets <- 1 - cor(t(m_targets))
  #   clust_num_check_tfs <- fpc::pamk(dissimilarity_mat_tfs,
  #                                    diss = T)
  #   clust_num_check_targets <- fpc::pamk(dissimilarity_mat_targets,
  #                                        diss = T)
  #   cluster_TFs_num <- clust_num_check_tfs$nc
  #   cluster_targets_num <- clust_num_check_targets$nc
  #   cat("number of clusters estimated by optimum average silhouette width: TF: ",
  #       cluster_TFs_num, ", targets: ", cluster_targets_num,
  #       "\n")
  # }
  if (cluster_TFs) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_tfs)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_TF_cluster <- data.frame(Cluster = factor(cutree(m_hclust,
                                                                cluster_TFs_num)), row.names = row.names(m_tfs))
    m_TFs_clusters <- matrix(nrow = ncol(cds_subset),
                             ncol = cluster_TFs_num)
    for (cluster_ind in 1:cluster_TFs_num) {
      gene_inds <- annotation_TF_cluster$Cluster ==
        cluster_ind

      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_tfs[gene_inds, ])) # as.vector(t(exprs_data[row.names(annotation_TF_cluster)[gene_inds], ]))
      test <- loess(Expression ~ Pseudotime, df)
      m_TFs_clusters[, cluster_ind] <- predict(test) #
    }
    colnames(m_TFs_clusters) <- paste0("TFs_", 1:cluster_TFs_num)
  } else {
    m_TFs_clusters <- m_tfs
  }
  if (cluster_targets) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_targets)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_target_cluster <- data.frame(Cluster = factor(cutree(m_hclust,
                                                                    cluster_targets_num)), row.names = row.names(m_targets))
    m_targets_clusters <- matrix(nrow = ncol(cds_subset),
                                 ncol = cluster_targets_num)
    for (cluster_ind in 1:cluster_targets_num) {
      gene_inds <- annotation_target_cluster$Cluster ==
        cluster_ind
      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_targets[gene_inds, ])) # as.vector(t(exprs_data[gene_inds, ]))
      test <- loess(Expression ~ Pseudotime, df)

      m_targets_clusters[, cluster_ind] <- predict(test)
    }
    colnames(m_targets_clusters) <- paste0("target_",
                                           1:cluster_targets_num)
  } else {
    m_targets_clusters <- m_targets
  }
  TF_vec_names <- colnames(m_TFs_clusters)
  target_vec_names <- colnames(m_targets_clusters)
  exprs_data <- cbind(m_TFs_clusters, m_targets_clusters)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names,
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi_cpp_wrap(as.matrix(exprs_data),
                                    delays = delays, super_graph = as.matrix(all_pairwise_gene),
                                    turning_points = 0, method = 1, uniformalize = F)
  if (include_conditioning) {
    print(include_conditioning)
    cRDI_res <- calculate_conditioned_rdi_cpp_wrap(as.matrix(exprs_data),
                                                   super_graph = as.matrix(all_pairwise_gene), max_rdi_value = RDI_res$max_rdi_value,
                                                   max_rdi_delays = RDI_res$max_rdi_delays, k = 1,
                                                   uniformalize = FALSE)
  }
} else {
  cds_subset@assayData$exprs <- exprs_data
  exprs_data <- t(exprs_data)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names,
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi(cds_subset, delays = delays,
                           super_graph = all_pairwise_gene, log = FALSE)

  # cmi: I(x(t - 1), y (t) | y(t - 1) )
  current_n <- as.matrix(rvel$current[colnames(exprs_data), row.names(exprs_data)]) # valid_cells
  projected <- as.matrix(rvel$projected[colnames(exprs_data), row.names(exprs_data)]) # valid_cells

  RDI_res_velocity <- pbapply(all_pairwise_gene, 1, function(x) {
    message(x[1], '\t', x[2])
    Scribe::cmi(as.matrix(current_n[x[1] + 1, ]), as.matrix(projected[x[2] + 1, ]), as.matrix(current_n[x[2] + 1, ]), k = 10, normalize = F)$cmi_res
  })

  if (include_conditioning) {
    print(include_conditioning)
    cRDI_res <- calculate_conditioned_rdi(exprs_data,
                                          rdi_list = RDI_res)
  }
}

save.image('./RData/figSI5_RNA_velocity.RData')

chromaffin_causality_res_velocity <- cbind(all_pairwise_gene, RDI_res_velocity) # genes from the paper
colnames(chromaffin_causality_res_velocity) <- c('Var1', 'Var2', 'val')

chromaffin_adj_mat_velocity <- matrix(0, ncol = length(gene_name_ids), nrow = length(gene_name_ids))

lapply(1:length(RDI_res_velocity), function(x) {
  chromaffin_adj_mat_velocity[all_pairwise_gene[x, 1] + 1, all_pairwise_gene[x, 2] + 1] <<- RDI_res_velocity[x]
})

dimnames(chromaffin_adj_mat_velocity) <- list(row.names(current_n), row.names(current_n))

sum(chromaffin_adj_mat_velocity[TF_vec_names, TF_vec_names] > 0.05) / length(TF_vec_names) ^2
sum(chromaffin_adj_mat_velocity[TF, target_vec_names] > 0.05) / length(TF_vec_names) ^2

sum(chromaffin_clr_res2[TF_vec_names, TF_vec_names] > 0) / length(TF_vec_names) ^2
sum(chromaffin_clr_res2[TF, target_vec_names] > 0) / length(TF_vec_names) ^2
################################################################################################################################################################# 
# produce the network 
# All TFs and target hiearachical network (also the pseudotime based summary TF-target cluster network) 
################################################################################################################################################################# 

# # all the TFs; should also consider all input regulations from the targets
# chromaffin_causality_res <- cbind(all_pairwise_gene, chromaffin_cmi_res) 
# chromaffin_causality_res <- cbind(valid_all_fig_genes_pair, paper_genes_chromaffin_cmi_res) # genes from the paper 
# 
# chromaffin_adj_mat <- reshape2::dcast(chromaffin_causality_res, Var1 ~ Var2)
# gene_name <- row.names(rvel$current)[chromaffin_adj_mat[, 1] + 1]
# chromaffin_adj_mat <- chromaffin_adj_mat[, -1]
# diag(chromaffin_adj_mat) <- 0
# dimnames(chromaffin_adj_mat) <- list(gene_name, gene_name)

# plot_clr_sparsify_net(chromaffin_adj_mat, 'pseudotime_wired_clustering')
# plot_clr_sparsify_net(chromaffin_adj_mat, 'RNA_velocity_wired_no_clustering')

plot_clr_sparsify_net <- function(rdi_res, file_name, top_num = 50) {
  rdi_res[is.na(rdi_res)] <- 0 
  
  gene_name <- colnames(rdi_res)
  chromaffin_clr_res <- clr(as.matrix(rdi_res))
  
  col_means <- colMeans(rdi_res)
  col_sd <- apply(rdi_res, 2, sd)
  
  chromaffin_clr_res2_tmp <- lapply(1:nrow(rdi_res), function(x) {
    row_i <- rdi_res[x, ]
    # message(row_i)
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / sd(row_i))
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
    
    sqrt(s_i_vec^2 + s_j_vec^2)
  })
  
  chromaffin_clr_res2 <- do.call(rbind, chromaffin_clr_res2_tmp) 
  dimnames(chromaffin_clr_res2) <- list(gene_name, gene_name)
  clr_mat <- chromaffin_clr_res2
  
  # visualize TF network with the top genes 
  z_threshold <- 2
  chromaffin_clr_res2[chromaffin_clr_res2 < 6] <- 0
  
  exprs_threshold <- sort(chromaffin_clr_res2, decreasing = T)[top_num]
  chromaffin_clr_res2[chromaffin_clr_res2 < exprs_threshold] <- 0
  chromaffin_clr_res2[is.na(chromaffin_clr_res2)] <- 0
  void_genes <- which(rowSums(chromaffin_clr_res2) == 0 & colSums(chromaffin_clr_res2) == 0)
  chromaffin_clr_res2 <- chromaffin_clr_res2[-void_genes, -void_genes]
  
  g <- igraph::graph_from_adjacency_matrix(as.matrix(chromaffin_clr_res2), weighted = T, mode = "direct")
  
  # subset_g <- subgraph(g, intersect(V(g)$name, fig6a))
  pdf(paste0(SI_fig_dir, file_name, 'subset_g_chromaffin_global_network_gggraph.pdf'), height = 2, width = 2)
  print(ggraph(subset_g, layout = "linear") + 
          geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                        ends = "last", type = "open")) + 
          scale_edge_width(range = c(0.2, 2)) +
          geom_node_text(aes(label = V(subset_g)$name), check_overlap = T, size = 3,repel = T) +
          labs(edge_width = "Causality") +
          theme_graph())
  dev.off()
  
  V(g)$hubness <- -hub_score(g)$vector 
  
  pdf(paste0(SI_fig_dir, file_name, 'chromaffin_global_network_gggraph.pdf'), height = 3.8, width = 11.31)
  print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
          geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                        ends = "last", type = "open")) + 
          scale_edge_width(range = c(0.2, 2)) +
          geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
          labs(edge_width = "Causality") +
          theme_graph())
  dev.off()
  
  edge <- get.edgelist(subset_g)
  
  pdf(paste0(SI_fig_dir, file_name, 'chromaffin_subset_g_global_network_arcplot.pdf'), height = 3.8, width = 11.31)
  print(arcplot(edge, ordering=sort(unique(c(edge[, 1], edge[, 2]))), 
                horizontal=TRUE,
                #labels=paste("node",1:10,sep="-"),
                #lwd.arcs=4*runif(10,.5,2), 
                col.arcs=hsv(runif(9,0.6,0.8),alpha=0.4),
                show.nodes=TRUE, pch.nodes=21, cex.nodes=runif(10,1,3), 
                col.nodes="gray80", bg.nodes="gray90", lwd.nodes=2))  
  dev.off()
  
  return(list(clr_mat = clr_mat, threshold_mat = chromaffin_clr_res2, g = g))
}

pseudotime_clr_res <- plot_clr_sparsify_net(RDI_res$max_rdi_value, 'pseudotime_wired_no_clustering')
velocity_clr_res <- plot_clr_sparsify_net(chromaffin_adj_mat_velocity, 'velocity_pseudotime_wired_no_clustering2')

################################################################################################################################################################# 
# calcuate the correlation between networks 
################################################################################################################################################################# 
# raw network 
pseudotime_vec <- as.vector(RDI_res$max_rdi_value)
velocity_vec <- as.vector(chromaffin_adj_mat_velocity)
cor(pseudotime_vec, velocity_vec) # 0.2252083
cor(pseudotime_vec, velocity_vec, method = 'spearman')
# cor(pseudotime_vec, velocity_vec, method = 'kendall')

# processed network 
a <- as.vector(pseudotime_clr_res$clr_mat)  # threshold_mat
b <- as.vector(velocity_clr_res$clr_mat) # threshold_mat

# a <- as.vector(pseudotime_clr_res$threshold_mat)  # threshold_mat
# b <- as.vector(velocity_clr_res$threshold_mat) # threshold_mat

a[!is.finite(a)] <- 0
b[!is.finite(b)] <- 0

cor(a, b) # 0.2252083
cor(a, b, method = 'spearman')
# cor(a, b, method = 'kendall')

pseudo_velocity_df <- data.frame(Type = c("Raw", "CLR"), Correlation = c(0.512, 0.464))

pdf(paste0(SI_fig_dir, 'pseu_vel_comparison.pdf'), height = 1.2, width = 1)
ggplot(aes(Type, Correlation), data = pseudo_velocity_df) + geom_col(aes(fill = Type)) + ylim(0, 1) + nm_theme()
dev.off()

################################################################################################################################################################# 
# Enriched network motif in the TF set 
################################################################################################################################################################# 
g1 <- igraph::graph_from_adjacency_matrix(as.matrix(pseudotime_clr_res$clr_mat), weighted = T, mode = "direct")
g2 <- igraph::graph_from_adjacency_matrix(as.matrix(velocity_clr_res$clr_mat), weighted = T, mode = "direct")
motifs(g1)
motifs(g2)

base_mat <- matrix(1, nrow = 3, ncol = 3)
g16 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")
base_mat[1, 2] <- 0
g15 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[3, 1] <- 0
g14 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[3, 1] <- 1; base_mat[1, 3] <- 0
g13 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[1, 2:3] <- 1; base_mat[2:3, 1] <- 0; 
g12 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[1, 3] <- 0; base_mat[3, 1] <- 1
g11 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[3, 2] <- 0; base_mat[2, 1] <- 0; base_mat[3, 1] <- 1; 
g10 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[1, 2] <- 0; base_mat[2, 1] <- 1; 
g9 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[2, 1] <- 0; base_mat[3, 2] <- 1; 
g8 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat[1, 3] <- 1; base_mat[3, 1] <- 0; 
g7 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3); base_mat[2, 1] <- 1; base_mat[1, 3] <- 1
g6 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3); base_mat[2:3, 1] <- 1;
g5 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3); base_mat[1, 2:3] <- 1; 
g4 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3); base_mat[2, 1] <- 1; base_mat[1, 2] <- 1
g3 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3); base_mat[2, 1] <- 1
g2 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

base_mat <- matrix(0, nrow = 3, ncol = 3)
g1 <- igraph::graph_from_adjacency_matrix(base_mat, weighted = T, mode = "direct")

pattern <- graph.full(3)
my.graph <- pseudotime_clr_res$g       # just an example graph, use yours
iso <- subgraph_isomorphisms(pattern, my.graph)      # takes a while
motifs <- lapply(iso, function (x) { induced_subgraph(my.graph, x) })

pattern <- graph.full(3)
my.graph <- grg.game(100, 0.2)        # just an example graph, use yours
iso <- subgraph_isomorphisms(pattern, my.graph)      # takes a while
motifs <- lapply(iso, function (x) { induced_subgraph(my.graph, x) })

################################################################################################################################################################# 
# save the data 
################################################################################################################################################################# 

save.image('./RData/figSI5_RNA_velocity.RData')


