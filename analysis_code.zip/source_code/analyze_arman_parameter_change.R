# analyze the relationship between parameters in RDI and the result 
library(reshape2)
library(stringr)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

AUC_res2 <- read.csv('./csv_data/arman_parameter_change', row.names = 1) #param_sim
AUC_res2_mlt <- melt(AUC_res2)
AUC_res2_mlt$type <- row.names(AUC_res2)

repeats_time_tmp <- str_split_fixed(AUC_res2_mlt$variable, '.', 2)[, 2]
repeats_time <- str_split_fixed(repeats_time_tmp, '\\.', 2)
AUC_res2_mlt$Repeat <- as.numeric(repeats_time[, 1])
AUC_res2_mlt$Run <- as.numeric(repeats_time[, 2])

AUC_res2_mlt$Run <- factor(AUC_res2_mlt$Run, levels = c("20", "40", "60", "80", "120", "200", "300", "400"))
  
pdf(paste0(SI_fig_dir, 'Arman_run.pdf'), width =  1.5, height = 1)
ggplot(aes(Run, value), data = subset(AUC_res2_mlt, type %in% c('RDI', "cRDI"))) + #geom_point(aes(color = type), size = I(0.5)) + 
  geom_boxplot(aes(color = type), size = I(0.5)) + ylab('AUC') + xlab('Terminal time point') + 
  ylim(0, 1) + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))
dev.off()

pdf(paste0(SI_fig_dir, 'Arman_run.pdf'), width =  1.5, height = 1)
ggplot(aes(as.numeric(Run), value), data = subset(AUC_res2_mlt, type %in% c('RDI', "cRDI") & Repeat != '5')) + #geom_point(aes(color = type), size = I(0.5)) + 
  geom_line(aes(color = type), size = I(0.5)) + ylab('AUC') + xlab('Terminal time point') + facet_wrap(~ Repeat) + 
  ylim(0, 1) + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))
dev.off()

#######################################################################################################################################
# get the result for the other analysis 
#######################################################################################################################################







