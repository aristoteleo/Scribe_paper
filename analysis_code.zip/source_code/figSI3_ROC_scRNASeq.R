# Figure SI3 (ROC curves for different scRNA-seq dataset)
# need to add benchmark for cRDI, uRDI, ucRDI
###############################################################################################################################################################################################
# load packages
###############################################################################################################################################################################################
rm(list = ls())

library(monocle)
library(Scribe)
library(plyr)
library(destiny)
library(igraph)
library(DESeq2)
library(DESeq)
library(stringr)
library(reshape2)
library(rEDM)
library(lmtest)

source("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R", echo = T)

smoothing <- FALSE
##################################################################################################################################################################################################################
# run ROC curve analysis:
##################################################################################################################################################################################################################
library(ROCR)

generate_roc_df <-function(p_value, classification, type = 'fpr') {
  p_value[is.na(p_value)] <- 1
  pred_p_value <- prediction(p_value, classification)
  perf_tpr_fpr <- performance(pred_p_value, "tpr", "fpr")

  fpr = perf_tpr_fpr@x.values

  tpr = perf_tpr_fpr@y.values

  perf_auc <- performance(pred_p_value, "auc")
  auc <- perf_auc@y.values

  data.frame(tpr = tpr, fpr = fpr, auc = auc)
}

# cRDI_roc_df_list <- lapply(colnames(lung_pval_df), function(x) {
#   print(x)
#
#   perm_pvals <- permutation_lung_pval_df[select_genes, 3] #use the spike-in as the gold standard
#   software_pvals <- lung_pval_df[select_genes, x]
#
#   perm_pvals[is.na(perm_pvals)] <- 1
#   software_pvals[is.na(software_pvals)] <- 1
#   res <- generate_roc_df(software_pvals, perm_pvals > p_thrsld)
#   colnames(res) <- c('tpr', 'fpr', 'auc')
#   cbind(res, method = x)
# })

# ###############################################################################################################################################################################################
# # network for the lung dataset (lung don't really have a network from biological evidence, skip for now)
# ###############################################################################################################################################################################################
# load('/Users/xqiu/Dropbox (Personal)/Projects/BEAM/RData/gen_lung_figures.RData') # sig_TFs_motif_enriched
# load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/tmp/absolute_cds')
#
# absolute_cds <- setOrderingFilter(absolute_cds, quake_id)
# absolute_cds <- reduceDimension(absolute_cds, ncenter = NULL, verbose = T)
# absolute_cds <- orderCells(absolute_cds)
# plot_cell_trajectory(absolute_cds)
# plot_cell_trajectory(absolute_cds, color_by = 'Time')
# plot_cell_trajectory(absolute_cds, color_by = 'Pseudotime')
# absolute_cds <- orderCells(absolute_cds, root_state = 3)
# plot_cell_trajectory(absolute_cds, color_by = 'Pseudotime')
#
# beam_res <- BEAM(absolute_cds, cores = detectCores() - 2)  # run BEAM analysis
# BEAM_genes <- as.character(subset(beam_res, qval < 1e-1)$gene_short_name)
#
# AT1_lung <- absolute_cds[, pData(absolute_cds)$State %in% c(2, 3)]
# AT2_lung <- absolute_cds[, pData(absolute_cds)$State %in% c(1, 3)] # adult AT2 cells
#
# AT1_dpt_res <- run_new_dpt(AT1_lung)
# AT2_dpt_res <- run_new_dpt(AT2_lung)
#
# valid_gene_ids <- row.names(subset(beam_res, qval < 1e-1))
# lung_exprs_AT1 <- as.matrix(t(exprs(AT1_lung)[valid_gene_ids, order(AT1_dpt_res$pt)])) # pData(AT2_lung)$Pseudotime
# lung_exprs_AT2 <- as.matrix(t(exprs(AT2_lung)[valid_gene_ids, order(AT2_dpt_res$pt)])) #
#
# split_names <- str_split_fixed(names(lung_TF_5k_enrichment_gsc$gsc), "::", 3)
# all_motif_names <- setdiff(unique(c(split_names[, 1], split_names[, 2], split_names[, 3])), "")
# motif_TFs <- c("ELF1", "EWSR1", "FLI1", "RAR", "BACH1", "STAT5A", "PPARG", "STAT5B", "SOX2", "TCFE2A", "RXR", "ARNT", "GATA1", "NR1H2", "BATF", "VDR", "MAX", "TAL1", "FOS", "HAND1", "POU5F1", "TCF3", "MYC", "TLX1", "NR1H3", "CEBPA", "MAF", "NFE2", "RXRA", "SMAD4", "SMAD3", "SMAD2", "MAFK", "STAT1", "DDIT3", "STAT2", "HIF1A", "JUN", "NFIC",  "HSF1", "RFX1", "SPI1", "MEF2C", "MYOD1", "MEF2A", "CDX2", "FOXO1", "TBP", "RORA", "REST", "NR2E3", "FOXO3", "GATA1", "GATA2", "ATOH1", "HOXC9", "FLI1", "GATA3", "GATA4", "FOXF2", "RREB1", "YY1", "RELA", "RXRA", "GABPA", "HNF4G", "MECOM", "JUNB", "HNF4A", "JUN", "TFAP2A", "NFE2L2", "PRDM1", "TFAP2C", "SOX3", "SOX2", "ELK1", "SOX6", "SOX9", "SRF", "MEIS1", "NR2C2", "FOXH1", "SRY", "T", "FOXQ1", "HOXA5", "ELK4", "LHX3", "JUND", "NKX3-2", "HOXA9", "NKX3-1", "BHLHE40", "RUNX1", "DUX4", "NKX2-5", "RUNX2", "TCF3", "PLAG1", "SREBF1", "KLF5", "MAFF", "ESRRA", "ESRRB", "RFX5", "MAFB", "FOXA1", "NR4A2", "TEAD1", "EN1", "MAFK", "USF1", "FOXP1", "BRCA1", "USF2", "FOXP2", "SREBF2", "NRF1", "ETS1", "EBF1", "RFX1", "MZF1", "RFX2", "KLF1", "FOXI1", "TCF12", "KLF4", "E2F1", "HLF", "ZBTB33", "HNF1B", "E2F3", "ELF1", "FOSL2", "HNF1A", "E2F4", "FOXA2", "E2F6", "ELF5", "PPARG", "PAX6", "SPI1", "PAX5", "TP63", "PAX4", "NFKB1", "CTCF", "ZEB1", "PAX2", "FEV", "CRX", "FOS", "MAX", "GFI1B", "HSF1", "NOBOX", "SPIB", "SOX17", "NFIL3", "MYB", "FOSL1", "MYC", "NR2F1", "EGR1", "ZFP423", "AR", "EGR2", "ZFX", "ESR1", "TP53", "ESR2", "ZNF143", "HLTF", "MYCN", "FOXC1", "SPZ1", "NFYB", "EHF", "NFYA", "NR3C1", "TCF7L2", "TCFCP2L1", "STAT6", "STAT4", "REL", "POU2F2", "HINFP", "BCL6", "MYOG", "THAP1", "GFI1", "NFATC2", "FOXD1", "FOXD3", "CEBPA", "INSM1", "ZNF263", "ERG", "CEBPB", "FOXL1", "CREB1", "STAT1", "STAT3", "SP1", "SP2", "IRF1", "IRF2", "PBX1", "NR5A2", "NHLH1")
# motif_TFs_add <- c("RARA", "E2A", "TRP63", "TRP53", "ZFP143", "TFCP2L1")
#
# uniq_motif <- unique(c(motif_TFs, motif_TFs_add))
#
# # significant TFs and knonw TFs:
# sig_TFs_motif_enriched <- intersect(toupper(BEAM_genes), uniq_motif)# c("Cebpa", "Foxp2", "Klf5", "Tcf7l2", "Elf1", "Fos", "Fosl", "Foxp2", "Klf5", "Nr3c1", "Rreb1", "Tcf3", "Tead1", "Zfx")
# sort(sig_TFs_motif_enriched)
#
# known_TFs <- c("Foxa2", "Gata6", "Hopx", "Nkx2-1", "Sox9")
#
# all_genes <- sort(unique(c(sig_TFs_motif_enriched, known_TFs)))
#
# setdiff(all_genes, c("Hopx", "Nkx2-1", "Fosl"))
# # BEAM target genes:
#
# fData(absolute_cds)$gene_short_name <- as.character(fData(absolute_cds)$gene_short_name)
# fData(AT1_lung)$gene_short_name <- toupper(fData(AT1_lung)$gene_short_name)
#
# super_graph <- create_super_graph(AT1_lung[valid_gene_ids, ], TFs = sig_TFs_motif_enriched, informative_genes = toupper(BEAM_genes))
# super_graph[, 1] <- match(super_graph[, 1], colnames(lung_exprs_AT1))
# super_graph[, 2] <- match(super_graph[, 2], colnames(lung_exprs_AT1))
# super_graph <- super_graph - 1
#
# AT1_lung_list <- calculate_rdi_cpp_wrap(as.matrix(lung_exprs_AT1), delays = c(2, 5, 10, 15), turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)
# AT2_lung_list <- calculate_rdi_cpp_wrap(as.matrix(lung_exprs_AT2), delays = c(2, 5, 10, 15), turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)
#
# save(file = './RData/AT12_lung_rdi_res.RData', AT1_lung_list, AT2_lung_list)
# ###############################################################################################################################################################################################
# # calculate the ROC curves / AUC
# ###############################################################################################################################################################################################
# # RDI_roc <- generate_roc_df(p_value, classification, type = 'fpr')
# # granger_roc <- generate_roc_df(p_value, classification, type = 'fpr')
# # ccm_roc <- generate_roc_df(p_value, classification, type = 'fpr')
#
# # plot the results
# p_thrsld <- 0
# all_cmbns <- super_graph + 1
# valid_all_cmbns_df <- data.frame(pair = paste(tolower(rownames(AT1_lung)[all_cmbns[, 1]]), tolower(rownames(AT1_lung)[all_cmbns[, 2]]), sep = '_'), pval = 0)
# row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
# # identify interaction from the motif-scan result
# lapply(names(lung_TF_5k_enrichment_gsc$gsc), function(x) {
#   x_split <- str_split_fixed(x, "::", 3)
#   source_id <- row.names(AT1_lung)[unlist(lapply(setdiff(x_split, ""), function(x) which(toupper(fData(AT1_lung)$gene_short_name) == x)))]
#
#   targets <- lung_TF_5k_enrichment_gsc$gsc[[x]]
#   targets_id <- row.names(subset(fData(AT1_lung), gene_short_name %in% toupper(targets)))
#   levels(fData(AT1_lung)$gene_short_name) %in% toupper(targets)
#   row.names(subset(fData(AT1_lung), gene_short_name %in% toupper(targets)))
#
#   cmbn_res <- expand.grid(source_id, targets_id)
#   valid_ind <- intersect(paste0(tolower(cmbn_res[, 1]), "_", tolower(cmbn_res[, 2])), row.names(valid_all_cmbns_df))
#
#   if(length(source_id)) {
#     # message('x is ', x)
#     # message('source_id is ', source_id)
#   }
#
#   if(length(valid_ind) > 0) {
#     message('valid_ind is ', valid_ind)
#     valid_all_cmbns_df[valid_ind, 'pval'] <<- 1
#   }
#
# })
#
# # valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1
#
# rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = valid_all_cmbns_df) {
#   rdi_pvals <- network_result_df[, x]
#
#   rdi_pvals[is.na(rdi_pvals)] <- 0
#   reference_network_pvals[is.na(reference_network_pvals)] <- 0
#   rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
#   res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
#   colnames(res) <- c('tpr', 'fpr', 'auc')
#   cbind(res, method = x)
# })
#
# rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
# rdi_roc_df <- do.call(rbind, rdi_roc_df_list)
#
# qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
#   xlab("False positive rate") +
#   ylab("True positive rate") +
#   ylim(c(0, 1.0)) + geom_abline(color = 'red') +
#   facet_wrap(~method) +
#   #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
#   xlim(c(0, 1.0))
#
# uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])
#
# ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
#   xlab("") + ylim(0, 1)
#
# ###############################################################################################################################################################################################
# # just show the network for the branched TFs
# ###############################################################################################################################################################################################
# AT1_max_rdi_res <- AT1_lung_list$max_rdi_value[, ]
# AT2_max_rdi_res <- AT2_lung_list$max_rdi_value[, ]
#
# clr_AT1_max_rdi_res <- apply(AT1_max_rdi_res, 1, function(x) {
#   if(any(x > 0)) {
#     x <- max(0, c(x - mean(x)) / sd(x))
#   }
#   x
# })
# clr_AT1_max_rdi_res <- do.call(rbind, clr_AT1_max_rdi_res)
# clr_AT2_max_rdi_res <- apply(AT2_max_rdi_res, 1, function(x) {
#   if(any(x > 0)) {
#     x <- max(0, c(x - mean(x)) / sd(x))
#   }
#   x
# })
# clr_AT2_max_rdi_res <- do.call(rbind, clr_AT2_max_rdi_res)
#
# dimnames(clr_AT1_max_rdi_res) <- list(colnames(lung_exprs_AT2), colnames(lung_exprs_AT2))
# dimnames(clr_AT2_max_rdi_res) <- list(colnames(lung_exprs_AT2), colnames(lung_exprs_AT2))
#
# dimnames(AT1_max_rdi_res) <- list(colnames(lung_exprs_AT2), colnames(lung_exprs_AT2))
# dimnames(AT2_max_rdi_res) <- list(colnames(lung_exprs_AT2), colnames(lung_exprs_AT2))
#
# # only visualize the true network
# sig_TFs_motif_enriched_id <- row.names(subset(fData(AT1_lung), toupper(gene_short_name) %in% sig_TFs_motif_enriched))
#
# clr_AT1_max_rdi_res <- apply(AT1_max_rdi_res[sig_TFs_motif_enriched_id, sig_TFs_motif_enriched_id], 1, function(x) {
#   if(any(x > 0)) {
#     x <- pmax(0, c(x - mean(x)) / sd(x))
#   }
#   x
# })
#
# clr_AT2_max_rdi_res <- apply(AT2_max_rdi_res[sig_TFs_motif_enriched_id, sig_TFs_motif_enriched_id], 1, function(x) {
#   if(any(x > 0)) {
#     x <- pmax(0, c(x - mean(x)) / sd(x))
#   }
#   x
# })
#
# dimnames(clr_AT1_max_rdi_res) <- list(sig_TFs_motif_enriched, sig_TFs_motif_enriched)
# dimnames(clr_AT2_max_rdi_res) <- list(sig_TFs_motif_enriched, sig_TFs_motif_enriched)
#
# # visualize TF network with the top genes
# z_threshold <- 1
# clr_AT1_max_rdi_res[clr_AT1_max_rdi_res < z_threshold] <- 0
# g <- igraph::graph_from_adjacency_matrix(as.matrix(clr_AT1_max_rdi_res), weighted = T, mode = "direct")
#
# clr_AT2_max_rdi_res[clr_AT2_max_rdi_res < z_threshold] <- 0
# g <- igraph::graph_from_adjacency_matrix(as.matrix(clr_AT2_max_rdi_res), weighted = T, mode = "direct")
#
# pdf('./Figures/main_figures/lung_global_network_gggraph.pdf', height = 2, width = 2)
# ggraph(g , layout = "linear") +
#   geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
#                                                                 ends = "last", type = "open")) +
#   scale_edge_width(range = c(0.2, 2)) +
#   geom_node_text(aes(label = V(g )$name), check_overlap = T, size = 3,repel = T) +
#   labs(edge_width = "Causality") +
#   theme_graph()
# dev.off()

##################################################################################################################################################################################################################
# LPS data
##################################################################################################################################################################################################################
load("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/fstree_ddrtree/RData/analysis_shalek_data.RData")

pd <- new("AnnotatedDataFrame", data = pData(Shalek_abs_subset_ko_LPS))
fd <- new("AnnotatedDataFrame", data = fData(Shalek_abs_subset_ko_LPS))
Shalek_abs_subset_ko_LPS <- newCellDataSet(as.matrix(Shalek_abs_subset_ko_LPS),
                                           phenoData = pd,
                                           featureData = fd,
                                           expressionFamily=negbinomial.size(),
                                           lowerDetectionLimit=1)

#Calculate size factors and dispersions
Shalek_abs_subset_ko_LPS = estimateSizeFactors(Shalek_abs_subset_ko_LPS)
Shalek_abs_subset_ko_LPS = estimateDispersions(Shalek_abs_subset_ko_LPS)

Shalek_abs_LPS <- Shalek_abs_subset_ko_LPS[, pData(Shalek_abs_subset_ko_LPS)$experiment_name %in% c('LPS', "Unstimulated_Replicate")]

################################################################################################################################################################
# reconstruct the trajectory
################################################################################################################################################################
Shalek_abs_LPS <- monocle::reduceDimension(Shalek_abs_LPS, verbose = T, ncenter = NULL)
Shalek_abs_LPS <- orderCells(Shalek_abs_LPS)

plot_cell_trajectory(Shalek_abs_LPS, color_by = 'experiment_name')
plot_cell_trajectory(Shalek_abs_LPS, color_by = 'State')
plot_cell_trajectory(Shalek_abs_LPS, color_by = 'Pseudotime')
Shalek_abs_LPS <- orderCells(Shalek_abs_LPS, reverse = T)
plot_cell_trajectory(Shalek_abs_LPS, color_by = 'Pseudotime')

Shalek_abs_LPS_dpt_res <- run_new_dpt(Shalek_abs_LPS, norm_method = 'log')
pData(Shalek_abs_LPS)$pt <- Shalek_abs_LPS_dpt_res$pt
plot_cell_trajectory(Shalek_abs_LPS, color_by = 'pt')

cor(pData(Shalek_abs_LPS)$pt, pData(Shalek_abs_LPS)$Pseudotime, method = 'spearman')
#
# ################################################################################################################################################################
# # save the dataset
# ################################################################################################################################################################
# grn_fig4a <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Rbl1", "Usp25", "Daxx", "Cd40", "Atm", "Irf1", "Ligp2", "Mertk", "Cxcl11", "Trim12a", "Trim21", "NfkbIz")
# grn_fig4b <- c("NFKBIZ", "ATF4", "ATF4", "Ilf2b", "FUS", "RBL1", "RBL1", "ligp1", "CBX4", "DNMT3A", "DNMT3A", "Ifnb1", "NFKBIZ", "FOS", "FOS", "Il12b", "JUN", "FUS", "FUS", "IFNB1", "FUS", "NFkbIz", "NFKBIZ", "FOS", "CBX4", "STAT1", "STAT1", "IFnb1", "CEBPZ", "HHEX", "HHEX", "IL12b")
# grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")
#
# grn_all_genes <- c(grn_fig4a, grn_fig4b, grn_fig4c)
# LPS_network <- read.table('./csv_data/LPS_network', header = T)
#
# grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_all_genes)))
# missing_genes <- grn_all_genes[!(toupper(grn_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]
#
# all_network_genes <- c(as.character(LPS_network$Source), as.character(LPS_network$Target))
# network_missing_genes <- all_network_genes[!(toupper(c(all_network_genes)) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]
#
# top_group <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "FUS")
# bottom_group <- c("Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Usp25", "Daxx", "Cd40", "Atm", "Lrf1", "Lgp2", "Mertk", "Cxcl11", "Trim12", "Trim21")
#
# top_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(top_group)))
# fData(Shalek_abs_subset_ko_LPS)[grn_ids, 'gene_short_name']
# bottom_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(bottom_group)))
# fData(Shalek_abs_subset_ko_LPS)[bottom_group_ids, 'gene_short_name']
#
# # order_LPS_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
# # pd <- pData(Shalek_abs_subset_LPS[grn_ids, colnames(order_LPS_mat)])
# # fd <- fData(Shalek_abs_subset_LPS[grn_ids, ])
#
# # write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
# # write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_phenotype_data.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
# # write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data.txt', order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)
#
# grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV8", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")
# fig4c_layer1 <- c("Tlr2", "Tlr3", "Tlr4")
# fig4c_layer2.1 <- c("STAT1", "STAT2", "IRF8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1")
# fig4c_layer2.2 <- c("PLAGL2", "NFKB1", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2")
# fig4c_layer3.1 <- c("HMGN3", "FUS", "SAP30")
# fig4c_layer3.2 <- c("NFE2L2", "IRF4", "FOS")
# fig4c_layer4.1 <- c("CXCL10", "Ifnb1", "IL15")
# fig4c_layer4.2 <- c("IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3")
#
# #only the small network:
# LPS_subset_network <- read.table('./csv_data/LPS_subset_network', header = T)
# #
# # grn_subset_all_genes <- c(as.character(LPS_subset_network$Source), as.character(LPS_subset_network$Target))
# # subset_grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_subset_all_genes)))
# # missing_genes <- grn_subset_all_genes[!(toupper(grn_subset_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]
# #
# # order_LPS_subset_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[subset_grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
# # write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_LPS_subset_mat.txt', order_LPS_subset_mat, col.names = T, sep = '\t', row.names = T, quote = F)
# #
# # fData(Shalek_abs_LPS)$gene_short_name <- as.character(fData(Shalek_abs_LPS)$gene_short_name)
#
# valid_gene_ids <- row.names(subset(fData(Shalek_abs_LPS), toupper(gene_short_name) %in% toupper(grn_all_genes)))
#
# super_graph <- create_super_graph(Shalek_abs_LPS[valid_gene_ids, ]) #  TFs = sig_TFs_motif_enriched, informative_genes = toupper(BEAM_genes)
# super_graph[, 1] <- match(super_graph[, 1], row.names(Shalek_abs_LPS[valid_gene_ids, ]))
# super_graph[, 2] <- match(super_graph[, 2], row.names(Shalek_abs_LPS[valid_gene_ids, ]))
# super_graph <- super_graph - 1
#
# Shalek_abs_LPS_exprs <- t(as.matrix(exprs(Shalek_abs_LPS)[valid_gene_ids, order(pData(Shalek_abs_LPS)$Pseudotime)]))
# # also add smoothing
# for(i in 1:ncol(Shalek_abs_LPS_exprs)) {
#   df <- data.frame(Pseudotime = 1:nrow(Shalek_abs_LPS_exprs), Expression = Shalek_abs_LPS_exprs[, i])
#   test <- loess(Expression ~ Pseudotime, df)
#   Shalek_abs_LPS_exprs[, i] <-  predict(test)
# }
# # Shalek_abs_LPS_exprs <- smooth_gene(Shalek_abs_LPS_exprs, window_size = 20)
#
# Shalek_abs_LPS_list <- calculate_rdi_cpp_wrap(as.matrix(Shalek_abs_LPS_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
#                                               turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)
#
# LPS_max_rdi_res <- Shalek_abs_LPS_list$max_rdi_value
# gene_name <- as.character(fData(Shalek_abs_LPS[valid_gene_ids, ])$gene_short_name)
# dimnames(LPS_max_rdi_res) <- list(gene_name, gene_name)
#
# col_means <- colMeans(LPS_max_rdi_res)
# col_sd <- apply(LPS_max_rdi_res, 2, sd)
#
# LPS_max_rdi_res <- as.matrix(LPS_max_rdi_res)
# LPS_max_rdi_res_tmp <- lapply(1:nrow(LPS_max_rdi_res), function(x) {
#   row_i <- LPS_max_rdi_res[x, ]
#   message(row_i)
#   s_i_vec <- pmax(0, (row_i - mean(row_i)) / sd(row_i))
#   s_j_vec <- pmax(0, (row_i - col_means)/ col_sd)
#
#   sqrt(s_i_vec^2 + s_j_vec^2)
# })
#
# LPS_max_rdi_res2 <- do.call(rbind, LPS_max_rdi_res_tmp)
# dimnames(LPS_max_rdi_res2) <- list(gene_name, gene_name)
# # visualize TF network with the top genes
# z_threshold <- 3
# LPS_max_rdi_res2[LPS_max_rdi_res2 < z_threshold] <- 0
# g <- igraph::graph_from_adjacency_matrix(as.matrix(LPS_max_rdi_res2), weighted = T, mode = "direct")
#
# V(g)$hubness <- -hub_score(g)$vector
# pdf('./Figures/main_figures/LPS_global_network_gggraph.pdf', height = 2, width = 2)
# # print(ggraph(g , layout = "linear", sort.by = "hubness") +
# #   geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
# #                                                                 ends = "last", type = "open")) +
# #   scale_edge_width(range = c(0.2, 2)) +
# #   geom_node_text(aes(label = V(g )$name), check_overlap = T, size = 3,repel = T) +
# #   labs(edge_width = "Causality") +
# #   theme_graph())
# dev.off()

################################################################################################################################################################
# use the new network
################################################################################################################################################################
TF_hiearchy <- read.table('./csv_data/TF_hiearchy.txt', header = T, row.names = 1)

gene_names <- colnames(TF_hiearchy)
valid_gene_ids <- row.names(subset(fData(Shalek_abs_LPS), gene_short_name %in% gene_names))
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(row.names(subset(fData(Shalek_abs_LPS), gene_short_name %in% gene_id1))),
                     Gene_1_NAME = c(gene_id1), Gene_2_ID = c(row.names(subset(fData(Shalek_abs_LPS), gene_short_name %in% gene_id2))),
                     Gene_2_NAME = c(gene_id2), delay_max = NA,
                     HT_seq = TF_hiearchy[gene_id1, gene_id2] )
    write.table(file = 'TF_hiearchy_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

Shalek_abs_LPS_exprs <- t(as.matrix(exprs(Shalek_abs_LPS)[valid_gene_ids, order(pData(Shalek_abs_LPS)$Pseudotime)]))
Shalek_abs_LPS_exprs_gene_name <- colnames(Shalek_abs_LPS_exprs)

# valid_gene_ids <- row.names(subset(fData(Shalek_abs_LPS), toupper(gene_short_name) %in% toupper(grn_all_genes)))

super_graph <- create_super_graph(Shalek_abs_LPS[valid_gene_ids, ]) #  TFs = sig_TFs_motif_enriched, informative_genes = toupper(BEAM_genes)
super_graph[, 1] <- match(super_graph[, 1], row.names(Shalek_abs_LPS[valid_gene_ids, ]))
super_graph[, 2] <- match(super_graph[, 2], row.names(Shalek_abs_LPS[valid_gene_ids, ]))
super_graph <- super_graph - 1

if(smoothing) {
  # Shalek_abs_LPS_exprs <- t(as.matrix(exprs(Shalek_abs_LPS)[valid_gene_ids, order(pData(Shalek_abs_LPS)$Pseudotime)]))
  # also add smoothing
  for(i in 1:ncol(Shalek_abs_LPS_exprs)) {
    df <- data.frame(Pseudotime = 1:nrow(Shalek_abs_LPS_exprs), Expression = Shalek_abs_LPS_exprs[, i])
    test <- loess(Expression ~ Pseudotime, df)
    Shalek_abs_LPS_exprs[, i] <-  predict(test)
  }
  # Shalek_abs_LPS_exprs <- smooth_gene(Shalek_abs_LPS_exprs, window_size = 20)
  colnames(Shalek_abs_LPS_exprs) <- Shalek_abs_LPS_exprs_gene_name
}

Shalek_abs_LPS_list <- calculate_rdi_cpp_wrap(as.matrix(Shalek_abs_LPS_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                              turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)

# crdi, urdi, ucrdi: 
Shalek_abs_LPS_list_crdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Shalek_abs_LPS_exprs), as.matrix(super_graph),
                                                               as.matrix(Shalek_abs_LPS_list$max_rdi_value), as.matrix(Shalek_abs_LPS_list$max_rdi_delays), 1, uniformalize = F)

Shalek_abs_LPS_list_urdi <- calculate_rdi_cpp_wrap(as.matrix(Shalek_abs_LPS_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                                   turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = T)
Shalek_abs_LPS_list_ucrdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Shalek_abs_LPS_exprs), as.matrix(super_graph),
                                                                Shalek_abs_LPS_list_urdi$max_rdi_value, Shalek_abs_LPS_list_urdi$max_rdi_delays, 1, uniformalize = T)

LPS_max_rdi_res <- Shalek_abs_LPS_list$max_rdi_value
gene_name <- as.character(fData(Shalek_abs_LPS[valid_gene_ids, ])$gene_short_name)
dimnames(LPS_max_rdi_res) <- list(gene_name, gene_name)

LPS_max_rdi_res2 <- clr_directed_R(LPS_max_rdi_res)
LPS_max_crdi_res2 <- clr_directed_R(Shalek_abs_LPS_list_crdi); dimnames(LPS_max_crdi_res2) <- dimnames(LPS_max_rdi_res2)
LPS_max_urdi_res2 <- clr_directed_R(Shalek_abs_LPS_list_urdi$max_rdi_value); dimnames(LPS_max_urdi_res2) <- dimnames(LPS_max_rdi_res2)
LPS_max_ucrdi_res2 <- clr_directed_R(Shalek_abs_LPS_list_ucrdi); dimnames(Shalek_abs_LPS_list_ucrdi) <- dimnames(LPS_max_rdi_res2)

# visualize TF network with the top genes
z_threshold <- 0
LPS_max_rdi_res2[LPS_max_rdi_res2 < z_threshold] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(LPS_max_rdi_res2), weighted = T, mode = "direct")

V(g)$hubness <- -hub_score(g)$vector
pdf('./Figures/main_figures/LPS_global_network_gggraph.pdf', height = 2, width = 2)
# print(ggraph(g , layout = "linear", sort.by = "hubness") +
#         geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
#                                                                       ends = "last", type = "open")) +
#         scale_edge_width(range = c(0.2, 2)) +
#         geom_node_text(aes(label = V(g )$name), check_overlap = T, size = 3,repel = T) +
#         labs(edge_width = "Causality") +
#         theme_graph())
dev.off()
# fd <- fData(Shalek_abs_LPS[gene_ids, ])
#
# write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
# write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_order_LPS_mat.txt', ht_chip_order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)

################################################################################################################################################################
# run CCM and granger causality
################################################################################################################################################################
# order_LPS_mat <- read.table('LPS_data.txt', header = T, row.names = 1)

order_LPS_mat_t <- Shalek_abs_LPS_exprs
if(smoothing) {
  for(i in 1:ncol(order_LPS_mat_t)) {
    df <- data.frame(Pseudotime = 1:nrow(order_LPS_mat_t), Expression = order_LPS_mat_t[, i])
    test <- loess(Expression ~ Pseudotime, df)
    order_LPS_mat_t[, i] <-  predict(test)
  }
}

# order_LPS_mat_t_smooth <- move_avg_f(order_LPS_mat_t, window_size = 20)

order_LPS_mat_t_smooth <- order_LPS_mat_t
colnames(order_LPS_mat_t_smooth) <- Shalek_abs_LPS_exprs_gene_name

#run CCM
LPS_parallel_res <- parallelCCM(ordered_exprs_mat = order_LPS_mat_t_smooth, cores = detectCores() - 2)
LPS_parallel_res_mat <- prepare_ccm_res(LPS_parallel_res)

gene_names <- as.character(fData(Shalek_abs_LPS[row.names(LPS_parallel_res_mat), ])$gene_short_name)
dimnames(LPS_parallel_res_mat) <- list(gene_names, gene_names)

# for(gene_id1 in gene_names) {
#   for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
#     df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(fData(Shalek_std[gene_id1, ])$gene_short_name),
#                      Gene_2_ID = c(gene_id2), Gene_2_NAME = c(fData(Shalek_std[gene_id2, ])$gene_short_name), delay_max = NA,
#                      ccm = LPS_parallel_res_mat[gene_id1, gene_id2] )
#     write.table(file = 'LPS_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
#   }
# }

#run granger causality:
order_LPS_mat_t_smooth_granger_res <- parallel_cal_grangertest(order_LPS_mat_t_smooth[, ], filename = 'order_LPS_mat_t_smooth_granger_res', delays = c(1, 20, 41), smooth = F)
LPS_max_rdi_res
order_LPS_mat_t_smooth_granger_res <- do.call(rbind.data.frame, order_LPS_mat_t_smooth_granger_res)

LPS_granger_mat <- dcast(order_LPS_mat_t_smooth_granger_res[, c(1, 3, 6)], formula = Gene_1_ID ~ Gene_2_ID)
row.names(LPS_granger_mat) <- LPS_granger_mat[, 1]
LPS_granger_mat <- LPS_granger_mat[, -1]
diag(LPS_granger_mat) <- 0

gene_names <- as.character(fData(Shalek_abs_LPS[row.names(LPS_granger_mat), ])$gene_short_name)
dimnames(LPS_granger_mat) <- list(gene_names, gene_names)

################################################################################################################################################################
# show the ROC curve for the dataset
################################################################################################################################################################
Shalek_abs_LPS[valid_gene_ids, ]

super_graph_gene_name <- super_graph + 1
super_graph_gene_name[, 1] <- as.character(fData(Shalek_abs_LPS[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 1]]
super_graph_gene_name[, 2] <- as.character(fData(Shalek_abs_LPS[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 2]]

# RDI_roc <- generate_roc_df(p_value, classification, type = 'fpr')
# granger_roc <- generate_roc_df(p_value, classification, type = 'fpr')
# ccm_roc <- generate_roc_df(p_value, classification, type = 'fpr')

# plot the results
p_thrsld <- 0
valid_all_cmbns_df <- data.frame(pair = paste(super_graph_gene_name[, 1], super_graph_gene_name[, 2], sep = '_'), pval = 0)

row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair

# # identify interaction from the motif-scan result
# uniq_genes <- unique(c(super_graph_gene_name[, 1], super_graph_gene_name[, 2]))
# apply(LPS_network, 1, function(x) {
#   x <- tools::toTitleCase(tolower(as.character(x[1:2])))
#   valid_ind <- paste0(x[1], '_', x[2])
#
#   message('valid_ind is ', valid_ind)
#   if(all(x[1:2] %in% uniq_genes)) {
#     valid_all_cmbns_df[valid_ind, 'pval'] <<- 1
#   }
# })

network_result_df <- melt(LPS_max_rdi_res) # LPS_max_rdi_res2
row.names(network_result_df) <- paste0(network_result_df[, 1], '_', network_result_df[, 2])
# network_result_df <- network_result_df[row.names(reference_network_pvals_df), ]
# network_result_df <- data.frame(RDI = network_result_df[, 3], row.names = row.names(network_result_df))

# reference_network_pvals_df <- data.frame(pval = valid_all_cmbns_df[, 2], row.names = row.names(valid_all_cmbns_df))

# TF_hiearchy:
reference_network_pvals_df <- melt(as.matrix(TF_hiearchy))
row.names(reference_network_pvals_df) <- paste0(reference_network_pvals_df[, 1], '_', reference_network_pvals_df[, 2])
# reference_network_pvals_df <- reference_network_pvals_df[row.names(valid_all_cmbns_df), ]
reference_network_pvals_df <- data.frame(pval = reference_network_pvals_df[, 3], row.names = row.names(reference_network_pvals_df))

# add ccm and granger:
# CCM:
LPS_parallel_res_mat_mlt <- melt(as.matrix(LPS_parallel_res_mat))
row.names(LPS_parallel_res_mat_mlt) <- paste0(LPS_parallel_res_mat_mlt[, 1], '_', LPS_parallel_res_mat_mlt[, 2])
LPS_parallel_res_mat_mlt <- LPS_parallel_res_mat_mlt[row.names(reference_network_pvals_df), ]
LPS_parallel_res_mat_mlt <- data.frame(ccm = LPS_parallel_res_mat_mlt[, 3], row.names = row.names(LPS_parallel_res_mat_mlt))

# granger:
LPS_granger_res_mat_mlt <- melt(as.matrix(LPS_granger_mat))
row.names(LPS_granger_res_mat_mlt) <- paste0(LPS_granger_res_mat_mlt[, 1], '_', LPS_granger_res_mat_mlt[, 2])
LPS_granger_res_mat_mlt <- LPS_granger_res_mat_mlt[row.names(reference_network_pvals_df), ]
LPS_granger_res_mat_mlt <- data.frame(ccm = LPS_granger_res_mat_mlt[, 3], row.names = row.names(LPS_granger_res_mat_mlt))

network_result_df$CCM <- LPS_parallel_res_mat_mlt[row.names(network_result_df), 'ccm']
network_result_df$Granger <- LPS_granger_res_mat_mlt[row.names(network_result_df), 1]

# LPS_max_rdi_res2 <- clr_directed_R(LPS_max_rdi_res)
network_result_df$cRDI <- melt(LPS_max_crdi_res2)$value
network_result_df$uRDI <- melt(LPS_max_urdi_res2)$value 
network_result_df$ucRDI <- melt(Shalek_abs_LPS_list_ucrdi)$value 

p_thrsld <- 0.01

colnames(network_result_df)[3] <- c('RDI')
rdi_roc_df_list <- lapply(colnames(network_result_df)[-c(1:2)], function(x, reference_network_pvals = reference_network_pvals_df$pval) {
  rdi_pvals <- network_result_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

pdf('./Figures/supplementary_figures/roc_LPS_small_net.pdf', height = 1, width = 1) #, aes(color = hub_score > 0.5)
qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  #facet_wrap(~method) +
  # scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0)) + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
  xlab('FPR') + ylab('TPR') + viridis::scale_color_viridis(discrete = T, option = 'D')
dev.off()

pdf('./Figures/supplementary_figures/roc_LPS_small_net_helper.pdf') #, aes(color = hub_score > 0.5)
qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  #facet_wrap(~method) +
  # scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0)) + theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
  xlab('FPR') + ylab('TPR')
dev.off()

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])
# uniq_rdi_auc_df[3, 1] <- 'NA'

pdf('./Figures/supplementary_figures/AUC_LPS_small_net.pdf', height = 1, width = 1) #, aes(color = hub_score > 0.5)
ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1) + xacHelper::nm_theme() + xlab('') + ylab('') + theme(axis.text.x = element_text(angle = 30, hjust = 1))+ viridis::scale_fill_viridis(discrete = T, option = 'D')
dev.off()


################################################################################################################################################################
# analyze on the blood dataset:
################################################################################################################################################################
# load Olsson dataset:
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Olsson.RData')

################################################################################################################################################################
# network from genome biology:
################################################################################################################################################################
myeloid_network_tmp <- read.table('./csv_data/genome_biology_RNAi_matrix_myeloid_network.txt', sep = '\t', header = T, fill = T, stringsAsFactors = F)
myeloid_network <- NULL

for(i in 1:nrow(myeloid_network_tmp)) {
  tmp <- melt(myeloid_network_tmp[i, -2], id.vars = 'Input.gene')[, c(1, 3)]
  tmp <- tmp[tmp$value != "", ]

  myeloid_network <- rbind(myeloid_network,
                                     tmp)
}
colnames(myeloid_network) <- c('V1', 'V2')
myeloid_network[, 1] <- tools::toTitleCase(tolower(myeloid_network[, 1]))
myeloid_network[, 2] <- tools::toTitleCase(tolower(myeloid_network[, 2]))

################################################################################################################################################################
# Gaowei's data
################################################################################################################################################################
myeloid_network <- read.table('./csv_data/gaowei_blood.txt', sep = '\t', header = F, stringsAsFactors = F)
# [1] "E2F"       "MYC"       "P21"       "CYCLIN E"  "RB"        "PU.1"      "CEBPS"     "NFKB"      "ERK"       "MTOR"      "B-CATENIN" "TGFB"      "GSK3B"     "CYCLIN D"
# [15] "ID2"       "P53"       "AMPK"      "EKLF"      "AKT/PKB"   "HIF1"      "PDH"       "PTEN"      "PKM2"      "NOTCH"     "C/EBPS"    "GATA1"     "GLS"       "PDK1"
# [29] "FAS"       "TNFA"      "BAX"       "CASPASE 3" "IAP"       "BCL2"      "CASPASE 8" "CASPASE 9" "BID/BAD"   "GFI1"      "CASPASE8"  "CASPASE3"  "FLI1"      "GATA2"
# [43]  "IFN"       "TET2"      "EGR/NAB"   "EGF"       "HIF"       "RAS"       "IDH"

replace_vec <- c("E2F" = "E2F1", "MYC" = "Myc", "P21" = "Cdkn1a", "CYCLIN E" = "CCNE1", "RB" = "Rb1", "PU.1" = "Spi1", "CEBPS" = "Cebpa/Cebpe",  "NFkB" = "NFkB", "ERK" = "Mapk1",
                 "MTOR" = "Mtor", "B-CATENIN" = "Ctnnb1", "TGFB" = "Tgfb1", "GSK3B" = "GSK3B", "CYCLIN D" = "Cdkn1a", "ID2" = "ID2", "P53" = "P53", "AMPK" = "Prkaa1", "EKLF" = "Klf1",
                 "AKT/PKB" = "Akt1", "HIF1" = "Epas1", "PDH" = "Pdk1", "PTEN" = "PTEN", "PKM2" = "Pkm", "NOTCH" = "Notch1", "C/EBPS" = "Cebpa/Cebpe",
                 "GATA1" = "Gata1", "GLS" = "GLS", "PDK1" = "Pdk1", "FAS" = "FAS", "TNFA" = "Tnf", "BAX" = "BAX",  "CASPASE 3" = "LOC101896713", "IAP" = "Cd47",
                 "BCL2" = "BCL2", "CASPASE 8" = "CASP 8","CASPASE 9" = "Casp 9", "BID/BAD" = "Tnf", "GFI1" = "GFI1", "CASPASE8"  = "CASP 8", "CASPASE3" = "CASP 3",
                 "FLI1" = "Fli1", "GATA2" = "GATA2", "IFN" = 'Ifng', "TET2" = "Tet2", "EGR/NAB" = "Nab2", "HIF" = "Epas1", "RAS" = "ras","IDH" = "Idh1")
myeloid_network$V1 <- revalue(toupper(myeloid_network$V1), replace_vec)
myeloid_network$V2 <- revalue(toupper(myeloid_network$V2), replace_vec)

myeloid_network$V1 <- tools::toTitleCase(tolower(myeloid_network$V1))
myeloid_network$V2 <- tools::toTitleCase(tolower(myeloid_network$V2))

gene_names <- unique(c(myeloid_network$V1, myeloid_network$V2))
valid_gene_ids <- row.names(subset(fData(Olsson_granulocyte_cds), gene_short_name %in% gene_names))

for(cell_type in c('gran', 'mono')) {
  if(cell_type == 'gran') {
    Olsson_blood_exprs <- t(as.matrix(exprs(Olsson_granulocyte_cds)[valid_gene_ids, order(pData(Olsson_granulocyte_cds)$Pseudotime)]))
  } else {
    Olsson_blood_exprs <- t(as.matrix(exprs(Olsson_monocyte_cds)[valid_gene_ids, order(pData(Olsson_monocyte_cds)$Pseudotime)]))
  }
  message('current cell type is ', cell_type)
  # valid_gene_ids <- row.names(subset(fData(Olsson_granulocyte_cds), toupper(gene_short_name) %in% toupper(grn_all_genes)))
  
  super_graph <- create_super_graph(Olsson_granulocyte_cds[valid_gene_ids, ]) #  TFs = sig_TFs_motif_enriched, informative_genes = toupper(BEAM_genes)
  super_graph[, 1] <- match(super_graph[, 1], row.names(Olsson_granulocyte_cds[valid_gene_ids, ]))
  super_graph[, 2] <- match(super_graph[, 2], row.names(Olsson_granulocyte_cds[valid_gene_ids, ]))
  super_graph <- super_graph - 1
  
  # Shalek_abs_LPS_exprs <- t(as.matrix(exprs(Olsson_granulocyte_cds)[valid_gene_ids, order(pData(Olsson_granulocyte_cds)$Pseudotime)]))
  # also add smoothing
  if(smoothing) {
    for(i in 1:ncol(Olsson_blood_exprs)) {
      df <- data.frame(Pseudotime = 1:nrow(Olsson_blood_exprs), Expression = Olsson_blood_exprs[, i])
      test <- loess(Expression ~ Pseudotime, df)
      Olsson_blood_exprs[, i] <-  predict(test)
    }
  }
  
  # Olsson_blood_exprs <- smooth_gene(Olsson_blood_exprs, window_size = 20)
  message('running rdi ...')
  
  Olsson_blood_exprs_list <- calculate_rdi_cpp_wrap(as.matrix(Olsson_blood_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                                turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)
  
  Olsson_max_rdi_res <- Olsson_blood_exprs_list$max_rdi_value
  gene_name <- valid_gene_ids
  dimnames(Olsson_max_rdi_res) <- list(valid_gene_ids, valid_gene_ids)
  
  # crdi, urdi, ucrdi: 
  message('running crdi ...')
  Olsson_blood_exprs_list_crdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Olsson_blood_exprs), as.matrix(super_graph),
                                                                 as.matrix(Olsson_blood_exprs_list$max_rdi_value), as.matrix(Olsson_blood_exprs_list$max_rdi_delays), 1, uniformalize = F)
  
  message('running urdi ...')
  Olsson_blood_exprs_list_urdi <- calculate_rdi_cpp_wrap(as.matrix(Olsson_blood_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                                     turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = T)
  message('running ucrdi ...')
  Olsson_blood_exprs_list_ucrdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Olsson_blood_exprs), as.matrix(super_graph),
                                                                      Olsson_blood_exprs_list_urdi$max_rdi_value, Olsson_blood_exprs_list_urdi$max_rdi_delays, 1, uniformalize = T)
  
  Olsson_max_rdi_res2 <- clr_directed_R(Olsson_max_rdi_res)
  Olsson_max_rdi_res2_crdi <- clr_directed_R(Olsson_blood_exprs_list_crdi); dimnames(Olsson_max_rdi_res2_crdi) <- dimnames(Olsson_max_rdi_res)
  Olsson_max_rdi_res2_urdi <- clr_directed_R(Olsson_blood_exprs_list_urdi$max_rdi_value); dimnames(Olsson_max_rdi_res2_urdi) <- dimnames(Olsson_max_rdi_res)
  Olsson_max_rdi_res2_ucrdi <- clr_directed_R(Olsson_blood_exprs_list_ucrdi); dimnames(Olsson_max_rdi_res2_ucrdi) <- dimnames(Olsson_max_rdi_res)
  
  message('finishing Scribe analysis ...')
  
  # visualize TF network with the top genes
  z_threshold <- 0 # 2
  Olsson_max_rdi_res2[Olsson_max_rdi_res2 < z_threshold] <- 0
  g <- igraph::graph_from_adjacency_matrix(as.matrix(Olsson_max_rdi_res2), weighted = T, mode = "direct")
  
  V(g)$hubness <- -hub_score(g)$vector
  pdf('./Figures/main_figures/Olsson_global_network_gggraph.pdf', height = 2, width = 2)
  # print(ggraph(g , layout = "linear", sort.by = "hubness") +
  #         geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
  #                                                                       ends = "last", type = "open")) +
  #         scale_edge_width(range = c(0.2, 2)) +
  #         geom_node_text(aes(label = V(g )$name), check_overlap = T, size = 3,repel = T) +
  #         labs(edge_width = "Causality") +
  #         theme_graph())
  dev.off()
  
  ################################################################################################################################################################
  # plot the results
  ################################################################################################################################################################
  super_graph_gene_name <- super_graph + 1
  super_graph_gene_name[, 1] <- as.character(fData(Olsson_granulocyte_cds[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 1]]
  super_graph_gene_name[, 2] <- as.character(fData(Olsson_granulocyte_cds[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 2]]
  
  p_thrsld <- 0
  valid_all_cmbns_df <- data.frame(pair = paste(super_graph_gene_name[, 1], super_graph_gene_name[, 2], sep = '_'), pval = 0)
  
  row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
  
  # identify interaction from the motif-scan result
  uniq_genes <- unique(c(super_graph_gene_name[, 1], super_graph_gene_name[, 2]))
  apply(myeloid_network, 1, function(x) {
    x <- tools::toTitleCase(tolower(as.character(x[1:2])))
    valid_ind <- paste0(x[1], '_', x[2])
  
    message('valid_ind is ', valid_ind)
    if(all(x[1:2] %in% uniq_genes)) {
      valid_all_cmbns_df[valid_ind, 'pval'] <<- 1
    }
  })
  
  network_result_df <- melt(Olsson_max_rdi_res)
  row.names(network_result_df) <- paste0(network_result_df[, 1], '_', network_result_df[, 2])
  # network_result_df <- network_result_df[row.names(reference_network_pvals_df), ]
  network_result_df <- data.frame(RDI = network_result_df[, 3], row.names = row.names(network_result_df))
  
  reference_network_pvals_df <- data.frame(pval = valid_all_cmbns_df[, 2], row.names = row.names(valid_all_cmbns_df))
  reference_network_pvals_df <- data.frame(pval = valid_all_cmbns_df[row.names(network_result_df), 2], row.names = row.names(network_result_df))
  
  ################################################################################################################################################################
  # run Granger and CCM on this dataset
  ################################################################################################################################################################
  # order_LPS_mat <- read.table('LPS_data.txt', header = T, row.names = 1)
  
  #run CCM
  message('running CCM ...')
  Olsson_parallel_res <- parallelCCM(ordered_exprs_mat = Olsson_blood_exprs, cores = detectCores() - 2)
  Olsson_parallel_res_mat <- prepare_ccm_res(Olsson_parallel_res)
  
  #run granger causality:
  message('running GC ...')
  order_Olsson_mat_t_smooth_granger_res <- parallel_cal_grangertest((Olsson_blood_exprs)[, ], filename = 'order_Olsson_mat_t_smooth_granger_res', delays = c(1, 20, 41), smooth = F)
  order_Olsson_mat_t_smooth_granger_res <- do.call(rbind.data.frame, order_Olsson_mat_t_smooth_granger_res)
  
  Olsson_granger_mat <- dcast(order_Olsson_mat_t_smooth_granger_res[, c(1, 3, 6)], formula = Gene_1_ID ~ Gene_2_ID)
  row.names(Olsson_granger_mat) <- Olsson_granger_mat[, 1]
  Olsson_granger_mat <- Olsson_granger_mat[, -1]
  diag(Olsson_granger_mat) <- 0
  
  # add ccm and granger:
  # CCM:
  Olsson_parallel_res_mat_mlt <- melt(as.matrix(Olsson_parallel_res_mat))
  row.names(Olsson_parallel_res_mat_mlt) <- paste0(Olsson_parallel_res_mat_mlt[, 1], '_', Olsson_parallel_res_mat_mlt[, 2])
  Olsson_parallel_res_mat_mlt <- Olsson_parallel_res_mat_mlt[row.names(reference_network_pvals_df), ]
  Olsson_parallel_res_mat_mlt <- data.frame(ccm = Olsson_parallel_res_mat_mlt[, 3], row.names = row.names(Olsson_parallel_res_mat_mlt))
  
  # granger:
  Olsson_granger_res_mat_mlt <- melt(as.matrix(Olsson_granger_mat))
  row.names(Olsson_granger_res_mat_mlt) <- paste0(Olsson_granger_res_mat_mlt[, 1], '_', Olsson_granger_res_mat_mlt[, 2])
  Olsson_granger_res_mat_mlt <- Olsson_granger_res_mat_mlt[row.names(reference_network_pvals_df), ]
  Olsson_granger_res_mat_mlt <- data.frame(ccm = Olsson_granger_res_mat_mlt[, 3], row.names = row.names(Olsson_granger_res_mat_mlt))
  
  
  network_result_df$ccm <- Olsson_parallel_res_mat_mlt[row.names(network_result_df), 'ccm']
  network_result_df$granger <- Olsson_granger_res_mat_mlt[row.names(network_result_df), 1]
  
  # TF_hiearchy:
  # reference_network_pvals_df <- melt(as.matrix(myeloid_network))
  # row.names(reference_network_pvals_df) <- paste0(reference_network_pvals_df[, 1], '_', reference_network_pvals_df[, 2])
  # # reference_network_pvals_df <- reference_network_pvals_df[row.names(valid_all_cmbns_df), ]
  # reference_network_pvals_df <- data.frame(pval = reference_network_pvals_df[, 3], row.names = row.names(reference_network_pvals_df))
  
  p_thrsld <- 0.01
  
  colnames(network_result_df) <- c('Scribe', 'CCM', 'Granger')
  network_result_df$cRDI <- melt(Olsson_max_rdi_res2_crdi)$value
  network_result_df$uRDI <- melt(Olsson_max_rdi_res2_urdi)$value
  network_result_df$ucRDI <- melt(Olsson_max_rdi_res2_ucrdi)$value
  
  message('generating figures ...')
  rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals = reference_network_pvals_df$pval) {
    rdi_pvals <- network_result_df[, x]
  
    rdi_pvals[is.na(rdi_pvals)] <- 0
    reference_network_pvals[is.na(reference_network_pvals)] <- 0
    rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
    res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
    colnames(res) <- c('tpr', 'fpr', 'auc')
    cbind(res, method = x)
  })
  
  rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
  rdi_roc_df <- do.call(rbind, rdi_roc_df_list)
  
  pdf(paste0('./Figures/supplementary_figures/roc_Olsson_net_', cell_type, '.pdf'), height = 1, width = 1) #, aes(color = hub_score > 0.5)
  print(qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
    xlab("False positive rate") +
    ylab("True positive rate") +
    ylim(c(0, 1.0)) + geom_abline(color = 'red') +
    # facet_wrap(~method) +
    # scale_color_manual(values = cols, name = "Type") #+ nm_theme()
    xlim(c(0, 1.0)) + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
    xlab('FPR') + ylab('TPR')) + viridis::scale_color_viridis(discrete = T, option = 'D')
  dev.off()
  
  uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])
  uniq_rdi_auc_df$cell_type <- cell_type 
  if(exists("uniq_rdi_auc_df_cmbn")) {
    uniq_rdi_auc_df_cmbn <- rbind(uniq_rdi_auc_df_cmbn, uniq_rdi_auc_df)
  } else {
    uniq_rdi_auc_df_cmbn <- uniq_rdi_auc_df
  }
  
  pdf(paste0('./Figures/supplementary_figures/AUC_Olsson_net_', cell_type, '.pdf'), height = 1, width = 1) #, aes(color = hub_score > 0.5)
  print(ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
    xlab("") + ylim(0, 1) + xacHelper::nm_theme() + xlab('') + ylab('') + theme(axis.text.x = element_text(angle = 30, hjust = .9)))  + viridis::scale_fill_viridis(discrete = T, option = 'D')
  dev.off()  
}

################################################################################################################################################################
# Erythroid data
################################################################################################################################################################

###############################################################################################################################################################################################
#2. erythroid network
# all_wt_GSE72857_cds: wild-type data from Paul
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/all_wt_GSE72857_cds')

erythroid_network <- read.table('./csv_data/erythroid_network.txt', sep = '\t', header = T)
erythroid_gene_list <- c(as.character(erythroid_network$Upstream.Gene), as.character(erythroid_network$Target.Gene))
print(t(t(unique(erythroid_gene_list[!(as.character(erythroid_gene_list) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]))))
write.table(unique(erythroid_gene_list[!(as.character(erythroid_gene_list) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]),
            row.names = F, col.names = F, quote = F, file = './csv_data/erythroid_missing_gene_list.txt')

# [1] "Foxa2"   "Glis3"   "Hnf1a"   "Hnf1b"   "Hnf4a"   "Isl1"    "Myt1"    "Neurod1" "Neurog3" "Nkx2.2"  "Nkx6.1"  "Nkx6.2"  "Pax4"    "Pax6"    "Rfx6"    "Smad7"   "Tle2"
# [18] "Ccnd1"   "cMyc"    "Gcg"     "Mafa"    "Ins2"    "Irx1"    "Insm1"   "Fev"     "Neurod2" "Ghrl"    "Mafb"    "Dnmt3a"  "Hdac1"   "Mnx1"    "Pdx1"    "Arx"     "Glut2"
# [35] "Sst"     "Tle3"    "Tm4sf4"  "Atf2"    "Atf3"    "Egr1"    "Foxo1"   "Gck"     "Ins1"    "Slc2a2"  "G6pc2"   "Glp1r"   "Rbp4"    "Ptf1a"   "Iapp"    "Dnmt1a"  "Mecp2"
# [52] "NFATc1"  "Ccnd2"   "Cdk4"    "ChgA"    "ChgB"    "Foxm1"   "Ia2"     "Irs2"    "Tnfa"    "Pcsk1"
update_gene_names <- c("Foxa2", "Glis3", "Hnf1a", "Hnf1b", "Hnf4a", "Isl1", "Myt1", "Pkmyt1", "Neurod1", "Neurog3", "Nkx2-2", "Nkx6-1", "Nkx6-2", "Pax4", "Pax6", "Rfx6", "Smad7", "Tle2", "Ccnd1",
                       "Cdkn1a", "Gcg", "Klrg1", "Mafa", "Ins2", "Irx1", "Insm1", "Fev", "Neurod2", "Ghrl", "Mafb", "Dnmt3a", "Hdac1", "Hdac2", "Mnx1", "Pdx1", "Pdhx", "Arx", "Uba2", "Slc2a2", "Sst",
                       "Lmx1a", "Tle3", "Tm4sf4", "Gdnf", "Atf2", "Atf3", "Egr1", "Foxo1", "Gck", "Map4k2", "Ins1", "Slc2a2", "G6pc", "G6pc2", "Glp1r", "Rbp4", "Polr2d", "Ptf1a", "Iapp", "Mecp2",
                       "Prr14", "Nfatc1", "Ccnd2", "Cdk4", "Defb1", "Chga", "Chgb", "Foxm1", "Ptprn", "H2-Ab1", "Irs2", "Tnf", "Pcsk1")

# write.table(unique(gene_list[!(as.character(update_gene_names) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]),
#             row.names = F, col.names = F, quote = F, file = './csv_data/erythroid_missing_gene_list.txt')

#find the missing gene name and correct the gene regulatory network
erythroid_network$Upstream.Gene <- revalue(erythroid_network$Upstream.Gene,
                                           c("Beta Catenin" = "Ctnnb1", "LEF-1" = "Lef1", "Hes1" = "Hes1", "notch1" = "Notch1", "CBF1" = "Rbpj", "p45" = "Nfe2",
                                             "NF-E2" = "Nfe2", "Maf" = "Maf", "Rb" = "Rb1", "SCL in a complex" = "SCL", "TCF3 (Wnt signalling)" = "Tcf3",
                                             "Wnt signalling (B-catenin)" = "Ctnnb1", "Alpha Globin" = "Hba-a2", "Beta Globin" = "Hbb-bs",
                                             "Beta Globin (via GATA-1)" = "Hbb-bs", "p45 NF-E2" = "Nfe2", "c-jun (PU.1)" = "Jun", "GATA-1 activity (P300)" = "Gata1",
                                             "alpha globin" = "Hba-a2", "Runx-1" = "Runx1", "HoxB4" = "Hoxb4", "Notch-1" = "Notch1", "Beta Catenin/LEF-1" = "Ctnnb1",
                                             "Hes1 (notch1)" = "Hes1", "Notch                                  (and CBF1 aka RBP-J)" = "Notch1",
                                             "Notch and CBF1(RBPjk)" = "Notch1", "p45 NF-E2 (via Maf proteins)" = "Nfe2", "BMP4" = "Bmp4",
                                             "CBP" = "Crebbp", "c-jun" = "Jun", "c-myb" = "Myb", "E2A" = "Tcf3", "E47" = "Tcf3", "EKLF" = "Klf1", "Elf-1" = "Elf1",
                                             "GATA-1" = "Gata1", "GATA-2" = "Gata2", "(notch1)" = "Notch1", "HoxB4" = "Hoxb4", "LMO2" = "Lmo2", "NFE2" = "Nfe2",
                                             "Notch" = "Notch1", "p45" = "Nfe2", "PU.1" = "Spi1", "Rb" = "Rb1", "SCL" = "Scx", "TCF3" = "Tcf3", "Brachyury" = "T",
                                             "Hex" = "Hhex", "c-kit" = "Kit", "GPA" = "Gypa", "c-myc" = "Myc", "GPIX" = "Gp9", "EpoR" = "Epor"))
erythroid_network$Target.Gene <- revalue(erythroid_network$Target.Gene,
                                         c("Beta Catenin" = "Ctnnb1", "LEF-1" = "Lef1", "Hes1" = "Hes1", "notch1" = "Notch1", "CBF1" = "Rbpj", "p45" = "Nfe2",
                                           "NF-E2" = "Nfe2", "Maf" = "Maf", "Rb" = "Rb1", "SCL in a complex" = "SCL", "TCF3 (Wnt signalling)" = "Tcf3",
                                           "Wnt signalling (B-catenin)" = "Ctnnb1", "Alpha Globin" = "Hba-a2", "Beta Globin" = "Hbb-bs",
                                           "Beta Globin (via GATA-1)" = "Hbb-bs", "p45 NF-E2" = "Nfe2", "c-jun (PU.1)" = "Jun", "GATA-1 activity (P300)" = "Gata1",
                                           "alpha globin" = "Hba-a2", "Runx-1" = "Runx1", "HoxB4" = "Hoxb4", "Notch-1" = "Notch1", "Beta Catenin/LEF-1" = "Ctnnb1",
                                           "Hes1 (notch1)" = "Hes1", "Notch                                  (and CBF1 aka RBP-J)" = "Notch1",
                                           "Notch and CBF1(RBPjk)" = "Notch1", "p45 NF-E2 (via Maf proteins)" = "Nfe2", "BMP4" = "Bmp4",
                                           "CBP" = "Crebbp", "c-jun" = "Jun", "c-myb" = "Myb", "E2A" = "Tcf3", "E47" = "Tcf3", "EKLF" = "Klf1", "Elf-1" = "Elf1",
                                           "GATA-1" = "Gata1", "GATA-2" = "Gata2", "(notch1)" = "Notch1", "HoxB4" = "Hoxb4", "LMO2" = "Lmo2", "NFE2" = "Nfe2",
                                           "Notch" = "Notch1", "p45" = "Nfe2", "PU.1" = "Spi1", "Rb" = "Rb1", "SCL" = "Scx", "TCF3" = "Tcf3", "Brachyury" = "T",
                                           "Hex" = "Hhex", "c-kit" = "Kit", "GPA" = "Gypa", "c-myc" = "Myc", "GPIX" = "Gp9", "EpoR" = "Epor"))

# write.table(file = './csv_data/erythroid_network_update.txt', erythroid_network, row.names = T, quote = F)
# erythroid_network <- read.table('./csv_data/erythroid_network_update.txt', sep = ' ', header = T)

gene_names <- unique(c(as.character(erythroid_network$Upstream.Gene), as.character(erythroid_network$Target.Gene)))
valid_gene_ids <- row.names(subset(fData(all_wt_GSE72857_cds), gene_short_name %in% gene_names))

# only take the erythroid branch please
table(pData(all_wt_GSE72857_cds)[, c('cell_type', 'State')])
erythroid_all_wt_GSE72857_cds <- all_wt_GSE72857_cds[, pData(all_wt_GSE72857_cds)$State %in% c(1, 2)]
#
# absolute_cds <- orderCells(absolute_cds)
# plot_cell_trajectory(absolute_cds)
# plot_cell_trajectory(absolute_cds, color_by = 'Time')
# plot_cell_trajectory(absolute_cds, color_by = 'Pseudotime')
# absolute_cds <- orderCells(absolute_cds, root_state = 3)
# plot_cell_trajectory(absolute_cds, color_by = 'Pseudotime')
erythroid_dpt_res <- run_new_dpt(erythroid_all_wt_GSE72857_cds)

Paul_blood_exprs <- t(as.matrix(exprs(erythroid_all_wt_GSE72857_cds)[valid_gene_ids, order(erythroid_dpt_res$pt)]))
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Paul_blood_exprs) * ncol(Paul_blood_exprs)), nrow = nrow(Paul_blood_exprs))
Paul_blood_exprs <- Paul_blood_exprs + noise

# Pauln_blood_exprs <- t(as.matrix(exprs(Paul_monocyte_cds)[valid_gene_ids, order(pData(all_wt_GSE72857_cds)$Pseudotime)]))

# valid_gene_ids <- row.names(subset(fData(all_wt_GSE72857_cds), toupper(gene_short_name) %in% toupper(grn_all_genes)))

super_graph <- create_super_graph(all_wt_GSE72857_cds[valid_gene_ids, ]) #  TFs = sig_TFs_motif_enriched, informative_genes = toupper(BEAM_genes)
super_graph[, 1] <- match(super_graph[, 1], row.names(all_wt_GSE72857_cds[valid_gene_ids, ]))
super_graph[, 2] <- match(super_graph[, 2], row.names(all_wt_GSE72857_cds[valid_gene_ids, ]))
super_graph <- super_graph - 1

# Shalek_abs_LPS_exprs <- t(as.matrix(exprs(all_wt_GSE72857_cds)[valid_gene_ids, order(pData(all_wt_GSE72857_cds)$Pseudotime)]))
# also add smoothing
if(smoothing) {
  for(i in 1:ncol(Paul_blood_exprs)) {
    df <- data.frame(Pseudotime = 1:nrow(Paul_blood_exprs), Expression = Paul_blood_exprs[, i])
    test <- loess(Expression ~ Pseudotime, df)
    Paul_blood_exprs[, i] <-  predict(test)
  }
}
# Paul_blood_exprs <- smooth_gene(Paul_blood_exprs, window_size = 20)

Paul_blood_exprs_list <- calculate_rdi_cpp_wrap(as.matrix(Paul_blood_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                                  turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = F)

# crdi, urdi, ucrdi: 
Paul_blood_exprs_list_crdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Paul_blood_exprs), as.matrix(super_graph),
                                                               as.matrix(Paul_blood_exprs_list$max_rdi_value), as.matrix(Paul_blood_exprs_list$max_rdi_delays), 1, uniformalize = F)

Paul_blood_exprs_list_urdi <- calculate_rdi_cpp_wrap(as.matrix(Paul_blood_exprs), delays = c(1, 20, 41), #c(1, 5, 10, 15),
                                                   turning_points = 0, super_graph = as.matrix(super_graph), method = 1, uniformalize = T)
Paul_blood_exprs_list_ucrdi <- calculate_conditioned_rdi_cpp_wrap(as.matrix(Paul_blood_exprs), as.matrix(super_graph),
                                                                Paul_blood_exprs_list_urdi$max_rdi_value, Paul_blood_exprs_list_urdi$max_rdi_delays, 1, uniformalize = T)

Paul_max_rdi_res <- Paul_blood_exprs_list$max_rdi_value
gene_name <- valid_gene_ids
dimnames(Paul_max_rdi_res) <- list(valid_gene_ids, valid_gene_ids)

Paul_max_rdi_res2 <- clr_directed_R(Paul_max_rdi_res)
Paul_max_crdi_res2 <- clr_directed_R(Paul_blood_exprs_list_crdi); dimnames(Paul_max_crdi_res2) <- dimnames(Paul_max_rdi_res2)
Paul_max_urdi_res2 <- clr_directed_R(Paul_blood_exprs_list_urdi$max_rdi_value); dimnames(LPS_max_urdi_res2) <- dimnames(Paul_max_rdi_res2)
Paul_max_ucrdi_res2 <- clr_directed_R(Paul_blood_exprs_list_ucrdi); dimnames(Paul_max_ucrdi_res2) <- dimnames(Paul_max_rdi_res2)

# visualize TF network with the top genes
z_threshold <- 2
Paul_max_rdi_res2[Paul_max_rdi_res2 < z_threshold] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(Paul_max_rdi_res2), weighted = T, mode = "direct")

V(g)$hubness <- -hub_score(g)$vector
pdf('./Figures/main_figures/Paul_global_network_gggraph.pdf', height = 2, width = 2)
# print(ggraph(g , layout = "linear", sort.by = "hubness") +
#         geom_edge_arc(aes(width = weight), alpha = 0.8, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
#                                                                       ends = "last", type = "open")) +
#         scale_edge_width(range = c(0.2, 2)) +
#         geom_node_text(aes(label = V(g )$name), check_overlap = T, size = 3,repel = T) +
#         labs(edge_width = "Causality") +
#         theme_graph())
dev.off()

################################################################################################################################################################
# plot the results
################################################################################################################################################################
super_graph_gene_name <- super_graph + 1
super_graph_gene_name[, 1] <- as.character(fData(all_wt_GSE72857_cds[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 1]]
super_graph_gene_name[, 2] <- as.character(fData(all_wt_GSE72857_cds[valid_gene_ids, ])$gene_short_name)[super_graph_gene_name[, 2]]

p_thrsld <- 0
valid_all_cmbns_df <- data.frame(pair = paste(super_graph_gene_name[, 1], super_graph_gene_name[, 2], sep = '_'), pval = 0)

row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair

# identify interaction from the motif-scan result
uniq_genes <- unique(c(super_graph_gene_name[, 1], super_graph_gene_name[, 2]))
apply(erythroid_network[, c(2, 3)], 1, function(x) {
  x <- tools::toTitleCase(tolower(as.character(x[1:2])))
  valid_ind <- paste0(x[1], '_', x[2])

  message('valid_ind is ', valid_ind)
  if(all(x[1:2] %in% uniq_genes)) {
    valid_all_cmbns_df[valid_ind, 'pval'] <<- 1
  }
})

network_result_df <- melt(Paul_max_rdi_res)
row.names(network_result_df) <- paste0(network_result_df[, 1], '_', network_result_df[, 2])
# network_result_df <- network_result_df[row.names(reference_network_pvals_df), ]
network_result_df <- data.frame(RDI = network_result_df[, 3], row.names = row.names(network_result_df))

reference_network_pvals_df <- data.frame(pval = valid_all_cmbns_df[, 2], row.names = row.names(valid_all_cmbns_df))
reference_network_pvals_df <- data.frame(pval = valid_all_cmbns_df[row.names(network_result_df), 2], row.names = row.names(network_result_df))

################################################################################################################################################################
# run Granger and CCM on this dataset
################################################################################################################################################################
# order_LPS_mat <- read.table('LPS_data.txt', header = T, row.names = 1)

#run CCM
Erythroid_parallel_res <- parallelCCM(ordered_exprs_mat = Paul_blood_exprs, cores = detectCores() - 2)
Erythroid_parallel_res_mat <- prepare_ccm_res(Erythroid_parallel_res)

#run granger causality:
order_Erythroid_mat_t_smooth_granger_res <- parallel_cal_grangertest((Paul_blood_exprs)[, ], filename = 'order_Erythroid_mat_t_smooth_granger_res', delays = c(1, 20, 41), smooth = F)
order_Erythroid_mat_t_smooth_granger_res <- do.call(rbind.data.frame, order_Erythroid_mat_t_smooth_granger_res)

Erythroid_granger_mat <- dcast(order_Erythroid_mat_t_smooth_granger_res[, c(1, 3, 6)], formula = Gene_1_ID ~ Gene_2_ID)
row.names(Erythroid_granger_mat) <- Erythroid_granger_mat[, 1]
Erythroid_granger_mat <- Erythroid_granger_mat[, -1]
diag(Erythroid_granger_mat) <- 0

# add ccm and granger:
# CCM:
Erythroid_parallel_res_mat_mlt <- melt(as.matrix(Erythroid_parallel_res_mat))
row.names(Erythroid_parallel_res_mat_mlt) <- paste0(Erythroid_parallel_res_mat_mlt[, 1], '_', Erythroid_parallel_res_mat_mlt[, 2])
Erythroid_parallel_res_mat_mlt <- Erythroid_parallel_res_mat_mlt[row.names(reference_network_pvals_df), ]
Erythroid_parallel_res_mat_mlt <- data.frame(ccm = Erythroid_parallel_res_mat_mlt[, 3], row.names = row.names(Erythroid_parallel_res_mat_mlt))

# granger:
Erythroid_granger_res_mat_mlt <- melt(as.matrix(Erythroid_granger_mat))
row.names(Erythroid_granger_res_mat_mlt) <- paste0(Erythroid_granger_res_mat_mlt[, 1], '_', Erythroid_granger_res_mat_mlt[, 2])
Erythroid_granger_res_mat_mlt <- Erythroid_granger_res_mat_mlt[row.names(reference_network_pvals_df), ]
Erythroid_granger_res_mat_mlt <- data.frame(ccm = Erythroid_granger_res_mat_mlt[, 3], row.names = row.names(Erythroid_granger_res_mat_mlt))


network_result_df$ccm <- Erythroid_parallel_res_mat_mlt[row.names(network_result_df), 'ccm']
network_result_df$granger <- Erythroid_granger_res_mat_mlt[row.names(network_result_df), 1]

# TF_hiearchy:
# reference_network_pvals_df <- melt(as.matrix(myeloid_network))
# row.names(reference_network_pvals_df) <- paste0(reference_network_pvals_df[, 1], '_', reference_network_pvals_df[, 2])
# # reference_network_pvals_df <- reference_network_pvals_df[row.names(valid_all_cmbns_df), ]
# reference_network_pvals_df <- data.frame(pval = reference_network_pvals_df[, 3], row.names = row.names(reference_network_pvals_df))

p_thrsld <- 0.01

colnames(network_result_df) <- c('Scribe', 'CCM', 'Granger')
network_result_df$cRDI <- melt(Paul_max_crdi_res2)$value
network_result_df$uRDI <- melt(Paul_max_urdi_res2)$value 
network_result_df$ucRDI <- melt(Paul_max_ucrdi_res2)$value 

rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals = reference_network_pvals_df$pval) {
  rdi_pvals <- network_result_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

pdf('./Figures/supplementary_figures/roc_Paul_ery.pdf', height = 1, width = 1) #, aes(color = hub_score > 0.5)
qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  # facet_wrap(~method) +
  # scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0)) + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
  xlab('FPR') + ylab('TPR') + viridis::scale_color_viridis(discrete = T, option = 'D')
dev.off()

pdf('./Figures/supplementary_figures/roc_Paul_ery_helper.pdf') #, aes(color = hub_score > 0.5)
qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  # facet_wrap(~method) +
  # scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0)) + theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
  xlab('FPR') + ylab('TPR') + viridis::scale_color_viridis(discrete = T, option = 'D')
dev.off()

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

pdf('./Figures/supplementary_figures/AUC_Paul_ery.pdf', height = 1, width = 1) #, aes(color = hub_score > 0.5)
ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1) + xacHelper::nm_theme() + xlab('') + ylab('') + theme(axis.text.x = element_text(angle = 30, hjust = .9)) + viridis::scale_fill_viridis(discrete = T, option = 'D')# geom_jitter(aes(color = Time), size = 0.5) +
dev.off()

# ################################################################################################################################################################
# # save the data 
# ################################################################################################################################################################
save.image('./RData/figSI3_ROC_scRNASeq.RData')
