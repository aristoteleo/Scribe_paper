load('/Users/xqiu/Downloads/analysis_HSMM_data.RData')
HSMM <- read.table('/Users/xqiu/Downloads/muscle.txt', header = T, row.names = 1)

Arman_top_50 <- read.table('/Users/xqiu/Downloads/Genes list.txt')
HSMM <- newCellDataSet(as.matrix(HSMM),
                       phenoData = new("AnnotatedDataFrame", data = pData(HSMM)),
                       featureData = new("AnnotatedDataFrame", data = fData(HSMM)),
                       expressionFamily = tobit(),
                       lowerDetectionLimit = 1)

qplot(esApply(HSMM[as.vector(Arman_top_50$V1), ], 1, mean))
qplot(apply(HSMM[as.vector(Arman_top_50$V1), ], 1, mean))
