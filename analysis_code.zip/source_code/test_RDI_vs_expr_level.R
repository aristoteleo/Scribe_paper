# test the method on the Olsson / Paul dataset
mouse_tf_df <- read.table("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/transcription_factors/RIKEN_TF_list_update.txt",
                          sep = '\t', quote = "", stringsAsFactors = F, header = T)
human_tf_df <- read.table("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/transcription_factors/TF_list.txt",
                          sep = '\t', quote = "", stringsAsFactors = F, header = F, skip = 1999, skipNul = T)
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/beam_gene_vec_URMM_fig1')

simpleCap <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), substring(s, 2),
        sep="", collapse=" ")
}

# save(file = "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/fig1b_beam_genes", fig1b_beam_genes)
load("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/fig1b_beam_genes")
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/verify_network_hiearchy.RData')

TF <- tools::toTitleCase(tolower(human_tf_df$V1)); filter_genes <- beam_gene_vec
cds <- Olsson_granulocyte_cds[beam_gene_vec, ]
exprs(Olsson_MEP_cds) <- as.matrix(exprs(Olsson_MEP_cds)); exprs(Olsson_monocyte_cds) <- as.matrix(exprs(Olsson_monocyte_cds)); exprs(Olsson_granulocyte_cds) <- as.matrix(exprs(Olsson_granulocyte_cds));
MEP_dpt_res <- run_new_dpt(Olsson_MEP_cds); monocyte_dpt_res <- run_new_dpt(Olsson_monocyte_cds); granulocyte_dpt_res <- run_new_dpt(Olsson_granulocyte_cds);

Olsson_monocyte_cds_exprs <- t(exprs(Olsson_monocyte_cds)[beam_gene_vec, order(monocyte_dpt_res$pt)])
Olsson_granulocyte_cds_exprs <- t(exprs(Olsson_granulocyte_cds)[beam_gene_vec, order(granulocyte_dpt_res$pt)])

cOlsson_monocyte_cds_exprs
Olsson_granulocyte_cds_exprs

Olsson_monocyte_cds

all_gene_sum_mono <- rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, ], na.rm = T)
all_gene_sum_gran <- rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, ], na.rm = T)

dim(exprs_data)
exprs_data <- t(exprs_data)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data) * ncol(exprs_data)), nrow = nrow(exprs_data))

a <- Sys.time()
RDI_parallel_res <- calculate_rdi(exprs_data + noise, delays = 10, method = 1)
b <- Sys.time()
# save(file = "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/RDI_parallel_res_mono", RDI_parallel_res)

#####################################################################################################################################################################
# check whether or not the RDI value and correlation is directly related to the genee expression level: both are related to the average expression 
#####################################################################################################################################################################
# lung 
qplot(rowMeans(exprs(AT1_lung)), rowSums(AT1_RDI_parallel_res_subset))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/lung_AT1.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(AT1_lung)), rowSums(AT1_RDI_parallel_res_subset)) + xlim(0, 100) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme()
dev.off()

# lowess 
qplot(rowMeans(exprs(AT1_lung)), rowSums(AT1_RDI_parallel_res_subset)) + scale_x_log10()  + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() # + xlim(0, 100)
sort(resid(rlm(rowSums(AT1_RDI_parallel_res_subset) ~ rowMeans(exprs(AT1_lung)))))

qplot(rowMeans(exprs(AT2_lung)), rowSums(AT2_RDI_parallel_res_subset))
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/lung_AT2.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(AT2_lung)), rowSums(AT2_RDI_parallel_res_subset)) + xlim(0, 100) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme()
dev.off()

# lowess
qplot(rowMeans(exprs(AT2_lung)), rowSums(AT2_RDI_parallel_res_subset)) + scale_x_log10()  + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() # + xlim(0, 100)
sort(resid(rlm(rowSums(AT2_RDI_parallel_res_subset) ~ rowMeans(exprs(AT2_lung)))))

cor_res <- cor(t(exprs(AT1_lung)))
cor_res[diag(cor_res)] <- 0
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/lung_AT1_cor.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(AT1_lung)[, ]), rowSums(abs(cor_res), na.rm = T)) + xlim(0, 100) + 
  geom_abline() + xlab('Sum expression') + ylab('correlation') + geom_smooth() + nm_theme()
dev.off()

cor_res <- cor(t(exprs(AT2_lung)))
cor_res[diag(cor_res)] <- 0
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/lung_AT2_cor.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(AT2_lung)[, ]), rowSums(abs(cor_res), na.rm = T)) + xlim(0, 100) + 
  geom_abline() + xlab('Sum expression') + ylab('correlation') + geom_smooth() + nm_theme()
dev.off()

# LPS 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/LPS_normal.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Shalek_abs_subset_normal_state[match(row.names(LPS_normal_RDI_parallel_res_subset), fData(Shalek_abs_subset_normal_state)$gene_short_name), ])), 
      rowSums(LPS_normal_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme()
dev.off()

# lowess
qplot(rowMeans(exprs(Shalek_abs_subset_normal_state[match(row.names(LPS_normal_RDI_parallel_res_subset), fData(Shalek_abs_subset_normal_state)$gene_short_name), ])), 
      rowSums(LPS_normal_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() + scale_x_log10()
sort(resid(rlm(log(rowMeans(exprs(Shalek_abs_subset_normal_state[match(row.names(LPS_normal_RDI_parallel_res_subset), fData(Shalek_abs_subset_normal_state)$gene_short_name), ]))) ~ 
                 rowSums(LPS_normal_RDI_parallel_res_subset))))

cor_res <- cor(t(exprs(Shalek_abs_subset_normal_state[match(row.names(LPS_normal_RDI_parallel_res_subset), fData(Shalek_abs_subset_normal_state)$gene_short_name), ])))
cor_res[diag(cor_res)] <- 0
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/LPS_normal_cor.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Shalek_abs_subset_normal_state[match(row.names(LPS_normal_RDI_parallel_res_subset), fData(Shalek_abs_subset_normal_state)$gene_short_name), ])), 
      rowSums(abs(cor_res), na.rm = T)) + geom_abline() + xlab('Sum expression') + ylab('correlation') + geom_smooth() + nm_theme()
dev.off()

# Olsson 
row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset)[order(rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset) / 
    rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_monocyte_cds)$gene_short_name), ])))]

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/monocyte_RDI.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_monocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme()
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/monocyte_cRDI.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_monocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset, na.rm = T)) + xlab('Average expression') + ylab('Sum of outgoing cRDI') + xacHelper::nm_theme()
dev.off()

cor_res <- cor(t(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_monocyte_cds)$gene_short_name), ])))
cor_res[diag(cor_res)] <- 0
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/monocyte_cor.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_monocyte_cds)$gene_short_name), ])), 
      rowSums(abs(cor_res), na.rm = T))  + geom_abline() + xlab('Sum expression') + ylab('correlation') + geom_smooth() + nm_theme()
dev.off()

# lowess
qplot(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() + scale_x_log10()
sort(resid(rlm(log(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ]))) ~ 
                 rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset))))

#13 76
match(c('Gfi1', 'Irf8'), names(sort(rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset))))

# 34 77
match(c('Gfi1', 'Irf8'), names(sort(rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset, na.rm = T))))

# 53 23
match(c('Gfi1', 'Irf8'), names(sort(resid(rlm(log(rowMeans(exprs(Olsson_monocyte_cds[match(row.names(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ]))) ~ 
                                        rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset))))))
#######################################################################################################################
# granulocyte
#######################################################################################################################
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/granulocyte_RDI.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme()
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/granulocyte_cRDI.pdf', height = 1.5, width = 1.5)
qplot(rowMeans(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset, na.rm = T)) + xlab('Average expression') + ylab('Sum of outgoing cRDI') + xacHelper::nm_theme()
dev.off()

cor_res <- cor(t(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])))
cor_res[diag(cor_res)] <- 0
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/granulocyte_cor.pdf', height = 1.5, width = 1.5)
qplot(rowSums(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])),
      rowSums(abs(cor_res), na.rm = T)) + geom_abline() + xlab('Sum expression') + ylab('correlation') + geom_smooth() + nm_theme()
dev.off()

# Olsson on all BEAM genes: 
all_genes_monocyte_RDI <- RDI_parallel_res$RDI
dimnames(all_genes_monocyte_RDI) <- list(colnames(exprs_data), colnames(exprs_data))
all_genes_output_sum_mono <- rowSums(all_genes_monocyte_RDI)
match(all_genes_output_sum_mono[c('Irf8', 'Gfi1')], sort(all_genes_output_sum_mono))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_mono_vs_expr.pdf', height = 1.5, width = 1.5)
qplot(colMeans(exprs_data), all_genes_output_sum_mono) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

# lowess
qplot(rowMeans(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ])), 
      rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset)) + xlab('Average expression') + ylab('Sum of outgoing RDI') + xacHelper::nm_theme() + scale_x_log10()
sort(resid(rlm(log(rowMeans(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ]))) ~ 
                 rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset))))

#66 45
match(c('Gfi1', 'Irf8'), names(sort(rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset))))

#65 42
match(c('Gfi1', 'Irf8'), names(sort(rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset, na.rm = T))))

# 51 41
match(c('Gfi1', 'Irf8'), names(sort(resid(rlm(log(rowMeans(exprs(Olsson_granulocyte_cds[match(row.names(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset), fData(Olsson_granulocyte_cds)$gene_short_name), ]))) ~ 
                                        rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset))))))
####################################################################################################################################################################################
# run CLR / MRNET / ARACNE algorithm 
####################################################################################################################################################################################
clr_monocyte_RDI <- clr(t(all_genes_monocyte_RDI))
aracne.a_monocyte_RDI <- parmigene::aracne.a(all_genes_monocyte_RDI)
aracne.m_monocyte_RDI <- parmigene::aracne.m(all_genes_monocyte_RDI)
mrnet_monocyte_RDI <- parmigene::mrnet(all_genes_monocyte_RDI)

qplot(colMeans(exprs_data), apply(all_genes_monocyte_RDI, 1, function(x) sum(x))) # > 0
qplot(colMeans(exprs_data), apply(clr_monocyte_RDI, 1, function(x) sum(x))) + xlab('Average expression') + ylab('Sum of outgoing RDI') + ggtitle('CLR') #  > 0
qplot(colMeans(exprs_data), apply(aracne.a_monocyte_RDI, 1, function(x) sum(x))) # > 0
qplot(colMeans(exprs_data), apply(aracne.m_monocyte_RDI, 1, function(x) sum(x))) # > 0
qplot(colMeans(exprs_data), apply(mrnet_monocyte_RDI, 1, function(x) sum(x))) #  > 0

length(TF_vec_id) # 67
match(c('Irf8', 'Gfi1'), names(sort(rowSums(all_genes_monocyte_RDI)[TF_vec_id]))) #original 46 52
match(c('Irf8', 'Gfi1'), names(sort(rowSums(clr_monocyte_RDI)[TF_vec_id])))
match(c('Irf8', 'Gfi1'), names(sort(rowSums(aracne.a_monocyte_RDI)[TF_vec_id])))
match(c('Irf8', 'Gfi1'), names(sort(rowSums(aracne.m_monocyte_RDI)[TF_vec_id])))
match(c('Irf8', 'Gfi1'), names(sort(rowSums(mrnet_monocyte_RDI)[TF_vec_id])))

####################################################################################################################################################################################
# check the TF's total output sum 
####################################################################################################################################################################################
mono_RDI_10 <- RDI_parallel_res$RDI
dimnames(mono_RDI_10) <- list(colnames(exprs_data), colnames(exprs_data))
avg_exprs <- apply(exprs_data, 2, function(x) sum(x > 0.5))

avg_exprs_mat <- mono_RDI_10
k <- 1
for(i in row.names(avg_exprs_mat)) {
  print(k)
  for(j in colnames(avg_exprs_mat)){
    avg_exprs_mat[i, j] <- mean(exprs_data[, c(i)]) #only outgoing edges 
  }
  k <- k + 1
}

qplot(as.vector(avg_exprs_mat), as.vector(mono_RDI_10))

total_output_sum <- rowSums(mono_RDI_10)

label_name <- names(sort(rowSums(mono_RDI_10[TF_vec_id, TF_vec_id])))
label_name[!(label_name %in% c('Irf8', "Gfi1"))] <- NA
qplot(1:length(TF_vec_id), sort(rowSums(mono_RDI_10[TF_vec_id, TF_vec_id]) / avg_exprs[TF_vec_id]) ) + geom_text(aes(label = label_name), size = 4)

label_name <- names(sort(rowSums(mono_RDI_10[TF_vec_id, ])))
label_name[!(label_name %in% c('Irf8', "Gfi1"))] <- NA
qplot(1:length(TF_vec_id), sort(rowSums(mono_RDI_10[TF_vec_id, ]))) + 
  geom_text(aes(label = label_name), size = 4, color = 'red') + xlab('Rank') + ylab('Sum of total out-going edge')

# CLR: 
clr_mono_RDI_10 <- t(clr(t(mono_RDI_10)))
label_name <- names(sort(rowSums(clr_mono_RDI_10[TF_vec_id, ])))
label_name[!(label_name %in% c('Irf8', "Gfi1"))] <- NA
qplot(1:length(TF_vec_id), sort(rowSums(clr_mono_RDI_10[TF_vec_id, ]))) + 
  geom_text(aes(label = label_name), size = 4, color = 'red') + xlab('Rank') + ylab('Sum of total out-going edge')

# running the cRDI 
a <- Sys.time()
RDI_parallel_res <- calculate_conditioned_rdi(exprs_data + noise, super_graph = all_pairwise_gene, rdi_list = RDI_parallel_res, top_incoming_k = 1)
b <- Sys.time()

clr_mono_RDI_10 <- clr(mono_RDI_10)
label_name <- names(sort(rowSums(clr_mono_RDI_10[TF_vec_id, ])))
label_name[!(label_name %in% c('Irf8', "Gfi1"))] <- NA
qplot(1:length(TF_vec_id), sort(rowSums(clr_mono_RDI_10[TF_vec_id, ]))) + 
  geom_text(aes(label = label_name), size = 4, color = 'red') + xlab('Rank') + ylab('Sum of total out-going edge')

####################################################################################################################################################################################
# run CLR on all genes and then make the network hiearchy (we cannot do this) 
####################################################################################################################################################################################


####################################################################################################################################################################################
# maybe do normalized sum or something 
####################################################################################################################################################################################
AT1_residual_res <- monocle:::genSmoothCurveResiduals(AT1_lung)
AT2_residual_res <- monocle:::genSmoothCurveResiduals(AT1_lung)

exprs_data <- t(AT1_residual_res)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data) * ncol(exprs_data)), nrow = nrow(exprs_data))

a <- Sys.time()
residual_RDI_parallel_res <- calculate_rdi(exprs_data + noise, delays = 10, method = 1)
b <- Sys.time()

a <- Sys.time()
residual_RDI_parallel_res <- calculate_rdi(exprs_data + noise, delays = 10, method = 1)
b <- Sys.time()

# do on Paul dataset: 
pData(Olsson_monocyte_cds)$Pseudotime =  monocyte_dpt_res$pt
mono_residual_res <- monocle:::genSmoothCurveResiduals(Olsson_monocyte_cds[TF_vec_id, ])
pData(Olsson_granulocyte_cds)$Pseudotime =  granulocyte_dpt_res$pt
gran_residual_res <- monocle:::genSmoothCurveResiduals(Olsson_granulocyte_cds[TF_vec_id, ])

# run RDI and check the result 
mono_residual_res <- t(mono_residual_res)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(mono_residual_res) * ncol(mono_residual_res)), nrow = nrow(mono_residual_res))
a <- Sys.time()
mono_residual_RDI_parallel_res <- calculate_rdi(mono_residual_res + noise, delays = 10, method = 1)
b <- Sys.time()

match(c("Gfi1", "Irf8"), names(sort(rowSums(mono_residual_RDI_parallel_res$RDI, na.rm=T))))

gran_residual_res <- t(gran_residual_res)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(gran_residual_res) * ncol(gran_residual_res)), nrow = nrow(gran_residual_res))
a <- Sys.time()
gran_residual_RDI_parallel_res <- calculate_rdi(gran_residual_res + noise, delays = 10, method = 1)
b <- Sys.time()

match(c("Gfi1", "Irf8"), names(sort(rowSums(gran_residual_RDI_parallel_res$RDI, na.rm=T))))

# simulate the dataset and check the result

# check a few genes: 
URMM_all_fig1b <- orderCells(URMM_all_fig1b)
plot_genes_branched_pseudotime(URMM_all_fig1b[c('Id2', 'Nupl2', "Irf8", "Gfi1",
                                                "Myc", "Nr4a2", "Zfhx3", "Dach1", "Egr1", "Zeb2", "Znf512b"), ])

# test our method in the sc imaging dataset (maybe difficult to get the data)
qplot(log(rowMeans(exprs(Olsson_granulocyte_cds[TF_vec_id, ]))), 
  rowSums(mono_RDI_10[TF_vec_id, ]))

dimnames(mono_RDI_10) <- list(colnames(exprs_data), colnames(exprs_data))
match(c('Gfi1', 'Irf8'), names(sort(resid(rlm(log(rowMeans(exprs(Olsson_granulocyte_cds[TF_vec_id, ]))) ~ 
                                        rowSums(mono_RDI_10[TF_vec_id, ]))))))
match(c('Gfi1', 'Irf8'), names(sort(resid(rlm(log(rowMeans(exprs(Olsson_granulocyte_cds[TF_vec_id, ]))) ~ 
                                                rowSums(mono_RDI_10[TF_vec_id, ]))))))

# original is better 
match(c('Gfi1', 'Irf8'), names(sort(rowSums(mono_RDI_10[TF_vec_id, ]))))

