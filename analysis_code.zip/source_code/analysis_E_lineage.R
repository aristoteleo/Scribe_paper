# this script is used to do a detailed analysis for the E lineage 
library(Scribe)
library(igraph)
library(monocle)
library(reshape2)
library(ggraph)
library(extrafont) 
font_import() 
loadfonts()

# convert gene name to conventional names: 
convert_to_true_ids <- function(x) {
  splited <- stringr::str_split_fixed(x, '\\.', 2) # tools::toTitleCase()
  paste0(splited[, 1], '-', splited[, 2])
}

load('./RData/analysis_c_elegans.RData')
##################################################################################################################################################################
# Show intestine cell type TFs and the corresponding causal network 
##################################################################################################################################################################

# 1. end. 1/3; elt2/7 to show the causality 
cell_types <- c("muscle", "intestine")
muscle_genes <- c('hnd.1', 'unc.120', 'hlh.1')

valid_muscle_cell_id <- which(expressed_cnt2$cell %in% body_muscle)
sorted_expressed_cnt2 <- expressed_cnt2[, ] %>% arrange(desc(hnd.1), desc(unc.120), desc(hlh.1)) # valid_muscle_cell_id

sorted_expressed_cnt2[, muscle_genes]

# instentine gene: end3 <-> end1 -> elt1/2/7
intestine_cell <- c("Eprppp", "Eprppa", "Eprpa", "Eprap", "Epraa", "Eplppp", "Eplppa", "Eplpa", "Eplap", "Eplaa", "Earpp", "Earpa", "Earap", "Earaav", "Earaad", "Ealpp", "Ealpa", "Ealap", "Ealaav", "Ealaad")
intestine_gene <- c('end.3', 'end.1', 'elt.2', 'elt.7', 'elt.1')

valid_intestine_cell_id <- which(expressed_cnt2$cell %in% intestine_cell)
sorted_expressed_cnt2 <- expressed_cnt2[valid_intestine_cell_id, ] %>% arrange(desc(end.3), desc(end.1), desc(elt.2)) # valid_muscle_cell_id
sorted_expressed_cnt2[, c('end.3', 'end.1', 'elt.2')]

good_gene_lineages <- as.character(sorted_expressed_cnt2[, 'cell'][[1]])

cell_id <-  good_gene_lineages[1] #'Capaaa' #Muscle: 5, 6, 8
# cell_id <-  "MSpapaapap" #"Capaa" #

get_cell_lineage <- function(cell_id) {
  cell_id_vec <- strsplit(cell_id, "")[[1]]
  
  cell_lineage_vec <- c()
  for(i in 1:length(cell_id_vec)) {
    cell_lineage_vec <- c(cell_lineage_vec, paste0(cell_id_vec[1:i], collapse = ''))
  }
  return(cell_lineage_vec)
} 

cell_lineage_ids <- get_cell_lineage(cell_id)  
cell_lineage_ids <- c(c('P0', 'P1', 'EMS'), cell_lineage_ids)
test_c_elegans_data_ori <- subset(c_elegans_data, cell == cell_id)
test_c_elegans_data_ori <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids) # === cell_id

test_c_elegans_data <- t(test_c_elegans_data_ori[, -c(1:6)])
colnames(test_c_elegans_data) <- subset(c_elegans_data, cell %in% cell_lineage_ids)[, 'time']

qplot(1:ncol(test_c_elegans_data), test_c_elegans_data[1, ])

# three muscle genes: 
# 
# p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['hnd.1', ]) + xlab('Time') + ylab('Hnd-1') + ggtitle(paste('Cell name:', cell_id))
# p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['unc.120', ]) + xlab('Time') + ylab('Unc-1') + ggtitle(paste('Cell name:', cell_id))
# p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['hlh.1', ]) + xlab('Time') + ylab('Hlh-1') + ggtitle(paste('Cell name:', cell_id))

p1 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['end.3', ]) + xlab('Time') + ylab('End-3') + ggtitle(paste('Cell name:', cell_id))
p2 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['end.1', ]) + xlab('Time') + ylab('End-1') + ggtitle(paste('Cell name:', cell_id))
p3 <- qplot(test_c_elegans_data_ori$time, test_c_elegans_data['elt.2', ]) + xlab('Time') + ylab('Elt-2') + ggtitle(paste('Cell name:', cell_id))

xacHelper::multiplot(plotlist = list(p1, p2, p3))

rng_hnd <- range(test_c_elegans_data['hnd.1', ]) 
rng_hlh <- range(test_c_elegans_data['hlh.1', ]) 
rng_unc <- range(test_c_elegans_data['unc.120', ]) 

panel_a_df <- data.frame(Time = test_c_elegans_data_ori$time, 
                         Expression = c((test_c_elegans_data['hnd.1', ] - rng_hnd[1])/ diff(rng_hnd), #
                                        (test_c_elegans_data['hlh.1', ] - rng_hlh[1])  / diff(rng_hlh) , #
                                        (test_c_elegans_data['unc.120', ] - rng_unc[1]) / diff(rng_unc)), #  
                         gene_short_name = c(rep(c('Hnd-1', 'Hlh-1', 'Unc-120'), each = nrow(test_c_elegans_data_ori))))

gene_vec <- intestine_gene
min_time <- min(subset(test_c_elegans_data_ori, is.finite(end.3) & is.finite(end.1) & is.finite(elt.1))[, 'time'])
max_time <- max(subset(test_c_elegans_data_ori, is.finite(end.3) & is.finite(end.1) & is.finite(elt.1))[, 'time'])

test_c_elegans_data <- subset(test_c_elegans_data, time > min_time & time < max_time)
rng_A <- range(test_c_elegans_data[gene_vec[1], ], na.rm = T) 
rng_B <- range(test_c_elegans_data[gene_vec[2], ], na.rm = T) 
rng_C <- range(test_c_elegans_data[gene_vec[3], ], na.rm = T) 
rng_D <- range(test_c_elegans_data[gene_vec[4], ], na.rm = T) 

panel_a_df <- data.frame(Time = test_c_elegans_data_ori$time, 
                         Expression = c((test_c_elegans_data[gene_vec[1], ] - rng_A[1])/ diff(rng_A), #
                                        (test_c_elegans_data[gene_vec[2], ] - rng_B[1])  / diff(rng_B), #
                                        (test_c_elegans_data[gene_vec[3], ] - rng_C[1]) / diff(rng_C),
                                        (test_c_elegans_data[gene_vec[4], ] - rng_D[1]) / diff(rng_D)), #  
                         gene_short_name = c(rep(gene_vec[1:4], each = nrow(test_c_elegans_data_ori))))

pdf(paste0(main_fig_dir, 'worm_', cell_types[2], '_plot_kinetics.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)) + xlim(min_time, max_time) #+ ylim(0, 1)
dev.off()

pdf(paste0(main_fig_dir, 'worm_', cell_types[2], '_plot_kinetics_ori.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xacHelper::nm_theme() + xlab('Minutes') + theme(axis.text.x = element_text(angle = 30)) + xlim(min_time, max_time)
dev.off()

pdf(paste0(main_fig_dir, 'worm_', cell_types[2], '_plot_kinetics_helper.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name), size = I(0.01)) + geom_smooth(aes(color = gene_short_name), size = 0.5) + 
  xlab('Minutes') + theme(axis.text.x = element_text(angle = 30))
dev.off()

pdf(paste0(main_fig_dir, 'worm_intestine_plot.pdf'), width =  1, height = 1)
ggplot(aes(Time, Expression), data = panel_a_df) + geom_point(aes(color = gene_short_name)) + geom_smooth(aes(color = gene_short_name)) + 
  xacHelper::nm_theme()
dev.off()


##########################################################################################################################################################
# create a test cds and start to analyze the data 
##########################################################################################################################################################

# function to create a time series starting from the very beginning: 
pData <- test_c_elegans_data_ori[, 1:6]
row.names(pData) <- test_c_elegans_data_ori$time
pData$Pseudotime <- pData$time
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(test_c_elegans_data_ori)[-c(1:6)], row.names = colnames(test_c_elegans_data_ori)[-c(1:6)])
fd <- new("AnnotatedDataFrame", data = fData)

# Now, make a new CellDataSet using the RNA counts
test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0 # remove NaN values
test_cds <- newCellDataSet(test_c_elegans_data, 
                           phenoData = pd,
                           featureData = fd,
                           lowerDetectionLimit=1,
                           expressionFamily=gaussianff())

test_cds <- test_cds[, pData(test_cds)$time < 250]
test_urdi_res <- calculate_rdi(test_cds[gene_vec, ], delays = c(1, 5, 10, 15, 20), uniformalize = T, log = F, pseudo_cnt = 0) #
test_rdi_res <- calculate_rdi(test_cds[gene_vec, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F, pseudo_cnt = 0) #

# test_rdi_res <- calculate_rdi(test_cds[gene_vec, ], delays = c(20, 30, 40, 50, 60, 80), uniformalize = F, log = F) #
# test_urdi_res <- calculate_rdi(test_cds[gene_vec, ], delays = c(20, 30, 40, 50, 60, 80), uniformalize = T, log = F) #

test_umi_res <- calculate_umi(test_cds[gene_vec, ], log = F)
# test_umi_res_lung <- calculate_umi(AT1_lung, log = T)
# test_mi_res_lung <- cal_knn_mi_parmigene(AT1_lung)

# write.table(file = 'csv_data/c_elegans_muscle_matrix.csv', exprs(test_cds[gene_vec, ]), quote = F)
# write.table(file = 'csv_data/AT1_lung_matrix.csv', exprs(AT1_lung[, ]), quote = F)

test_rdi_res <- calculate_rdi(test_cds[gene_vec, ], delays = c(1:5), uniformalize = F, log = F) #muscle_genes
con_test_rdi_res <- calculate_conditioned_rdi(test_cds[gene_vec, ], rdi_list = test_rdi_res, uniformalize = T, top_incoming_k = 2, log = F) #muscle_genes

# exprs(test_cds)[gene_vec, ] <- t(apply(exprs(test_cds[gene_vec, ]), 1, function(x) {
#   x_rng <- range(x)
#   norm_x <- (x - x_rng[1])/ (diff(x_rng))
#   df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data)), 
#                    val = norm_x)
#   l_model <- loess(val ~ Time, df)
#   res <- predict(l_model)
#   return(res)
# }))

inflection_points <- apply(exprs(test_cds)[gene_vec, ], 1, function(data) {
  inflection_point <- inflection::bede(1:length(data), data, 0)
  if (!is.finite(inflection_point$iplast)) 
    inflection_point <- inflection::bede(1:length(data), data, 
                             1)
  round(inflection_point$iplast)
})

p1 <- qplot(pData(test_cds)$time, exprs(test_cds)[gene_vec[1], ]) + xlab('Time') + ylab(gene_vec[1]) + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = inflection_points[1] + min(pData(test_cds)$time))
p2 <- qplot(pData(test_cds)$time, exprs(test_cds)[gene_vec[2], ]) + xlab('Time') + ylab(gene_vec[2]) + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = inflection_points[2] + min(pData(test_cds)$time))
p3 <- qplot(pData(test_cds)$time, exprs(test_cds)[gene_vec[3], ]) + xlab('Time') + ylab(gene_vec[3]) + ggtitle(paste('Cell name:', cell_id)) + 
  geom_vline(xintercept = inflection_points[3] + min(pData(test_cds)$time))

xacHelper::multiplot(plotlist = list(p1, p2, p3))

dimnames(test_rdi_res$max_rdi_value) <- list(convert_to_true_ids(gene_vec), convert_to_true_ids(gene_vec))
pdf(paste0(main_fig_dir, 'worm_', cell_types[2], '_plot.pdf'), width =  1, height = 1)
pheatmap::pheatmap(test_rdi_res$max_rdi_value[convert_to_true_ids(gene_vec)[1:4], convert_to_true_ids(gene_vec)[1:4]], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = F, border_color = NA)
dev.off()

dimnames(test_urdi_res$max_rdi_value) <- list(convert_to_true_ids(gene_vec), convert_to_true_ids(gene_vec))
pheatmap::pheatmap(test_urdi_res$max_rdi_value[convert_to_true_ids(gene_vec), convert_to_true_ids(gene_vec)], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)

pdf(paste0(main_fig_dir, 'worm_', cell_types[2], '_uMI_plot.pdf'), width =  1, height = 1)
pheatmap::pheatmap(test_urdi_res$max_rdi_value[convert_to_true_ids(gene_vec)[1:4], convert_to_true_ids(gene_vec)[1:4]], cluster_rows = F, cluster_cols = F, fontsize = 6, legend = T, border_color = NA)
dev.off()

norm_test_c_elegans_data <- apply(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) > 100 & as.numeric(colnames(test_c_elegans_data)) < 250], 1, function(x) {
  x_rng <- range(x)
  norm_x <- (x - x_rng[1])/ (diff(x_rng))
  
  df <- data.frame(Time = as.numeric(colnames(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) > 100 & as.numeric(colnames(test_c_elegans_data)) < 250])),
                   val = norm_x)
  l_model <- loess(val ~ Time, df)
  res <- predict(l_model)

  return(res)
})

##################################################################################################################################################################
# Create half-max ordered heatmap for the E lineage 
##################################################################################################################################################################
source('./Scripts/create_half_max_ordering_heatmap.R', echo = T) # generate the figure 

qplot(as.numeric(colnames(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) < 250])), test_c_elegans_data[3, as.numeric(colnames(test_c_elegans_data)) < 250]) + geom_vline(xintercept = 28)
qplot(as.numeric(colnames(test_c_elegans_data[, as.numeric(colnames(test_c_elegans_data)) > 28 & as.numeric(colnames(test_c_elegans_data)) < 250])), norm_test_c_elegans_data[, 4]) + geom_vline(xintercept = 28)

# inflection_points <- apply(norm_test_c_elegans_data, 2, function(data) {
#   inflection_point <- bede(1:length(data), data, 0)
#   if (!is.finite(inflection_point$iplast)) 
#     inflection_point <- bede(1:length(data), data, 
#                              1)
#   round(inflection_point$iplast)
# })
# 
# middle_points <- apply(norm_test_c_elegans_data, 2, function(data) {
#   loc <- which.min(data - 0.5)
#   sign(mean(data[1:loc])) * loc
# })
# 
# pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(inflection_points), ], cluster_rows = T, cluster_cols = F)
# 
# pdf(paste0(main_fig_dir, 'c_elegans_', cell_types[2], '_muscle_heatmap.pdf'), width =  1, height = 2)
# pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(middle_points), ], cluster_rows = F, cluster_cols = F,
#                    annotation_names_row = F, border_color = NA, legend = F, show_rownames = F)
# dev.off()
# 
# pdf(paste0(main_fig_dir, 'c_elegans_muscle_heatmap_helper.pdf'))
# pheatmap::pheatmap(t(norm_test_c_elegans_data)[order(middle_points), ], cluster_rows = F, cluster_cols = F,
#                    annotation_names_row = F, border_color = NA, legend = T, show_rownames = F)
# dev.off()
# 
# pheatmap::pheatmap(con_test_rdi_res[muscle_genes, muscle_genes], cluster_rows = F, cluster_cols = F)
# 
# pheatmap::pheatmap(test_rdi_res$max_rdi_value[intestine_gene, intestine_gene], cluster_rows = F, cluster_cols = F)
# pheatmap::pheatmap(con_test_rdi_res[intestine_gene, intestine_gene], cluster_rows = F, cluster_cols = F)
# 
# pdf('Figures/c_elegans.pdf', width = 40, height = 40)
# pheatmap::pheatmap(test_rdi_res$max_rdi_value)
# dev.off()
# 
# which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[1], arr.ind = T)
# plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("unc.120", "hlh.1"), ncol = 2))
# row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[2], arr.ind = T)]
# row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[3], arr.ind = T)]
# row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[4], arr.ind = T)]
# row.names(test_cds)[which(test_rdi_res$max_rdi_value == sort(test_rdi_res$max_rdi_value, decreasing = T)[5], arr.ind = T)]
# 
# qplot(1:ncol(test_cds), exprs(test_cds)['tbx.8', ], geom = 'line', color = 'red') + geom_line(aes(1:ncol(test_cds), exprs(test_cds)['his.72', ], color = 'blue'))
# 
# qplot(1:ncol(test_cds), exprs(test_cds)['tbx.8', ], geom = 'line', color = 'red') + geom_line(aes(1:ncol(test_cds), exprs(test_cds)['his.72', ], color = 'blue'))
#
# plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("tbx.8", "Y71G12B.6"), ncol = 2))
# plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("crh.2", "Y71G12B.6"), ncol = 2))
# plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("sup.37", "Y71G12B.6"), ncol = 2))
# 
# plot_comb_logic(test_cds, gene_pairs_target_mat = matrix(c("crh.2", "tbx.8", "Y71G12B.6"), nrow = 1))

plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("end.3", "end.1"), ncol = 2), log = F)
plot_lagged_drevi(test_cds, gene_pairs_mat = matrix(c("end.3", "elt.7"), ncol = 2), log = F)
plot_comb_logic(test_cds, gene_pairs_target_mat = matrix(c("end.3", "end.1", "elt.7"), nrow = 1))

##################################################################################################################################################################
# Create the systematic network 
# a. lineage network (MI + RDI for data points in the same cell)
# b. committment network (MI + RDI for data points from progenitors to the daughters)
##################################################################################################################################################################

# a. lineage network (MI + RDI for data points in the same cell)
valid_cells <- c('E', 'Ea', 'Eal', 'Eala', 'Ealp', 'Ear', 'Eara', 'Earp', 'Ep', 'Epl', 'Epla', 'Eplp', 'Epr', 'Epra', 'Eprp')
expr_threshold <- 0

for(curr_cell in valid_cells) {
  message('current_cell is ', curr_cell)
  subset_cell_res <- subset(uMI_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell) #uMI from fig6_worm 
  # qplot(as.numeric(exprs(c_elegans_cds['sea.1', pData(c_elegans_cds)$cell == 'Ea'])), as.numeric(exprs(c_elegans_cds['aly.1', pData(c_elegans_cds)$cell == 'Ea'])))
  # df <- data.frame(time = pData(c_elegans_cds[, pData(c_elegans_cds)$cell == curr_cell])$time, 
  #                  source = as.numeric(exprs(c_elegans_cds['sea.1', pData(c_elegans_cds)$cell == curr_cell])),
  #                  target = as.numeric(exprs(c_elegans_cds['aly.1', pData(c_elegans_cds)$cell == curr_cell])))
  # qplot(time, source, data = df, color = I('red')) + geom_point(aes(time, target), color = 'blue')
  subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == curr_cell]
  cur_gene_gene_pairs <- unique(as.character(subset_cell_res$source, subset_cell_cds$target))
  causality_res <- calculate_rdi(subset_cell_cds[cur_gene_gene_pairs, ], delays = 1:5, log = F)
  
  adj_mat <- causality_res$max_rdi_value
  diag(adj_mat) <- 0
  # adj_mat[adj_mat < t(adj_mat)] <- 0
  
  adj_mat_cp <- adj_mat
  adj_mat_cp[adj_mat_cp != 0] <- 0
  
  for(i in 1:nrow(subset_cell_res)) { 
    source <- as.character(subset_cell_res[i, 'source'])
    target <- as.character(subset_cell_res[i, 'target'])
    
    adj_mat_cp[source, target] <- adj_mat[source, target]
  }
  
  col_means <- colMeans(adj_mat_cp)
  col_sd <- apply(adj_mat_cp, 2, sd)
  col_sd[col_sd == 0] <- 1e-4
  
  adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
    row_i <- adj_mat_cp[x, ]
    row_sd <- sd(row_i) 
    row_sd[row_sd == 0] <- 1e-4
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
    
    sqrt(s_i_vec^2 + s_j_vec^2)
  })
  
  adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
  dimnames(adj_mat_cp2) <- dimnames(adj_mat)
  # visualize TF network with the top genes 
  z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
  
  if(nrow(adj_mat_cp2) > 8) {
    z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
    z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
    
  }
  adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
  
  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
  
  # remove zero-input/out-genes: 
  adj_col_sum <- colSums(adj_mat_cp2)
  adj_row_sum <- rowSums(adj_mat_cp2)
  olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
  if(length(olphan_genes) > 0)
    adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
  
  g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
  V(g)$name <- convert_to_true_ids(V(g)$name)
  
  pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'))
  plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
  dev.off()
  
  V(g)$hubness <- hub_score(g)$vector 
  
  pdf(paste0('./Figures/main_figures/', curr_cell, '_lineage_net.pdf'), height = 15, width = 15)
  print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
    geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                  ends = "last", type = "open")) + 
    scale_edge_width(range = c(0.2, 2)) +
    geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
    labs(edge_width = "Causality") +
    theme_graph())
  dev.off()
}

# b. committment network (MI + RDI for data points from progenitors to the daughters)
for(curr_cell in valid_cells) {
  message('current_cell is ', curr_cell)
  reachable_cells <- V(graph.neighborhood(lineage_tree, 1, nodes = curr_cell, 'out')[[1]])$name
  
  p_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[1]))
  a_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[2]))
  b_mathced_cells <- row.names(subset(pData(c_elegans_cds), cell == reachable_cells[3]))
  
  subset_cds <- cds[, c(p_mathced_cells, a_mathced_cells, b_mathced_cells)] #
  
  pData(subset_cds)[p_mathced_cells[seq(1, length(p_mathced_cells), 2)], 'Lineage'] <- 'A'
  pData(subset_cds)[p_mathced_cells[seq(2, length(p_mathced_cells), 2)], 'Lineage'] <- 'B'
  pData(subset_cds)[a_mathced_cells, 'Lineage'] <- 'A'
  pData(subset_cds)[b_mathced_cells, 'Lineage'] <- 'B'
  
  exprs_mat <- log(as.matrix(exprs(subset_cds)) + abs(min(exprs(subset_cds))) + 1)
  pd <- new("AnnotatedDataFrame", data = pData(subset_cds))
  fd <- new("AnnotatedDataFrame", data = fData(subset_cds))
  
  # Now, make a new CellDataSet using the RNA counts
  subset_cds <- newCellDataSet(as(exprs_mat, 'sparseMatrix'), 
                               phenoData = pd,
                               featureData = fd,
                               lowerDetectionLimit=0,
                               expressionFamily=gaussianff())
  
  res <- differentialGeneTest(subset_cds, fullModelFormulaStr = "~sm.ns(time, df = 3) * Lineage", reducedModelFormulaStr = "~sm.ns(time, df = 3)")
  
  ############################## first daugther commitment ##############################
  
  subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == reachable_cells[1:2]]
  cur_genes <- row.names(subset(res, qval < 0.1))
  causality_res <- calculate_rdi(subset_cell_cds[cur_genes, ], delays = 1:5, log = F)
  
  adj_mat <- causality_res$max_rdi_value
  diag(adj_mat) <- 0
  # adj_mat[adj_mat < t(adj_mat)] <- 0 # do not use this normalization 
  
  adj_mat_cp <- adj_mat
  adj_mat_cp[adj_mat_cp != 0] <- 0
  
  umi_res <- parmigene::knnmi.all(as.matrix(exprs(subset_cell_cds[cur_genes, ])))
  mlt_umi_res <- melt(umi_res)
  colnames(mlt_umi_res) <- c('source', 'target', 'uMI')
  
  mlt_umi_res$current_cell <- current_cell
  
  avg_exprs <- rowMeans(as.matrix(exprs(subset_cds))) 
  mlt_umi_res$avg_source <- avg_exprs[mlt_umi_res$source]
  mlt_umi_res$avg_target <- avg_exprs[mlt_umi_res$target]
  
  subset_cell_res <- subset(mlt_umi_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell)
  
  for(i in 1:nrow(mlt_umi_res)) { 
    source <- as.character(mlt_umi_res[i, 'source'])
    target <- as.character(mlt_umi_res[i, 'target'])
    
    adj_mat_cp[source, target] <- adj_mat[source, target]
  }
  
  col_means <- colMeans(adj_mat_cp)
  col_sd <- apply(adj_mat_cp, 2, sd)
  col_sd[col_sd == 0] <- 1e-4
  
  adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
    row_i <- adj_mat_cp[x, ]
    row_sd <- sd(row_i) 
    row_sd[row_sd == 0] <- 1e-4
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
    
    sqrt(s_i_vec^2 + s_j_vec^2)
  })
  
  adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
  # visualize TF network with the top genes 
  z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
  if(nrow(adj_mat_cp2) > 8) {
    z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
    z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
  }
  adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
  
  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
  
  # remove zero-input/out-genes: 
  adj_col_sum <- colSums(adj_mat_cp2)
  adj_row_sum <- rowSums(adj_mat_cp2)
  olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
  if(length(olphan_genes) > 0)
    adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
  
  g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
  V(g)$name <- convert_to_true_ids(V(g)$name)
  
  pdf(paste0('./Figures/main_figures/', reachable_cells[2], '_fate_net.pdf'))
  plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
  dev.off()
  
  V(g)$hubness <- -hub_score(g)$vector 
  message('before ggraph')
  
  pdf(paste0('./Figures/main_figures/', reachable_cells[2], '_fate_net.pdf'), height = 15, width = 15)
  print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
    geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                  ends = "last", type = "open")) + 
    scale_edge_width(range = c(0.2, 2)) +
    geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
    labs(edge_width = "Causality") +
    theme_graph())
  dev.off()
  
  ############################## second daugther commitment ##############################
  
  subset_cell_cds <- c_elegans_cds[, pData(c_elegans_cds)$cell == reachable_cells[c(1, 3)]]
  cur_genes <- row.names(subset(res, qval < 0.1))
  causality_res <- calculate_rdi(subset_cell_cds[cur_genes, ], delays = 1:5, log = F)
  
  adj_mat <- causality_res$max_rdi_value
  diag(adj_mat) <- 0
  # adj_mat[adj_mat < t(adj_mat)] <- 0
  
  adj_mat_cp <- adj_mat
  adj_mat_cp[adj_mat_cp != 0] <- 0
  
  umi_res <- parmigene::knnmi.all(as.matrix(exprs(subset_cell_cds[cur_genes, ])))
  mlt_umi_res <- melt(umi_res)
  colnames(mlt_umi_res) <- c('source', 'target', 'uMI')
  
  mlt_umi_res$current_cell <- current_cell
  
  avg_exprs <- rowMeans(as.matrix(exprs(subset_cds))) 
  mlt_umi_res$avg_source <- avg_exprs[mlt_umi_res$source]
  mlt_umi_res$avg_target <- avg_exprs[mlt_umi_res$target]
  
  subset_cell_res <- subset(mlt_umi_res, avg_source > expr_threshold & avg_target > expr_threshold & uMI > 1 & current_cell == curr_cell)
  
  for(i in 1:nrow(mlt_umi_res)) { 
    source <- as.character(mlt_umi_res[i, 'source'])
    target <- as.character(mlt_umi_res[i, 'target'])
    
    adj_mat_cp[source, target] <- adj_mat[source, target]
  }
  
  col_means <- colMeans(adj_mat_cp)
  col_sd <- apply(adj_mat_cp, 2, sd)
  col_sd[col_sd == 0] <- 1e-4
  
  adj_mat_cp_tmp <- lapply(1:nrow(adj_mat_cp), function(x) {
    row_i <- adj_mat_cp[x,]
    row_sd <- sd(row_i) 
    row_sd[row_sd == 0] <- 1e-4
    s_i_vec <- pmax(0, (row_i - mean(row_i)) / row_sd)
    s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
    
    sqrt(s_i_vec^2 + s_j_vec^2)
  })
  
  adj_mat_cp2 <- do.call(rbind, adj_mat_cp_tmp) 
  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
  # visualize TF network with the top genes 
  z_threshold <- min(adj_mat_cp2[adj_mat_cp2 > 0])
  if(nrow(adj_mat_cp2) > 8) {
    z_threshold <- adj_mat_cp2[order(adj_mat_cp2, decreasing = T)[50]]
    z_threshold <- max(min(adj_mat_cp2[adj_mat_cp2 > 0]), z_threshold)
    
    # 
  }
  adj_mat_cp2[adj_mat_cp2 < z_threshold] <- 0
  
  dimnames(adj_mat_cp2) <- dimnames(adj_mat_cp)
  
  # remove zero-input/out-genes: 
  adj_col_sum <- colSums(adj_mat_cp2)
  adj_row_sum <- rowSums(adj_mat_cp2)
  olphan_genes <- which(adj_col_sum + adj_row_sum == 0)
  if(length(olphan_genes) > 0)
    adj_mat_cp2 <- adj_mat_cp2[-olphan_genes, -olphan_genes]
  
  g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat_cp2), weighted = T, mode = "direct")
  V(g)$name <- convert_to_true_ids(V(g)$name)
  
  pdf(paste0('./Figures/main_figures/', reachable_cells[3], '_fate_net.pdf'))
  plot.igraph(g, edge.width=E(g)$weight, edge.curved=TRUE)
  dev.off()
  
  V(g)$hubness <- -hub_score(g)$vector 
  message('before ggraph')
  
  pdf(paste0('./Figures/main_figures/', reachable_cells[3], '_fate_net.pdf'), height = 15, width = 15)
  print(ggraph(g, layout = "linear", sort.by = "hubness", circular = F) + 
    geom_edge_arc(aes(width = weight), alpha = 0.3, arrow = arrow(angle = 30, length = unit(0.1, "inches"),
                                                                  ends = "last", type = "open")) + 
    scale_edge_width(range = c(0.2, 2)) +
    geom_node_text(aes(label = V(g)$name), check_overlap = T, size = 3,repel = T) +
    labs(edge_width = "Causality") +
    theme_graph())
  dev.off()
  # res <- differentialGeneTest(subset_cds, fullModelFormulaStr = "~Lineage", reducedModelFormulaStr = "~1")
  
  # df <- data.frame(lineage = pData(subset_cds)[, 'Lineage'], 
  #                  expression = c(exprs(subset_cds)["F37B4.10", ]),
  #                  time = pData(subset_cds)[, 'time']
  #                  )
  # qplot(time, expression, data = df, color = lineage, facets = "~lineage")
  # qplot(time, expression, data = df, color = lineage)
}

##################################################################################################################################################################
# make sense of the network 
##################################################################################################################################################################
E_lineage_genes <- c("mom.5", "mes.1", "pal.1", "tbx.35", "end.3", "end.1", "ceh.51", "wee1.1", "elt.2", "elt.7", "ges.1", "pho.1", "pha.4")
  
##################################################################################################################################################################
# Create the cell type-specific network 
##################################################################################################################################################################

##########################################################################################################################################################
# get the network from Jonathan's ChIP-seq data (43 overlapping; 286 total)
##########################################################################################################################################################
gene_promoter_ChIP <- read.table('./csv_data/c_elegans/gene_promoter_ChIP.tsv', header = T, row.names = 1)
EM_ids <- colnames(gene_promoter_ChIP)[grep("_E", colnames(gene_promoter_ChIP))]
gene_promoter_ChIP_EM <- gene_promoter_ChIP[, EM_ids]
colnames(gene_promoter_ChIP_EM) <- str_split_fixed(colnames(gene_promoter_ChIP_EM), pattern = "EM", n = 2)[, 1] 

genes_with_chip_seq <- colnames(c_elegans_data)[tolower(colnames(c_elegans_data)) %in% tolower(colnames(gene_promoter_ChIP_EM))]
colnames(gene_promoter_ChIP_EM)[tolower(colnames(gene_promoter_ChIP_EM)) %in% tolower(colnames(c_elegans_data))]
gene_promoter_ChIP_EM_valid <- gene_promoter_ChIP_EM[, toupper(genes_with_chip_seq)]

##########################################################################################################################################################
# do the network for all seven major lineages 
##########################################################################################################################################################
# AB, C, D, E, MS, P, Z lineages 
AB_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^AB', unique(c_elegans_data_ori$cell))])
C_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^C', unique(c_elegans_data_ori$cell))])
D_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^D', unique(c_elegans_data_ori$cell))])
E_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^E', unique(c_elegans_data_ori$cell))])
MS_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^MS', unique(c_elegans_data_ori$cell))])
P_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^P', unique(c_elegans_data_ori$cell))])
Z_cells <- as.character(unique(c_elegans_data_ori$cell)[grep('^Z', unique(c_elegans_data_ori$cell))])

# identify terminal cells: 
AB_cells_terminal <- AB_cells[unlist(lapply(AB_cells, function(x) {x_remaining <- setdiff(AB_cells, x); length(grep(x, x_remaining)) == 0}))]
C_cells_terminal <- C_cells[unlist(lapply(C_cells, function(x) {x_remaining <- setdiff(C_cells, x); length(grep(x, x_remaining)) == 0}))]
D_cells_terminal <- D_cells[unlist(lapply(D_cells, function(x) {x_remaining <- setdiff(D_cells, x); length(grep(x, x_remaining)) == 0}))]
E_cells_terminal <- E_cells[unlist(lapply(E_cells, function(x) {x_remaining <- setdiff(E_cells, x); length(grep(x, x_remaining)) == 0}))]
MS_cells_terminal <- MS_cells[unlist(lapply(MS_cells, function(x) {x_remaining <- setdiff(MS_cells, x); length(grep(x, x_remaining)) == 0}))]
P_cells_terminal <- P_cells[unlist(lapply(P_cells, function(x) {x_remaining <- setdiff(P_cells, x); length(grep(x, x_remaining)) == 0}))]
Z_cells_terminal <- Z_cells[unlist(lapply(Z_cells, function(x) {x_remaining <- setdiff(Z_cells, x); length(grep(x, x_remaining)) == 0}))]

data_stat <- data.frame(count = c(length(AB_cells_terminal), 
                                  length(C_cells_terminal), 
                                  length(D_cells_terminal), 
                                  length(E_cells_terminal), 
                                  length(MS_cells_terminal), 
                                  length(P_cells_terminal), 
                                  length(Z_cells_terminal)), 
                        Type = c('AB', 'C', 'D', 'E', 'MS', 'P', 'Z'))

CreatesWormImageCDS <- function(c_elegans_data_ori, cell_ids) {
  cell_lineage_ids <- get_cell_lineage(cell_ids)  
  
  test_c_elegans_data_ori <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids) # === cell_id
  
  test_c_elegans_data <- t(test_c_elegans_data_ori[, -c(1:6)])
  colnames(test_c_elegans_data) <- subset(c_elegans_data_ori, cell %in% cell_lineage_ids)[, 'time']
  
  # function to create a time series starting from the very beginning: 
  pData <- test_c_elegans_data_ori[, 1:6]
  row.names(pData) <- test_c_elegans_data_ori$time
  pData$Pseudotime <- pData$time
  pd <- new("AnnotatedDataFrame", data = pData)
  fData <- data.frame(gene_short_name = colnames(test_c_elegans_data_ori)[-c(1:6)], row.names = colnames(test_c_elegans_data_ori)[-c(1:6)])
  fd <- new("AnnotatedDataFrame", data = fData)
  
  # Now, make a new CellDataSet using the RNA counts
  test_c_elegans_data[!is.finite(test_c_elegans_data)] <- 0 # remove NaN values
  test_cds <- newCellDataSet(test_c_elegans_data, 
                             phenoData = pd, 
                             featureData = fd,
                             lowerDetectionLimit=1,
                             expressionFamily=gaussianff())
  return(test_cds)
}

for(i in D_cells_terminal) {
  current_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = i)
  
  test_rdi_res <- calculate_rdi(current_cds[, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
  con_test_rdi_res <- calculate_conditioned_rdi(test_cds[, ], rdi_list = test_rdi_res, uniformalize = T, top_incoming_k = 2, log = F) #muscle_genes
  
}

# create the network for each lineage 
AB_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = AB_cells_terminal[1])
C_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = C_cells_terminal[1])
D_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = D_cells_terminal[1])
E_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = E_cells_terminal[1])
MS_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = MS_cells_terminal[1])
P_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = P_cells_terminal[1])
Z_cds <- CreatesWormImageCDS(c_elegans_data_ori, cell_ids = Z_cells_terminal[1])

## 
# lineage specific genes: 
epidermal_gene <- c('elt.1', 'lin.26', 'elt.3')
lineage_specific_genes <- c(muscle_genes, c_lineage_genes, EMS_lineage_genes, intestine_gene, epidermal_gene)  
lineage_specific_genes <- lineage_specific_genes[lineage_specific_genes %in% row.names(AB_cds)]

# gene_num <- 1:74 
gene_num <- lineage_specific_genes
AB_rdi_res_all <- calculate_rdi(AB_cds[, ], delays = c(5), uniformalize = F, log = F)

AB_rdi_res <- calculate_rdi(AB_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
C_rdi_res <- calculate_rdi(C_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
D_rdi_res <- calculate_rdi(D_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
E_rdi_res <- calculate_rdi(E_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
MS_rdi_res <- calculate_rdi(MS_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)
P_rdi_res <- calculate_rdi(P_cds[gene_num, ], delays = c(1, 5), uniformalize = F, log = F)
Z_rdi_res <- calculate_rdi(Z_cds[gene_num, ], delays = c(1, 5, 10, 15, 20), uniformalize = F, log = F)

# gene_names <- row.names(AB_cds)[1:74]
gene_names <- lineage_specific_genes
casuality_mat_list <- list(AB_rdi_res$max_rdi_value[gene_names, gene_names], 
                           C_rdi_res$max_rdi_value[gene_names, gene_names],
                           D_rdi_res$max_rdi_value[gene_names, gene_names],
                           E_rdi_res$max_rdi_value[gene_names, gene_names],
                           MS_rdi_res$max_rdi_value[gene_names, gene_names],
                           P_rdi_res$max_rdi_value[gene_names, gene_names],
                           Z_rdi_res$max_rdi_value[gene_names, gene_names])

cds_list <- list(AB_cds[gene_names, ], 
                 C_cds[gene_names, ],
                 D_cds[gene_names, ],
                 E_cds[gene_names, ],
                 MS_cds[gene_names, ],
                 P_cds[gene_names, ],
                 Z_cds[gene_names, ])

group_names <- c('AB', 'C', 'D', 'E', 'MS', 'P', 'Z')

# show gene causality between lineage specific genes: muscle_genes, c_lineage_genes, EMS_lineage_genes, intestine_gene, epidermal_gene
pdf(paste0(main_fig_dir, 'c_elegans_lineage_networks.pdf'), width =  1.2, height = 1.2)
plot_hive_network(gene_names, casuality_mat_list[1:6], cds_list[1:6], group_names[1:6], top_edge_num = 100)
dev.off()

pdf(paste0(main_fig_dir, 'c_elegans_lineage_networks_2.pdf'), width =  1.2, height = 1.2)
plot_hive_network(gene_names, casuality_mat_list[1:6], cds_list[1:6], group_names[1:6], top_edge_num = 25)
dev.off()
##################################################################################################################################################################
# Compare the results with the ChIP-seq data 
##################################################################################################################################################################

casuality_mat_list[[1]]
gene_promoter_ChIP_EM_valid

dimnames(AB_rdi_res_all$max_rdi_value) <- list(tolower(row.names(AB_rdi_res_all$max_rdi_value)), tolower(row.names(AB_rdi_res_all$max_rdi_value)))
dimnames(gene_promoter_ChIP_EM_valid) <- list(tolower(row.names(gene_promoter_ChIP_EM_valid)), tolower(colnames(gene_promoter_ChIP_EM_valid)))
overlapping_ChIP_gene <- intersect(row.names(AB_rdi_res_all$max_rdi_value), colnames(gene_promoter_ChIP_EM_valid))
setdiff_ChIP_gene <- setdiff(row.names(AB_rdi_res_all$max_rdi_value), colnames(gene_promoter_ChIP_EM_valid))

ChIP_res <- c()
for(current_gene in overlapping_ChIP_gene) {
  valid_target <- intersect(row.names(gene_promoter_ChIP_EM_valid)[gene_promoter_ChIP_EM_valid[, current_gene] > 0], row.names(AB_rdi_res_all$max_rdi_value))
  ChIP_res <- c(ChIP_res, AB_rdi_res_all$max_rdi_value[current_gene, valid_target])
  
}

df <- data.frame(value = c(as.numeric(ChIP_res), 
                           as.numeric(AB_rdi_res_all$max_rdi_value[setdiff_ChIP_gene, ])),
                 Type = c(rep("ChIP-seq", length(ChIP_res)), 
                          rep("others", length(AB_rdi_res_all$max_rdi_value[setdiff_ChIP_gene, ])))
)

# AB lineage do this for all gene interactions? 
pdf(paste0(main_fig_dir, 'chip-seq.pdf'), width =  1, height = 1)
qplot(Type, value, data = df, geom = 'boxplot', color = Type) + xlab('') +  ylab('Causality') + xacHelper::nm_theme() + theme(axis.text.x = element_text(angle = 30))# + xlim(0) , color = Type
dev.off()

##################################################################################################################################################################
# save the results 
##################################################################################################################################################################
save.image('./RData/analysis_E_lineage.RData')

