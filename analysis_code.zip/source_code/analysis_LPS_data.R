#analyze the Aviv LPS dataset: 
library(monocle)
library(plyr)

load('/Users/xqiu/Dropbox (Personal)/Projects/BEAM/RData/analysis_shalek_data.RData')
Shalek_abs <- relative2abs(Shalek_std, estimate_t(Shalek_std), verbose = T) #
pd <- new("AnnotatedDataFrame", data = pData(Shalek_std))
fd <- new("AnnotatedDataFrame", data = fData(Shalek_std))
Shalek_abs <- newCellDataSet(as.matrix(Shalek_abs), 
                              phenoData = pd, 
                              featureData = fd, 
                              expressionFamily=negbinomial(), 
                              lowerDetectionLimit=1)
pData(Shalek_abs)$Total_mRNAs <- colSums(exprs(Shalek_abs))

#Calculate size factors and dispersions
Shalek_abs = estimateSizeFactors(Shalek_abs)
Shalek_abs = estimateDispersions(Shalek_abs)

# Filter to only expressed genes (feel free to change this as needed, I have tried several methods)
Shalek_abs = detectGenes(Shalek_abs, min_expr = 1)

Shalek_abs_subset_ko_LPS <- Shalek_abs[, pData(Shalek_abs)$experiment_name %in% c('Ifnar1_KO_LPS', 'Stat1_KO_LPS',  "LPS", "Unstimulated_Replicate")]
pData(Shalek_abs_subset_ko_LPS)[, 'stim_time'] <- as.character(pData(Shalek_abs_subset_ko_LPS)$time)
pData(Shalek_abs_subset_LPS)$stim_time <- as.character(pData(Shalek_abs_subset_LPS)$stim_time)

pData(Shalek_abs_subset_ko_LPS)$stim_time[pData(Shalek_abs_subset_ko_LPS)$stim_time == ''] <- 0
pData(Shalek_abs_subset_ko_LPS)$stim_time <- as.integer(revalue(pData(Shalek_abs_subset_ko_LPS)$stim_time, c("1h" = 1, "2h" = 2, "4h" = 4, "6h" = 6)))
Shalek_abs_subset_ko_LPS <- detectGenes(Shalek_abs_subset_ko_LPS, min_expr = 0.1)

################################################################################################################################################################
# run dpFeature to reconstruct the trajectory 
################################################################################################################################################################
#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05
qval_thrsld <- 0.1

Shalek_abs_subset_ko_LPS <- detectGenes(Shalek_abs_subset_ko_LPS)
fData(Shalek_abs_subset_ko_LPS)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(Shalek_abs_subset_ko_LPS)) #
fData(Shalek_abs_subset_ko_LPS)$use_for_ordering[fData(Shalek_abs_subset_ko_LPS)$num_cells_expressed > num_cells_expressed] <- T

Shalek_abs_subset_ko_LPS@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(Shalek_abs_subset_ko_LPS, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# Shalek_abs_subset_ko_LPS <- setOrderingFilter(Shalek_abs_subset_ko_LPS, quake_id)
Shalek_abs_subset_ko_LPS <- reduceDimension(Shalek_abs_subset_ko_LPS, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 15,  verbose = T) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
Shalek_abs_subset_ko_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_ko_LPS, verbose = T)

#4. check the clusters 
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'experiment_name', show_density = F)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'stimulation', show_density = F)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'time', show_density = F)

#5. also check the decision plot 
plot_rho_delta(Shalek_abs_subset_ko_LPS, rho_threshold = 10, delta_threshold = 5)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'experiment', rho_threshold = 10, delta_threshold = 5)

#6. re-run cluster and skipping calculating the rho_sigma 
Shalek_abs_subset_ko_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_ko_LPS, verbose = T,  rho_threshold = 10, delta_threshold = 5, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(experiment_name)', show_density = F)

#perform DEG test across clusters: 
Shalek_abs_subset_ko_LPS@expressionFamily <- negbinomial.size()
pData(Shalek_abs_subset_ko_LPS)$Cluster <- factor(pData(Shalek_abs_subset_ko_LPS)$Cluster)
Shalek_abs_subset_ko_LPSclustering_DEG_genes <- differentialGeneTest(Shalek_abs_subset_ko_LPS, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

Shalek_abs_subset_ko_LPSclustering_DEG_genes_subset <- Shalek_abs_subset_ko_LPSclustering_DEG_genes[fData(Shalek_abs_subset_ko_LPS)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
Shalek_abs_subset_ko_LPSordering_genes <- row.names(subset(Shalek_abs_subset_ko_LPSclustering_DEG_genes, qval < qval_thrsld))

# 
Shalek_abs_subset_ko_LPSordering_genes <- row.names(Shalek_abs_subset_ko_LPSclustering_DEG_genes_subset)[order(Shalek_abs_subset_ko_LPSclustering_DEG_genes_subset$qval)][1:1000] 

Shalek_abs_subset_ko_LPS <- setOrderingFilter(Shalek_abs_subset_ko_LPS, ordering_genes = Shalek_abs_subset_ko_LPSordering_genes)
Shalek_abs_subset_ko_LPS <- reduceDimension(Shalek_abs_subset_ko_LPS, verbose = T)
Shalek_abs_subset_ko_LPS <- orderCells(Shalek_abs_subset_ko_LPS)

plot_cell_trajectory(Shalek_abs_subset_ko_LPS, color_by = 'experiment_name') 
plot_cell_trajectory(Shalek_abs_subset_ko_LPS, color_by = 'State') 
plot_cell_trajectory(Shalek_abs_subset_ko_LPS, color_by = 'Pseudotime') 
Shalek_abs_subset_ko_LPS <- orderCells(Shalek_abs_subset_ko_LPS, root_state = 2)

################################################################################################################################################################
# run MAGIC for downstream analysis 
################################################################################################################################################################
Shalek_abs_subset_LPS <- Shalek_abs_subset_ko_LPS[, pData(Shalek_abs_subset_ko_LPS)$experiment_name %in% c('LPS')]

#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05
qval_thrsld <- 0.1

Shalek_abs_subset_LPS <- detectGenes(Shalek_abs_subset_LPS)
fData(Shalek_abs_subset_LPS)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(Shalek_abs_subset_LPS)) #
fData(Shalek_abs_subset_LPS)$use_for_ordering[fData(Shalek_abs_subset_LPS)$num_cells_expressed > num_cells_expressed] <- T

Shalek_abs_subset_LPS@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(Shalek_abs_subset_LPS, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# Shalek_abs_subset_LPS <- setOrderingFilter(Shalek_abs_subset_LPS, quake_id)
Shalek_abs_subset_LPS <- reduceDimension(Shalek_abs_subset_LPS, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 3,  verbose = T) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
Shalek_abs_subset_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_LPS, verbose = T)

#4. check the clusters 
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'experiment_name', show_density = F)
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'stimulation', show_density = F)
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'time', show_density = F)

#5. also check the decision plot 
plot_rho_delta(Shalek_abs_subset_LPS, rho_threshold = 4, delta_threshold = 10)
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'experiment', rho_threshold = 4, delta_threshold = 10)

#6. re-run cluster and skipping calculating the rho_sigma 
Shalek_abs_subset_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_LPS, verbose = T,  rho_threshold = 4, delta_threshold = 10, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset_LPS, color_by = 'as.factor(time)', show_density = F)

#perform DEG test across clusters: 
Shalek_abs_subset_LPS@expressionFamily <- negbinomial.size()
pData(Shalek_abs_subset_LPS)$Cluster <- factor(pData(Shalek_abs_subset_LPS)$Cluster)
Shalek_abs_subset_LPSclustering_DEG_genes <- differentialGeneTest(Shalek_abs_subset_LPS, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

##################################################
# use the stim_time for DEG test
##################################################
Shalek_abs_subset_LPSclustering_DEG_genes <- differentialGeneTest(Shalek_abs_subset_LPS, fullModelFormulaStr = '~stim_time', cores = detectCores() - 2)

Shalek_abs_subset_LPSclustering_DEG_genes_subset <- Shalek_abs_subset_LPSclustering_DEG_genes[fData(Shalek_abs_subset_LPS)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
Shalek_abs_subset_LPSordering_genes <- row.names(subset(Shalek_abs_subset_LPSclustering_DEG_genes, qval < qval_thrsld))

# 
Shalek_abs_subset_LPSordering_genes <- row.names(Shalek_abs_subset_LPSclustering_DEG_genes_subset)[order(Shalek_abs_subset_LPSclustering_DEG_genes_subset$qval)][1:200] 

Shalek_abs_subset_LPS <- setOrderingFilter(Shalek_abs_subset_LPS, ordering_genes = Shalek_abs_subset_LPSordering_genes)
Shalek_abs_subset_LPS <- reduceDimension(Shalek_abs_subset_LPS, verbose = T, norm_method = 'log', param.gamma = 50)
Shalek_abs_subset_LPS <- orderCells(Shalek_abs_subset_LPS)

plot_cell_trajectory(Shalek_abs_subset_LPS, color_by = 'State') 
plot_cell_trajectory(Shalek_abs_subset_LPS, color_by = 'experiment_name') 
plot_cell_trajectory(Shalek_abs_subset_LPS, color_by = 'time') 
plot_cell_trajectory(Shalek_abs_subset_LPS, color_by = 'Pseudotime') 

Shalek_abs_subset_LPS <- orderCells(Shalek_abs_subset_LPS, reverse = T)

################################################################################################################################################################
# save the dataset 
################################################################################################################################################################
grn_fig4a <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Rbl1", "Usp25", "Daxx", "Cd40", "Atm", "Irf1", "Ligp2", "Mertk", "Cxcl11", "Trim12a", "Trim21", "NfkbIz")
grn_fig4b <- c("NFKBIZ", "ATF4", "ATF4", "Ilf2b", "FUS", "RBL1", "RBL1", "ligp1", "CBX4", "DNMT3A", "DNMT3A", "Ifnb1", "NFKBIZ", "FOS", "FOS", "Il12b", "JUN", "FUS", "FUS", "IFNB1", "FUS", "NFkbIz", "NFKBIZ", "FOS", "CBX4", "STAT1", "STAT1", "IFnb1", "CEBPZ", "HHEX", "HHEX", "IL12b")
grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")

grn_all_genes <- c(grn_fig4a, grn_fig4b, grn_fig4c) 
LPS_network <- read.table('./csv_data/LPS_network', header = T)

grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_all_genes)))
missing_genes <- grn_all_genes[!(toupper(grn_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

all_network_genes <- c(as.character(LPS_network$Source), as.character(LPS_network$Target))
network_missing_genes <- all_network_genes[!(toupper(c(all_network_genes)) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

top_group <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "FUS")
bottom_group <- c("Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Usp25", "Daxx", "Cd40", "Atm", "Lrf1", "Lgp2", "Mertk", "Cxcl11", "Trim12", "Trim21")

top_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(top_group)))
fData(Shalek_abs_subset_ko_LPS)[grn_ids, 'gene_short_name']
bottom_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(bottom_group)))
fData(Shalek_abs_subset_ko_LPS)[bottom_group_ids, 'gene_short_name']

order_LPS_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
pd <- pData(Shalek_abs_subset_LPS[grn_ids, colnames(order_LPS_mat)])
fd <- fData(Shalek_abs_subset_LPS[grn_ids, ])

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_phenotype_data.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data.txt', order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)

grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV8", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")
fig4c_layer1 <- c("Tlr2", "Tlr3", "Tlr4")
fig4c_layer2.1 <- c("STAT1", "STAT2", "IRF8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1")
fig4c_layer2.2 <- c("PLAGL2", "NFKB1", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2")
fig4c_layer3.1 <- c("HMGN3", "FUS", "SAP30")
fig4c_layer3.2 <- c("NFE2L2", "IRF4", "FOS")
fig4c_layer4.1 <- c("CXCL10", "Ifnb1", "IL15")
fig4c_layer4.2 <- c("IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3")

#only the small network: 
LPS_subset_network <- read.table('./csv_data/LPS_subset_network', header = T)

grn_subset_all_genes <- c(as.character(LPS_subset_network$Source), as.character(LPS_subset_network$Target))
subset_grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_subset_all_genes)))
missing_genes <- grn_subset_all_genes[!(toupper(grn_subset_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

order_LPS_subset_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[subset_grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_LPS_subset_mat.txt', order_LPS_subset_mat, col.names = T, sep = '\t', row.names = T, quote = F)

plot_genes_in_pseudotime(Shalek_abs_subset_LPS[top_group_ids, ])

################################################################################################################################################################
# run MAGIC 
################################################################################################################################################################
gene_ordering_id <- unique(c(row.names(Shalek_abs_subset_LPS)[fData(Shalek_abs_subset_LPS)$use_for_ordering], grn_ids))
LPS_wt_exprs_magic <- MAGIC_R(t(as.matrix(exprs(Shalek_std[gene_ordering_id, colnames(Shalek_abs_subset_LPS)]))), knn_autotune = 3, knn=9, t = 3) #knn = 3

LPS_wt_exprs_magic <- as.data.frame(t(LPS_wt_exprs_magic))
dimnames(LPS_wt_exprs_magic) <- dimnames(Shalek_abs_subset_LPS[gene_ordering_id, ])

pd <- new("AnnotatedDataFrame", data = pData(Shalek_abs_subset_LPS))
fd <- new("AnnotatedDataFrame", data = fData(Shalek_abs_subset_LPS[gene_ordering_id, ]))
Shalek_abs_subset_LPS2 <-  newCellDataSet(as(as.matrix(LPS_wt_exprs_magic), 'sparseMatrix'), 
                                   phenoData = pd, 
                                   featureData = fd, 
                                   expressionFamily=negbinomial.size(), 
                                   lowerDetectionLimit=1)
pData(Shalek_abs_subset_LPS2)$Total_mRNAs <- colSums(exprs(Shalek_abs_subset_LPS2))

Shalek_abs_subset_LPS2 <- estimateSizeFactors(Shalek_abs_subset_LPS2)
Shalek_abs_subset_LPS2 <- estimateDispersions(Shalek_abs_subset_LPS2)

Shalek_abs_subset_LPS2 <- reduceDimension(Shalek_abs_subset_LPS2, verbose = T, auto_param_selection = F, param.gamma = 50)
Shalek_abs_subset_LPS2 <- orderCells(Shalek_abs_subset_LPS2)

plot_cell_trajectory(Shalek_abs_subset_LPS2, color_by = 'State') 
plot_cell_trajectory(Shalek_abs_subset_LPS2, color_by = 'experiment_name') 
plot_cell_trajectory(Shalek_abs_subset_LPS2, color_by = 'time') 
plot_cell_trajectory(Shalek_abs_subset_LPS2, color_by = 'Pseudotime') 

order_LPS_mat_magic <- as.matrix(exprs(Shalek_abs_subset_LPS2)[grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
pd <- pData(Shalek_abs_subset_LPS[grn_ids, colnames(order_LPS_mat)])
fd <- fData(Shalek_abs_subset_LPS[grn_ids, ])

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_magic.txt', order_LPS_mat_magic, col.names = T, sep = '\t', row.names = T, quote = F)

################################################################################################################################################################
# use the new network 
################################################################################################################################################################
TF_hiearchy <- read.table('./csv_data/TF_hiearchy.txt', header = T, row.names = 1)

gene_names <- colnames(TF_hiearchy)
gene_ids <- row.names(subset(fData(Shalek_abs_subset_LPS), gene_short_name %in% gene_names))
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(row.names(subset(fData(Shalek_abs_subset_LPS), gene_short_name %in% gene_id1))), 
                     Gene_1_NAME = c(gene_id1), Gene_2_ID = c(row.names(subset(fData(Shalek_abs_subset_LPS), gene_short_name %in% gene_id2))),
                     Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     HT_seq = TF_hiearchy[gene_id1, gene_id2] )
    write.table(file = 'TF_hiearchy_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

ht_chip_order_LPS_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[gene_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
fd <- fData(Shalek_abs_subset_LPS[gene_ids, ])

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_ht_chip_order_LPS_mat.txt', ht_chip_order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)

################################################################################################################################################################
# run CCM and granger causality
################################################################################################################################################################
order_LPS_mat <- read.table('LPS_data.txt', header = T, row.names = 1)

order_LPS_mat_t <- t(order_LPS_mat)
order_LPS_mat_t_smooth <- move_avg_f(order_LPS_mat_t, window_size = 20)

#run CCM 
LPS_parallel_res <- parallelCCM(ordered_exprs_mat = order_LPS_mat_t_smooth, cores = detectCores())
LPS_parallel_res_mat <- prepare_ccm_res(LPS_parallel_res)

gene_names <- colnames(LPS_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(fData(Shalek_std[gene_id1, ])$gene_short_name), 
                     Gene_2_ID = c(gene_id2), Gene_2_NAME = c(fData(Shalek_std[gene_id2, ])$gene_short_name), delay_max = NA, 
                     ccm = LPS_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'LPS_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}
#run granger causality: 
order_LPS_mat_t_smooth_granger_res <- parallel_cal_grangertest(order_LPS_mat_t_smooth[, ], filename = 'order_LPS_mat_t_smooth_granger_res', delays = c(1, 21, 41), smooth = F)



