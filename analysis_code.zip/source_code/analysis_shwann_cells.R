# analyze Schwann cells 
# look also at the zebrafish shawnn cells 

################################################################################################################################################################
# do the same procedure for the Chromaffin cells 
################################################################################################################################################################
# load data and packages 
################################################################################################################################################################
rm(list = ls())

load('./RData/zebrafish_analysis_RNA_velocity_melanophore_cells.RData')
library(velocyto.R)
library(monocle)
library(destiny)
library(igraph)
library(pagoda2)
library(mclust)
library(Scribe)
library(netbiov)

# subset the dat matrix 
valid_cell_types <- c("Progenitor 1 (G2/Mitosis)", 'Progenitor 2', 'Myelinating Schwann Cell', 'unknown', 'Schwann Cell') # 
sum(cell_type %in% valid_cell_types) # 'unknown', 

valid_cells <- intersect(colnames(rvel.cd$current), names(cell_type)[cell_type %in% valid_cell_types])

gene_list <- c("sox10", 'sce', 'pou3f1', 'mse', 'erg2b', 'mpz',
               "fabp7", "erbb3", "plp1", "dhh", "ngfr", "mag", "sox2", "sh3tc2", "prrx", "arhgef10", "foxd3", 
               "lamb2", "lamb1", "lama2", "lama4", "mal", "s100b", "lgi4",
               "nfkbiaa", "brn2", "sox2", 'MO2-jun', 'srebp', 'hmg', 'coa', 'mbpa', 'cx32')
gene_list[gene_list %in% fData(comb2_cds_cell)$gene_short_name]
valid_gene <- gene_list[gene_list %in% rownames(rvel.cd$current)]

# subset Lauren's cds (maybe also create a CDS based on the dat matrix, by summing up exon, intron and spanning reads together)
Lauren_shwann_cds <- comb2_cds_cell[, pData(comb2_cds_cell)$Cell_type %in% valid_cell_types]

# subset dat based on cluster ID 
valid_clusters <- c(1:4, 9, 11)
exon_valid_genes <- intersect(row.names(dat1$exon), row.names(dat2$exon))
intron_valid_genes <- intersect(row.names(dat1$intron), row.names(dat2$intron))
spanning_valid_genes <- intersect(row.names(dat1$spanning), row.names(dat2$spanning))

EXON <- cBind(dat1$exon[exon_valid_genes, ], dat2$exon[exon_valid_genes, ])
INTRON <- cBind(dat1$intron[intron_valid_genes, ], dat2$intron[intron_valid_genes, ])
spanning =  cBind(dat1$spanning[spanning_valid_genes, ], dat2$spanning[spanning_valid_genes, ])
colnames(EXON) <- paste(colnames(EXON), rep(c('hypo', 'euth'), times  = c(ncol(dat1$exon), ncol(dat2$exon))))
colnames(INTRON) <- paste(colnames(INTRON), rep(c('hypo', 'euth'), times  = c(ncol(dat1$exon), ncol(dat2$exon))))
colnames(spanning) <- paste(colnames(spanning), rep(c('hypo', 'euth'), times  = c(ncol(dat1$spanning), ncol(dat2$spanning))))

dat <- list(exon =EXON , intron = INTRON, spanning = spanning)
valid_cells_by_cluster <- names(r$clusters$PCA$multilevel)[r$clusters$PCA$multilevel %in% valid_clusters]
all_genes <- unique(c(row.names(dat$exon), row.names(dat$intron), row.names(dat$spanning)))

mat_lappy <- lapply(all_genes, function(x) {
  message("current x is ", x)
  
  tmp <- rep(0, ncol(dat$exon))
  if(x %in% row.names(dat$exon)) {
    tmp <- tmp + as.numeric(dat$exon[x, ])
  } 
  if(x %in% row.names(dat$intron)) {
    tmp <- tmp + as.numeric(dat$intron[x, ])
  } 
  if(x %in% row.names(dat$spanning)) {
    tmp <- tmp + as.numeric(dat$spanning[x, ])
  }
  
  return(tmp)
})

mat <- do.call(rbind, mat_lappy) 
dimnames(mat) <- list(all_genes, colnames(dat$exon))

# create a cds 
pData <- data.frame(cell = colnames(mat), row.names = colnames(mat))
pData$cluster <- NA 
pData$cluster <- r$clusters$PCA$multilevel[colnames(mat)]
pData$cell_type <- pData$cluster
# cell types based on the Lauren's data 
pData$cell_type <- plyr::revalue(pData$cell_type, c("1" = "unknown", "2" = "Schwann Cell", "3" = "Myelinating Schwann Cell", "4" = "Progenitor 1 (G2/Mitosis)", 
                                                    "5" = "Chondrocyte/Osteoblast", "6" = "Oligodendrocyte", "7" = "Dorsal Root Ganglion / Radial Glial Cell",
                                                    "8" = "Xanthophore/Xanthoblast", "9" = "Schwann Cell", "10" = "Progenitor 1 (G2/Mitosis)", 
                                                    "11" = "Progenitor 2", "12" = "Macrophage", "13" = "Chondrocyte/Osteoblast", "14" = "Pigment progenitor/Melanophore"))

pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = row.names(mat), row.names = row.names(mat))
fd <- new("AnnotatedDataFrame", data = fData)

schwann_cds <- newCellDataSet(as(mat, "sparseMatrix"), 
                              phenoData = pd, 
                              featureData = fd,
                              lowerDetectionLimit=1,
                              expressionFamily=negbinomial.size())

valid_schwann_cds <- schwann_cds[, which(!is.na(pData(schwann_cds)$cluster))]

valid_schwann_cds <- estimateSizeFactors(valid_schwann_cds)
valid_schwann_cds <- estimateDispersions(valid_schwann_cds)

valid_schwann_cds <- setOrderingFilter(valid_schwann_cds, row.names(rvel.cd$current))
comb2_cds_cell <- setOrderingFilter(comb2_cds_cell, row.names(subset(fData(comb2_cds_cell), gene_short_name %in% row.names(rvel.cd$current))))

################################################################################################################################################################# 
# DA genes: 
NC_clusters_DEA_TF <- read.csv('./csv_data/NC-clusters_DEA_TF.csv', header = T)
# shwann_DA_genes <- c("egr2b", "nr4a2b", "tsc22d3", "jun", "hoxb7a", "fosb", "id1", "stat1a", "nr1d2a", "id2b", "znf536", "foxo3b", "myca", "mych", "id2a", "sox4a", "klf11a", "znf384l", "jund", "hoxb9a", "nr4a1", "creb3l3l", "ubtf", "hoxd3a", "cebpg", "lcor", "nr3c1", "nr2f5", "klf11b", "nfybb", "zeb2b", "usf1", "nfia", "hmgb3a", "hoxd9a", "hes2.2", "her9", "ubtfl", "pou3f1", "srebf2", "tfeb", "mxi1", "klf2b", "sox10", "mxd4", "hoxd4a", "smad1", "klf13", "tcf7l2", "rerea", "hoxa9b", "maff", "zgc:113343", "yy1b", "atf3", "atf7b", "zgc:65895", "rxraa", "hmgb3b", "zgc:113102", "bhlhe40", "yy1a", "mef2d", "sp4", "nkx2.2a", "kdm5ba", "hoxb6a", "hoxb3a", "mef2ca", "id3", "rx3", "pias4a", "nfil3", "zgc:171599", "si:ch211-198a12.6", "nr1h3", "zgc:163143", "foxn3", "hbp1", "znf410", "usf2", "ikzf5", "max", "si:ch211-206a7.2", "rest", "hoxd11a", "si:dkeyp-113d7.1", "zfx", "hoxa10b", "rxrgb", "mafk", "dlx6a", "zbtb12.2", "znf277", "tcf7l1a", "hoxd10a", "tfcp2", "hsf2", "hinfp", "rereb", "si:ch73-138e16.8", "hmg20b", "zgc:175284", "mafba", "xbp1", "zgc:113372", "zbtb37", "si:rp71-1g18.1", "dpf2", "pbx4", "sp2", "zgc:113411", "nr1d1", "si:ch211-89o9.6", "snapc4", "tshz1", "hoxd12a", "atf1", "zgc:173575", "si:dkeyp-53d3.3", "plag1", "hand2", "her4.2", "her4.2", "hmga1a", "gsx2", "zic2a", "her15.1", "hoxb8a", "tlx2", "her4.1", "ascl1a", "her15.1", "zic3", "sox19a", "zic5", "zic1", "isl1", "mxd3", "neurog1", "tal1", "drgx", "zic4", "sox3", "neurod4", "si:ch211-202h22.9", "gbx1", "foxp4", "id4", "hmgb3a", "lhx1a", "isl2a", "neurod6b", "hes6", "scrt2", "nhlh2", "pax6a", "hoxa3a", "pbx3b", "hmx2", "lbx1b", "ascl1b", "sox1b", "smarca5", "e2f7", "tsc22d1", "tfam", "hoxb6b", "hoxb10a", "lbx1a", "tal2", "foxj1a", "foxm1", "tfdp1b", "hmga1b", "nkx6.1", "hoxa2b", "gata2a", "terf1", "e2f4", "rfx4", "onecut1", "sox2", "hoxb1b", "hoxa9a", "wdhd1", "zgc:158291", "hoxb9a", "her12", "mybl1", "irx3a", "hoxc11a", "hoxb5a", "pms1", "mier1a", "smarcc2", "tgif1", "smarce1", "hoxc6b", "bhlhe22", "mynn", "rfx2", "zbtb20", "hoxc12a", "her8.2", "lhx5", "hey1", "nr2f1b", "her13", "nr2f1a", "terfa", "tlx3b", "ctcf", "setdb1b", "her6", "irx5a", "etv5a", "etv1", "gata3", "nr2f2", "zgc:113135", "hoxb3a", "zgc:161969", "her9", "pknox1.1", "prdm1a", "nfe2l3", "dlx3b", "irf8", "hoxa9b", "tbx2b", "mkxa", "zgc:113348", "mbd3b", "hoxd10a", "zgc:101562", "hoxa10b", "hoxb6a", "hoxc13a", "sox21a", "tbx16", "znfl2a", "hoxb5b", "pax7a", "bhlhe41", "litaf", "mitfa", "ar", "tsc22d2", "runx3", "tfap2c", "tfap2a", "snai1a", "ef1", "snai2", "mycn", "hoxa11b", "xbp1", "bcl11ab", "rarga", "cbfb", "zgc:173720", "sox21a", "rxraa", "olig2", "nkx6.2", "foxo3a", "pou3f3b", "pou3f3a", "foxp2", "sox9b", "meis3", "pou3f1", "id2a", "tfdp2", "zgc:153115", "mxi1", "znf536", "smarce1", "sox4a", "tbx2b", "xbp1", "hmgb3b", "foxo3b", "sox10", "hbp1", "egr2b", "fosb", "ybx1", "nfe2l3", "rcor1", "pou2f1b", "sox4a", "nr2f5", "hoxb5a", "zbed4", "maff", "gabpa", "hes2.2", "smarcc1a", "hif1ab", "hey2", "baz2a", "nr2f1a", "tfap2a", "mitfa", "pknox1.2", "tfap2c", "snai2", "bhlhe41", "ncor1", "pax3a", "id3", "mycb", "snai1a", "cbfb", "tfeb", "runx3", "ef1", "elk3", "rxrab", "bhlhe40", "foxp4", "myog", "cebpb", "hmga1a", "irf8", "dnajc2", "sp8a", "sox6", "pitx3", "lef1", "terf1", "egr1", "tfam", "smarca5", "tp53", "gtf3aa", "six1b", "gli3", "zgc:171220", "zbtb7a", "mybl1", "zgc:171506", "tfec", "alx4b", "tsc22d2", "snai1a", "id2b", "smad1", "bcl6a", "pax7a", "tp53", "tbx2a", "snai2", "hoxa11b", "thraa", "tcf12", "raraa", "tcf7l1b", "mycn", "dlx5a", "pax3a", "tfap2a", "mef2cb", "tfec", "sox4a", "zeb2a", "mitfa", "tfap2c", "foxo1a", "smarce1", "zbtb20", "snai2", "mbd3b", "nfe2l3", "zbtb2b", "foxp4", "sox6", "atoh8", "mycb", "egr1", "her12", "hmga1a", "dnajc2", "mef2cb", "atf3", "zeb2a", "mecp2", "her6", "id1", "dlx5a", "pknox2", "rfx4", "mef2cb", "sox5", "nkx2.2a", "klf9", "pou3f1", "irf8", "sox10", "nr0b1", "arid3b", "nr2f2", "hey2", "pou3f3b", "klf13", "zgc:113518", "hic1", "hoxc13a", "hsf2", "nr1d2a", "hoxc3a", "foxo1a", "carhsp1", "tcf12", "tox", "gli3", "foxp4", "rcor1", "tcf7l2", "myf5", "mych")
# names(shwann_DA_genes) <- c("Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Schwann Cell", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Progenitor 1/DRG neuron", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Xanthophore/Xanthoblast", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Oligodendrocyte", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Myelinating Schwann Cell", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Melanophore", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Progenitor 2", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Iridophore", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Pigment progenitor", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "Progenitor 3", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown", "unknown")
################################################################################################################################################################# 
# genes 
################################################################################################################################################################# 
Schwann_gene <- c("sox10", "mpz", "egr2b", "pou3f1", "xox9", "tfap2a", "pax3", "nfatc4", "sox2", "egr1", "jun", "pou3f1", "yy1", "brn2")
other_genes <- c("pax3a", "pax3b", "etv5", "etv6", "yy1a", "yy1b", "egr2a", "egr2b")

################################################################################################################################################################# 
# create a dimension reduction figure for the shwann cell 
################################################################################################################################################################# 
# first do the dimension reduction 

# 1. tSNE + velocity 

# Prepare matrices and clustering data:
schawnn_emat <- dat$exon[, valid_cells]; schawnn_nmat <- dat$intron[, valid_cells]; # disregarding spanning reads, as there are too few of them
schawnn_r <- Pagoda2$new(schawnn_emat,modelType='plain',trim=10,log.scale=T)
schawnn_r$adjustVariance(plot=T,do.par=T,gam.k=10)

#Run basic analysis steps to generate cell embedding and clustering, visualize:
schawnn_r$calculatePcaReduction(nPcs=100,n.odgenes=3e3,maxit=300)
schawnn_r$makeKnnGraph(k=30,type='PCA',center=T,distance='cosine');
schawnn_r$getKnnClusters(method=multilevel.community,type='PCA',name='multilevel')
schawnn_r$getEmbedding(type='PCA',embeddingType='tSNE',perplexity=25,verbose=T)

#Plot embedding, labeling clusters (left) and "Xist" expression (which separates the male and female )
par(mfrow=c(1,2))
schawnn_r$plotEmbedding(type='PCA',embeddingType='tSNE',show.legend=F,mark.clusters=T,min.group.size=10,shuffle.colors=F,mark.cluster.cex=1,alpha=0.3,main='cell clusters')
schawnn_r$plotEmbedding(type='PCA',embeddingType='tSNE',colors=r$depth,main='depth')  
schawnn_r$plotEmbedding(type='PCA',colors = pagoda2:::fac2col(cell_type[valid_cells]), group.level.colors = pagoda2:::fac2col(cell_type[valid_cells]), groups =  cell_type[valid_cells], 
                        embeddingType='tSNE',show.legend=T,mark.clusters=T,min.group.size=10,shuffle.colors=F,mark.cluster.cex=1,alpha=0.3,main='cell clusters')

# take cluster labels
schawnn_cluster.label <- schawnn_r$clusters$PCA$multilevel # take the cluster factor that was calculated by p2
schawnn_cell.colors <- pagoda2:::fac2col(schawnn_cluster.label)
# take embedding form p2
schawnn_emb <- schawnn_r$embeddings$PCA$tSNE

#In addition to clustering and the t-SNE embedding, from the p2 processing we will also take a cell-cell distance, which will be better than the default whole-transcriptome correlation distance that velocyto.R would normally use.
schawnn_cell.dist <- as.dist(1-armaCor(t(schawnn_r$reductions$PCA)))

#Filter genes based on the minimum average expresion magnitude (in at least one of the clusters), output total number of resulting valid genes:
schawnn_emat <- filter.genes.by.cluster.expression(schawnn_emat,schawnn_cluster.label,min.max.cluster.average = 0.2)
schawnn_nmat <- filter.genes.by.cluster.expression(schawnn_nmat,schawnn_cluster.label,min.max.cluster.average = 0.05)
length(intersect(rownames(schawnn_emat),rownames(schawnn_emat)))

#Estimate RNA velocity (using gene-relative model with k=20 cell kNN pooling and using top/bottom 2% quantiles for gamma fit):
fit.quantile <- 0.02
schawnn_rvel.cd <- gene.relative.velocity.estimates(schawnn_emat,schawnn_nmat,deltaT=1,kCells=25,cell.dist=schawnn_cell.dist,fit.quantile=fit.quantile)

#Visualize velocity on the t-SNE embedding, using velocity vector fields:
show.velocity.on.embedding.cor(schawnn_emb,schawnn_rvel.cd,n=200,scale='sqrt',cell.colors=ac(schawnn_cell.colors,alpha=0.5),cex=0.8,arrow.scale=3,show.grid.flow=TRUE,min.grid.cell.mass=0.5,grid.n=20,arrow.lwd=1,do.par=F,cell.border.alpha = 0.1)

show.velocity.on.embedding.cor(schawnn_emb,schawnn_rvel.cd,n=200,scale='sqrt',cell.colors=ac(schawnn_cell.colors,alpha=0.5),cex=0.8,arrow.scale=3,show.grid.flow=TRUE,min.grid.cell.mass=0.5,grid.n=20,arrow.lwd=1,do.par=F,cell.border.alpha = 0.1)

#Visualize a fit for a particular gene (we reuse rvel.cd to save on calcualtions here): (`you may need to select a few good genes to visualize here`)
#gene <- "gpc5a"
#gene.relative.velocity.estimates(emat,nmat,deltaT=1,kCells = 25,kGenes=1,fit.quantile=fit.quantile,cell.emb=emb,cell.colors=cell.colors,cell.dist=cell.dist,show.gene=gene,old.fit=rvel.cd,do.par=T)

#Increase neighborhood size, which should give us a more idealistic view of the phase portraits, particularly when it comes to the main, macrophage differentiation streak:
#gene <- "rps13"
#gene.relative.velocity.estimates(emat,nmat,deltaT=1,kCells = 100,kGenes=1,fit.quantile=fit.quantile,cell.emb=emb,cell.colors=cell.colors,cell.dist=cell.dist,show.gene=gene,do.par=T)

## Visualization on an existing embedding

#Here we use DDRTree embedding from the original publication (in emb variable).

emb_DDRTree_x <- t(lung@reducedDimS[, ])
row.names(emb_DDRTree_x) <- paste0(stringr::str_split_fixed(colnames(lung), "_", 2)[, 1], "_thout")

monocle::plot_cell_trajectory(lung, color_by = 'Time')
proj2_emb <- emb
proj2_emb[intersect(row.names(emb_DDRTree_x), row.names(emb)), ] <- emb_DDRTree_x[intersect(row.names(emb_DDRTree_x), row.names(emb)), ]
vel <- rvel.cd; arrow.scale=6; cell.alpha=0.4; cell.cex=1; fig.height=4; fig.width=4.5;
show.velocity.on.embedding.cor(proj2_emb,vel,n=100,scale='sqrt',cell.colors=ac(cell.colors,alpha=cell.alpha),cex=cell.cex,arrow.scale=arrow.scale,arrow.lwd=1)

# 2. force-directed layout / diffusion map / phater / SKL + velocity 

################################################################################################################################################################# 
# do force-directed layout 
################################################################################################################################################################# 
# run dpt but build the kNN graph and visualize with forced layout: 
run_dpt <- function(data, branching = T, norm_method = 'log', root = NULL, verbose = F){
  if(verbose)
    message('root should be the id to the cell not the cell name ....')
  
  data_ori <- t(data)
  duplicated_cells <- duplicated(data_ori)
  
  # avoid dpt to remove duplicated cells
  data_ori[duplicated_cells, 1] <-  rnorm(sum(duplicated_cells), sd = min(data_ori[data_ori > 0]))
  dm <- DiffusionMap(as.matrix(data_ori))
  
  return(dm@eigenvectors)
}

schwann_cds_cds_dpt <- run_dpt(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, ]) + 1)))

dx <- FNN::get.knn(schwann_cds_cds_dpt, k = 30)

# neighborMatrix <- nn2(data, data, k + 1, searchtype = "standard")[[1]][,-1]
jaccard_coeff_res <- monocle:::jaccard_coeff(dx$nn.index[, -1], TRUE)

jaccard_coeff_res <- jaccard_coeff_res[jaccard_coeff_res[,1]>0, ]
relations <- as.data.frame(jaccard_coeff_res)
colnames(relations)<- c("from","to","weight")

g <- graph.data.frame(relations, directed=FALSE)
layout_coord <- igraph::layout.drl(g)

plot(g, layout = layout_coord, vertex.size=2, vertex.label=NA, vertex.color = pagoda2:::fac2col(cell_type)) + 
  legend('topleft',legend=unique(cell_type),col=pagoda2:::fac2col(unique(cell_type)), pch=21, pt.bg='white')

###############################################################
# show the result for subset data 
###############################################################
valid_schwann_cds_cds_dpt <- run_dpt(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells_by_cluster]) + 1)))
valid_schwann_cds_cds_dpt_2 <- run_dpt(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells]) + 1)))

dx <- FNN::get.knn(valid_schwann_cds_cds_dpt[, 1:20], k = 30)

# neighborMatrix <- nn2(data, data, k + 1, searchtype = "standard")[[1]][,-1]
jaccard_coeff_res <- monocle:::jaccard_coeff(dx$nn.index[, -1], TRUE)

jaccard_coeff_res <- jaccard_coeff_res[jaccard_coeff_res[,1]>0, ]
relations <- as.data.frame(jaccard_coeff_res)
colnames(relations)<- c("from","to","weight")

g <- graph.data.frame(relations, directed=FALSE)
layout_coord <- igraph::layout.drl(g)

plot(g, layout = layout_coord, vertex.size=2, vertex.label=NA, vertex.color = pagoda2:::fac2col(cell_type)) + 
  legend('topleft',legend=unique(cell_type),col=pagoda2:::fac2col(unique(cell_type)), pch=21, pt.bg='white')

# provide functionality to visualize marker gene expression
plot_cell_layout <- function(cds, layout_type = 'drl', num_dim = 20, k = 30, return_all = FALSE) {
  valid_schwann_cds_cds_dpt <- run_dpt(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells_by_cluster]) + 1)))
  
  dx <- FNN::get.knn(valid_schwann_cds_cds_dpt[, 1:min(num_dim, ncol(valid_schwann_cds_cds_dpt))], k = k)
  
  # neighborMatrix <- nn2(data, data, k + 1, searchtype = "standard")[[1]][,-1]
  jaccard_coeff_res <- monocle:::jaccard_coeff(dx$nn.index[, -1], TRUE)
  
  jaccard_coeff_res <- jaccard_coeff_res[jaccard_coeff_res[,1]>0, ]
  relations <- as.data.frame(jaccard_coeff_res)
  colnames(relations)<- c("from","to","weight")
  
  g <- graph.data.frame(relations, directed=FALSE)
  layout_coord <- igraph::layout.drl(g)
  
  # plot(g, layout = layout_coord, vertex.size=2, vertex.label=NA, vertex.color = pagoda2:::fac2col(cell_type)) + 
  #   legend('topleft',legend=unique(cell_type),col=pagoda2:::fac2col(unique(cell_type)), pch=21, pt.bg='white')
  
  df <- data.frame(x = layout_coord[, 1], y = layout_coord[, 2], color = pagoda2:::fac2col(cell_type))
  p <- qplot(x, y, data = df, color = color) 
  
  if(return_all) {
    return(list(p = p, graph = g, df = df))
  }
  else {
    p
  }
}

################################################################################################################################################################# 
# phater (only on Schwann cell) 
################################################################################################################################################################# 
library(phater)

valid_schwann_cds_cds_phate <- phate(t(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells_by_cluster]) + 1))), t = 50, k = 30, npca = 20, pca.method = 'svd', mds.method = 'mmds')
valid_schwann_cds_cds_phate_lauren_2 <- phate(t(log(as.matrix(exprs(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells]) + 1))), t = 50, k = 30, npca = 20, pca.method = 'svd', mds.method = 'mmds')
valid_schwann_cds_cds_phate_lauren_2.1 <- phate(t(log(as.matrix(exprs(comb2_cds_cell[fData(comb2_cds_cell)$use_for_ordering, valid_cells]) + 1))), t = 50, k = 30, npca = 20, pca.method = 'svd', mds.method = 'mmds')
valid_schwann_cds_cds_phate_lauren_3 <- phate(t(log(as.matrix(exprs(tSNE_by_cluster[fData(tSNE_by_cluster)$use_for_ordering, ]) + 1))), t = 50, k = 30, npca = 20, pca.method = 'svd', mds.method = 'mmds')
valid_schwann_cds_cds_phate_lauren_4 <- phate(t(log(as.matrix(exprs(tSNE_by_Lauren[fData(tSNE_by_Lauren)$use_for_ordering, ]) + 1))), t = 50, k = 30, npca = 20, pca.method = 'svd', mds.method = 'mmds')

df <- data.frame(x = valid_schwann_cds_cds_phate_lauren_2$embedding[,1], y = valid_schwann_cds_cds_phate_lauren_2$embedding[,2], color = pagoda2:::fac2col(cell_type[valid_cells]))
color = pagoda2:::fac2col(unique(cell_type[valid_cells]))
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2") + scale_colour_manual(label = unique(cell_type[valid_cells]), values = color, name = 'cell_type')
qplot(x, y, col = factor(color), data = df, xlab = "phate1", ylab = "phate2") + 
  scale_colour_manual(label = unique(cell_type[valid_cells_by_cluster]), values = color, name = 'cell_type') 
+ facet_wrap(~color)

lung_mat <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code/data/lung_exprs.mat')
lung_phate <- phate(t(log(lung_mat$lung.exprs + 1)), t = 10, k = 5, npca = 5, pca.method = 'svd', mds.method = 'mmds')

################################################################################################################################################################# 
# tSNE result 
################################################################################################################################################################# 
tSNE_by_cluster <- reduceDimension(valid_schwann_cds[fData(valid_schwann_cds)$use_for_ordering, valid_cells_by_cluster], reduction_method = 'tSNE', norm_method = 'log')
tSNE_by_cluster <- clusterCells(tSNE_by_cluster, method = 'louvain')
tSNE_by_cluster <- clusterCells(tSNE_by_cluster)

tSNE_by_Lauren <- reduceDimension(comb2_cds_cell[fData(comb2_cds_cell)$use_for_ordering, pData(comb2_cds_cell)$Cell_type %in% valid_cell_types], reduction_method = 'tSNE', norm_method = 'log')
tSNE_by_Lauren <- clusterCells(tSNE_by_Lauren, method = 'louvain')
tSNE_by_Lauren <- clusterCells(tSNE_by_Lauren)

plot_cell_clusters(tSNE_by_Lauren)
plot_cell_clusters(tSNE_by_Lauren, color_by = 'Cell_type')

tSNE_by_cluster_dpt <- run_dpt(log(as.matrix(exprs(tSNE_by_cluster[fData(tSNE_by_cluster)$use_for_ordering, ]) + 1)))
tSNE_by_Lauren_dpt <- run_dpt(log(as.matrix(exprs(tSNE_by_Lauren[fData(tSNE_by_Lauren)$use_for_ordering, ]) + 1)))

qplot(tSNE_by_cluster_dpt[, 1], tSNE_by_cluster_dpt[, 2])
qplot(tSNE_by_Lauren_dpt[, 1], tSNE_by_Lauren_dpt[, 2])

################################################################################################################################################################# 
# skl (need to implement this method)
################################################################################################################################################################# 
# load the mat data 
writeMat(file = '/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code 2/data/tSNE_by_cluster', X = t(log(as.matrix(exprs(tSNE_by_cluster[fData(tSNE_by_cluster)$use_for_ordering, ]) + 1))))

res_25 <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code 2/matlab_25.mat')
res_35 <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code 2/matlab_35.mat')
qplot(res_25$Y[, 1], res_25$Y[, 2], color = pData(tSNE_by_cluster)$cell_type)
qplot(res_35$Y[, 1], res_35$Y[, 2], color = pData(tSNE_by_cluster)$cell_type)

res_5 <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code/matlab_5.mat')
res_15 <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code/matlab.mat')
qplot(res_5$Y[, 1], res_5$Y[, 2], color = pData(tSNE_by_cluster)$cell_type)
qplot(res_15$Y[, 1], res_15$Y[, 2], color = pData(tSNE_by_cluster)$cell_type)

################################################################################################################################################################# 
# get two separate cds and run trajectory for each cds
################################################################################################################################################################# 
schwann_comb2_cds_cell <- reduceDimension(comb2_cds_cell[, pData(comb2_cds_cell)$Cell_type %in% valid_cell_types], norm_method = 'log', verbose = T)
schwann_comb2_cds_cell <- orderCells(schwann_comb2_cds_cell)
plot_cell_trajectory(schwann_comb2_cds_cell, color_by = 'Cell_type')

valid_cell_types <- c("Progenitor 1 (G2/Mitosis)", 'Progenitor 2', 'Myelinating Schwann Cell', 'unknown', 'Schwann Cell') # 

unknown_cds <- reduceDimension(comb2_cds_cell[, pData(comb2_cds_cell)$Cell_type %in% valid_cell_types[c(1:2, 4:5)]], norm_method = 'log', verbose = T)
unknown_cds <- orderCells(unknown_cds)
pData(unknown_cds)$Cell_type <- as.character(pData(unknown_cds)$Cell_type)
plot_cell_trajectory(unknown_cds, color_by = 'Cell_type')
unknown_cds <- orderCells(unknown_cds, root_state = 2)
plot_cell_trajectory(unknown_cds, color_by = 'Pseudotime')

myelinating_cds<- reduceDimension(comb2_cds_cell[, pData(comb2_cds_cell)$Cell_type %in% valid_cell_types[c(1:3, 5)]], norm_method = 'log', verbose = T)
myelinating_cds <- orderCells(myelinating_cds)
pData(myelinating_cds)$Cell_type <- as.character(pData(myelinating_cds)$Cell_type)
plot_cell_trajectory(myelinating_cds, color_by = 'Cell_type')
myelinating_cds <- orderCells(myelinating_cds, reverse = T)
plot_cell_trajectory(myelinating_cds, color_by = 'Pseudotime')
################################################################################################################################################################# 
# visualize velocity on the DDRTree embedding (note that we only have a subset of cells here)
################################################################################################################################################################# 
# a mapping from comb2_cds_cell colnames to the dropest colnames 
unknown_schawnn_rvel.cd <- schawnn_rvel.cd
unknown_schawnn_rvel.cd$cellKNN[, ]

################################################################################################################################################################# 
# gene expression over the two paths (example genes): a branched heatmap 
################################################################################################################################################################# 

# 1. make heatmap 
valid_unknown_cds <- unknown_cds[, pData(unknown_cds)$State %in% c(1, 2)]
unknon_pseudo_res <- differentialGeneTest(valid_unknown_cds, cores = detectCores() / 2)
myelinating_pseudo_res <- differentialGeneTest(myelinating_cds, cores = detectCores() / 2)

unknown_sig_res <- subset(unknon_pseudo_res, qval < 1e-2)
myelinating_sig_res <- subset(myelinating_pseudo_res, qval < 1e-2)

pData(valid_unknown_cds)$scaled_pseudotime <- pData(valid_unknown_cds)$Pseudotime / max(pData(valid_unknown_cds)$Pseudotime)
pData(myelinating_cds)$scaled_pseudotime <- pData(myelinating_cds)$Pseudotime / max(pData(myelinating_cds)$Pseudotime)

newdata <- data.frame(scaled_pseudotime = seq(0, 1, length.out = 100))

unknown_smoothed_exprs <- genSmoothCurves(valid_unknown_cds[row.names(unknown_sig_res), ], cores = detectCores()/ 4, 
                                          trend_formula = "~sm.ns(scaled_pseudotime, df=3)", relative_expr = T, new_data = newdata)

myelinating_smoothed_exprs <- genSmoothCurves(myelinating_cds[row.names(myelinating_sig_res), ], cores = detectCores()/ 4, 
                                              trend_formula = "~sm.ns(scaled_pseudotime, df=3)", relative_expr = T, new_data = newdata)

col_gap_ind <- 100
num_clusters <- 6
branch_labels <- c('Unknown', 'Myelinating')
add_annotation_col <- T
scale_max <- 3; scale_min <- -3
branch_colors = c("#F05662", "#7990C8")
hmcols = NULL
hclust_method = "ward.D2"
cluster_rows = TRUE
add_annotation_row = NULL 
add_annotation_col = NULL
show_rownames = FALSE
use_gene_short_name = TRUE
norm_method = "log"
return_heatmap = FALSE

inter_genes <- intersect(row.names(unknown_smoothed_exprs), row.names(myelinating_smoothed_exprs))

heatmap_matrix <- cBind(unknown_smoothed_exprs[inter_genes, ], # (col_gap_ind - 1):1
                        myelinating_smoothed_exprs[inter_genes, ])
heatmap_matrix = heatmap_matrix[!apply(heatmap_matrix, 1, 
                                       sd) == 0, ]
heatmap_matrix = Matrix::t(scale(Matrix::t(heatmap_matrix), 
                                 center = TRUE))
heatmap_matrix = heatmap_matrix[is.na(row.names(heatmap_matrix)) == 
                                  FALSE, ]
heatmap_matrix[is.nan(heatmap_matrix)] = 0
heatmap_matrix[heatmap_matrix > scale_max] = scale_max
heatmap_matrix[heatmap_matrix < scale_min] = scale_min
heatmap_matrix_ori <- heatmap_matrix
heatmap_matrix <- heatmap_matrix[is.finite(heatmap_matrix[, 
                                                          1]) & is.finite(heatmap_matrix[, col_gap_ind]), ]
row_dist <- as.dist((1 - cor(Matrix::t(heatmap_matrix)))/2)
row_dist[is.na(row_dist)] <- 1
exp_rng <- range(heatmap_matrix)
bks <- seq(exp_rng[1] - 0.1, exp_rng[2] + 0.1, by = 0.1)
if (is.null(hmcols)) {
  hmcols <- monocle:::blue2green2red(length(bks) - 1)
}
ph <- pheatmap::pheatmap(heatmap_matrix, useRaster = T, cluster_cols = FALSE, 
                         cluster_rows = TRUE, show_rownames = F, show_colnames = F, 
                         clustering_distance_rows = row_dist, clustering_method = hclust_method, 
                         cutree_rows = num_clusters, silent = TRUE, filename = NA, 
                         breaks = bks, color = hmcols)
annotation_row <- data.frame(Cluster = factor(cutree(ph$tree_row, 
                                                     num_clusters)))
colnames(heatmap_matrix) <- c(1:ncol(heatmap_matrix))
annotation_col <- data.frame(row.names = c(1:ncol(heatmap_matrix)), 
                             `Cell Type` = c(rep(branch_labels[1], 100), rep(branch_labels[2], 99)))
colnames(annotation_col) <- "Cell Type"

names(branch_colors) <- c(branch_labels[1], 
                          branch_labels[2])
annotation_colors = list(`Cell Type` = branch_colors)
names(annotation_colors$`Cell Type`) = branch_labels
# if (use_gene_short_name == TRUE) {
#   if (is.null(fData(cds_subset)$gene_short_name) == FALSE) {
#     feature_label <- as.character(fData(cds_subset)[row.names(heatmap_matrix), 
#                                                     "gene_short_name"])
#     feature_label[is.na(feature_label)] <- row.names(heatmap_matrix)
#     row_ann_labels <- as.character(fData(cds_subset)[row.names(annotation_row), 
#                                                      "gene_short_name"])
#     row_ann_labels[is.na(row_ann_labels)] <- row.names(annotation_row)
#   }
#   else {
#     feature_label <- row.names(heatmap_matrix)
#     row_ann_labels <- row.names(annotation_row)
#   }
# }
# else {
#   feature_label <- row.names(heatmap_matrix)
#   row_ann_labels <- row.names(annotation_row)
# }
# row.names(heatmap_matrix) <- feature_label
# row.names(annotation_row) <- row_ann_labels
ph_res <- pheatmap(heatmap_matrix[, ], useRaster = T, cluster_cols = FALSE, 
                   cluster_rows = TRUE, show_rownames = show_rownames, show_colnames = F, 
                   clustering_distance_rows = row_dist, clustering_method = hclust_method, 
                   cutree_rows = num_clusters, annotation_row = annotation_row, 
                   annotation_col = annotation_col, annotation_colors = annotation_colors, 
                   gaps_col = col_gap_ind, treeheight_row = 20, breaks = bks, 
                   fontsize = 6, color = hmcols, border_color = NA, silent = TRUE)
grid::grid.rect(gp = grid::gpar("fill", col = NA))
grid::grid.draw(ph_res$gtable)

pdf('./Figures/main_figures/schwann_branch_heatmap.pdf', height = 8, width = 7)
pheatmap(heatmap_matrix[, ], useRaster = T, cluster_cols = FALSE, 
         cluster_rows = TRUE, show_rownames = show_rownames, show_colnames = F, 
         clustering_distance_rows = row_dist, clustering_method = hclust_method, 
         cutree_rows = num_clusters, annotation_row = annotation_row, legend = F,
         annotation_col = annotation_col, annotation_colors = annotation_colors, 
         gaps_col = col_gap_ind, treeheight_row = 20, breaks = bks, 
         fontsize = 6, color = hmcols, border_color = NA, silent = F)
dev.off()
# 2. identify important regulators (divergence between two paths > 95% of the data)

cor_res <- lapply(inter_genes, function(x) {
  cor(myelinating_smoothed_exprs[x, ], unknown_smoothed_exprs[x, ])
})

# 3. overlap with the TF list 
zfish_TFs <- read.csv('./csv_data/zfish_TF_list.csv', header = F)

zfish_TFs$V1 %in% fData(valid_unknown_cds)[inter_genes, 'gene_short_name']

# run RDI on the TFs and RDI between TFs and the target genes 
cluster_TFs <- T
cluster_targets <- T
scale <- T
smoothing <- F
cluster_num_method <- "mcclust"
delays <- c(5)
include_conditioning <- F
cluster_TFs_num = 2
cluster_targets_num = 10
scale_max <- 3
scale_min <- -3
hclust_method = "ward.D2"

informative_genes <- inter_genes; TF <- row.names(subset(fData(valid_unknown_cds), gene_short_name %in% zfish_TFs$V1))
pseudocount <- 1
TF_vec_names <- intersect(TF, informative_genes)
target_vec_names <- setdiff(informative_genes, TF)
unique_gene <- unique(c(TF, informative_genes))
gene_name_ids <- intersect(row.names(valid_unknown_cds), unique_gene)
if (length(unique_gene) != length(gene_name_ids)) {
  stop("The valid_unknown_cds you provided doesn't include all genes from the TF and informative_genes vector!")
}
cds_subset <- valid_unknown_cds[gene_name_ids, ]
pData(cds_subset)$Pseudotime <- order(pData(cds_subset)$Pseudotime)
exprs_data <- exprs(cds_subset)[, pData(cds_subset)$Pseudotime]
if (norm_method == "vstExprs" && is.null(cds_subset@dispFitInfo[["blind"]]$disp_func) == 
    FALSE) {
  exprs_data = vstExprs(cds_subset, expr_matrix = exprs_data)
} else if (norm_method == "log") {
  exprs_data = log10(exprs_data + pseudocount)
}
annotation_TF_cluster = NULL
annotation_target_cluster = NULL
cRDI <- NULL
if (cluster_TFs | cluster_targets) {
  if (smoothing) {
    for (i in 1:ncol(exprs_data)) {
      df <- data.frame(Pseudotime = 1:ncol(exprs_data), 
                       Expression = exprs_data[i, ])
      test <- loess(Expression ~ Pseudotime, df)
      exprs_data[i, ] <- predict(test)
    }
  }
  cds_subset@assayData$exprs <- exprs_data
  m <- exprs_data
  m = m[!apply(m, 1, sd) == 0, ]
  if (scale) {
    m = Matrix::t(scale(Matrix::t(m), center = TRUE))
    m = m[is.na(row.names(m)) == FALSE, ]
    m[is.nan(m)] = 0
    m[m > scale_max] = scale_max
    m[m < scale_min] = scale_min
  }
  TF_vec_names <- intersect(TF_vec_names, row.names(m))
  target_vec_names <- intersect(target_vec_names, row.names(m))
  m_tfs <- m[TF_vec_names, ]
  m_targets <- m[target_vec_names, ]
  # if (cluster_num_method == "mcclust") {
  #   clust_num_check_tfs <- Mclust(t(m_tfs), G = 1:min(10, 
  #                                                     length(TF_vec_names)/2))
  #   cluster_TFs_num <- dim(clust_num_check_tfs$z)[2]
  #   clust_num_check_targets <- Mclust(t(m_targets), 
  #                                     G = 1:min(10, length(target_vec_names)/2))
  #   cluster_targets_num <- dim(clust_num_check_targets$z)[2]
  #   cat("model-based optimal number of clusters: TF: ", 
  #       cluster_TFs_num, ", targets: ", cluster_targets_num, 
  #       "\n")
  # }
  # else if (cluster_num_method == "pamk") {
  #   dissimilarity_mat_tfs <- 1 - cor(t(m_tfs))
  #   dissimilarity_mat_targets <- 1 - cor(t(m_targets))
  #   clust_num_check_tfs <- fpc::pamk(dissimilarity_mat_tfs, 
  #                                    diss = T)
  #   clust_num_check_targets <- fpc::pamk(dissimilarity_mat_targets, 
  #                                        diss = T)
  #   cluster_TFs_num <- clust_num_check_tfs$nc
  #   cluster_targets_num <- clust_num_check_targets$nc
  #   cat("number of clusters estimated by optimum average silhouette width: TF: ", 
  #       cluster_TFs_num, ", targets: ", cluster_targets_num, 
  #       "\n")
  # }
  if (cluster_TFs) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_tfs)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_TF_cluster <- data.frame(Cluster = factor(cutree(m_hclust, 
                                                                cluster_TFs_num)), row.names = row.names(m_tfs))
    m_TFs_clusters <- matrix(nrow = ncol(cds_subset), 
                             ncol = cluster_TFs_num)
    for (cluster_ind in 1:cluster_TFs_num) {
      gene_inds <- annotation_TF_cluster$Cluster == 
        cluster_ind
      
      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_tfs[gene_inds, ])) # as.vector(t(exprs_data[row.names(annotation_TF_cluster)[gene_inds], ]))
      test <- loess(Expression ~ Pseudotime, df)
      m_TFs_clusters[, cluster_ind] <- predict(test) # 
    }
    colnames(m_TFs_clusters) <- paste0("TFs_", 1:cluster_TFs_num)
  } else {
    m_TFs_clusters <- m_tfs
  }
  if (cluster_targets) {
    row_dist <- as.dist((1 - cor(Matrix::t(m_targets)))/2)
    row_dist[is.na(row_dist)] <- 1
    m_hclust <- hclust(row_dist, method = hclust_method)
    annotation_target_cluster <- data.frame(Cluster = factor(cutree(m_hclust, 
                                                                    cluster_targets_num)), row.names = row.names(m_targets))
    m_targets_clusters <- matrix(nrow = ncol(cds_subset), 
                                 ncol = cluster_targets_num)
    for (cluster_ind in 1:cluster_targets_num) {
      gene_inds <- annotation_target_cluster$Cluster == 
        cluster_ind
      df <- data.frame(Pseudotime = 1:ncol(exprs_data), Expression = colMeans(m_targets[gene_inds, ])) # as.vector(t(exprs_data[gene_inds, ]))
      test <- loess(Expression ~ Pseudotime, df)
      
      m_targets_clusters[, cluster_ind] <- predict(test) 
    }
    colnames(m_targets_clusters) <- paste0("target_", 
                                           1:cluster_targets_num)
  } else {
    m_targets_clusters <- m_targets
  }
  TF_vec_names <- colnames(m_TFs_clusters)
  target_vec_names <- colnames(m_targets_clusters)
  exprs_data <- cbind(m_TFs_clusters, m_targets_clusters)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names, 
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi_cpp_wrap(as.matrix(exprs_data), 
                                    delays = delays, super_graph = as.matrix(all_pairwise_gene), 
                                    turning_points = 0, method = 1, uniformalize = F)
  if (include_conditioning) 
    cRDI_res <- calculate_conditioned_rdi_cpp_wrap(as.matrix(exprs_data), 
                                                   super_graph = as.matrix(all_pairwise_gene), max_rdi_value = RDI_res$max_rdi_value, 
                                                   max_rdi_delays = RDI_res$max_rdi_delays, k = 1, 
                                                   uniformalize = FALSE)
} else {
  cds_subset@assayData$exprs <- exprs_data
  exprs_data <- t(exprs_data)
  TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
  TF_target_pair <- expand.grid(TF_vec_names, target_vec_names, 
                                stringsAsFactors = F)
  tmp <- rbind(TF_pair, TF_target_pair)
  tmp[, 1] <- match(tmp[, 1], colnames(exprs_data))
  tmp[, 2] <- match(tmp[, 2], colnames(exprs_data))
  all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1
  RDI_res <- calculate_rdi(cds_subset, delays = delays, 
                           super_graph = all_pairwise_gene, log = FALSE, ...)
  if (include_conditioning) 
    cRDI_res <- calculate_conditioned_rdi(exprs_data, 
                                          rdi_list = RDI_res, ...)
}

return(list(RDI_res = RDI_res, cRDI = cRDI, annotation_TF_cluster = annotation_TF_cluster, 
            annotation_target_cluster = annotation_target_cluster))

# visualize the result 
# 1. draw the smooth average curve for each TF or target cluster
pdf('./Figures/main_figures/TF_clust1.pdf', height = 1, width = 1)
qplot(1:nrow(m_TFs_clusters), m_TFs_clusters[, 1], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
dev.off()
pdf('./Figures/main_figures/TF_clust2.pdf', height = 1, width = 1)
qplot(1:nrow(m_TFs_clusters), m_TFs_clusters[, 2], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
dev.off()

for(cur_target in target_vec_names) {
  q <- qplot(1:nrow(m_TFs_clusters), m_targets_clusters[, cur_target], size = I(0.5)) + xlab('Pseudotime') + ylab('Expression') + xacHelper::nm_theme()
  pdf(paste0('./Figures/main_figures/', cur_target, '.pdf'), height = 1, width = 1)
  print(q)
  dev.off()
}

################################################################################################################################################################# 
# perform causal network inference on all the important regulators for two different approaches 
################################################################################################################################################################# 
# 1. calculate the TF to target network 
# 2. visualize a few important genes 
max_rdi_value <- apply(RDI_res$max_rdi_value, 2, function(x) {
  y <- rep(0, length(x))
  y[which.max(x)] <- x[which.max(x)]
  y
}) 
dimnames(max_rdi_value) <- list(colnames(exprs_data), colnames(exprs_data))

g <- igraph::graph_from_adjacency_matrix(as.matrix(max_rdi_value), weighted = T, mode = "direct")

res <- level.plot(g)

res$layout[, 2] <- c(0, 0, rep(-1, 10))
res$layout[, 1] <- c(-1, 1, seq(-5, 5, length.out = 10))
pdf('./Figures/main_figures/TF_target_cluster_network_hiearchy.pdf', height = 7, width = 7)
plot.igraph(g, edge.width=E(g)$weight * 10, edge.curved=F, layout = res$layout)
dev.off()

################################################################################################################################################################# 
# do a large scale regulatory network inference (apply the network sparsifier -- use directed CLR) 
################################################################################################################################################################# 
informative_genes_name <- intersect(fData(valid_unknown_cds[informative_genes, ])$gene_short_name, row.names(rvel.cd$current))
informative_genes <- informative_genes_name; TF <- informative_genes_name[informative_genes_name %in% zfish_TFs$V1]
pseudocount <- 1
TF_vec_names <- intersect(TF, informative_genes)
target_vec_names <- setdiff(informative_genes, TF)
unique_gene <- unique(c(TF, informative_genes))

TF_pair <- expand.grid(TF_vec_names, TF_vec_names, stringsAsFactors = F)
TF_target_pair <- expand.grid(TF_vec_names, target_vec_names, 
                              stringsAsFactors = F)
tmp <- rbind(TF_pair, TF_target_pair)
tmp[, 1] <- match(tmp[, 1], row.names(rvel.cd$current))
tmp[, 2] <- match(tmp[, 2], row.names(rvel.cd$current))
all_pairwise_gene <- tmp[tmp[, 1] != tmp[, 2], ] - 1

# cmi: I(x(t - 1), y (t) | y(t - 1) )
current_n <- as.matrix(rvel.cd$current[, ]) # valid_cells
projected <- as.matrix(rvel.cd$projected[, ]) # valid_cells

shwann_cmi_res <- apply(all_pairwise_gene, 1, function(x) {
  message(x[1], ", ", x[2])
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 15, normalize = F)$cmi_res
})

# run CLR algorithm 

# visualize TF network with the top genes 

# identify the hub genes / motifs, etc. 

################################################################################################################################################################# 
# visualize the network 
################################################################################################################################################################# 
# run CLR algorithm 
schwann_causality_res <- cbind(all_pairwise_gene, shwann_cmi_res)
schwann_adj_mat <- reshape2::dcast(schwann_causality_res, Var1 ~ Var2)

TF_name <- row.names(rvel.cd$current)[schwann_adj_mat[, 1]]
schwann_adj_mat <- schwann_adj_mat[, -1]
Target_name <- row.names(rvel.cd$current)[as.numeric(colnames(schwann_adj_mat))] # +1 index issue 
dimnames(schwann_adj_mat) <- list(gene_name, Target_name)

schwann_clr_res <- clr(as.matrix(schwann_adj_mat))

schwann_adj_mat[is.na(schwann_adj_mat)] <- 0

schwann_adj_mat_TF <- schwann_adj_mat[TF_name, TF_name]
col_means <- colMeans(schwann_adj_mat_TF)
col_sd <- apply(schwann_adj_mat_TF, 2, sd)

schwann_clr_res2_tmp_TF <- lapply(1:nrow(schwann_adj_mat_TF), function(x) {
  row_i <- t(schwann_adj_mat_TF)[, x]
  # message(row_i)
  s_i_vec <- pmax(0, (row_i - mean(row_i)) / sd(row_i))
  s_j_vec <- pmax(0, (row_i - col_means)/ col_sd) 
  
  sqrt(s_i_vec^2 + s_j_vec^2)
})

schwann_adj_mat_Target <- schwann_adj_mat[TF_name, Target_name]
schwann_clr_res2_tmp_Target <- lapply(1:nrow(schwann_adj_mat_Target), function(x) {
  row_i <- t(schwann_adj_mat_Target)[, x]
  # message(row_i)
  s_i_vec <- pmax(0, (row_i - mean(row_i)) / sd(row_i))
  
  s_i_vec
})

schwann_clr_res2_TF <- do.call(rbind, schwann_clr_res2_tmp_TF) 
dimnames(schwann_clr_res2_TF) <- list(TF_name, TF_name)
schwann_clr_res2_Target <- do.call(rbind, schwann_clr_res2_tmp_Target) 
dimnames(schwann_clr_res2_Target) <- list(TF_name, Target_name)

uniq_names <- unique(c(TF_name, Target_name))
schwann_clr_res_final <- matrix(rep(0, length(uniq_names)^2), nrow = length(uniq_names), dimnames = list(uniq_names, uniq_names))
schwann_clr_res_final[TF_name, TF_name] <- schwann_clr_res2_TF
schwann_clr_res_final[TF_name, Target_name] <- schwann_clr_res2_Target

# visualize TF network with the top genes 
z_threshold <- 2
schwann_clr_res_final[schwann_clr_res_final < 4] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(schwann_clr_res_final), weighted = T, mode = "direct")

# level.plot 
res <- level.plot(g)
# spiral-view: nodes are ranked using reingold-tilford algorithm
plot.spiral.graph(g, tp=90,vertex.color="blue",e.col="gold",rank.function=layout.reingold.tilford)
# spiral-view: starting with the highest degree node
data("color_list")
plot.spiral.graph(g, tp=60,vertex.color=sample(color.list$bright))
plot.spiral.graph(g, tp=179,vertex.color=sample(color.list$bright) )
# 3
fn <- function(g)plot.spiral.graph(g,12)$layout
plot.modules(g, layout.function=fn, layout.overall=layout.fruchterman.reingold,sf=20, v.size=1, color.random=TRUE)

# star-like global view of a scale free network starting with the five highest degree nodes 
plot.NetworkSperical.startSet(g, mo = "in", nc = 5)
# Global view
plot.NetworkSperical(g, mo="in", v.lab=FALSE, tkplot = FALSE,v.size=1 )

# Modular layout with hierarchical plots for the modules
plot.modules(g, layout.function = layout.reingold.tilford, col.grad=list(color.list$citynight), tkplot=FALSE)

# Modular layout (has errors)
exp <- rnorm(vcount(g))
plot.modules(g, modules.color="grey", expression = exp, exp.by.module = c(1,2,5), tkplot=FALSE)
plot.modules(g1, expression = exp, tkplot=FALSE)
cl <- list(rainbow(40), heat.colors(40) ); plot.modules(g, col.grad=cl , tkplot=FALSE)
plot.modules(g, layout.function = c(layout.fruchterman.reingold, layout.star,layout.reingold.tilford, layout.graphopt,layout.kamada.kawai), modules.color = sample(color.list$bright), sf=40, tkplot=FALSE)
plot.modules(g, layout.function = c(layout.fruchterman.reingold), modules.color = sample(color.list$bright),layout.overall = layout.star,sf=40, tkplot=FALSE)
plot.modules(g,mod.list=lm,layout.function=c(layout.fruchterman.reingold), modules.color="grey", mod.edge.col = sample(color.list$bright), tkplot=FALSE)
plot.modules(g, mod.list = lm, layout.function = layout.graphopt, modules.color = cl,mod.edge.col=c("green","darkgreen"), tkplot=FALSE, ed.color = c("blue"),sf=-25)
plot.modules(g, layout.function = layout.graphopt, modules.color = cl, mod.edge.col=c("green","darkgreen") , tkplot=FALSE, ed.color = c("blue"),sf=-25)
plot.modules(g, modules.color=cl, mod.edge.col=cl,
             sf=5, nodeset=c(2,5,44,34),
             mod.lab=TRUE, v.size=.9,
             path.col=c("blue", "purple", "green"),
             col.s1 = c("yellow", "pink"),
             col.s2 = c("orange", "white" ),
             e.path.width=c(1.5,3.5), v.size.path=.9)
plot.modules(g, color.random=TRUE, v.size=1, layout.function=layout.graphopt)

# MST plot: Global layout style: Kamada-Kawai
mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE, layout.function=layout.kamada.kawai)
mst.plot(g, colors=c("purple4","purple"),mst.edge.col="green",vertex.color = "white",tkplot=FALSE,layout.function=layout.fruchterman.reingold)
ecl <- rgb(r=0, g=1, b=1, alpha=.6)
ppx <- mst.plot.mod(g, v.size=degree(g),e.size=.5,
                    colors=ecl,mst.e.size=1.2,expression=degree(g),
                    mst.edge.col="white", sf=-10, v.sf=6)

hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
cl <- rgb(r=1, b=.7, g=0, alpha=.1)
fn <- function(x){layout.reingold.tilford(x, circular=TRUE,
                                          root=which.max(degree(x)))}
mst.plot.mod(g, vertex.color=cl, v.size=1, sf=30,
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=fn, layout.overall=layout.kamada.kawai)

hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=.2)
cl <- rgb(r=0, b=.7, g=1, alpha=.05)
mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=layout.fruchterman.reingold)

#Abstract modular view of a component 
plot.abstract.nodes(g, v.sf=-35,layout.function=layout.fruchterman.reingold, lab.color="white",lab.cex=.75)
plot.abstract.nodes(g, layout.function=layout.fruchterman.reingold, v.sf=-30, lab.color="green")
# Information flow layout

# information flow: 
level.plot(g, tkplot=FALSE, level.spread=FALSE, layout.function=layout.fruchterman.reingold)
cl <- rgb(r=.6, g=.6, b=.6, alpha=.5)
level.plot(g, init_nodes=20,tkplot=FALSE, level.spread=TRUE,
           order_degree=NULL, v.size=1, edge.col=c(cl, cl, "green", cl),
           vertex.colors=c("red", "red", "red"), e.size=.5, e.curve=.25)

# abstract module 
plot.abstract.nodes(g, nodes.color ="grey",layout.function=layout.star, edge.colors= sample(color.list$bright), tkplot =FALSE,lab.color = "red")
# module view: (don't work for directed graph)
splitg.mst(g, vertex.color = sample(color.list$bright), colors = color.list$warm[1:30], tkplot = FALSE)
# abstract module: (don't work for directed graph)
plot.abstract.module(g, tkplot = FALSE, layout.function=layout.star)

plot.igraph(g, edge.width=E(g)$weight, edge.curved=F, layout = layout_with_fr(g))

pdf('./Figures/main_figures/schwann_global_network.pdf', height = 7, width = 7)
hc <- rgb(t(col2rgb(heat.colors(20)))/255,alpha=1)
cl <- rgb(r=0, b=.7, g=1, alpha=.05)
mst.plot.mod(g, vertex.color=cl, v.size=3, sf=-20,
             bg = "white",
             colors=hc, e.size=.5, mst.e.size=.75,
             layout.function=layout.fruchterman.reingold)
dev.off()

pdf('./Figures/main_figures/schwann_global_network.pdf', height = 1, width = 1)
res <- level.plot(g, bg = 'white')
dev.off()

################################################################################################################################################################# 
# Calculate the centrality of the vertex for ranking genes  
################################################################################################################################################################# 
# identify the hub genes / motifs, etc. 
# degree centrality
degree(g, mode="out")
centr_degree(g, mode="out", normalized=T)
closeness(g, mode="all")
centr_clo(g, mode="all", normalized=T)
eigen_centrality(g, directed=T)
centr_eigen(g, directed=T, normalized=T)

betweenness(g, directed=T)
edge_betweenness(g, directed=T)
centr_betw(g, directed=T, normalized=T)

hs <- hub_score(g)$vector
as <- authority_score(g)$vector
plot(g, vertex.size=hs*50, main="Hubs")
plot(g, vertex.size=as*30, main="Authorities")

page_rank(g)
# centralization 
# closeness 
# eigenvector 
# betweeness 
# pageRank 
################################################################################################################################################################# 
# Ranking genes 
################################################################################################################################################################# 
gene_list <- c("sox10", 'sce', 'pou3f1', 'mse', 'erg2b', 'mpz',
               "fabp7", "erbb3", "plp1", "dhh", "ngfr", "mag", "sox2", "sh3tc2", "prrx", "arhgef10", "foxd3", 
               "lamb2", "lamb1", "lama2", "lama4", "mal", "s100b", "lgi4",
               "nfkbiaa", "brn2", "sox2", 'MO2-jun', 'srebp', 'hmg', 'coa', 'mbpa', 'cx32')

Schwann_gene <- c("sox10", "mpz", "egr2b", "pou3f1", "xox9", "tfap2a", "pax3", "nfatc4", "sox2", "egr1", "jun", "pou3f1", "yy1", "brn2")
other_genes <- c("pax3a", "pax3b", "etv5", "etv6", "yy1a", "yy1b", "egr2a", "egr2b")
all_genes <- tools::toTitleCase(c(gene_list, Schwann_gene, other_genes))
sort(page_rank(g)$vector)[all_genes]

hs <- hub_score(g)$vector
hs <- sort(hs, decreasing = T)

df <- data.frame(Order = 1:length(hs), name = tools::toTitleCase(names(hs)), hub_score = hs)
# df$name[df$hub_score < 0.5] <- NA

pdf('./Figures/main_figures/schwann_network_centrality.pdf', height = 1, width = 1)
ggplot(aes(Order, hub_score, label = name), data = subset(df, name %in% tools::toTitleCase(TF_name))) + geom_point(size = 0.5, aes(color = hub_score > 0.5))  + geom_text(hjust = -0.5, nudge_x = 0, check_overlap = TRUE, size = I(2)) + 
  ylab('Hub centrality') + xlab('') + xacHelper::nm_theme() + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + scale_color_manual(values = c('black', 'red'))
dev.off()

################################################################################################################################################################# 

################################################################################################################################################################# 
# save the data 
################################################################################################################################################################# 
save.image('./RData/analysis_shwann_cells.RData')

