library(Scribe)
run_vec <- rep(1, 400)

res <- read.csv("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat_nonlinear_n_4_step_400_N_end_400", sep = '\t')
data <- res[, -c(1)]
data <- data
gene_name_vec <- as.character(res$GENE_ID)

tmp <- expand.grid(1:nrow(data), 1:nrow(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 

# test rdi value between python and cpp:  
python_res_d1 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/rdi_results_d1.txt', sep = ',', row.names = 1)
python_res_d2 <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/rdi_results_d2.txt', sep = ',', row.names = 1)
neuron_rdi_list2 <- calculate_rdi_multiple_run_cpp(t(data), delay = c(1, 2), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise
dimnames(neuron_rdi_list2$RDI) <- list(as.character(res$GENE_ID[1:nrow(data)]), c(as.character(res$GENE_ID[1:nrow(data)]), as.character(res$GENE_ID[1:nrow(data)])))

python_res_d1 - neuron_rdi_list2$RDI[, 1:13][row.names(python_res), colnames(python_res)]
python_res_d2 - neuron_rdi_list2$RDI[, 14:26][row.names(python_res), colnames(python_res)]

# test crdi value between python and cpp:  
python_res <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/crdi_results.txt', sep = ',', row.names = 1)
# extract_top_incoming_nodes_delays(neuron_rdi_list$max_rdi_value, neuron_rdi_list$max_rdi_delays, k = 1)
con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(t(data), as.matrix(super_graph), as.matrix(neuron_rdi_list$max_rdi_value), as.matrix(neuron_rdi_list$max_rdi_delays), run_vec - 1, k = 1)

dimnames(con_rdi_res_test) <- list(res$GENE_ID[1:nrow(data)], res$GENE_ID[1:nrow(data)])
con_rdi_res_test[sort(gene_name_vec), sort(gene_name_vec)] # [1:5, 1:5]

mi(matrix(data[, 1], ncol = 1), matrix(data[, 2], ncol = 1), k = 5, normalize = 0)

# res <- read.csv("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/test_data.txt", sep = '\t')
python_res - con_rdi_res_test[row.names(python_res), colnames(python_res)]

# ### test the conditional_RDI 
# set.seed(2017)
# rdi_value <- matrix(sample(1:16, 16), ncol = 4)
# diag(rdi_value) <- 0
# max_rdi_delays <- matrix(1, nrow = 4, ncol = 4)
# 
# res <- extract_top_incoming_nodes_delays(rdi_value, max_rdi_delays, k = 2)
# 
# ####
# test_multiple_run_rdi <- read.csv('./csv_data/test_multiple_run_rdi.txt', sep = '\t')
# cmi(matrix(test_multiple_run_rdi[, 1], ncol = 1), matrix(test_multiple_run_rdi[, 2], ncol = 1), matrix(test_multiple_run_rdi[, 3], ncol = 1), k = 5, normalize = 0)
