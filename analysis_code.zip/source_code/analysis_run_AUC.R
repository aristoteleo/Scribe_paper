# parameters used by Arman on the analysis:
# steps_no=100 (# of samples for each run)
# runs_no=20
# N_end=100 (which means dt=1)
# rdi's parameters: d = [1,2,3]
# crdi's parameters: k = 1
# no_of_repeats = 25

##########################################################################################################################################################
# history:
# v0.1: debug the c++ code to make sure we got the same result as in python
# v0.2: use the parameters from Arman to show that we get the same result as Arman did
# v0.3: make sure the data is based on Arman's dataset
# v0.4: double checked with python code and make sure we get the same result from Python for multiple run;
#       (hope if we run the UCMI method, we will resolve the duplicate points after time steps 200)
# v0.5
##########################################################################################################################################################
# read the data
##########################################################################################################################################################
rm(list = ls()) # make a clear environment
# library(InformationEstimator)
library(devtools)
load_all('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe/') # always use the newest version

library(monocle)
library(reshape2)
library(R.matlab)
library(plyr)
library(xacHelper)

source('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R', echo = T)

########################################################################################################################################################################
#reference network:
########################################################################################################################################################################
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- unique(c(as.character(neuron_network[, 1]), as.character(neuron_network[, 2])))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
# debugging the RDI and cRDI result for 20 runs of the sample
########################################################################################################################################################################
# data_ori <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat.txt', sep = '\t', skip = 1)
# data_ori <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat (3).txt', sep = '\t', skip = 1)
data_ori <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat_n_equal_1.txt', sep = '\t', skip = 1)
# data_ori <- subset(data_ori, V1 != 'Mature')
data <- matrix(nrow = (ncol(data_ori) - 2) * 20, ncol = 13)
data <- data[, ]
gene_vec <- as.character(data_ori$V1)
uniq_gene <- unique(gene_vec)

for(i in 1:length(uniq_gene)) { #1:(ncol(data_ori) - 2)
  tmp <- t(as.matrix(data_ori[data_ori$V1 == uniq_gene[i], -(1:2)]))
  data[, i] <- tmp
}

run_vec <- rep(1:20, each = ncol(data_ori) - 2)
tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

data_rem_dup <- data[!duplicated(data), ]
tmp <- expand.grid(1:ncol(data_rem_dup), 1:ncol(data_rem_dup), stringsAsFactors = F)
super_graph_remove_dup <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph_remove_dup <- super_graph_remove_dup[, c(2, 1)]
#
# add some noise
noise = matrix(rnorm(mean = 0, sd = 0, nrow(data) * ncol(data)), nrow = nrow(data))
noise_remove_dup = matrix(rnorm(mean = 0, sd = 0, nrow(data_rem_dup) * ncol(data_rem_dup)), nrow = nrow(data_rem_dup))

# run multiple rdi
a <- Sys.time()
rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise
b <- Sys.time()
rdi_time <- b - a

dimnames(rdi_list$max_rdi_value) <- list(uniq_gene, uniq_gene)
con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 1)
dimnames(con_rdi_res_test) <- list(uniq_gene, uniq_gene)

# compare with the python implementation (see below)
rdi_list$max_rdi_value[sort(uniq_gene), sort(uniq_gene)]
con_rdi_res_test[sort(uniq_gene), sort(uniq_gene)]

RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))

colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

# calculate the ROC / AUC values
RDI_df <- calROCAUC(RDI_res_df)
cRDI_df <- calROCAUC(cRDI_res_df)

qplot(fpr, tpr, data = RDI_df)
qplot(fpr, tpr, data = cRDI_df)

###############################################################################################################################################################################
# compare the result from python code to seek the difference (successfully confirmed the package)
###############################################################################################################################################################################
# nicely done

python_res_rdi <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/rdi_results_d1_simulation_expr_mat_n_equal_1.txt', sep = ',', row.names = 1)
python_res_crdi <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/crdi_results_simulation_expr_mat_n_equal_1.txt', sep = ',', row.names = 1)

python_res_rdi - rdi_list$max_rdi_value[sort(uniq_gene), sort(uniq_gene)]
python_res_crdi - con_rdi_res_test[sort(uniq_gene), sort(uniq_gene)]

##########################################################################################################################################################
# run RDI /cRDI as a function of number of runs (as runs increass the AUC should also be improved)
########################################################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'

#########################################################################################################################################################
gene_name_vec <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')
all_cell_simulation <- cell_simulate$cell.simulate[, 1:400, ] #time 0-20 are the period two branches appear

row.names(all_cell_simulation) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

#obtain the corresponding lineage for each simulation run:
neuron_cell_ids <- which(all_cell_simulation['Mash1', 400, ] > 2.9)
astrocyte_cell_ids <- which(all_cell_simulation['Scl', 400, ] > 1.9)
oligodendrocyte_cell_ids <- which(all_cell_simulation['Olig2', 400, ] > 1.9)

cell_type_id_list <- list(neuron = neuron_cell_ids, astrocyte = astrocyte_cell_ids, oligodendrocyte = oligodendrocyte_cell_ids)

##########################################################################################################################################################
# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
# run the gradient for all lineages (up to 40 cells)
calStatisticsLadder <- function(data = all_cell_simulation[, 1:200, ], cell_ids = neuron_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25, 40), delay = c(1), uniformalize = FALSE) {

  # collect the RDI and cRDI network for each run
  RDI_parallel_res_list <- list()
  cRDI_parallel_res_list <- list()

  # run RDI / cRDI for each sampled run
  for(id in ladder_vec) {
    message(id)

    # a <- Sys.time() # calculate RDI
    # RDI_parallel_res <- calculate_rdi_many_run(all_cell_simulation[, 1:200, ], sample(cell_ids, id))
    # b <- Sys.time()

    RDI_parallel_res <- calculate_rdi_many_run_concatenation(data, sample(cell_ids, id), delay = delay, uniformalize)

    # no conditioning for this part:
    # a <- Sys.time() # calculate cRDI
    # cRDI_parallel_res <- calculate_rdi_many_run(all_cell_simulation[, 1:200, ], sample(cell_ids, id))
    # b <- Sys.time()

    RDI_parallel_res_list <- c(RDI_parallel_res_list, RDI_parallel_res = list(RDI_parallel_res$max_rdi_value)) # RDI_parallel_res returned is a matrix
    cRDI_parallel_res_list <- c(cRDI_parallel_res_list, cRDI_parallel_res = list(RDI_parallel_res$con_rdi_res_test))
  }

  # extract only the max_rdi_values
  RDI_res_df <- process_data(RDI_parallel_res_list); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
  cRDI_res_df <- process_data(cRDI_parallel_res_list); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))

  colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
  # colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

  # calculate the ROC / AUC values
  RDI_df <- calROCAUC(RDI_res_df)
  cRDI_df <- calROCAUC(cRDI_res_df)

  # return the results
  return(list(RDI_df = RDI_df, cRDI_df = cRDI_df, RDI_parallel_res_list = RDI_parallel_res_list, cRDI_parallel_res_list = cRDI_parallel_res_list))
}

# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
# function to run multiple run by concatenation:
calculate_rdi_many_run_concatenation <- function(x3d, cell_ids = neuron_cell_ids, delay = c(1), sd = 0, uniformalize = FALSE) {
  # concatenate to a two-dimensional matrix instead of a three dimensional one
  data <- x3d[, , cell_ids] # subset the data

  run_vec <- rep(1:length(cell_ids), each = dim(data)[2]) # set the run id for each cell

  dim(data) <- c(nrow(x3d), dim(data)[2] * dim(data)[3]) # convert the dimension of data

  # correctly assign the value for each gene (firstly use entire run from the first run followed by the second run, etc.)
  for(i in 1:nrow(x3d)) {
    tmp <- x3d[i, , cell_ids]
    dim(tmp) <- c(1, dim(tmp)[1] * dim(tmp)[2])
    data[i, ] <- tmp
  }

  # add random noise
  set.seed(831)
  noise = matrix(rnorm(mean = 0, sd = sd, nrow(data) * ncol(data)), nrow = nrow(data)) # 1e-12
  # noise = matrix(rnorm(mean = 0, sd = sd, nrow(data) * ncol(data)), nrow = nrow(data))
  data_noise <- t(data + noise)

  tmp <- expand.grid(1:ncol(data_noise), 1:ncol(data_noise), stringsAsFactors = F)
  super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
  super_graph <- super_graph[, c(2, 1)]

  # calculate rdi values
  a <- Sys.time()
  rdi_list <- calculate_rdi_multiple_run_cpp(data_noise, delay = delay, run_vec - 1, as.matrix(super_graph), method = 1, uniformalize) #calculate_rdi(data_noise, delay, method = 1)
  b <- Sys.time()
  rdi_time <- b - a

  # calculate crdi values
  con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data_noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 5)

  return(list(max_rdi_value = rdi_list$max_rdi_value, con_rdi_res_test = con_rdi_res_test))
}

# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
calculate_rdi_many_run <- function(x3d, cell_ids = neuron_cell_ids, sd = 0, uniformalize = FALSE) {
  gene_step_cells <- dim(x3d)

  res <- matrix(nrow = gene_step_cells[1], ncol = gene_step_cells[1])

  noise = matrix(rnorm(mean = 0, sd = sd, gene_step_cells[2] * length(cell_ids)), nrow = gene_step_cells[2])

  for(i in 1:gene_step_cells[1]) {
    for(j in 1:gene_step_cells[1]) {
      message(paste('i is', i, 'j is', j))
      if(i == j) {
        res[i, j] <- NA
      }
      else {
        res[i, j] <- rdi_many_runs(as.matrix(x3d[i, ,cell_ids]) + noise, as.matrix(x3d[j, ,cell_ids]) + noise, uniformalize) # + noise
        message(res[i, j])
      }
    }
  }

  return(res)
}

# # rdi_many_runs(x3d[i, ,cell_ids], x3d[i, ,cell_ids])
# rdi_many_runs(all_cell_simulation[, 1:200, ][1, , neuron_cell_ids], all_cell_simulation[, 1:200, ][2, ,neuron_cell_ids])
# rdi_many_runs(as.matrix(all_cell_simulation[, 1:200, ][1, , neuron_cell_ids]), all_cell_simulation[, 1:200, ][2, ,neuron_cell_ids])
#
# x3d <- all_cell_simulation[, 1:200, ][, , neuron_cell_ids]
# new.data <- aperm(x3d, c(1, 3, 2))

# # test
# a <- Sys.time()
# test <- calculate_rdi_many_run(all_cell_simulation[, 1:200, ], neuron_cell_ids)
# b <- Sys.time()
################################################################################################################################################################################
# convert the data into x3d
################################################################################################################################################################################
# data_ori <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat (3).txt', sep = '\t', skip = 1)
data_ori <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat_n_equal_1.txt', sep = '\t', skip = 1)
x3d <- array(dim = c(13, 101, 20))

data_ori_gene_unique <- unique(data_ori$V1)

data_ori$V2
for(i in 1:dim(x3d)[1]) {
  for(j in 1:dim(x3d)[3]) {
    x3d[i, , j] <- as.numeric(data_ori[data_ori$V1 == data_ori_gene_unique[i] & data_ori$V2 == paste0("R", j), -c(1:2)]) # make sure data_ori$V2 has R#
  }
}

dim(x3d)

message('run Arman parameters ...')
Arman_ladder <- calStatisticsLadder(data = x3d, cell_ids = 1:20, ladder_vec = c(2, 5, 8, 10, 12, 15, 18, 20))

Arman_ladder$cRDI_df$method <- rep(c("cluster_1", "cluster_2", "cluster_3", "cluster_4", "cluster_5", "cluster_6", "cluster_7", "cluster_8"), each = 133)
Arman_ladder$cRDI_df$method  <- as.character(Arman_ladder$cRDI_df$method)
Arman_ladder$cRDI_df$method <- revalue(Arman_ladder$cRDI_df$method, c("cluster_1" = 2,  "cluster_2" = 5, "cluster_3" = 8, "cluster_4" = 10, "cluster_5" = 12,  "cluster_6" = 15, "cluster_7" = 18, "cluster_8" = 20))
Arman_ladder$cRDI_df$method <- as.numeric(Arman_ladder$cRDI_df$method)
Arman_ladder$RDI_df$method <- Arman_ladder$cRDI_df$method

pdf(paste0(SI_fig_dir, 'Arman_Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = subset(Arman_ladder$RDI_df, method != 25)) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()

pdf(paste0(SI_fig_dir, 'Arman_Runs_AUC_cRDI.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = subset(Arman_ladder$cRDI_df, method != 25)) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (cRDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()

################################################################################################################################################################################
# run the analysis on 25 simulation datasets
################################################################################################################################################################################
all_sim_res_RDI <- matrix(nrow = 8 * 25, ncol = 3)
all_sim_res_RDI[, 3] <- rep(1:25, each = 8)
all_sim_res_RDI <- as.data.frame(all_sim_res_RDI)
colnames(all_sim_res_RDI) <- c('auc', 'Runs', 'ind')
all_sim_res_cRDI <- all_sim_res_RDI

for(file_ind in 0:24) {
  file <- paste0("simulation_expr_mat_n_equal_", file_ind)
  message(paste0("current file is ", file))
  data_ori <- read.table(paste0('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/', file), sep = '\t', skip = 1)
  x3d <- array(dim = c(13, 101, 20))

  data_ori_gene_unique <- unique(data_ori$V1)

  data_ori$V2
  for(i in 1:dim(x3d)[1]) {
    for(j in 1:dim(x3d)[3]) {
      x3d[i, , j] <- as.numeric(data_ori[data_ori$V1 == data_ori_gene_unique[i] & data_ori$V2 == paste0("R", j), -c(1:2)]) # make sure data_ori$V2 has R#
    }
  }

  dim(x3d)

  message('run Arman parameters ...')
  Arman_ladder <- calStatisticsLadder(data = x3d, cell_ids = 1:20, ladder_vec = c(2, 5, 8, 10, 12, 15, 18, 20))

  Arman_ladder$cRDI_df$method <- rep(c("cluster_1", "cluster_2", "cluster_3", "cluster_4", "cluster_5", "cluster_6", "cluster_7", "cluster_8"), each = 133)
  Arman_ladder$cRDI_df$method  <- as.character(Arman_ladder$cRDI_df$method)
  Arman_ladder$cRDI_df$method <- revalue(Arman_ladder$cRDI_df$method, c("cluster_1" = 2,  "cluster_2" = 5, "cluster_3" = 8, "cluster_4" = 10, "cluster_5" = 12,  "cluster_6" = 15, "cluster_7" = 18, "cluster_8" = 20))
  Arman_ladder$cRDI_df$method <- as.numeric(Arman_ladder$cRDI_df$method)
  Arman_ladder$RDI_df$method <- Arman_ladder$cRDI_df$method

  all_sim_res_RDI[(file_ind * 8 + 1): ((file_ind+1) * 8), 1:2] <- unique(Arman_ladder$RDI_df[, c('auc', 'method')])
  all_sim_res_cRDI[(file_ind * 8 + 1): ((file_ind+1) * 8), 1:2] <- unique(Arman_ladder$cRDI_df[, c('auc', 'method')])

}

# make the boxplot:
# ggplot(aes(x = as.factor(Runs), y = auc), data = all_sim_res_RDI) + geom_boxplot()
pdf(paste0(SI_fig_dir, 'Arman_Runs_AUC_boxplot.pdf'), width =  1, height = 1) #+ geom_line(aes(color = "red"))
ggplot(aes(x = Runs, y = auc), data = all_sim_res_RDI) + geom_boxplot(aes(color = Runs, group = ind)) + xlab('') + ylab('AUC (RDI)') + nm_theme() #+ geom_smooth()
dev.off()

pdf(paste0(SI_fig_dir, 'Arman_Runs_AUC_cRDI_boxplot.pdf'), width =  1, height = 1)
ggplot(aes(Runs, auc), data = all_sim_res_cRDI) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (cRDI)') + nm_theme() + ylim(0, 1)#+ geom_smooth()
dev.off()

################################################################################################################################################################################
# run the analysis on the more realistic simulation dataset
################################################################################################################################################################################

# debug(calStatisticsLadder)
message('run neuron ...')
neuron_ladder <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = neuron_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25), delay = 1) #

# add both of the RDI and cRDI's result here
neuron_ladder$RDI_df$method <- revalue(neuron_ladder$RDI_df$method, c("cluster_1" = 2,  "cluster_2" = 5, "cluster_3" = 10, "cluster_4" = 15, "cluster_5" = 20,  "cluster_6" = 25))
neuron_ladder$RDI_df$method <- as.numeric(as.character(neuron_ladder$RDI_df$method))
neuron_ladder$cRDI_df$method <- revalue(neuron_ladder$cRDI_df$method, c("cRDI_parallel_res" = 2,  "cRDI_parallel_res1" = 5, "cRDI_parallel_res2" = 10, "cRDI_parallel_res3" = 15, "cRDI_parallel_res4" = 20,  "cRDI_parallel_res5" = 25))
neuron_ladder$cRDI_df$method <- as.numeric(as.character(neuron_ladder$cRDI_df$method))
# neuron_ladder$cRDI_df$method <- neuron_ladder$RDI_df$method

pdf(paste0(SI_fig_dir, 'Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder$RDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()
pdf(paste0(SI_fig_dir, 'cRDI_Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder$cRDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()

# neuron_ladder <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = neuron_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25), delay = 1) #, 20, 25, 40

message('run astrocyte ...')
astrocyte_ladder <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = astrocyte_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25))
message('run oligodendrocyte ...')
oligodendrocyte_ladder <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = oligodendrocyte_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25))

################################################################################################################################################################
message('run lineage mixture (uniformly mix the lineages) ...')
set.seed(2017)
mix_cell_ids <- c(sample(neuron_cell_ids, 1), sample(astrocyte_cell_ids, 1), sample(oligodendrocyte_cell_ids, 1))
nao_ladder_3 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(3))

mix_cell_ids <- c(sample(neuron_cell_ids, 2), sample(astrocyte_cell_ids, 2), sample(oligodendrocyte_cell_ids, 2))
nao_ladder_6 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(6))

mix_cell_ids <- c(sample(neuron_cell_ids, 3), sample(astrocyte_cell_ids, 3), sample(oligodendrocyte_cell_ids, 3))
nao_ladder_9 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(9))

mix_cell_ids <- c(sample(neuron_cell_ids, 5), sample(astrocyte_cell_ids, 5), sample(oligodendrocyte_cell_ids, 5))
nao_ladder_12 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(12))

mix_cell_ids <- c(sample(neuron_cell_ids, 7), sample(astrocyte_cell_ids, 7), sample(oligodendrocyte_cell_ids, 7))
nao_ladder_15 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(15))

mix_cell_ids <- c(sample(neuron_cell_ids, 9), sample(astrocyte_cell_ids, 9), sample(oligodendrocyte_cell_ids, 9))
nao_ladder_18 <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = mix_cell_ids, ladder_vec = c(18))

nao_ladder_all_RDI_df <- Reduce(f = rbind, list(nao_ladder_3$RDI_df, nao_ladder_6$RDI_df, nao_ladder_9$RDI_df, nao_ladder_12$RDI_df, nao_ladder_15$RDI_df, nao_ladder_18$RDI_df))
nao_ladder_all_cRDI_df <- Reduce(f = rbind, list(nao_ladder_3$cRDI_df, nao_ladder_6$cRDI_df, nao_ladder_9$cRDI_df, nao_ladder_12$cRDI_df, nao_ladder_15$cRDI_df, nao_ladder_18$cRDI_df))

# update the number of cells:
nao_ladder_all_RDI_df$method <- rep(c(3, 6, 9, 12, 15, 18), each = nrow(nao_ladder_3$RDI_df))
# nao_ladder_all_cRDI_df$method <- rep(c(3, 6, 9, 12, 15, 18), each = nrow(nao_ladder_3$cRDI_df))
qplot(method, auc, data = nao_ladder_all_RDI_df)
qplot(method, auc, data = nao_ladder_all_cRDI_df)

################################################################################################################################################################
# check the AUC across different runs:
many_run_ladder_auc_df <- data.frame(Type = c(rep("neuron", 6),
                                       rep("astrocyte", 6),
                                       rep("oligodendrocyte", 6),
                                       rep("mixture lineage", 6)),
                                     Runs = c(rep(c(2, 5, 10, 15, 20, 25), 3), c(3, 6, 9, 12, 15, 18)),
                                     AUC = c(unique(neuron_ladder$RDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(astrocyte_ladder$RDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(oligodendrocyte_ladder$RDI_df[, c('method', 'auc')])[, 'auc'],
                                       unique(nao_ladder_all_RDI_df[, c('method', 'auc')])[, 'auc']))
pdf(paste0(main_fig_dir, 'Runs_AUC.pdf'), width = 1, height = 1)
ggplot(aes(Runs, AUC), data = many_run_ladder_auc_df) + geom_line(aes(color = Type)) + xlab('') + ylim(0, 1) + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'Runs_AUC_helper.pdf'))
ggplot(aes(Runs, AUC), data = many_run_ladder_auc_df) + geom_line(aes(color = Type)) + xlab('') + ylim(0, 1)
dev.off()

################################################################################################################################################################
# Potential thing to do:
# Run simple concatenation to compare the result from the more sophisticated concatenation
################################################################################################################################################################
# The result is pretty much the same
data <- t(all_cell_simulation[, 1:200, neuron_cell_ids[2]])

run_vec <- rep(1, each = nrow(data))

# run multiple rdi
a <- Sys.time()
rdi_list <- calculate_rdi_multiple_run_cpp(data, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0, uniformalize = F) #* 100 + noise
b <- Sys.time()
rdi_time <- b - a

uniq_gene <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

dimnames(rdi_list$max_rdi_value) <- list(uniq_gene, uniq_gene)
con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 1, uniformalize = F)
dimnames(con_rdi_res_test) <- list(uniq_gene, uniq_gene)

# compare with the python implementation (see below)
rdi_list$max_rdi_value[sort(uniq_gene), sort(uniq_gene)]
con_rdi_res_test[sort(uniq_gene), sort(uniq_gene)]

RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))

colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

# calculate the ROC / AUC values
RDI_df <- calROCAUC(RDI_res_df)
cRDI_df <- calROCAUC(cRDI_res_df)

qplot(fpr, tpr, data = RDI_df)
qplot(fpr, tpr, data = cRDI_df)

##########################################################################################################################################################

##########################################################################################################################################################
# save the data
save.image('./RData/analysis_run_AUC.RData')
