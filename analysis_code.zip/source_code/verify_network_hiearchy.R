# Sreeram's suggestion: Out_degree_sum - In_degree_sum 

library(xacHelper)
library(InformationEstimator)
library(destiny)
library(monocle)
library(plyr)

lung <- load_lung()
AT1_lung <- lung[, pData(lung)$State %in% c(1, 3)]
AT2_lung <- lung[, pData(lung)$State %in% c(1, 2)]
AT1_dpt_res <- run_new_dpt(AT1_lung)

AT2_lung <- AT2_lung[, ! pData(AT2_lung)$Time %in% c('Adult')] 
AT2_dpt_res <- run_new_dpt(AT2_lung)
AT2_lung <- reduceDimension(AT2_lung)
AT2_lung <- orderCells(AT2_lung)
AT2_lung <- orderCells(AT2_lung, root_state = 3)

lung_exprs_AT1 <- t(exprs(AT1_lung)[, order(AT1_dpt_res$pt)])
lung_exprs_AT2 <- t(exprs(AT2_lung)[, order(pData(AT2_lung)$Pseudotime)]) #AT2_dpt_res$pt

## add smoothing and different delays (maybe we don't really need it because we have all those delay, etc.)
lung_exprs_AT1_smth <- smooth_gene(lung_exprs_AT1, 10)
lung_exprs_AT2_smth <- smooth_gene(lung_exprs_AT2, 10)

AT1_early <- c("Aqp5", "Pdpn", "Rtkn2", "Ager", "Emp2", "Cav1", "Clic5", "Lmo7", "S100a6", "Col4a3", "Akap5", "Cryab")
AT1_late <- c("Sdpr", "S100a14")

AT2_early <- c("Fabp5", "Lamp3", "Cd36", "Scd1", "Sftpb", "Slc34a2", "Abca3", "Sftpa1", "Egfl6", "Soat1", "Bex2", "Muc1", "Sftpc")
AT2_late <- c("Lcn2", "Il33", "Hc", "Trf", "Lyz2", "S100g", "Lyz1")

all_genes <- c(AT1_early, AT1_late, AT2_early, AT2_late)

## best way to visualize the data 
## try also cRDI 
regulatory_hiearchy_network <- function(cds, exprs_data_1, exprs_data_2, 
                                        early_1 = AT1_early, late_1 = AT1_late, 
                                        early_2 = AT2_early, late_2 = AT2_late,
                                        cell_types = c("AT1", 'AT2'),
                                        time_category = c('AT1_early', 'AT1_late', 'AT2_early', 'AT2_late')) {
  set.seed(2017)
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_1) * ncol(exprs_data_1)), nrow = nrow(exprs_data_1))
  a <- Sys.time()
  RDI_parallel_res_1_list <- calculate_rdi(exprs_data_1 + noise, delays = c(5, 10, 15), method = 1) #, R_cores = detectCores() - 2
  b <- Sys.time()
  
  set.seed(2017)
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_2) * ncol(exprs_data_2)), nrow = nrow(exprs_data_2))
  a <- Sys.time()
  RDI_parallel_res_2_list <- calculate_rdi(exprs_data_2 + noise, delays = c(5, 10, 15), method = 1)
  b <- Sys.time()
  
  RDI_parallel_res_1 <- RDI_parallel_res_1_list$RDI
  RDI_parallel_res_2 <- RDI_parallel_res_2_list$RDI
  # clr_res_1 <- clr(AT1_RDI_parallel_res) #
  clr_res_1 <- t(apply(RDI_parallel_res_1[, 1:nrow(RDI_parallel_res_1)], 1, function(x) (x - mean(x)) / (sd(x)))); clr_res_1[clr_res_1 < 0] <- 0
  #clr_res_2 <- clr(AT2_RDI_parallel_res) #
  clr_res_2 <- t(apply(RDI_parallel_res_2[, 1:nrow(RDI_parallel_res_1)], 1, function(x) (x - mean(x)) / (sd(x)))); clr_res_2[clr_res_2 < 0] <- 0
  
  RDI_parallel_res_subset_1 <- RDI_parallel_res_1[, 1:nrow(RDI_parallel_res_1)] 
  dimnames(RDI_parallel_res_subset_1) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);
  RDI_parallel_res_subset_2 <- RDI_parallel_res_2[, 1:nrow(RDI_parallel_res_1)] 
  dimnames(RDI_parallel_res_subset_2) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);
  
  dimnames(clr_res_1) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);
  dimnames(clr_res_2) <- list(fData(cds)$gene_short_name, fData(cds)$gene_short_name);

  all_genes <- c(early_1, late_1, early_2, late_2)
  
  graph_res_1 <- igraph::graph_from_adjacency_matrix(clr_res_1[all_genes, all_genes], mode = 'directed', weighted = T)
  # plot(graph_res_1, layout = layout.fruchterman.reingold(graph_res_1), vertex.size=2, vertex.label.size=4)

  graph_res_2 <- igraph::graph_from_adjacency_matrix(clr_res_2, mode = 'directed', weighted = T)
  # plot(graph_res_2, layout = layout.fruchterman.reingold(graph_res_2), vertex.size=2, vertex.label.size=4)

  Branch_1_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_1, ])
  Branch_1_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_1, ])
  Branch_2_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_2, ])
  Branch_2_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_2, ])

  Branch_1_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_1, ])
  Branch_1_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_1, ])
  Branch_2_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_2, ])
  Branch_2_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_2, ])

  rdi_df <- data.frame(sum_of_output_rdi =
                         c(Branch_1_rdi_sum_early_1, Branch_1_rdi_sum_late_1, Branch_2_rdi_sum_early_1, Branch_2_rdi_sum_late_1,
                           Branch_1_rdi_sum_early_2, Branch_1_rdi_sum_late_2, Branch_2_rdi_sum_early_2, Branch_2_rdi_sum_late_2),
                       Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                       Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                    rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))

  p <- ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') + geom_jitter(aes(color = Time))

  # cRDI  
  set.seed(2017)
  a <- Sys.time()
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_1) * ncol(exprs_data_1)), nrow = nrow(exprs_data_1))
  cRDI_R_1 <- calculate_conditioned_rdi(exprs_data_1 + noise, super_graph = NULL, RDI_parallel_res_1_list, 1L)
  b <- Sys.time(); b - a
  
  set.seed(2017)
  a <- Sys.time()
  noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(exprs_data_2) * ncol(exprs_data_2)), nrow = nrow(exprs_data_2))
  cRDI_R_2 <- calculate_conditioned_rdi(exprs_data_2 + noise, super_graph = NULL, RDI_parallel_res_2_list, 1L)
  b <- Sys.time(); b - a
  
  return(list(RDI_parallel_res_subset_1 = RDI_parallel_res_subset_1, RDI_parallel_res_subset_2 = RDI_parallel_res_subset_2, 
              clr_res_1 = clr_res_1, clr_res_2 = clr_res_2, rdi_df = rdi_df, p = NA, 
              RDI_res_list_1 = RDI_parallel_res_1_list, RDI_res_list_2 = RDI_parallel_res_2_list,
              cRDI_R_1 = cRDI_R_1, cRDI_R_2 = cRDI_R_2))
}

#####################################################################################################################################################################
# test no smoothing RDI values: 
#####################################################################################################################################################################

lung_AT1_AT2 <- regulatory_hiearchy_network(lung, lung_exprs_AT1, lung_exprs_AT2)
set.seed(2017)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(lung_exprs_AT1) * ncol(lung_exprs_AT1)), nrow = nrow(lung_exprs_AT1))
cRDI_R_AT1 <- calculate_conditioned_rdi(lung_exprs_AT1 + noise, super_graph = NULL, lung_AT1_AT2$RDI_res_list_1, 1L)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(lung_exprs_AT2) * ncol(lung_exprs_AT2)), nrow = nrow(lung_exprs_AT2))
cRDI_R_AT2 <- calculate_conditioned_rdi(lung_exprs_AT2 + noise, super_graph = NULL, lung_AT1_AT2$RDI_res_list_2, 1L)

# make figures: 
load("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/InformationEstimator/rdi_df")
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_lung.pdf', height = 1.5, width = 1.5)
ggplot(aes(Type, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Time), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

RDI_parallel_res_subset_1 <- lung_AT1_AT2$RDI_parallel_res_subset_1
RDI_parallel_res_subset_2 <- lung_AT1_AT2$RDI_parallel_res_subset_2

RDI_parallel_res_subset_1 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_1) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_1))))
RDI_parallel_res_subset_2 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_2) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_2))))

Branch_1_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_1, ], na.rm = T)
Branch_1_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_1, ], na.rm = T)
Branch_2_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_2, ], na.rm = T)
Branch_2_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_2, ], na.rm = T)

Branch_1_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_1, ], na.rm = T)
Branch_1_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_1, ], na.rm = T)
Branch_2_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_2, ], na.rm = T)
Branch_2_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_2, ], na.rm = T)

rdi_df <- data.frame(sum_of_input_rdi =
                                c(Branch_1_rdi_sum_early_1, Branch_1_rdi_sum_late_1, Branch_2_rdi_sum_early_1, Branch_2_rdi_sum_late_1,
                                  Branch_1_rdi_sum_early_2, Branch_1_rdi_sum_late_2, Branch_2_rdi_sum_early_2, Branch_2_rdi_sum_late_2),
                              Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                              Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                           rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_lung_indegree_clr.pdf', height = 1.5, width = 1.5)
ggplot(aes(Type, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Time), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme()
dev.off()

indegree_Branch_1_rdi_sum_early_1 = colSums(RDI_parallel_res_subset_1[, early_1])
indegree_Branch_1_rdi_sum_late_1 = colSums(RDI_parallel_res_subset_1[, late_1])
indegree_Branch_2_rdi_sum_early_1 = colSums(RDI_parallel_res_subset_1[, early_2])
indegree_Branch_2_rdi_sum_late_1 = colSums(RDI_parallel_res_subset_1[, late_2])

indegree_Branch_1_rdi_sum_early_2 = colSums(RDI_parallel_res_subset_2[, early_1])
indegree_Branch_1_rdi_sum_late_2 = colSums(RDI_parallel_res_subset_2[, late_1])
indegree_Branch_2_rdi_sum_early_2 = colSums(RDI_parallel_res_subset_2[, early_2])
indegree_Branch_2_rdi_sum_late_2 = colSums(RDI_parallel_res_subset_2[, late_2])

indegree_rdi_df <- data.frame(sum_of_input_rdi =
                                 c(indegree_Branch_1_rdi_sum_early_1, indegree_Branch_1_rdi_sum_late_1, indegree_Branch_2_rdi_sum_early_1, indegree_Branch_2_rdi_sum_late_1,
                                   indegree_Branch_1_rdi_sum_early_2, indegree_Branch_1_rdi_sum_late_2, indegree_Branch_2_rdi_sum_early_2, indegree_Branch_2_rdi_sum_late_2),
                               Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                               Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                            rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_lung_indegree.pdf', height = 1.5, width = 1.5)
ggplot(aes(Type, sum_of_input_rdi), data = indegree_rdi_df) + geom_boxplot(aes(fill = Time), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme()
dev.off()
#####################################################################################################################################################################
# test running conditional restricted direction information: 
#####################################################################################################################################################################
early_1 = AT1_early; late_1 = AT1_late;
early_2 = AT2_early; late_2 = AT2_late

RDI_parallel_res_subset_1 <- lung_AT1_AT2$cRDI_R_1; 
RDI_parallel_res_subset_2 <- lung_AT1_AT2$cRDI_R_2; 

# run indegree CLR:
diag(RDI_parallel_res_subset_1) <- 0
diag(RDI_parallel_res_subset_2) <- 0

RDI_parallel_res_subset_1 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_1) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_1))))
RDI_parallel_res_subset_2 <- sqrt(InformationEstimator::clr(RDI_parallel_res_subset_2) * t(InformationEstimator::clr(t(RDI_parallel_res_subset_2))))

dimnames(RDI_parallel_res_subset_1) <- list(fData(AT2_lung)$gene_short_name, fData(AT2_lung)$gene_short_name);
dimnames(RDI_parallel_res_subset_2) <- list(fData(AT2_lung)$gene_short_name, fData(AT2_lung)$gene_short_name);

cBranch_1_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_1, ], na.rm = T)
cBranch_1_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_1, ], na.rm = T)
cBranch_2_rdi_sum_early_1 = rowSums(RDI_parallel_res_subset_1[early_2, ], na.rm = T)
cBranch_2_rdi_sum_late_1 = rowSums(RDI_parallel_res_subset_1[late_2, ], na.rm = T)

cBranch_1_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_1, ], na.rm = T)
cBranch_1_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_1, ], na.rm = T)
cBranch_2_rdi_sum_early_2 = rowSums(RDI_parallel_res_subset_2[early_2, ], na.rm = T)
cBranch_2_rdi_sum_late_2 = rowSums(RDI_parallel_res_subset_2[late_2, ], na.rm = T)

indegree_cBranch_1_rdi_sum_early_1 = colSums(RDI_parallel_res_subset_1[, early_1], na.rm = T)
indegree_cBranch_1_rdi_sum_late_1 = colSums(RDI_parallel_res_subset_1[, late_1], na.rm = T)
indegree_cBranch_2_rdi_sum_early_1 = colSums(RDI_parallel_res_subset_1[, early_2], na.rm = T)
indegree_cBranch_2_rdi_sum_late_1 = colSums(RDI_parallel_res_subset_1[, late_2], na.rm = T)

indegree_cBranch_1_rdi_sum_early_2 = colSums(RDI_parallel_res_subset_2[, early_1], na.rm = T)
indegree_cBranch_1_rdi_sum_late_2 = colSums(RDI_parallel_res_subset_2[, late_1], na.rm = T)
indegree_cBranch_2_rdi_sum_early_2 = colSums(RDI_parallel_res_subset_2[, early_2], na.rm = T)
indegree_cBranch_2_rdi_sum_late_2 = colSums(RDI_parallel_res_subset_2[, late_2], na.rm = T)

cell_types = c("AT1", 'AT2')
time_category = c('AT1_early', 'AT1_late', 'AT2_early', 'AT2_late')
crdi_df <- data.frame(sum_of_output_rdi =
                       c(cBranch_1_rdi_sum_early_1, cBranch_1_rdi_sum_late_1, cBranch_2_rdi_sum_early_1, cBranch_2_rdi_sum_late_1,
                         cBranch_1_rdi_sum_early_2, cBranch_1_rdi_sum_late_2, cBranch_2_rdi_sum_early_2, cBranch_2_rdi_sum_late_2),
                     Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                     Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                  rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_crdi_lung.pdf', height = 1.5, width = 1.5)
ggplot(aes(Type, sum_of_output_rdi), data = crdi_df) + geom_boxplot(aes(fill = Time), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme()
dev.off()

indegree_crdi_df <- data.frame(sum_of_input_rdi =
                        c(indegree_cBranch_1_rdi_sum_early_1, indegree_cBranch_1_rdi_sum_late_1, indegree_cBranch_2_rdi_sum_early_1, indegree_cBranch_2_rdi_sum_late_1,
                          indegree_cBranch_1_rdi_sum_early_2, indegree_cBranch_1_rdi_sum_late_2, indegree_cBranch_2_rdi_sum_early_2, indegree_cBranch_2_rdi_sum_late_2),
                      Type = c(rep(cell_types[1], length(all_genes)), rep(cell_types[2], length(all_genes))),
                      Time = rep(c(rep(time_category[1], length(early_1)), rep(time_category[2], length(late_1)),
                                   rep(time_category[3], length(early_2)), rep(time_category[4], length(late_2))), 2))

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_crdi_lung_indegree.pdf', height = 1.5, width = 1.5)
ggplot(aes(Type, sum_of_input_rdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Time), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme()
dev.off()

# make the network: 
order(RDI_parallel_res_subset_1, decreasing = T)[1.5 * nrow(RDI_parallel_res_subset_1)]
RDI_parallel_res_subset_1[28262]
# [1] 3.110456
RDI_parallel_res_subset_1_graph <- RDI_parallel_res_subset_1; RDI_parallel_res_subset_1_graph[RDI_parallel_res_subset_1_graph < 3.110456] <- 0

graph_res_1 <- igraph::graph_from_adjacency_matrix(RDI_parallel_res_subset_1_graph[, ], mode = 'directed', weighted = T)
plot(graph_res_1, layout = layout.circle(graph_res_1), vertex.size=2, vertex.label.size=4)

#####################################################################################################################################################################
# test on the LPS dataset:
#####################################################################################################################################################################
load("/Users/xqiu/Desktop/shalek_custom_color_scale_plus_states")
load("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/Shalek_abs_subset_ko_LPS_new")

plot_spanning_tree(Shalek_abs_subset_ko_LPS_new, color_by="interaction(experiment_name, time)", cell_size=2) + 
  scale_color_manual(values=shalek_custom_color_scale_plus_states) + nm_theme()

# test on only the normal cells 
Shalek_abs_subset_normal <- Shalek_abs_subset_ko_LPS_new[, pData(Shalek_abs_subset_ko_LPS_new)$experiment_name %in% c('LPS', 'Unstimulated_Replicate')]
Shalek_abs_subset_normal <- setOrderingFilter(Shalek_abs_subset_normal, all_gene_ids)
Shalek_abs_subset_normal <- reduceDimension(Shalek_abs_subset_normal)
Shalek_abs_subset_normal <- orderCells(Shalek_abs_subset_normal, reverse = T)
plot_cell_trajectory(Shalek_abs_subset_normal, color_by = 'time')
plot_cell_trajectory(Shalek_abs_subset_normal, color_by = 'Pseudotime')

exprs(Shalek_abs_subset_normal) <- as.matrix(exprs(Shalek_abs_subset_normal))
Shalek_abs_subset_normal_dpt_res <- run_new_dpt(Shalek_abs_subset_normal)

# Antiviral regulators and the targets 
#select only the significant genes: 
top_group <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "FUS")

#set the inferred regulators and the potential targets 
# top_group <- c("STAT2", "IRF1", "IRF2") 
bottom_group <- c("Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Usp25", "Daxx", "Cd40", "Atm", "Lrf1", "Lgp2", "Mertk", "Cxcl11", "Trim12", "Trim21")

top_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(top_group)))
fData(Shalek_abs_subset_ko_LPS_new)[top_group_ids, 'gene_short_name']
bottom_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS_new), toupper(gene_short_name) %in% toupper(bottom_group)))
fData(Shalek_abs_subset_ko_LPS_new)[bottom_group_ids, 'gene_short_name']

all_gene_ids <- c(top_group_ids, bottom_group_ids)

# test on only the normal cells 
Shalek_abs_subset_normal <- Shalek_abs_subset_ko_LPS_new[, pData(Shalek_abs_subset_ko_LPS_new)$experiment_name %in% c('LPS', 'Unstimulated_Replicate')]
Shalek_abs_subset_normal <- setOrderingFilter(Shalek_abs_subset_normal, all_gene_ids)
Shalek_abs_subset_normal <- reduceDimension(Shalek_abs_subset_normal)
Shalek_abs_subset_normal <- orderCells(Shalek_abs_subset_normal, reverse = T)
plot_cell_trajectory(Shalek_abs_subset_normal, color_by = 'time')
plot_cell_trajectory(Shalek_abs_subset_normal, color_by = 'Pseudotime')

# Normal cells 
Shalek_abs_subset_normal_state <- Shalek_abs_subset_normal[, pData(Shalek_abs_subset_normal)$State %in% c(1, 3)]
exprs(Shalek_abs_subset_normal_state) <- as.matrix(exprs(Shalek_abs_subset_normal_state))
Shalek_abs_subset_normal_state_dpt_res <- run_new_dpt(Shalek_abs_subset_normal_state)
Shalek_abs_subset_normal_state_exprs <- t(exprs(Shalek_abs_subset_normal_state)[all_gene_ids, order(Shalek_abs_subset_normal_state_dpt_res$pt)])

# KO cells 
Shalek_abs_subset_KO_state <- Shalek_abs_subset_normal[, pData(Shalek_abs_subset_normal)$State %in% c(1, 2)]
exprs(Shalek_abs_subset_KO_state) <- as.matrix(exprs(Shalek_abs_subset_KO_state))
Shalek_abs_subset_KO_state_dpt_res <- run_new_dpt(Shalek_abs_subset_KO_state)
Shalek_abs_subset_KO_state_exprs <- t(exprs(Shalek_abs_subset_KO_state)[all_gene_ids, order(Shalek_abs_subset_KO_state_dpt_res$pt)])

# run RDI network 
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Shalek_abs_subset_normal_state_exprs) * ncol(Shalek_abs_subset_normal_state_exprs)), nrow = nrow(Shalek_abs_subset_normal_state_exprs))

a <- Sys.time()
Shalek_abs_subset_normal_state_RDI_parallel_res <- calculate_rdi(Shalek_abs_subset_normal_state_exprs + noise, delays = c(5, 10, 15), method = 1)
b <- Sys.time()

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Shalek_abs_subset_KO_state_exprs) * ncol(Shalek_abs_subset_KO_state_exprs)), nrow = nrow(Shalek_abs_subset_KO_state_exprs))
a <- Sys.time()
Shalek_abs_subset_KO_state_RDI_parallel_res <- calculate_rdi(Shalek_abs_subset_KO_state_exprs + noise, delays = c(5, 10, 15), method = 1) # KO branch doesn't work 
b <- Sys.time()

Shalek_abs_subset_normal_state_RDI_parallel_res_subset <- Shalek_abs_subset_normal_state_RDI_parallel_res$RDI[, 1:29]; # Shalek_abs_subset_KO_state_RDI_parallel_res$RDI[, 1:29] 
dimnames(Shalek_abs_subset_normal_state_RDI_parallel_res_subset) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);

regulator_rdi_sum = rowSums(Shalek_abs_subset_normal_state_RDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[top_group_ids, ])$gene_short_name), ]) #c(top_group_ids[top_group_ids %in% valid_genes])
target_rdi_sum = rowSums(Shalek_abs_subset_normal_state_RDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[bottom_group_ids, ])$gene_short_name), ]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

rdi_df <- data.frame(sum_of_output_rdi = 
                       c(regulator_rdi_sum, target_rdi_sum), 
                     Type = c(rep('regulator', length(regulator_rdi_sum)), rep('target', length(target_rdi_sum))),
                     Time = rep('normal', length(all_gene_ids))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

# save the result: 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_DC_LPS.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_DC_LPS_helper.pdf')
ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

################################################################################################################################################
# top in-degree
################################################################################################################################################
indegree_regulator_rdi_sum = colSums(Shalek_abs_subset_normal_state_RDI_parallel_res_subset[, as.character(fData(Shalek_abs_subset_normal[top_group_ids, ])$gene_short_name)]) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_target_rdi_sum = colSums(Shalek_abs_subset_normal_state_RDI_parallel_res_subset[, as.character(fData(Shalek_abs_subset_normal[bottom_group_ids, ])$gene_short_name)]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_rdi_df <- data.frame(indegree_sum_of_output_rdi = 
                       c(indegree_regulator_rdi_sum, indegree_target_rdi_sum), 
                     Type = c(rep('regulator', length(indegree_regulator_rdi_sum)), rep('target', length(indegree_target_rdi_sum))),
                     Time = rep('normal', length(all_gene_ids))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, indegree_sum_of_output_rdi), data = indegree_rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

# save the result: 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/indegree_rdi_DC_LPS.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, indegree_sum_of_output_rdi), data = indegree_rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()
#####################################################################################################################################################################
# test running conditional restricted direction information: 
#####################################################################################################################################################################
a <- Sys.time()
Shalek_abs_subset_normal_state_cRDI_parallel_res <- calculate_conditioned_rdi(Shalek_abs_subset_normal_state_exprs + noise, super_graph = NULL, 
                                                                              rdi_list = Shalek_abs_subset_normal_state_RDI_parallel_res, top_incoming_k = 1)
b <- Sys.time()

Shalek_abs_subset_normal_state_cRDI_parallel_res_subset <- Shalek_abs_subset_normal_state_cRDI_parallel_res[, 1:29]; # Shalek_abs_subset_KO_state_RDI_parallel_res$RDI[, 1:29] 
dimnames(Shalek_abs_subset_normal_state_cRDI_parallel_res_subset) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);

regulator_crdi_sum = rowSums(Shalek_abs_subset_normal_state_cRDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[top_group_ids, ])$gene_short_name), ], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
target_crdi_sum = rowSums(Shalek_abs_subset_normal_state_cRDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[bottom_group_ids, ])$gene_short_name), ], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

crdi_df <- data.frame(sum_of_output_crdi = 
                       c(regulator_crdi_sum, target_crdi_sum), 
                     Type = c(rep('regulator', length(regulator_crdi_sum)), rep('target', length(target_crdi_sum))),
                     Time = rep('normal', length(all_gene_ids))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_output_crdi), data = crdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_crdi_DC_LPS.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_output_crdi), data = crdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

################################################################################################################################################
# top in-degree
################################################################################################################################################
indegree_regulator_crdi_sum = colSums(Shalek_abs_subset_normal_state_cRDI_parallel_res_subset[, as.character(fData(Shalek_abs_subset_normal[top_group_ids, ])$gene_short_name)], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_target_crdi_sum = colSums(Shalek_abs_subset_normal_state_cRDI_parallel_res_subset[, as.character(fData(Shalek_abs_subset_normal[bottom_group_ids, ])$gene_short_name)], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_crdi_df <- data.frame(sum_of_input_crdi = 
                        c(indegree_regulator_crdi_sum, indegree_target_crdi_sum), 
                      Type = c(rep('regulator', length(indegree_regulator_crdi_sum)), rep('target', length(indegree_target_crdi_sum))),
                      Time = rep('normal', length(all_gene_ids))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 
pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/input_crdi_DC_LPS.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n cRDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()
################################################################################################################################################################
# maybe also the inferred genes? (not that important)
################################################################################################################################################################
grn_fig4a <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Rbl1", "Usp25", "Daxx", "Cd40", "Atm", "Irf1", "Ligp2", "Mertk", "Cxcl11", "Trim12a", "Trim21", "NfkbIz")
grn_fig4b <- c("NFKBIZ", "ATF4", "ATF4", "Ilf2b", "FUS", "RBL1", "RBL1", "ligp1", "CBX4", "DNMT3A", "DNMT3A", "Ifnb1", "NFKBIZ", "FOS", "FOS", "Il12b", "JUN", "FUS", "FUS", "IFNB1", "FUS", "NFkbIz", "NFKBIZ", "FOS", "CBX4", "STAT1", "STAT1", "IFnb1", "CEBPZ", "HHEX", "HHEX", "IL12b")
grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")

grn_all_genes <- c(grn_fig4a, grn_fig4b, grn_fig4c) 
LPS_network <- read.table('./csv_data/LPS_network', header = T)

grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_all_genes)))
missing_genes <- grn_all_genes[!(toupper(grn_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

all_network_genes <- c(as.character(LPS_network$Source), as.character(LPS_network$Target))
network_missing_genes <- all_network_genes[!(toupper(c(all_network_genes)) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

top_group <- c("STAT2", "STAT1", "HHEX", "RBL1", "Timeless", "FUS")
bottom_group <- c("Ifnb1", "Cxcl9", "Ifit3", "Tsc22d1", "Tnfsf8", "Isg20", "Nmi", "Iigp1", "Irf7", "Lhx2", "Bbx", "Fus", "Tcf4", "Pml", "Usp12", "Irf7", "Ifit1", "Isg15", "Usp25", "Daxx", "Cd40", "Atm", "Lrf1", "Lgp2", "Mertk", "Cxcl11", "Trim12", "Trim21")

top_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(top_group)))
fData(Shalek_abs_subset_ko_LPS)[grn_ids, 'gene_short_name']
bottom_group_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(bottom_group)))
fData(Shalek_abs_subset_ko_LPS)[bottom_group_ids, 'gene_short_name']

order_LPS_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
pd <- pData(Shalek_abs_subset_LPS[grn_ids, colnames(order_LPS_mat)])
fd <- fData(Shalek_abs_subset_LPS[grn_ids, ])

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data_phenotype_data.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/LPS_data.txt', order_LPS_mat, col.names = T, sep = '\t', row.names = T, quote = F)

grn_fig4c <- c("Tlr3", "STAT1", "Tlr4", "STAT2", "Tlr2", "IRf8", "ETV8", "JUN", "STAT4", "IRF9", "ATF3", "RBL1", "PLAGL2", "NFKB1", "NFKB2", "RUX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2", "CXCL10", "IFNb1", "IL15", "HMGN3", "FUS", "SAP30", "IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3", "NFE2L2", "IRF4", "FOS")
fig4c_layer1 <- c("Tlr2", "Tlr3", "Tlr4")
fig4c_layer2.1 <- c("STAT1", "STAT2", "IRF8", "ETV6", "JUN", "STAT4", "IRF9", "ATF3", "RBL1")
fig4c_layer2.2 <- c("PLAGL2", "NFKB1", "RUNX1", "CEBPB", "ATF4", "HAT1", "RELA", "PNRC2")
fig4c_layer3.1 <- c("HMGN3", "FUS", "SAP30")
fig4c_layer3.2 <- c("NFE2L2", "IRF4", "FOS")
fig4c_layer4.1 <- c("CXCL10", "Ifnb1", "IL15")
fig4c_layer4.2 <- c("IL12b", "CXCL2", "CXCL1", "IL1B", "CCL3")

#only the small network: 
LPS_subset_network <- read.table('./csv_data/LPS_subset_network', header = T)

grn_subset_all_genes <- c(as.character(LPS_subset_network$Source), as.character(LPS_subset_network$Target))
subset_grn_ids <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), toupper(gene_short_name) %in% toupper(grn_subset_all_genes)))
missing_genes <- grn_subset_all_genes[!(toupper(grn_subset_all_genes) %in% toupper(fData(Shalek_abs_subset_ko_LPS)$gene_short_name))]

order_LPS_subset_mat <- as.matrix(exprs(Shalek_abs_subset_LPS)[subset_grn_ids, order(pData(Shalek_abs_subset_LPS)$Pseudotime)])
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_LPS_subset_mat.txt', order_LPS_subset_mat, col.names = T, sep = '\t', row.names = T, quote = F)

# plot_genes_in_pseudotime(Shalek_abs_subset_LPS[top_group_ids, ])

################################################################################################################################################################
# test on the Olsson dataset:
################################################################################################################################################################
# get different levels of the regulatory interactions 
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Olsson.RData')
load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res")

qplot(MEP_dm@eigenvectors[, 1], MEP_dm@eigenvectors[, 2], color = pData(Olsson_MEP_cds)$cluster)
# run RDI: (Olsson_MEP_cds: MEP_dpt_res; Olsson_monocyte_cds: monocyte_dpt_res Olsson_granulocyte_cds: granulocyte_dpt_res)
exprs(Olsson_MEP_cds) <- as.matrix(exprs(Olsson_MEP_cds)); exprs(Olsson_monocyte_cds) <- as.matrix(exprs(Olsson_monocyte_cds)); exprs(Olsson_granulocyte_cds) <- as.matrix(exprs(Olsson_granulocyte_cds)); 
MEP_dpt_res <- run_new_dpt(Olsson_MEP_cds); monocyte_dpt_res <- run_new_dpt(Olsson_monocyte_cds); granulocyte_dpt_res <- run_new_dpt(Olsson_granulocyte_cds); 

Olsson_all_gene_ids <- V(res$g)$name
Olsson_monocyte_cds_exprs <- t(exprs(Olsson_monocyte_cds)[Olsson_all_gene_ids, order(monocyte_dpt_res$pt)])
Olsson_granulocyte_cds_exprs <- t(exprs(Olsson_granulocyte_cds)[Olsson_all_gene_ids, order(granulocyte_dpt_res$pt)])

# run RDI network 
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_monocyte_cds_exprs) * ncol(Olsson_monocyte_cds_exprs)), nrow = nrow(Olsson_monocyte_cds_exprs))

a <- Sys.time()
Olsson_monocyte_cds_exprs_RDI_parallel_res <- calculate_rdi(Olsson_monocyte_cds_exprs + noise, delays = c(5, 10, 15), method = 1)
b <- Sys.time()

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_granulocyte_cds_exprs) * ncol(Olsson_granulocyte_cds_exprs)), nrow = nrow(Olsson_granulocyte_cds_exprs))

a <- Sys.time()
Olsson_granulocyte_cds_exprs_RDI_parallel_res <- calculate_rdi(Olsson_granulocyte_cds_exprs + noise, delays = c(5, 10, 15), method = 1)
b <- Sys.time()

Olsson_monocyte_cds_exprs_RDI_parallel_res_subset <- Olsson_monocyte_cds_exprs_RDI_parallel_res$RDI[, 1:nrow(Olsson_granulocyte_cds_exprs_RDI_parallel_res$RDI)]; 
dimnames(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset) <- list(fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name, fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name);
Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset <- Olsson_granulocyte_cds_exprs_RDI_parallel_res$RDI[, 1:nrow(Olsson_granulocyte_cds_exprs_RDI_parallel_res$RDI)]; 
dimnames(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset) <- list(fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name, fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name);

first_layer <- V(res$g)$name[res$layout[, 2] == 0]; 
second_layer <- V(res$g)$name[res$layout[, 2] == -1]; 
third_layer <- V(res$g)$name[res$layout[, 2] == -2]; 
first_layer_id <- row.names(subset(fData(Olsson_monocyte_cds), gene_short_name %in% first_layer));
second_layer_id <- row.names(subset(fData(Olsson_monocyte_cds), gene_short_name %in% second_layer));
third_layer_id <- row.names(subset(fData(Olsson_monocyte_cds), gene_short_name %in% third_layer));

regulator_rdi_sum = rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[first_layer_id, ]) #c(top_group_ids[top_group_ids %in% valid_genes])
second_layer_rdi_sum = rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[second_layer_id, ]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
third_layer_rdi_sum = rowSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[third_layer_id, ]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

regulator_rdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[first_layer_id, ]) #c(top_group_ids[top_group_ids %in% valid_genes])
second_layer_rdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[second_layer_id, ]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
third_layer_rdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[third_layer_id, ]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

rdi_df <- data.frame(sum_of_output_rdi = 
                       c(regulator_rdi_sum, second_layer_rdi_sum, third_layer_rdi_sum, 
                         regulator_rdi_sum_gran, second_layer_rdi_sum_gran, third_layer_rdi_sum_gran), 
                     Type = c(rep('regulator', length(regulator_rdi_sum)), rep('second', length(second_layer_rdi_sum)), rep('third', length(third_layer_rdi_sum)) ),
                     Time = c(rep('Monocyte', length(Olsson_all_gene_ids)), rep('Granulocyte', length(Olsson_all_gene_ids)))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_blood.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_DC_LPS_helper.pdf')
ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

#####################################################################################################################################################################
# indegree: 
#####################################################################################################################################################################
indegree_regulator_rdi_sum = colSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[, first_layer_id]) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_rdi_sum = colSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[, second_layer_id]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_rdi_sum = colSums(Olsson_monocyte_cds_exprs_RDI_parallel_res_subset[, third_layer_id]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_regulator_rdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[, first_layer_id]) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_rdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[, second_layer_id]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_rdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_RDI_parallel_res_subset[, third_layer_id]) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_rdi_df <- data.frame(sum_of_input_rdi = 
                       c(indegree_regulator_rdi_sum, indegree_second_layer_rdi_sum, indegree_third_layer_rdi_sum, 
                         indegree_regulator_rdi_sum_gran, indegree_second_layer_rdi_sum_gran, indegree_third_layer_rdi_sum_gran), 
                     Type = c(rep('regulator', length(regulator_rdi_sum)), rep('second', length(second_layer_rdi_sum)), rep('third', length(third_layer_rdi_sum)) ),
                     Time = c(rep('Monocyte', length(Olsson_all_gene_ids)), rep('Granulocyte', length(Olsson_all_gene_ids)))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_input_rdi), data = indegree_rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/input_rdi_DC_LPS.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_input_rdi), data = indegree_rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + nm_theme()# geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

# show the overlapping of the gene regulation strength 
#####################################################################################################################################################################
# test running conditional restricted direction information: 
#####################################################################################################################################################################
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_monocyte_cds_exprs) * ncol(Olsson_monocyte_cds_exprs)), nrow = nrow(Olsson_monocyte_cds_exprs))

a <- Sys.time()
Olsson_monocyte_cds_exprs_cRDI_parallel_res <- calculate_conditioned_rdi(Olsson_monocyte_cds_exprs + noise,  super_graph = NULL, Olsson_monocyte_cds_exprs_RDI_parallel_res, 1L)
b <- Sys.time()

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Olsson_granulocyte_cds_exprs) * ncol(Olsson_granulocyte_cds_exprs)), nrow = nrow(Olsson_granulocyte_cds_exprs))

a <- Sys.time()
Olsson_granulocyte_cds_exprs_cRDI_parallel_res <- calculate_conditioned_rdi(Olsson_granulocyte_cds_exprs + noise, super_graph = NULL, Olsson_granulocyte_cds_exprs_RDI_parallel_res, 1L)
b <- Sys.time()

Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset <- Olsson_monocyte_cds_exprs_cRDI_parallel_res[, 1:nrow(Olsson_granulocyte_cds_exprs_cRDI_parallel_res)]; 
dimnames(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset) <- list(fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name, fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name);
Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset <- Olsson_granulocyte_cds_exprs_cRDI_parallel_res[, 1:nrow(Olsson_granulocyte_cds_exprs_cRDI_parallel_res)]; 
dimnames(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset) <- list(fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name, fData(Olsson_monocyte_cds[c(Olsson_all_gene_ids), ])$gene_short_name);

regulator_crdi_sum = rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[first_layer_id, ], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
second_layer_crdi_sum = rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[second_layer_id, ], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
third_layer_crdi_sum = rowSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[third_layer_id, ], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

regulator_crdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[first_layer_id, ], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
second_layer_crdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[second_layer_id, ], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
third_layer_crdi_sum_gran = rowSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[third_layer_id, ], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

crdi_df <- data.frame(sum_of_output_crdi = 
                       c(regulator_crdi_sum, second_layer_crdi_sum, third_layer_crdi_sum, 
                         regulator_crdi_sum_gran, second_layer_crdi_sum_gran, third_layer_crdi_sum_gran), 
                     Type = c(rep('regulator', length(regulator_crdi_sum)), rep('second', length(second_layer_crdi_sum)), rep('third', length(third_layer_crdi_sum)) ),
                     Time = c(rep('Monocyte', length(Olsson_all_gene_ids)), rep('Granulocyte', length(Olsson_all_gene_ids)))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_output_crdi), data = crdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_crdi_blood.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_output_crdi), data = crdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

#####################################################################################################################################################################
# indegree 
#####################################################################################################################################################################
indegree_regulator_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, first_layer_id], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, second_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, third_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_regulator_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, first_layer_id], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, second_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, third_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_crdi_df <- data.frame(sum_of_input_crdi = 
                        c(indegree_regulator_crdi_sum, indegree_second_layer_crdi_sum, indegree_third_layer_crdi_sum, 
                          indegree_regulator_crdi_sum_gran, indegree_second_layer_crdi_sum_gran, indegree_third_layer_crdi_sum_gran), 
                      Type = c(rep('regulator', length(indegree_regulator_crdi_sum)), rep('second', length(indegree_second_layer_crdi_sum)), rep('third', length(indegree_third_layer_crdi_sum)) ),
                      Time = c(rep('Monocyte', length(Olsson_all_gene_ids)), rep('Granulocyte', length(Olsson_all_gene_ids)))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/input_crdi_blood.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

#####################################################################################################################################################################
# outdegree 
#####################################################################################################################################################################
indegree_regulator_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, first_layer_id], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, second_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_crdi_sum = colSums(Olsson_monocyte_cds_exprs_cRDI_parallel_res_subset[, third_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_regulator_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, first_layer_id], na.rm = T) #c(top_group_ids[top_group_ids %in% valid_genes])
indegree_second_layer_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, second_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])
indegree_third_layer_crdi_sum_gran = colSums(Olsson_granulocyte_cds_exprs_cRDI_parallel_res_subset[, third_layer_id], na.rm = T) #c(bottom_group_ids[bottom_group_ids %in% valid_genes])

indegree_crdi_df <- data.frame(sum_of_input_crdi = 
                                 c(indegree_regulator_crdi_sum, indegree_second_layer_crdi_sum, indegree_third_layer_crdi_sum, 
                                   indegree_regulator_crdi_sum_gran, indegree_second_layer_crdi_sum_gran, indegree_third_layer_crdi_sum_gran), 
                               Type = c(rep('regulator', length(indegree_regulator_crdi_sum)), rep('second', length(indegree_second_layer_crdi_sum)), rep('third', length(indegree_third_layer_crdi_sum)) ),
                               Time = c(rep('Monocyte', length(Olsson_all_gene_ids)), rep('Granulocyte', length(Olsson_all_gene_ids)))) #[all_gene_ids %in% valid_genes]

ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 

pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/input_crdi_blood.pdf', height = 1.5, width = 1.5)
ggplot(aes(Time, sum_of_input_crdi), data = indegree_crdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
  xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
  nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
dev.off()

#####################################################################################################################################################################
# test on other dataset : 
# 1. Paul's dataset 
#####################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Paul.RData')

#####################################################################################################################################################################
# test on other dataset : 
# 2. Pancreas's dataset 
#####################################################################################################################################################################

#####################################################################################################################################################################
# test on other dataset : 
# 2. BJ-myo reprogramming dataset 
#####################################################################################################################################################################

#####################################################################################################################################################################
# save the result 
#####################################################################################################################################################################
save.image('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/verify_network_hiearchy.RData')

# Shalek_abs_subset_normal_exprs <- t(exprs(Shalek_abs_subset_normal)[all_gene_ids, order(Shalek_abs_subset_normal_dpt_res$pt)])
# 
# ## add smoothing and different delays (maybe we don't really need it because we have all those delay, etc.)
# Shalek_abs_subset_normal_exprs_smth <- smooth_gene(Shalek_abs_subset_normal_exprs, 10)
# 
# set.seed(2017)
# noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Shalek_abs_subset_normal_exprs) * ncol(Shalek_abs_subset_normal_exprs)), nrow = nrow(Shalek_abs_subset_normal_exprs))
# 
# a <- Sys.time()
# LPS_normal_RDI_parallel_res <- calculate_rdi(Shalek_abs_subset_normal_exprs + noise, delays = c(5L, 10L, 15L), method = 1L)
# b <- Sys.time()
# 
# #LPS_normal_RDI_parallel_res_clr_res <- clr(LPS_normal_RDI_parallel_res) #
# LPS_normal_RDI_parallel_res_clr_res <- t(apply(LPS_normal_RDI_parallel_res$RDI[, 1:nrow(LPS_normal_RDI_parallel_res$RDI)], 1, function(x) (x - mean(x)) / (sd(x)))); LPS_normal_RDI_parallel_res_clr_res[LPS_normal_RDI_parallel_res_clr_res < 0] <- 0
# 
# LPS_normal_RDI_parallel_res_subset <- LPS_normal_RDI_parallel_res$RDI[, 1:nrow(LPS_normal_RDI_parallel_res$RDI)] # LPS_normal_RDI_parallel_res[, 1:nrow(LPS_normal_RDI_parallel_res)] 
# dimnames(LPS_normal_RDI_parallel_res_subset) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);
# 
# dimnames(LPS_normal_RDI_parallel_res_clr_res) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);
# 
# # run BEAM: 
# all_gene_ids_deg <- differentialGeneTest(Shalek_abs_subset_normal[all_gene_ids, ])
# # all_gene_ids_beam <- branchTest(Shalek_abs_subset_ko_LPS_new[all_gene_ids, ])
# 
# valid_genes <- row.names(subset(all_gene_ids_deg, qval < 1e-5))
# 
# regulator_rdi_sum = rowSums(LPS_normal_RDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[c(top_group_ids[top_group_ids %in% valid_genes]), ])$gene_short_name), ])
# target_rdi_sum = rowSums(LPS_normal_RDI_parallel_res_subset[as.character(fData(Shalek_abs_subset_normal[c(bottom_group_ids[bottom_group_ids %in% valid_genes]), ])$gene_short_name), ])
# 
# rdi_df <- data.frame(sum_of_output_rdi = 
#                        c(regulator_rdi_sum, target_rdi_sum), 
#                      Type = c(rep('regulator', length(regulator_rdi_sum)), rep('target', length(target_rdi_sum))),
#                      Time = rep('normal', length(all_gene_ids[all_gene_ids %in% valid_genes])))
# 
# ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 
# 
# # save the result: 
# pdf('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/output_rdi_DC_LPS.pdf', height = 1.5, width = 1.5)
# ggplot(aes(Time, sum_of_output_rdi), data = rdi_df) + geom_boxplot(aes(fill = Type), size = I(0.25), position = 'dodge') + 
#   xlab('') + ylab('Sum of output \n RDI values') + theme(axis.text.x = element_text(angle = 30, hjust = 1)) + 
#   nm_theme() # geom_jitter(aes(color = Time), size = 0.5) + 
# dev.off()
# 
# # test the cRDI result 
# a <- Sys.time()
# cRDI_LPS_normal_cRDI_parallel_res <- calculate_conditioned_rdi(Shalek_abs_subset_normal_exprs + noise, super_graph = NULL, LPS_normal_RDI_parallel_res, 1L)
# b <- Sys.time()
# 
# dimnames(cRDI_LPS_normal_cRDI_parallel_res) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);
# dimnames(cRDI_LPS_normal_cRDI_parallel_res) <- list(fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name, fData(Shalek_abs_subset_normal[c(all_gene_ids), ])$gene_short_name);
# cRDI_regulator_crdi_sum = rowSums(cRDI_LPS_normal_cRDI_parallel_res[as.character(fData(Shalek_abs_subset_normal[c(top_group_ids[top_group_ids %in% all_gene_ids]), ])$gene_short_name), ], na.rm = T) 
# cRDI_target_crdi_sum = rowSums(cRDI_LPS_normal_cRDI_parallel_res[as.character(fData(Shalek_abs_subset_normal[c(bottom_group_ids[bottom_group_ids %in% all_gene_ids]), ])$gene_short_name), ], na.rm = T)
# 
# cRDI_df <- data.frame(sum_of_output_rdi = 
#                        c(cRDI_regulator_crdi_sum, cRDI_target_crdi_sum), 
#                      Type = c(rep('regulator', length(cRDI_regulator_crdi_sum)), rep('target', length(cRDI_target_crdi_sum))),
#                      Time = rep('normal', length(all_gene_ids[all_gene_ids %in% all_gene_ids])))
# 
# ggplot(aes(Time, sum_of_output_rdi), data = cRDI_df) + geom_boxplot(aes(fill = Type), position = 'dodge') # + geom_jitter(aes(color = Time)) 
# 
# # run on the KO cells dataset 
# plot_spanning_tree(Shalek_abs_subset_ko_LPS_new, color_by="interaction(experiment_name, time)", cell_size=2) + 
#   scale_color_manual(values=shalek_custom_color_scale_plus_states) + nm_theme()

