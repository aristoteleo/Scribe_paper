
# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Session info
sessionInfo()

fpkm_matrix <- read.delim("normalized_out/genes.fpkm_table", row.names="tracking_id")
colnames(fpkm_matrix) <- str_replace(colnames(fpkm_matrix), "-", ".")
colnames(fpkm_matrix) <- str_replace(colnames(fpkm_matrix), "/", ".")
colnames(fpkm_matrix) <- str_replace(colnames(fpkm_matrix), "first_run.", "R1_")
colnames(fpkm_matrix) <- str_replace(colnames(fpkm_matrix), "second_run.", "R2_")
colnames(fpkm_matrix) <- str_replace(colnames(fpkm_matrix), "Sample_", "")

isoform_fpkm_matrix <- read.delim("normalized_out/isoforms.fpkm_table", row.names="tracking_id")
colnames(isoform_fpkm_matrix) <- str_replace(colnames(isoform_fpkm_matrix), "-", ".")
colnames(isoform_fpkm_matrix) <- str_replace(colnames(isoform_fpkm_matrix), "/", ".")
colnames(isoform_fpkm_matrix) <- str_replace(colnames(isoform_fpkm_matrix), "first_run.", "R1_")
colnames(isoform_fpkm_matrix) <- str_replace(colnames(isoform_fpkm_matrix), "second_run.", "R2_")
colnames(isoform_fpkm_matrix) <- str_replace(colnames(isoform_fpkm_matrix), "Sample_", "")

sample_sheet <- read.delim("normalized_out/samples.table", row.names="sample_id")
row.names(sample_sheet) <- str_replace(row.names(sample_sheet), "-", ".")
row.names(sample_sheet) <- str_replace(row.names(sample_sheet), "/", ".")
row.names(sample_sheet) <- str_replace(row.names(sample_sheet), "first_run.", "R1_")
row.names(sample_sheet) <- str_replace(row.names(sample_sheet), "second_run.", "R2_")
row.names(sample_sheet) <- str_replace(row.names(sample_sheet), "Sample_", "")
sample_sheet <- sample_sheet[,-1]

gene_ann <- read.delim("normalized_out/genes.attr_table", row.names="tracking_id")
gencode_biotypes <- read.delim("gencode_biotypes.txt")
gene_ann <- merge(gene_ann, gencode_biotypes, by.x="row.names", by.y="gene_id", all.x=T)
row.names(gene_ann) <- gene_ann$Row.names
gene_ann <- gene_ann[,-1]

pd <- new("AnnotatedDataFrame", data = sample_sheet)
fd <- new("AnnotatedDataFrame", data = gene_ann)

# Re-order rows in fpkm_matrix alphabetically so that the order is the same as in gene_ann
fpkm_matrix <- fpkm_matrix[order(row.names(fpkm_matrix)),]

panc_cds <- newCellDataSet(as.matrix(fpkm_matrix), 
                           phenoData = pd, 
                           featureData = fd)

panc_cds <- detectGenes(panc_cds, min_expr = 0.1)
cells_to_keep <- row.names(subset(pData(panc_cds), num_genes_expressed >=1000))
cells_to_remove <- row.names(subset(pData(panc_cds), num_genes_expressed <1000))
length(cells_to_remove)

fpkm_matrix <- fpkm_matrix[,cells_to_keep]
isoform_fpkm_matrix <- isoform_fpkm_matrix[,cells_to_keep]
sample_sheet <- sample_sheet[cells_to_keep,]
pd <- new("AnnotatedDataFrame", data = sample_sheet)
panc_cds <- newCellDataSet(as.matrix(fpkm_matrix), 
                           phenoData = pd, 
                           featureData = fd)

# Save workspace
save.image(file = 'pancreas_0.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace
load('pancreas_0.RData')
ls()

# TEMP
dim(panc_cds)
head(pData(panc_cds))
head(exprs(panc_cds))

# Suppress warning messages globally 
# (since relative2abs results in hundreds of warning messages, making jupyter crash)
options(warn=-1)

# 'relative2abs' transforms relative expression matrix to absolute transcript matrix. Need to provide CellDataSet object.
# 'verbose=T' is optional.
fpkm_matrix_adj <- relative2abs(panc_cds, estimate_t(isoform_fpkm_matrix), verbose=T, cores=32)

# Turn warning messages back on
options(warn=0)

fpkm_matrix_adj <- as.matrix(fpkm_matrix_adj)
fpkm_matrix_adj <- fpkm_matrix_adj[row.names(gene_ann),]
fpkm_matrix_adj <- fpkm_matrix_adj[,row.names(sample_sheet)]

# Save workspace
save.image(file = 'pancreas_1.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_1.RData')
ls()

panc_cds <- newCellDataSet(fpkm_matrix_adj, 
						   phenoData = pd, 
						   featureData = fd, 
						   expressionFamily=negbinomial.size(), 
						   lowerDetectionLimit=1)

# TEMP
dim(panc_cds)
head(pData(panc_cds))
head(exprs(panc_cds))

pData(panc_cds)$Total_mRNAs <- colSums(exprs(panc_cds))
pData(panc_cds)$Replicate <- str_split_fixed(row.names(pData(panc_cds)), "_", 4)[,c(1)]
pData(panc_cds)$Time <- toupper(str_split_fixed(row.names(pData(panc_cds)), "_", 4)[,c(2)])
pData(panc_cds)$Cell <- row.names(pData(panc_cds))
panc_cds <- estimateSizeFactors(panc_cds)
panc_cds <- detectGenes(panc_cds, min_expr = 0.1)
dim(panc_cds)
count(pData(panc_cds)$Time)

# Eliminate E11/E12 cells from panc_cds
cells_E13_E14_E15 <- row.names(subset(pData(panc_cds), 
                               pData(panc_cds)$Time %in% c("E13", "E14", "E15")))
panc_cds <- panc_cds[,cells_E13_E14_E15]
dim(panc_cds)
count(pData(panc_cds)$Time)

# Log transform Total_mRNAs
pData(panc_cds)$Total_mRNAs_log <- log10(pData(panc_cds)$Total_mRNAs)

# Mean of log-transformed Total_mRNA for each Time and Replicate
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R1"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R2"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R2"])
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R1"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R2"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R2"])
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R1"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_mean[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R2"] <- mean(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R2"])

# Calculate SD for each Time and Replicate
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R1"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R2"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E13" & pData(panc_cds)$Replicate == "R2"])
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R1"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R2"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E14" & pData(panc_cds)$Replicate == "R2"])
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R1"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R1"])
pData(panc_cds)$Total_mRNAs_log_SD[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R2"] <- sd(pData(panc_cds)$Total_mRNAs_log[pData(panc_cds)$Time == "E15" & pData(panc_cds)$Replicate == "R2"])
count(pData(panc_cds)$Total_mRNAs_log > pData(panc_cds)$Total_mRNAs_log_mean+2*pData(panc_cds)$Total_mRNAs_log_SD)
count(pData(panc_cds)$Total_mRNAs_log < pData(panc_cds)$Total_mRNAs_log_mean-2*pData(panc_cds)$Total_mRNAs_log_SD)

pData(panc_cds)$Within2SD <- TRUE
pData(panc_cds)$Within2SD[pData(panc_cds)$Total_mRNAs_log > pData(panc_cds)$Total_mRNAs_log_mean+2*pData(panc_cds)$Total_mRNAs_log_SD] <- FALSE
pData(panc_cds)$Within2SD[pData(panc_cds)$Total_mRNAs_log < pData(panc_cds)$Total_mRNAs_log_mean-2*pData(panc_cds)$Total_mRNAs_log_SD] <- FALSE
count(pData(panc_cds)$Within2SD)
#pdf("qplot_total_mrna_2sd.pdf")
qplot(Total_mRNAs, data=pData(panc_cds), fill=Within2SD, geom="histogram", position="dodge", binwidth=5000) +
facet_grid(Replicate~Time)
#dev.off()

qplot(Total_mRNAs, data=pData(panc_cds), fill=Within2SD, binwidth=10000) + 
geom_vline(xintercept=370000)

panc_cds <- panc_cds[,row.names(subset(pData(panc_cds), Total_mRNAs <370000))]
dim(panc_cds)

# Plot total mRNAs for E13/R1 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E13") & 
                  pData(panc_cds)$Replicate %in% c("R1")),
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=55000) +
geom_vline(xintercept=235000)

# Plot total mRNAs for E13/R2 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E13") & 
                  pData(panc_cds)$Replicate %in% c("R2")),
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=50000) +
geom_vline(xintercept=200000)

# Plot total mRNAs for E14/R1 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E14") & 
                  pData(panc_cds)$Replicate %in% c("R1")), 
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=30000) +
geom_vline(xintercept=160000)

# Plot total mRNAs for E14/R2 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E14") & 
                  pData(panc_cds)$Replicate %in% c("R2")), 
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=35000) +
geom_vline(xintercept=160000)

# Plot total mRNAs for E15/R1 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E15") & 
                  pData(panc_cds)$Replicate %in% c("R1")), 
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=30000) +
geom_vline(xintercept=185000)

# Plot total mRNAs for E15/R2 and define lower and upper thresholds, 
# making sure that cells not within 2SD are also excluded
qplot(Total_mRNAs, 
      data=subset(pData(panc_cds), 
                  pData(panc_cds)$Time %in% c("E15") & 
                  pData(panc_cds)$Replicate %in% c("R2")), 
      fill=Within2SD,
      binwidth=5000) + 
geom_vline(xintercept=30000) +
geom_vline(xintercept=200000)

# Subset using the above thresholds, which - per the above graphs - also exclude cells not within 2SD of the mean
count(pData(panc_cds)$Time)
panc_cds_valid_cells <- panc_cds[,row.names(subset(pData(panc_cds), 
                                                   (subset = pData(panc_cds)$Time %in% c("E13") & 
                                                             pData(panc_cds)$Replicate %in% c("R1") & 
                                                             Total_mRNAs >55000 & 
                                                             Total_mRNAs <235000) | 
                                                   (subset = pData(panc_cds)$Time %in% c("E13") & 
                                                             pData(panc_cds)$Replicate %in% c("R2") & 
                                                             Total_mRNAs >50000 & 
                                                             Total_mRNAs <200000) |
                                                   (subset = pData(panc_cds)$Time %in% c("E14") & 
                                                             pData(panc_cds)$Replicate %in% c("R1") & 
                                                             Total_mRNAs >30000 & 
                                                             Total_mRNAs <160000) |
                                                   (subset = pData(panc_cds)$Time %in% c("E14") & 
                                                             pData(panc_cds)$Replicate %in% c("R2") & 
                                                             Total_mRNAs >35000 & 
                                                             Total_mRNAs <160000) |
                                                   (subset = pData(panc_cds)$Time %in% c("E15") & 
                                                             pData(panc_cds)$Replicate %in% c("R1") & 
                                                             Total_mRNAs >30000 & 
                                                             Total_mRNAs <185000) |
                                                   (subset = pData(panc_cds)$Time %in% c("E15") & 
                                                             pData(panc_cds)$Replicate %in% c("R2") & 
                                                             Total_mRNAs >30000 & 
                                                             Total_mRNAs <200000)
                                                  ))]
dim(panc_cds_valid_cells)
count(pData(panc_cds_valid_cells)$Time)

panc_cds_valid_cells <- detectGenes(panc_cds_valid_cells, min_expr=0.1)
panc_cds_valid_cells <- estimateSizeFactors(panc_cds_valid_cells)

Arx_id <- row.names(subset(fData(panc_cds), gene_short_name == "Arx"))
Ccnb2_id <- row.names(subset(fData(panc_cds), gene_short_name == "Ccnb2"))
Gcg_id <- row.names(subset(fData(panc_cds), gene_short_name == "Gcg"))
Ghrl_id <- row.names(subset(fData(panc_cds), gene_short_name == "Ghrl"))
Ins1_id <- row.names(subset(fData(panc_cds), gene_short_name == "Ins1"))
Ins2_id <- row.names(subset(fData(panc_cds), gene_short_name == "Ins2"))
Ngn3_id <- row.names(subset(fData(panc_cds), gene_short_name == "Neurog3"))
Ppy_id <- row.names(subset(fData(panc_cds), gene_short_name == "Ppy"))
Sst_id <- row.names(subset(fData(panc_cds), gene_short_name == "Sst"))
eGFP_id <- row.names(subset(fData(panc_cds), gene_id == "eGFP"))

# Define Single, Double and Triple Hormone Positives (with Ins1)
cth3 <- newCellTypeHierarchy()
cth3 <- addCellType(cth3, "Alpha only", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins1_id,] < 30 & x[Ghrl_id,] < 30})
cth3 <- addCellType(cth3, "Beta only", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins1_id,] > 30 & x[Ghrl_id,] < 30})
cth3 <- addCellType(cth3, "Epsilon only", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins1_id,] < 30 & x[Ghrl_id,] > 30})
cth3 <- addCellType(cth3, "Alpha/Beta", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins1_id,] > 30 & x[Ghrl_id,] < 30})
cth3 <- addCellType(cth3, "Alpha/Epsilon", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins1_id,] < 30 & x[Ghrl_id,] > 30})
cth3 <- addCellType(cth3, "Beta/Epsilon", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins1_id,] > 30 & x[Ghrl_id,] > 30})
cth3 <- addCellType(cth3, "Alpha/Beta/Epsilon", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins1_id,] > 30 & x[Ghrl_id,] > 30})
panc_cds_valid_cells <- classifyCells(panc_cds_valid_cells, cth3)
count(pData(panc_cds_valid_cells)$CellType)

# Remove Double and Triple Hormone Positives (with Ins1)
panc_cds_valid_cells <- panc_cds_valid_cells[,row.names(subset(pData(panc_cds_valid_cells), 
                                                               pData(panc_cds_valid_cells)$CellType %in% 
                                                               c("Alpha/Beta", 
                                                                 "Alpha/Epsilon", 
                                                                 "Beta/Epsilon", 
                                                                 "Alpha/Beta/Epsilon") == FALSE))]
dim(panc_cds_valid_cells)
count(pData(panc_cds_valid_cells)$CellType)

# Define Single, Double and Triple Hormone Positives (with Ins2)
cth4 <- newCellTypeHierarchy()
cth4 <- addCellType(cth4, "Alpha only", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins2_id,] < 30 & x[Ghrl_id,] < 30})
cth4 <- addCellType(cth4, "Beta only", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins2_id,] > 30 & x[Ghrl_id,] < 30})
cth4 <- addCellType(cth4, "Epsilon only", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins2_id,] < 30 & x[Ghrl_id,] > 30})
cth4 <- addCellType(cth4, "Alpha/Beta", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins2_id,] > 30 & x[Ghrl_id,] < 30})
cth4 <- addCellType(cth4, "Alpha/Epsilon", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins2_id,] < 30 & x[Ghrl_id,] > 30})
cth4 <- addCellType(cth4, "Beta/Epsilon", classify_func=function(x) {x[Gcg_id,] < 30 & x[Ins2_id,] > 30 & x[Ghrl_id,] > 30})
cth4 <- addCellType(cth4, "Alpha/Beta/Epsilon", classify_func=function(x) {x[Gcg_id,] > 30 & x[Ins2_id,] > 30 & x[Ghrl_id,] > 30})
panc_cds_valid_cells <- classifyCells(panc_cds_valid_cells, cth4)
count(pData(panc_cds_valid_cells)$CellType)

# Remove Double and Triple Hormone Positives (with Ins2)
panc_cds_valid_cells <- panc_cds_valid_cells[,row.names(subset(pData(panc_cds_valid_cells), 
                                                               pData(panc_cds_valid_cells)$CellType %in% 
                                                               c("Alpha/Beta", 
                                                                 "Alpha/Epsilon", 
                                                                 "Beta/Epsilon", 
                                                                 "Alpha/Beta/Epsilon") == FALSE))]
dim(panc_cds_valid_cells)
count(pData(panc_cds_valid_cells)$CellType)

panc_cds_valid_cells <- detectGenes(panc_cds_valid_cells, min_expr=0.1)
panc_cds_valid_cells <- estimateDispersions(panc_cds_valid_cells, modelFormulaStr="~Time", cores=32, 
                                            min_cells_detected=1, removeOutliers=T)

# Save workspace
save.image(file = 'pancreas_2.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_2.RData')
ls()

# TEMP
aggregate(pData(panc_cds_valid_cells)[,10], list(pData(panc_cds_valid_cells)$Time), mean)
qplot(num_genes_expressed, data=pData(panc_cds_valid_cells), binwidth=100)+facet_wrap(~Time)
qplot(num_cells_expressed, data=fData(panc_cds_valid_cells), binwidth=5)

# TEMP
cth <- newCellTypeHierarchy()
cth <- addCellType(cth, "GCG high", classify_func=function(x) {x[Gcg_id,] > 100})
cth <- addCellType(cth, "INS high", classify_func=function(x) {x[Ins1_id,] > 100 | x[Ins2_id,] > 100})
cth <- addCellType(cth, "GHRL high", classify_func=function(x) {x[Ghrl_id,] > 100})

#cth <- addCellType(cth, "SST high", classify_func=function(x) {x[Sst_id,] > 100})
#cth <- addCellType(cth, "PPY high", classify_func=function(x) {x[Ppy_id,] > 100})

cth <- addCellType(cth, "NGN3 high", classify_func=function(x) {x[Ngn3_id,] > 100})
#cth <- addCellType(cth, "eGFP+ cells", classify_func=function(x) {x[eGFP_id,] > 4})
#cth <- addCellType(cth, "Ccnb2+ cells", classify_func=function(x) {x[Ccnb2_id,] > 4})

panc_cds_valid_cells <- classifyCells(panc_cds_valid_cells, cth)
count(pData(panc_cds_valid_cells)$CellType)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(1), y = ..count.., fill = CellType)) +
    geom_bar(width = 1) +
    coord_polar(theta = "y") +
    theme(
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        strip.background = element_rect(colour = 'white', fill = 'white'),
        panel.border = element_blank(), axis.line = element_blank(),
        panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank(),
        panel.background = element_rect(fill='white')) +
    geom_text(stat="count", aes(x= 1.7, y=cumsum(..count..)-..count../2, label=..count..), size=5)

cth1 <- newCellTypeHierarchy()
cth1 <- addCellType(cth1, "Ngn3+ Arx+", classify_func=function(x) {x[Ngn3_id,] > 1 & x[Arx_id,] > 1})
cth1 <- addCellType(cth1, "Ngn3+ Arx-", classify_func=function(x) {x[Ngn3_id,] > 1 & x[Arx_id,] < 1})
cth1 <- addCellType(cth1, "Ngn3-", classify_func=function(x) {x[Ngn3_id,] < 1})
panc_cds_valid_cells_Ngn3_Arx <- classifyCells(panc_cds_valid_cells, cth1)
colnames(pData(panc_cds_valid_cells_Ngn3_Arx)) <- str_replace(colnames(pData(panc_cds_valid_cells_Ngn3_Arx)), 
                                                              "CellType", "CellType_Ngn3_Arx")
pData(panc_cds_valid_cells) <- cbind(pData(panc_cds_valid_cells), pData(panc_cds_valid_cells_Ngn3_Arx)
                                     [!names(pData(panc_cds_valid_cells_Ngn3_Arx)) %in% names(pData(panc_cds_valid_cells))])

cth2 <- newCellTypeHierarchy()
cth2 <- addCellType(cth2, "eGFP+", classify_func=function(x) {x[eGFP_id,] > 1})
cth2 <- addCellType(cth2, "eGFP-", classify_func=function(x) {x[eGFP_id,] < 1})
panc_cds_valid_cells_eGFP <- classifyCells(panc_cds_valid_cells, cth2)
pData(panc_cds_valid_cells_eGFP)$CellType_Ngn3_Arx <- NULL
colnames(pData(panc_cds_valid_cells_eGFP)) <- str_replace(colnames(pData(panc_cds_valid_cells_eGFP)), 
                                                              "CellType", "CellType_eGFP")
pData(panc_cds_valid_cells) <- cbind(pData(panc_cds_valid_cells), pData(panc_cds_valid_cells_eGFP)
                                     [!names(pData(panc_cds_valid_cells_eGFP)) %in% names(pData(panc_cds_valid_cells))])

pdf("pieplots.pdf", height=2.5, width=4)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(1), y = ..count.., fill = Time)) +
    geom_bar(width = 1) +
    coord_polar(theta = "y") +
    theme(
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        strip.background = element_rect(colour = 'white', fill = 'white'),
        panel.border = element_blank(), axis.line = element_blank(),
        panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank(),
        panel.background = element_rect(fill='white')) +
    geom_text(stat="count", aes(x= 1.8, y=cumsum(..count..)-..count../2, label=..count..), size=5)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(1), y = ..count.., fill = CellType)) +
    geom_bar(width = 1) +
    coord_polar(theta = "y") +
    theme(
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        strip.background = element_rect(colour = 'white', fill = 'white'),
        panel.border = element_blank(), axis.line = element_blank(),
        panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank(),
        panel.background = element_rect(fill='white')) +
    geom_text(stat="count", aes(x= 1.7, y=cumsum(..count..)-..count../2, label=..count..), size=5)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(1), y = ..count.., fill = CellType_eGFP)) +
    geom_bar(width = 1) +
    coord_polar(theta = "y") +
    theme(
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        strip.background = element_rect(colour = 'white', fill = 'white'),
        panel.border = element_blank(), axis.line = element_blank(),
        panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank(),
        panel.background = element_rect(fill='white')) +
    geom_text(stat="count", aes(x= 1.8, y=cumsum(..count..)-..count../2, label=..count..), size=5)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(1), y = ..count.., fill = CellType_Ngn3_Arx)) +
    geom_bar(width = 1) +
    coord_polar(theta = "y") +
    theme(
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        strip.background = element_rect(colour = 'white', fill = 'white'),
        panel.border = element_blank(), axis.line = element_blank(),
        panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank(),
        panel.background = element_rect(fill='white')) +
    geom_text(stat="count", aes(x= 1.8, y=cumsum(..count..)-..count../2, label=..count..), size=5)
dev.off()

pdf("barplots.pdf", height=4, width=3)
#pdf("barplots.pdf", height=4, width=3)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(Time), fill = CellType)) +
    geom_bar() +
    scale_x_discrete(name="") +
    geom_text(stat="count", position="stack", aes(y=..count.., label=..count..), size=3)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(Time), fill = CellType_eGFP)) +
    geom_bar() +
    scale_x_discrete(name="") +
    geom_text(stat="count", position="stack", aes(y=..count.., label=..count..), size=3)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(Time), fill = CellType_Ngn3_Arx)) +
    geom_bar() +
    scale_x_discrete(name="") +
    geom_text(stat="count", position="stack", aes(y=..count.., label=..count..), size=3)
dev.off()

head(pData(panc_cds_valid_cells))

# Exclude genes expressed in <10 cells; and exclude ribosomal (Rps/Rpl) and mitochondrial (mt-) genes
valid_expressed_genes <- row.names(subset(fData(panc_cds_valid_cells), 
                                          num_cells_expressed >= 10 & 
                                          biotype %in% c("protein_coding", "lincRNA") & 
                                          grepl("Rps", gene_short_name) == FALSE & 
                                          grepl("Rpl", gene_short_name) == FALSE & 
                                          grepl("mt-", gene_short_name) == FALSE
                                         ))
length(valid_expressed_genes)

marker_diff <- markerDiffTable(panc_cds_valid_cells[valid_expressed_genes,], 
                                cth, 
                                balanced=F,
                                residualModelFormulaStr="~Time",
                                verbose=T,
                                cores=32)

# Save workspace
save.image(file = 'pancreas_3.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_3.RData')
ls()

# Define the top genes per CellType:
marker_spec <- calculateMarkerSpecificity(panc_cds_valid_cells[row.names(subset(marker_diff, qval < 1e-5)),], 
                                          cth)
top_genes <- unique(as.character(selectTopMarkers(marker_spec, 15)$gene_id))
length(top_genes)

# Which are the top_genes?
subset(fData(panc_cds_valid_cells), gene_id %in% top_genes)$gene_short_name

# TEMP
# Generate/write table with marker specificities for all cell types
marker_spec_reformatted <- calculateMarkerSpecificity(panc_cds_valid_cells[row.names(subset(marker_diff, qval < 0.05)),], 
                                          cth)
gene_id_short_name_table <- fData(panc_cds_valid_cells)[,3:4]
marker_spec_reformatted <- merge(marker_spec_reformatted, gene_id_short_name_table, by="gene_id")
marker_spec_reformatted <- marker_spec_reformatted[,c(1,4,2,3)]
marker_spec_GCG <- marker_spec_reformatted[marker_spec_reformatted$CellType == "GCG high",]
marker_spec_GCG <- marker_spec_GCG[,-3]
colnames(marker_spec_GCG)[3] <- "Specificity for GCG high"
marker_spec_GHRL <- marker_spec_reformatted[marker_spec_reformatted$CellType == "GHRL high",]
marker_spec_GHRL <- marker_spec_GHRL[,-3]
colnames(marker_spec_GHRL)[3] <- "Specificity for GHRL high"
marker_spec_INS <- marker_spec_reformatted[marker_spec_reformatted$CellType == "INS high",]
marker_spec_INS <- marker_spec_INS[,-3]
colnames(marker_spec_INS)[3] <- "Specificity for INS high"
marker_spec_NGN3 <- marker_spec_reformatted[marker_spec_reformatted$CellType == "NGN3 high",]
marker_spec_NGN3 <- marker_spec_NGN3[,-3]
colnames(marker_spec_NGN3)[3] <- "Specificity for NGN3 high"
marker_spec_reformatted <- merge(marker_spec_GCG, marker_spec_GHRL[,c(1,3)], by="gene_id")
marker_spec_reformatted <- merge(marker_spec_reformatted, marker_spec_INS[,c(1,3)], by="gene_id")
marker_spec_reformatted <- merge(marker_spec_reformatted, marker_spec_NGN3[,c(1,3)], by="gene_id")
dim(marker_spec_reformatted)
head(marker_spec_reformatted)
write.table(marker_spec_reformatted, "marker_specificities_by_celltype.txt", quote=F, sep="\t", row.names=T, col.names=NA)

panc_cds_valid_cells <- setOrderingFilter(panc_cds_valid_cells, top_genes)
#plot_ordering_genes(panc_cds_valid_cells)

# TEMP (Save CDS for Xiaojie)
#save(file="panc_cds_valid_cells.cds", panc_cds_valid_cells)

panc_cds_valid_cells <- reduceDimension(panc_cds_valid_cells, max_components = 4, verbose=F)

plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by="CellType")
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by="CellType") + scale_x_reverse()
#plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by="CellType", cell_size=1.1) + scale_color_brewer(palette="Set1")
#plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by="Total_mRNAs")

# This adds a "state" column to the pData:
panc_cds_valid_cells <- orderCells(panc_cds_valid_cells)

# TEMP
# Save workspace
save.image(file = 'pancreas_3B.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_3B.RData')
ls()

plot_genes_jitter(panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), gene_short_name %in% 
	c("Ccnb2", "Ins1", "Ins2", "Gcg", "Ghrl", "Sst", "Ppy", "Neurog3", "Chga"))),], grouping="State")

# Added the following 3 commands to determine where the spanning tree starts and set the root_state: 
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType")

plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "State")
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "State", show_branch_points = F)
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "State", cell_size =1, show_branch_points = F) + facet_wrap(~State)

panc_cds_valid_cells <- orderCells(panc_cds_valid_cells, root_state = 12)

plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType") + facet_wrap(~Time)

# plot_cell_trajectory function with non-logarithmic scale for the markers argument
monocle_theme_opts <- function()
{
    theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
    theme(panel.border = element_blank()) +
    theme(axis.line.x = element_line(size=0.25, color="black")) +
    theme(axis.line.y = element_line(size=0.25, color="black")) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + 
    theme(panel.background = element_rect(fill='white')) +
    theme(legend.key=element_blank())
}

plot_cell_trajectory_2 <- function(cds, 
                               x=1, 
                               y=2, 
                               color_by="State", 
                               show_tree=TRUE, 
                               show_backbone=TRUE, 
                               backbone_color="black", 
                               markers=NULL, 
                               show_cell_names=FALSE, 
                               cell_size=1.5,
                               cell_link_size=0.75,
                               cell_name_size=2,
                               show_branch_points=TRUE){
  gene_short_name <- NULL
  sample_name <- NULL
  
  #TODO: need to validate cds as ready for this plot (need mst, pseudotime, etc)
  lib_info_with_pseudo <- pData(cds)
  
  if (is.null(cds@dim_reduce_type)){
    stop("Error: dimensionality not yet reduced. Please call reduceDimension() before calling this function.")
  }
  
  if (cds@dim_reduce_type == "ICA"){
    reduced_dim_coords <- reducedDimS(cds)
  }else if (cds@dim_reduce_type == "DDRTree"){
    reduced_dim_coords <- reducedDimK(cds)
  }else {
    stop("Error: unrecognized dimensionality reduction method.")
  }
  
  if (is.null(reduced_dim_coords)){
    stop("You must first call reduceDimension() before using this function")
  }
  
  ica_space_df <- data.frame(Matrix::t(reduced_dim_coords[c(x,y),]))
  colnames(ica_space_df) <- c("prin_graph_dim_1", "prin_graph_dim_2")
  
  ica_space_df$sample_name <- row.names(ica_space_df)
  #ica_space_with_state_df <- merge(ica_space_df, lib_info_with_pseudo, by.x="sample_name", by.y="row.names")
  #print(ica_space_with_state_df)
  dp_mst <- minSpanningTree(cds)
  
  if (is.null(dp_mst)){
    stop("You must first call orderCells() before using this function")
  }
  
  edge_list <- as.data.frame(igraph::get.edgelist(dp_mst))
  colnames(edge_list) <- c("source", "target")
  
  edge_df <- merge(ica_space_df, edge_list, by.x="sample_name", by.y="source", all=TRUE)
  #edge_df <- ica_space_df
  edge_df <- plyr::rename(edge_df, c("prin_graph_dim_1"="source_prin_graph_dim_1", "prin_graph_dim_2"="source_prin_graph_dim_2"))
  edge_df <- merge(edge_df, ica_space_df[,c("sample_name", "prin_graph_dim_1", "prin_graph_dim_2")], by.x="target", by.y="sample_name", all=TRUE)
  edge_df <- plyr::rename(edge_df, c("prin_graph_dim_1"="target_prin_graph_dim_1", "prin_graph_dim_2"="target_prin_graph_dim_2"))
  
  S_matrix <- reducedDimS(cds)
  data_df <- data.frame(t(S_matrix[c(x,y),]))
  colnames(data_df) <- c("data_dim_1", "data_dim_2")
  data_df$sample_name <- row.names(data_df)
  data_df <- merge(data_df, lib_info_with_pseudo, by.x="sample_name", by.y="row.names")
  
  markers_exprs <- NULL
  if (is.null(markers) == FALSE){
    markers_fData <- subset(fData(cds), gene_short_name %in% markers)
    if (nrow(markers_fData) >= 1){
      markers_exprs <- reshape2::melt(as.matrix(exprs(cds[row.names(markers_fData),])))
      colnames(markers_exprs)[1:2] <- c('feature_id','cell_id')
      markers_exprs <- merge(markers_exprs, markers_fData, by.x = "feature_id", by.y="row.names")
      #print (head( markers_exprs[is.na(markers_exprs$gene_short_name) == FALSE,]))
      markers_exprs$feature_label <- as.character(markers_exprs$gene_short_name)
      markers_exprs$feature_label[is.na(markers_exprs$feature_label)] <- markers_exprs$Var1
    }
  }
  if (is.null(markers_exprs) == FALSE && nrow(markers_exprs) > 0){
    data_df <- merge(data_df, markers_exprs, by.x="sample_name", by.y="cell_id")
    #print (head(edge_df))
    #RC: log and +0.1 was removed on the following line
    g <- ggplot(data=data_df, aes(x=data_dim_1, y=data_dim_2, size=value)) + facet_wrap(~feature_label)
  }else{
    g <- ggplot(data=data_df, aes(x=data_dim_1, y=data_dim_2)) 
  }
  if (show_tree){
    g <- g + geom_segment(aes_string(x="source_prin_graph_dim_1", y="source_prin_graph_dim_2", xend="target_prin_graph_dim_1", yend="target_prin_graph_dim_2"), size=.3, linetype="solid", na.rm=TRUE, data=edge_df)
  }
  
  # FIXME: setting size here overrides the marker expression funtionality. 
  # Don't do it!
  if (is.null(markers_exprs) == FALSE && nrow(markers_exprs) > 0){
    g <- g + geom_point(aes_string(color = color_by), na.rm = TRUE)
  }else {
    g <- g + geom_point(aes_string(color = color_by), size=I(cell_size), na.rm = TRUE)
  }
  
  
  if (show_branch_points && cds@dim_reduce_type == 'DDRTree'){
    mst_branch_nodes <- cds@auxOrderingData[[cds@dim_reduce_type]]$branch_points
    branch_point_df <- subset(edge_df, sample_name %in% mst_branch_nodes)[,c("sample_name", "source_prin_graph_dim_1", "source_prin_graph_dim_2")]
    branch_point_df$branch_point_idx <- match(branch_point_df$sample_name, mst_branch_nodes)
    branch_point_df <- branch_point_df[!duplicated(branch_point_df$branch_point_idx), ]
    
    g <- g + geom_point(aes_string(x="source_prin_graph_dim_1", y="source_prin_graph_dim_2"), 
                        size=5, na.rm=TRUE, data=branch_point_df) +
      geom_text(aes_string(x="source_prin_graph_dim_1", y="source_prin_graph_dim_2", label="branch_point_idx"), 
                size=4, color="white", na.rm=TRUE, data=branch_point_df)
  }
  if (show_cell_names){
    g <- g +geom_text(aes(label=sample_name), size=cell_name_size)
  }
  g <- g + 
    #scale_color_brewer(palette="Set1") +
    monocle_theme_opts() + 
    xlab(paste("Component", x)) + 
    ylab(paste("Component", y)) +
    theme(legend.position="top", legend.key.height=grid::unit(0.35, "in")) +
    #guides(color = guide_legend(label.position = "top")) +
    theme(legend.key = element_blank()) +
    theme(panel.background = element_rect(fill='white'))
  g
}

# TEMP: Test plot_cell_trajectory_2
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers="Ins1")

# scale_x_reverse switches around the X axis!
pdf("cell_trajectories.pdf", height=4, width=4)
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "Time", show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", show_branch_points = F) + facet_wrap(~Time) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType_eGFP", show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType_eGFP", show_branch_points = F) + facet_wrap(~Time) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType_Ngn3_Arx", show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType_Ngn3_Arx", show_branch_points = F) + facet_wrap(~Time) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "State", show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "State", show_branch_points = F) + facet_wrap(~Time) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "Pseudotime", show_branch_points = F) + scale_color_gradientn(colours=rainbow(7)) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "Pseudotime", show_branch_points = F) + scale_color_gradientn(colours=rainbow(7)) + facet_wrap(~Time) + scale_x_reverse()
dev.off()
pdf("cell_trajectories_showing_hormone_expression.pdf", height=4, width=4)
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins1"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins2"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Gcg"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ghrl"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ppy"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Sst"), show_branch_points = F) + scale_x_reverse()
dev.off()
pdf("cell_trajectories_showing_hormone_expression_non_logarithmic.pdf", height=4, width=4)
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins1"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins2"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Gcg"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ghrl"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ppy"), show_branch_points = F) + scale_x_reverse()
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Sst"), show_branch_points = F) + scale_x_reverse()
dev.off()

# Write tables
write.table(pData(panc_cds_valid_cells), "panc_cds_pData.txt", quote=F, sep="\t", row.names=T, col.names=NA)
write.table(exprs(panc_cds_valid_cells), "panc_cds_exprs_absolute.txt", sep="\t", row.names=T, col.names=NA)
write.table(t(t(exprs(panc_cds_valid_cells))/sizeFactors(panc_cds_valid_cells)), "panc_cds_exprs_absolute_normalized.txt", sep="\t", row.names=T, col.names=NA)

# Save workspace
save.image(file = 'pancreas_4.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_4.RData')
ls()

# TEMP: Figures for Presentation
pdf("Cole_CellDistribution.pdf", width = 3, height = 4)
ggplot(pData(panc_cds_valid_cells), aes(x = factor(Time), fill = CellType)) +
    geom_bar(position="fill") + scale_x_discrete(name="")
dev.off()
pdf("Cole_Trajectories.pdf", width = 5, height = 4)
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by="CellType", show_branch_points = F)
plot_cell_trajectory(panc_cds_valid_cells, 1, 2, color_by = "Pseudotime", show_branch_points = F) + scale_color_gradientn(colours=rainbow(7))
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins1"), show_branch_points = F)
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ins2"), show_branch_points = F)
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Gcg"), show_branch_points = F)
plot_cell_trajectory_2(panc_cds_valid_cells, 1, 2, color_by = "CellType", markers=c("Ghrl"), show_branch_points = F)
dev.off()

# Calculate pseudotime medians per Time point 
pseudotime_medians <- ddply(pData(panc_cds_valid_cells), "Time", summarise, pseudotime.median=median(Pseudotime))
pseudotime_medians

# Density Plot by Pseudotime
pdf("density_plot.pdf")
ggplot(pData(panc_cds_valid_cells), aes(x=Pseudotime, y=..count.., colour=Time))+
    geom_density(size=1)+
    geom_vline(data=pseudotime_medians, aes(xintercept=pseudotime.median, colour=Time), linetype="dashed", size=1)
dev.off()

# Figure out approximate pseudotime of branch point alpha vs. beta (1)
#cells_state11 <- row.names(subset(pData(panc_cds_valid_cells), 
#                               pData(panc_cds_valid_cells)$State %in% c("11")))
#panc_cds_state11 <- panc_cds_valid_cells[,cells_state11]
#dim(panc_cds_state11)

# Figure out approximate pseudotime of branch point alpha vs. beta (2)
#pData_cells_state11 <- pData(panc_cds_state11)
#pData_cells_state11 <- pData_cells_state11[18:19]
#pData_cells_state11 <- pData_cells_state11[order(pData_cells_state11$Pseudotime),]
#head(pData_cells_state11)
#tail(pData_cells_state11)

# Calculate relative pseudotime of branchpoint alpha vs. beta
#100/11.79509*7.37

# Alpha vs. beta branch expression plots for a set of marker genes
marker_genes1 <- c("Arx", "Etv1", "Pou3f4", "Gcg", "Pdx1", "Nkx6-1", "Pdx1", "Ins1", "Ins2", "Neurog3", 
                  "Chga", "Vim", "Isl1")
panc_marker_cds1 <- panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), 
                                                          gene_short_name %in% marker_genes1)),]
pdf("branching_pseudotime_plots1.pdf", width=4, height=19.5)
plot_genes_branched_pseudotime(panc_marker_cds1, stretch=T,
						 color_by="Time",
                         branch_states=c(4,1),
#                         branch_point=5,
						 branch_labels=c("Alpha cells", "Beta cells"),
						 min_expr=0.5)#+
#geom_vline(xintercept=62.48)
dev.off()

# Alpha vs. beta branch expression plots for additional genes
marker_genes2 <- c("Gapdh", "Ubc", "Tbp", "Mafb", "Ttr", "Ddp4", "Psen1", "Psen2", "Dll1")
panc_marker_cds2 <- panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), 
						 gene_short_name %in% marker_genes2)),]
pdf("branching_pseudotime_plots2.pdf", width=4, height=13.5)
plot_genes_branched_pseudotime(panc_marker_cds2, stretch=F,
						 color_by="Time",
                         branch_states=c(4,1),
#                         branch_point=5,
						 branch_labels=c("Alpha cells", "Beta cells"),
						 min_expr=0.5)#+
#geom_vline(xintercept=62.48)
dev.off()

# Alpha vs. beta branch expression plots for Wnt pathway genes
marker_genes_Wnt <- c("Frzb", "Apc", "Ctnnb1", "Axin1", "Axin2", "Fzd5", "Tle6", "Hbp1", "Tcf7", "Tcf7l1", 
                      "Tcf7l2", "Tcf3", "Wnt1")
panc_marker_cds_Wnt <- panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), 
						 gene_short_name %in% marker_genes_Wnt)),]
pdf("branching_pseudotime_plots_Wnt.pdf", width=4, height=19.5)
plot_genes_branched_pseudotime(panc_marker_cds_Wnt, stretch=T,
						 color_by="Time",
                         branch_states=c(4,1),
#                         branch_point=5,
						 branch_labels=c("Alpha cells", "Beta cells"),
						 min_expr=0.5)#+
#geom_vline(xintercept=62.48)
dev.off()

# eGFP vs. Ngn3 in pseudotime
eGFP_vs_Ngn3 <- c("eGFP", "ENSMUSG00000044312.3")
panc_eGFP_vs_Ngn3 <- panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), 
						 gene_id %in% eGFP_vs_Ngn3)),]
pdf("branching_pseudotime_plots_eGFP_vs_Ngn3.pdf")
plot_genes_branched_pseudotime(panc_eGFP_vs_Ngn3, 
                               stretch=T,
                               color_by="Time",
                         branch_states=c(4,1),
#                         branch_point=5,
						 branch_labels=c("Alpha cells", "Beta cells"),
						 min_expr=0.5)#+
#geom_vline(xintercept=62.48)
dev.off()

genes_to_test <- row.names(subset(fData(panc_cds_valid_cells), num_cells_expressed >= 5 & biotype %in% c("protein_coding", "lincRNA")))
length(valid_expressed_genes)
length(genes_to_test)
length(intersect(valid_expressed_genes, genes_to_test))

# TEST
plot_cell_trajectory(panc_cds_valid_cells, color_by = "State", show_branch_points = F)

# Subset alpha branch + progenitors
panc_cds_alpha_progenitors <- panc_cds_valid_cells[,pData(panc_cds_valid_cells)$State %in% 
                                                   c(12,11,10,9,8,13,7, 5, 4) == TRUE]
plot_cell_trajectory(panc_cds_alpha_progenitors, color_by = "State", show_branch_points = F)

panc_cds_alpha_progenitors <- detectGenes(panc_cds_alpha_progenitors, min_expr = 0.1)
panc_cds_alpha_progenitors <- estimateDispersions(panc_cds_alpha_progenitors, cores=32)

#genes_to_test_alpha <- row.names(subset(fData(panc_cds_alpha_progenitors),
#                                        num_cells_expressed >= 5 & biotype %in% c("protein_coding", "lincRNA")))
#length(genes_to_test_alpha)

diff_test_res1 <- differentialGeneTest(panc_cds_alpha_progenitors[genes_to_test,],
                                      fullModelFormulaStr="~sm.ns(Pseudotime)",
                                      cores=32)

# Save workspace
save.image(file = 'pancreas_4B.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_4B.RData')
ls()

sig_gene_names1 <- row.names(subset(diff_test_res1, qval<1e-2))
length(sig_gene_names1)

# I got an error when generating a heatmap indicating that I had duplicate row names.
# So I checked, and I indeed found two genes with the same gene_short_name, i.e. Zbtb20. 
# In fact, when I look at all the 33k genes, I find that 272 have duplicate gene_short_names.
# Per Cole, this is a property of many gene annotation files.
# Options:
# 1. Discard the genes for now if they are not interesting.
# 2. Add these rows together and collapse them into one row (but this is annoying to do all the time).
# 3. Use the gene_ids as the row name for the heatmap (which is fine as long as you don’t want to show 
# the gene names in the heatmap, which is usually what you want for large heatmaps).
dim(fData(panc_cds_alpha_progenitors[sig_gene_names1,]))
head(fData(panc_cds_alpha_progenitors[sig_gene_names1,]), 1)
sig_gene_names1_shortnames <- fData(panc_cds_alpha_progenitors)[sig_gene_names1,3:4]
sig_gene_names1_shortnames[duplicated(sig_gene_names1_shortnames$gene_short_name) == TRUE,]
sig_gene_names1_shortnames[sig_gene_names1_shortnames$gene_short_name == "Zbtb20",]
count(duplicated(fData(panc_cds)$gene_short_name))

# Exclude one of each of the duplicate genes
length(sig_gene_names1)
length(sig_gene_names1[!sig_gene_names1 %in% c("ENSMUSG00000036279.6")])

# Generate heatmap incl. pheatmap object
# Excluding genes from the list that are duplicated in the annotation file.
pdf("heatmap_alpha.pdf", width=10, height=130)
pheatmap_object1 <- plot_pseudotime_heatmap(panc_cds_alpha_progenitors[sig_gene_names1[!sig_gene_names1 %in% c("ENSMUSG00000036279.6")],],
                       num_clusters=4,
                       cores=32,
                       show_rownames=T,
                       return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters1 <- as.data.frame(cutree(pheatmap_object1$tree_row, k=4))
clusters_table1 <- cbind(fData(panc_cds)[rownames(clusters1),"gene_short_name"], clusters1)
names(clusters_table1) <- c("gene_short_name", "cluster_number")
clusters_table1 <- clusters_table1[order(clusters_table1$cluster_number),]
clusters_table1 <- cbind(clusters_table1, diff_test_res1[rownames(clusters1),c("pval", "qval")])
count(clusters_table1$cluster_number)
dim(clusters_table1)
head(clusters_table1)
write.table(clusters_table1, "heatmap_alpha_gene_table.txt", quote=F, sep="\t", row.names=T, col.names=NA)

# Subset beta branch + progenitors
panc_cds_beta_progenitors <- panc_cds_valid_cells[,pData(panc_cds_valid_cells)$State %in% 
                                                   c(12,11,10,9,8,13,7, 5, 2,1) == TRUE]
plot_cell_trajectory(panc_cds_beta_progenitors, color_by = "State", show_branch_points = F)

panc_cds_beta_progenitors <- detectGenes(panc_cds_beta_progenitors, min_expr = 0.1)
panc_cds_beta_progenitors <- estimateDispersions(panc_cds_beta_progenitors, cores=32)

#genes_to_test_beta <- row.names(subset(fData(panc_cds_beta_progenitors),
#                                        num_cells_expressed >= 5 & biotype %in% c("protein_coding", "lincRNA")))
#length(genes_to_test_beta)

diff_test_res2 <- differentialGeneTest(panc_cds_beta_progenitors[genes_to_test,],
                                      fullModelFormulaStr="~sm.ns(Pseudotime)",
                                      cores=32)

# Save workspace
save.image(file = 'pancreas_4C.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_4C.RData')
ls()

sig_gene_names2 <- row.names(subset(diff_test_res2, qval<1e-2))
length(sig_gene_names2)

# Check whether any gene short names in this list are duplicate.
dim(fData(panc_cds_beta_progenitors[sig_gene_names2,]))
head(fData(panc_cds_beta_progenitors[sig_gene_names2,]), 1)
sig_gene_names2_shortnames <- fData(panc_cds_beta_progenitors)[sig_gene_names2,3:4]
sig_gene_names2_shortnames[duplicated(sig_gene_names2_shortnames$gene_short_name) == TRUE,]
sig_gene_names2_shortnames[sig_gene_names2_shortnames$gene_short_name == "Zbtb20",]
sig_gene_names2_shortnames[sig_gene_names2_shortnames$gene_short_name == "Gm12302",]

# Exclude one of each of the duplicate genes
length(sig_gene_names2)
length(sig_gene_names2[!sig_gene_names2 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")])

# Generate heatmap incl. pheatmap object
# Excluding genes from the list that are duplicated in the annotation file.
pdf("heatmap_beta.pdf", width=10, height=130)
pheatmap_object2 <- plot_pseudotime_heatmap(panc_cds_beta_progenitors[sig_gene_names2[!sig_gene_names2 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                       num_clusters=4,
                       cores=32,
                       show_rownames=T,
                       return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters2 <- as.data.frame(cutree(pheatmap_object2$tree_row, k=4))
clusters_table2 <- cbind(fData(panc_cds)[rownames(clusters2),"gene_short_name"], clusters2)
names(clusters_table2) <- c("gene_short_name", "cluster_number")
clusters_table2 <- clusters_table2[order(clusters_table2$cluster_number),]
clusters_table2 <- cbind(clusters_table2, diff_test_res2[rownames(clusters2),c("pval", "qval")])
count(clusters_table2$cluster_number)
dim(clusters_table2)
head(clusters_table2)
write.table(clusters_table2, "heatmap_beta_gene_table.txt", quote=F, sep="\t", row.names=T, col.names=NA)

# Subset epsilon branch + progenitors
panc_cds_epsilon_progenitors <- panc_cds_valid_cells[,pData(panc_cds_valid_cells)$State %in% 
                                                   c(12,11,10,9,8,13,7, 6) == TRUE]
plot_cell_trajectory(panc_cds_epsilon_progenitors, color_by = "State", show_branch_points = F)

panc_cds_epsilon_progenitors <- detectGenes(panc_cds_epsilon_progenitors, min_expr = 0.1)
panc_cds_epsilon_progenitors <- estimateDispersions(panc_cds_epsilon_progenitors, cores=32)

#genes_to_test_epsilon <- row.names(subset(fData(panc_cds_epsilon_progenitors),
#                                        num_cells_expressed >= 5 & biotype %in% c("protein_coding", "lincRNA")))
#length(genes_to_test_epsilon)

diff_test_res3 <- differentialGeneTest(panc_cds_epsilon_progenitors[genes_to_test,],
                                      fullModelFormulaStr="~sm.ns(Pseudotime)",
                                      cores=32)

# Save workspace
save.image(file = 'pancreas_4D.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_4D.RData')
ls()

sig_gene_names3 <- row.names(subset(diff_test_res3, qval<1e-2))
length(sig_gene_names3)

# Check whether any gene short names in this list are duplicate.
dim(fData(panc_cds_epsilon_progenitors[sig_gene_names3,]))
head(fData(panc_cds_epsilon_progenitors[sig_gene_names3,]), 1)
sig_gene_names3_shortnames <- fData(panc_cds_epsilon_progenitors)[sig_gene_names3,3:4]
sig_gene_names3_shortnames[duplicated(sig_gene_names3_shortnames$gene_short_name) == TRUE,]

# Generate heatmap incl. pheatmap object
pdf("heatmap_epsilon.pdf", width=10, height=60)
pheatmap_object3 <- plot_pseudotime_heatmap(panc_cds_epsilon_progenitors[sig_gene_names3,],
                       num_clusters=4,
                       cores=32,
                       show_rownames=T,
                       return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters3 <- as.data.frame(cutree(pheatmap_object3$tree_row, k=4))
clusters_table3 <- cbind(fData(panc_cds)[rownames(clusters3),"gene_short_name"], clusters3)
names(clusters_table3) <- c("gene_short_name", "cluster_number")
clusters_table3 <- clusters_table3[order(clusters_table3$cluster_number),]
clusters_table3 <- cbind(clusters_table3, diff_test_res3[rownames(clusters3),c("pval", "qval")])
count(clusters_table3$cluster_number)
dim(clusters_table3)
head(clusters_table3)
write.table(clusters_table3, "heatmap_epsilon_gene_table.txt", quote=F, sep="\t", row.names=T, col.names=NA)

# TEMP
diff_test_res1[diff_test_res1$gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                     "Neurog3", "Stmn1", "Mcm3", "Mcm5"),
               c("gene_short_name", "qval")]
diff_test_res2[diff_test_res2$gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                     "Neurog3", "Stmn1", "Mcm3", "Mcm5"),
               c("gene_short_name", "qval")]
diff_test_res3[diff_test_res3$gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                     "Neurog3", "Stmn1", "Mcm3", "Mcm5"),
               c("gene_short_name", "qval")]

diff_test_res1_qval <- diff_test_res1[,c("gene_short_name", "qval")]
names(diff_test_res1_qval) <- c("gene_short_name", "qval_alpha")
diff_test_res2_qval <- diff_test_res2[,c("gene_short_name", "qval")]
names(diff_test_res2_qval) <- c("gene_short_name", "qval_beta")
diff_test_res3_qval <- diff_test_res3[,c("gene_short_name", "qval")]
names(diff_test_res3_qval) <- c("gene_short_name", "qval_epsilon")
diff_test_res_qval_merged <- cbind(diff_test_res1_qval, diff_test_res2_qval, diff_test_res3_qval)
diff_test_res_qval_merged <- diff_test_res_qval_merged[,-5]
diff_test_res_qval_merged <- diff_test_res_qval_merged[,-3]
head(diff_test_res_qval_merged)
dim(diff_test_res_qval_merged)
write.table(diff_test_res_qval_merged, "qvals_diff_expression_by_pseudotime_unbranched.txt", 
            quote=F, sep="\t", row.names=T, col.names=NA)

pData(panc_cds_alpha_progenitors) <- pData(panc_cds_alpha_progenitors)[,-9]
pData(panc_cds_beta_progenitors) <- pData(panc_cds_beta_progenitors)[,-9]
pData(panc_cds_epsilon_progenitors) <- pData(panc_cds_epsilon_progenitors)[,-9]

pdf("Genes_of_Interest_In_Pseudotime_Alpha.pdf")
plot_genes_in_pseudotime(panc_cds_alpha_progenitors[rownames(subset(fData(panc_cds), 
                                                                    gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                                                           "Neurog3", "Stmn1", "Mcm3", "Mcm5"))),],
                        color_by = "CellType")
dev.off()
pdf("Genes_of_Interest_In_Pseudotime_Beta.pdf")
plot_genes_in_pseudotime(panc_cds_beta_progenitors[rownames(subset(fData(panc_cds), 
                                                                    gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                                                           "Neurog3", "Stmn1", "Mcm3", "Mcm5"))),],
                        color_by = "CellType")
dev.off()
pdf("Genes_of_Interest_In_Pseudotime_Epsilon.pdf")
plot_genes_in_pseudotime(panc_cds_epsilon_progenitors[rownames(subset(fData(panc_cds), 
                                                                    gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Vim", 
                                                                                           "Neurog3", "Stmn1", "Mcm3", "Mcm5"))),],
                        color_by = "CellType")
dev.off()

# Save workspace
save.image(file = 'pancreas_4E.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_4E.RData')
ls()

# BEAM on alpha and beta branches
BEAM_res_alpha_beta <- BEAM(panc_cds_valid_cells[genes_to_test,],
                            branch_states=c(4,1),
                            branch_labels=c("Alpha cells", "Beta cells"),
                            cores=32)

# TEMP

# My concern is that the current version of BEAM generates a number of genes that are false positives.
# When I run the current version of BEAM on a particular dataset I get 366 genes with a qval of <1e-2.
# When I run a slightly modified version of BEAM that accepts the argument `progenitor_method = 'duplicate'` 
# on the same dataset (and with this latter argument) I get 131 genes whereby 127 intersect with the previous list.

branchTest2 <- 
function(cds, fullModelFormulaStr = "~sm.ns(Pseudotime, df = 3)*Branch",
                       reducedModelFormulaStr = "~sm.ns(Pseudotime, df = 3)", 
                       branch_states = NULL, 
                       branch_point=1,
                       relative_expr = TRUE,
                       cores = 1, 
                       branch_labels = NULL, 
                       verbose = FALSE,
                       ...) {
  
  if("Branch" %in% all.vars(terms(as.formula(fullModelFormulaStr)))) {
    cds_subset <- buildBranchCellDataSet(cds = cds, 
                                                branch_states = branch_states,
                                                branch_point=branch_point,
                                                branch_labels = branch_labels, ...)
  }
  else
    cds_subset <- cds
  
  branchTest_res <- differentialGeneTest(cds_subset, 
                                         fullModelFormulaStr = fullModelFormulaStr, 
                                         reducedModelFormulaStr = reducedModelFormulaStr, 
                                         cores = cores, 
                                         relative_expr = relative_expr, 
                                         verbose=verbose)
  
  return(branchTest_res)
}

BEAM2 <- function(cds, fullModelFormulaStr = "~sm.ns(Pseudotime, df = 3)*Branch", 
					reducedModelFormulaStr = "~sm.ns(Pseudotime, df = 3)", 
					branch_states = NULL,
					branch_point=1,
					relative_expr = TRUE, 
					branch_labels = NULL, 
					verbose = FALSE,
					cores = 1, 
					...) {

	branchTest_res <- branchTest2(cds, fullModelFormulaStr = fullModelFormulaStr,
	                       reducedModelFormulaStr = reducedModelFormulaStr, 
	                       branch_states = branch_states, 
	                       branch_point=branch_point,
	                       relative_expr = relative_expr,
	                       cores = cores, 
	                       branch_labels = branch_labels, 
	                       verbose=verbose, 
	                       ...)
	cmbn_df <- branchTest_res[, 1:4] 

  #make a newCellDataSet object with the smoothed data? 
	if(verbose)
   message('pass branchTest')

	fd <- fData(cds)[row.names(cmbn_df),]

	#combined dataframe: 
	cmbn_df <- cbind(cmbn_df, fd)

  if(verbose)
   message('return results')

	return(cmbn_df)
}
        
BEAM_res_alpha_beta2 <- BEAM2(panc_cds_valid_cells[genes_to_test,],
                            branch_states=c(4,1),
                            branch_labels=c("Alpha cells", "Beta cells"),
                            cores=32,
                            progenitor_method = 'duplicate')

# Number of significant genes generated by conventional BEAM (sequential_split)
length(row.names(subset(BEAM_res_alpha_beta, qval<1e-2)))
# Number of significant genes generated by modified BEAM (progenitor duplication)
length(row.names(subset(BEAM_res_alpha_beta2, qval<1e-2)))
# Intersection
length(intersect(row.names(subset(BEAM_res_alpha_beta, qval<1e-2)), 
                 row.names(subset(BEAM_res_alpha_beta2, qval<1e-2))))

# Generate heatmap incl. pheatmap object
pdf("branched_heatmap_alpha_beta_significant.pdf", height=30, width=6)
pheatmap_object4 <- plot_genes_branched_heatmap(panc_cds_valid_cells[row.names(subset(BEAM_res_alpha_beta, qval<1e-2)),],
                                                branch_states=c(4,1),
                                                branch_labels=c("Alpha cells", "Beta cells"),
                                                show_rownames=T,
                                                num_clusters=4,
                                                return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters4 <- as.data.frame(cutree(pheatmap_object4$ph$tree_row, k=4))
clusters_table4 <- cbind(fData(panc_cds)[rownames(clusters4),"gene_short_name"], clusters4)
names(clusters_table4) <- c("gene_short_name", "cluster_number")
clusters_table4 <- clusters_table4[order(clusters_table4$cluster_number),]
clusters_table4 <- cbind(clusters_table4, BEAM_res_alpha_beta[rownames(clusters4),c("pval", "qval")])
count(clusters_table4$cluster_number)
dim(clusters_table4)
head(clusters_table4)
write.table(clusters_table4, "branched_heatmap_alpha_beta_significant_gene_table.txt", quote=F, sep="\t", 
            row.names=T, col.names=NA)

pdf("branched_heatmap_alpha_beta_marker_genes.pdf", height=2, width=6)
plot_genes_branched_heatmap(panc_marker_cds1,
                            branch_states=c(4,1),
                            branch_labels=c("Alpha cells", "Beta cells"),
                            show_rownames=TRUE,
                            num_clusters=4)
dev.off()

# BEAM on alpha and epsilon branches
BEAM_res_alpha_epsilon <- BEAM(panc_cds_valid_cells[genes_to_test,],
                               branch_states=c(4,6),
                               branch_labels=c("Alpha cells", "Epsilon cells"),
                               cores=32)

# Generate heatmap incl. pheatmap object
pdf("branched_heatmap_alpha_epsilon_significant.pdf", height=40, width=6)
pheatmap_object5 <- plot_genes_branched_heatmap(panc_cds_valid_cells[row.names(subset(BEAM_res_alpha_epsilon, 
                                                                                      qval<1e-2)),],
                                                branch_states=c(4,6),
                                                branch_labels=c("Alpha cells", "Epsilon cells"),
                                                show_rownames=TRUE,
                                                num_clusters=4,
                                                return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters5 <- as.data.frame(cutree(pheatmap_object5$ph$tree_row, k=4))
clusters_table5 <- cbind(fData(panc_cds)[rownames(clusters5),"gene_short_name"], clusters5)
names(clusters_table5) <- c("gene_short_name", "cluster_number")
clusters_table5 <- clusters_table5[order(clusters_table5$cluster_number),]
clusters_table5 <- cbind(clusters_table5, BEAM_res_alpha_epsilon[rownames(clusters5),c("pval", "qval")])
count(clusters_table5$cluster_number)
dim(clusters_table5)
head(clusters_table5)
write.table(clusters_table5, "branched_heatmap_alpha_epsilon_significant_gene_table.txt", quote=F, sep="\t", 
            row.names=T, col.names=NA)

# BEAM on beta and epsilon branches
BEAM_res_beta_epsilon <- BEAM(panc_cds_valid_cells[genes_to_test,],
                              branch_states=c(1,6),
                              branch_labels=c("Beta cells", "Epsilon cells"),
                              cores=32)

pdf("branched_heatmap_beta_epsilon_significant.pdf", height=50, width=6)
pheatmap_object6 <- plot_genes_branched_heatmap(panc_cds_valid_cells[row.names(subset(BEAM_res_beta_epsilon, qval<1e-2)),],
                                                branch_states=c(1,6),
                                                branch_labels=c("Beta cells", "Epsilon cells"),
                                                show_rownames=TRUE,
                                                num_clusters=4,
                                                return_heatmap=T)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters6 <- as.data.frame(cutree(pheatmap_object6$ph$tree_row, k=4))
clusters_table6 <- cbind(fData(panc_cds)[rownames(clusters6),"gene_short_name"], clusters6)
names(clusters_table6) <- c("gene_short_name", "cluster_number")
clusters_table6 <- clusters_table6[order(clusters_table6$cluster_number),]
clusters_table6 <- cbind(clusters_table6, BEAM_res_beta_epsilon[rownames(clusters6),c("pval", "qval")])
count(clusters_table6$cluster_number)
dim(clusters_table6)
head(clusters_table6)
write.table(clusters_table6, "branched_heatmap_beta_epsilon_significant_gene_table.txt", quote=F, sep="\t", 
            row.names=T, col.names=NA)

# TEMP
pdf("branched_heatmap_alpha_beta_hormones.pdf", height=1, width=6)
plot_genes_branched_heatmap(panc_cds_valid_cells[row.names(subset(fData(panc_cds_valid_cells), 
                                                                   gene_short_name %in% 
                                                                   c("Ins1", "Gcg"))),],
                            branch_states=c(4,1),
                            branch_labels=c("Alpha cells", "Beta cells"),
                            show_rownames=TRUE,
                            num_clusters=2)
dev.off()

BEAM_res_alpha_beta_qval <- BEAM_res_alpha_beta[,c("gene_short_name", "qval")]
names(BEAM_res_alpha_beta_qval) <- c("gene_short_name", "qval_alpha_beta")
BEAM_res_alpha_epsilon_qval <- BEAM_res_alpha_epsilon[,c("gene_short_name", "qval")]
names(BEAM_res_alpha_epsilon_qval) <- c("gene_short_name", "qval_alpha_epsilon")
BEAM_res_beta_epsilon_qval <- BEAM_res_beta_epsilon[,c("gene_short_name", "qval")]
names(BEAM_res_beta_epsilon_qval) <- c("gene_short_name", "qval_beta_epsilon")
BEAM_res_qval_merged <- cbind(BEAM_res_alpha_beta_qval, BEAM_res_alpha_epsilon_qval, BEAM_res_beta_epsilon_qval)
BEAM_res_qval_merged <- BEAM_res_qval_merged[,-5]
BEAM_res_qval_merged <- BEAM_res_qval_merged[,-3]
head(BEAM_res_qval_merged)
dim(BEAM_res_qval_merged)
write.table(BEAM_res_qval_merged, "qvals_diff_expression_by_pseudotime_branched.txt", 
            quote=F, sep="\t", row.names=T, col.names=NA)

# Save workspace
save.image(file = 'pancreas_5.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_5.RData')
ls()

# Modified function: Plot heatmap of 3 branches with the same coloring. Each CDS subset has to have the same set of genes.
plot_pseudotime_heatmap_cbind3 <- function(cds_subset1, cds_subset2, cds_subset3, 
                                    
                                    cluster_rows = TRUE,
                                    hclust_method = "ward.D2", 
                                    num_clusters = 6,
                                    
                                    hmcols = NULL, 
                                    
                                    add_annotation_row = NULL,
                                    add_annotation_col = NULL,
                                    show_rownames = FALSE, 
                                    use_gene_short_name = TRUE,
                                    
                                    norm_method = c("vstExprs", "log"), 
                                    scale_max=3, 
                                    scale_min=-3, 
                                    
                                    trend_formula = '~sm.ns(Pseudotime, df=3)',
                                    
                                    return_heatmap=FALSE,
                                    cores=1){
  
  newdata1 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset1)$Pseudotime),length.out = 100)) 
  
  m1 <- genSmoothCurves(cds_subset1, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata1)

  newdata2 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset2)$Pseudotime),length.out = 100)) 
  
  m2 <- genSmoothCurves(cds_subset2, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata2)
  
  newdata3 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset3)$Pseudotime),length.out = 100)) 
  
  m3 <- genSmoothCurves(cds_subset3, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata3)

  m <- cbind(m1, m2, m3)

  #remove genes with no expression in any condition
  m=m[!apply(m,1,sum)==0,]
  
  norm_method <- match.arg(norm_method)
  
  # FIXME: this needs to check that vst values can even be computed. (They can only be if we're using NB as the expressionFamily)
  if(norm_method == 'vstExprs' && is.null(cds_subset1@dispFitInfo[["blind"]]$disp_func) == FALSE) {
    m = vstExprs(cds_subset1, expr_matrix=m)
  }     
  else if(norm_method == 'log') {
    m = log10(m+pseudocount)
  }
  
  # Row-center the data.
  m=m[!apply(m,1,sd)==0,]
  m=Matrix::t(scale(Matrix::t(m),center=TRUE))
  m=m[is.na(row.names(m)) == FALSE,]
  m[is.nan(m)] = 0
  m[m>scale_max] = scale_max
  m[m<scale_min] = scale_min

  heatmap_matrix <- m
  
  row_dist <- as.dist((1 - cor(Matrix::t(heatmap_matrix)))/2)
  row_dist[is.na(row_dist)] <- 1
  
  if(is.null(hmcols)) {
    bks <- seq(-3.1,3.1, by = 0.1)
    hmcols <- blue2green2red(length(bks) - 1)
  }
  else {
    bks <- seq(-3.1,3.1, length.out = length(hmcols))
  } 
  
  ph <- pheatmap(heatmap_matrix, 
                 useRaster = T,
                 cluster_cols=FALSE, 
                 cluster_rows=cluster_rows, 
                 show_rownames=F, 
                 show_colnames=F, 
                 clustering_distance_rows=row_dist,
                 clustering_method = hclust_method,
                 cutree_rows=num_clusters,
                 silent=TRUE,
                 filename=NA,
                 breaks=bks,
                 color=hmcols)

  annotation_row <- data.frame(Cluster=factor(cutree(ph$tree_row, num_clusters)))
 
  if(!is.null(add_annotation_row)) {
    old_colnames_length <- ncol(annotation_row)
    annotation_row <- cbind(annotation_row, add_annotation_row[row.names(annotation_row), ])  
    colnames(annotation_row)[(old_colnames_length+1):ncol(annotation_row)] <- colnames(add_annotation_row)
    # annotation_row$bif_time <- add_annotation_row[as.character(fData(absolute_cds[row.names(annotation_row), ])$gene_short_name), 1]
  }
  
  
  if (use_gene_short_name == TRUE) {
    if (is.null(fData(cds_subset1)$gene_short_name) == FALSE) {
      feature_label <- as.character(fData(cds_subset1)[row.names(heatmap_matrix), 'gene_short_name'])
      feature_label[is.na(feature_label)] <- row.names(heatmap_matrix)
      
      row_ann_labels <- as.character(fData(cds_subset1)[row.names(annotation_row), 'gene_short_name'])
      row_ann_labels[is.na(row_ann_labels)] <- row.names(annotation_row)
    }
    else {
      feature_label <- row.names(heatmap_matrix)
      row_ann_labels <- row.names(annotation_row)
    }
  }
  else {
    feature_label <- row.names(heatmap_matrix)
    row_ann_labels <- row.names(annotation_row)
  }

  row.names(heatmap_matrix) <- feature_label
  row.names(annotation_row) <- row_ann_labels
  
  
  colnames(heatmap_matrix) <- c(1:ncol(heatmap_matrix))
  
  ph_res <- pheatmap(heatmap_matrix[, ], #ph$tree_row$order
                     useRaster = T,
                     cluster_cols = FALSE, 
                     cluster_rows = cluster_rows, 
                     show_rownames=show_rownames, 
                     show_colnames=F, 
                     #scale="row",
                     clustering_distance_rows=row_dist, #row_dist
                     clustering_method = hclust_method, #ward.D2
                     cutree_rows=num_clusters,
                     # cutree_cols = 2,
                     annotation_row=annotation_row,
                     gaps_col = c(100, 200),
                     treeheight_row = 20, 
                     breaks=bks,
                     fontsize = 12,
                     color=hmcols, 
                     silent=TRUE,
                     filename=NA
  )
  
  grid::grid.rect(gp=grid::gpar("fill", col=NA))
  grid::grid.draw(ph_res$gtable)
  if (return_heatmap){
    return(ph_res)
  }
}

# TEMP: Genes of interest
genes_of_interest <- c("Iapp", "Ins1", "Ins2", "Gcg", "Ghrl", "Vim", "Neurog3", "Stmn1", 
                       "Mcm3", "Mcm5", "Mlxipl", "Meox1")

# Union (rather than intersect) of all genes that are significantly differentially expressed in pseudotime per branch
length(sig_gene_names1)
length(sig_gene_names2)
length(sig_gene_names3)
union_sig_gene_names_1_2_3 <- union(union(sig_gene_names1, sig_gene_names2), sig_gene_names3)
length(union_sig_gene_names_1_2_3)
# Remove genes with duplicate short gene names (as above)
length(union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")])

pdf("heatmap_genes_of_interest_alpha_beta_epsilon.pdf", width=20, height=5)
plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% genes_of_interest)),],
                               panc_cds_beta_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% genes_of_interest)),],
                               panc_cds_epsilon_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% genes_of_interest)),],
                               num_clusters = 1, cores = 1, show_rownames = T, return_heatmap = F)
dev.off()

# Without gene names (and with removed duplicated genes)
pdf("heatmap_significant_genes_alpha_beta_epsilon_small.pdf", width=8, height=6)
pheatmap_object7 <- plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_beta_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_epsilon_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               num_clusters = 8, cores = 1, show_rownames = F, return_heatmap = T)
dev.off()

# With gene names (and with removed duplicated genes)
pdf("heatmap_significant_genes_alpha_beta_epsilon_big.pdf", width=20, height=400)
plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_beta_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_epsilon_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               num_clusters = 8, cores = 1, show_rownames = T, return_heatmap = F)
dev.off()

# Generate table with heatmap genes and cluster numbers
clusters7 <- as.data.frame(cutree(pheatmap_object7$tree_row, k=8))
clusters_table7 <- cbind(fData(panc_cds)[rownames(clusters7),"gene_short_name"], clusters7)
names(clusters_table7) <- c("gene_short_name", "cluster_number")
clusters_table7 <- clusters_table7[order(clusters_table7$cluster_number),]
count(clusters_table7$cluster_number)
dim(clusters_table7)
head(clusters_table7)
write.table(clusters_table7, "heatmap_significant_genes_alpha_beta_epsilon_gene_table.txt", quote=F, sep="\t", 
            row.names=T, col.names=NA)

# TEMP: Figures for Presentation
pdf("Cole_Heatmap1.pdf", width = 6, height = 4)
plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_beta_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               panc_cds_epsilon_progenitors[union_sig_gene_names_1_2_3[!union_sig_gene_names_1_2_3 %in% c("ENSMUSG00000036279.6","ENSMUSG00000097886.1")],],
                               num_clusters = 8, cores = 1, show_rownames = F, return_heatmap = F)
dev.off()

# TEMP: Figures for Presentation
pdf("Cole_Heatmap2.pdf", width = 6, height = 2.2)
plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Neurog3", "Cdh1", "Vim"))),],
                               panc_cds_beta_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Neurog3", "Cdh1", "Vim"))),],
                               panc_cds_epsilon_progenitors[row.names(subset(fData(panc_cds),
                                                                           gene_short_name %in% c("Ins1", "Ins2", "Gcg", "Ghrl", "Neurog3", "Cdh1", "Vim"))),],
                               num_clusters = 1, cores = 1, show_rownames = T, return_heatmap = F)
dev.off()

# Replace cds_subset with cds_exprs on line 65 (error in code)
plot_genes_in_pseudotime2 <-function(cds_subset, 
                                    min_expr=NULL, 
                                    cell_size=0.75, 
                                    nrow=NULL, 
                                    ncol=1, 
                                    panel_order=NULL, 
                                    color_by="State",
                                    trend_formula="~ sm.ns(Pseudotime, df=3)",
                                    label_by_short_name=TRUE,
                                    relative_expr=TRUE,
                                    vertical_jitter=NULL,
                                    horizontal_jitter=NULL){
  
    if (cds_subset@expressionFamily@vfamily %in% c("negbinomial", "negbinomial.size")) {
        integer_expression <- TRUE
    }
    else {
        integer_expression <- FALSE
        relative_expr <- TRUE
    }
    if (integer_expression) {
        cds_exprs <- exprs(cds_subset)
        if (relative_expr) {
            if (is.null(sizeFactors(cds_subset))) {
                stop("Error: to call this function with relative_expr=TRUE, you must call estimateSizeFactors() first")
            }
            cds_exprs <- Matrix::t(Matrix::t(cds_exprs)/sizeFactors(cds_subset))
        }
        cds_exprs <- reshape2::melt(round(as.matrix(cds_exprs)))
    }
    else {
        cds_exprs <- reshape2::melt(as.matrix(exprs(cds_subset)))
    }
    if (is.null(min_expr)) {
        min_expr <- cds_subset@lowerDetectionLimit
    }
    colnames(cds_exprs) <- c("f_id", "Cell", "expression")
    cds_pData <- pData(cds_subset)
    cds_fData <- fData(cds_subset)
    cds_exprs <- merge(cds_exprs, cds_fData, by.x = "f_id", by.y = "row.names")
    cds_exprs <- merge(cds_exprs, cds_pData, by.x = "Cell", by.y = "row.names")
    #cds_exprs$f_id <- as.character(cds_exprs$f_id)
    #cds_exprs$Cell <- as.character(cds_exprs$Cell)
    
    if (integer_expression) {
        cds_exprs$adjusted_expression <- cds_exprs$expression
    }
    else {
        cds_exprs$adjusted_expression <- log10(cds_exprs$expression)
    }
    # trend_formula <- paste("adjusted_expression", trend_formula,
    #     sep = "")
    if (label_by_short_name == TRUE) {
        if (is.null(cds_exprs$gene_short_name) == FALSE) {
            cds_exprs$feature_label <- as.character(cds_exprs$gene_short_name)
            cds_exprs$feature_label[is.na(cds_exprs$feature_label)] <- cds_exprs$f_id
        }
        else {
            cds_exprs$feature_label <- cds_exprs$f_id
        }
    }
    else {
        cds_exprs$feature_label <- cds_exprs$f_id
    }
    cds_exprs$f_id <- as.character(cds_exprs$f_id)
    cds_exprs$feature_label <- factor(cds_exprs$feature_label)

    new_data <- data.frame(Pseudotime = pData(cds_subset)$Pseudotime)
    model_expectation <- genSmoothCurves(cds_subset, cores=1, trend_formula = trend_formula,
                        relative_expr = T, new_data = new_data)
    colnames(model_expectation) <- colnames(cds_subset)
    expectation <- ddply(cds_exprs, .(f_id, Cell), function(x) data.frame("expectation"=model_expectation[x$f_id, x$Cell]))
    cds_exprs <- merge(cds_exprs, expectation)
    #cds_exprs$expectation <- expectation#apply(cds_exprs,1, function(x) model_expectation[x$f_id, x$Cell])

    cds_exprs$expression[cds_exprs$expression < min_expr] <- min_expr
    cds_exprs$expectation[cds_exprs$expectation < min_expr] <- min_expr
    if (is.null(panel_order) == FALSE) {
        cds_exprs$feature_label <- factor(cds_exprs$feature_label,
            levels = panel_order)
    }
    q <- ggplot(aes(Pseudotime, expression), data = cds_exprs)
    if (is.null(color_by) == FALSE) {
        q <- q + geom_point(aes_string(color = color_by), size = I(cell_size), position=position_jitter(horizontal_jitter, vertical_jitter))
    }
    else {
        q <- q + geom_point(size = I(cell_size), position=position_jitter(horizontal_jitter, vertical_jitter))
    }

    q <- q + geom_line(aes(x = Pseudotime, y = expectation), data = cds_exprs)

    q <- q + scale_y_log10() + facet_wrap(~feature_label, nrow = nrow,
        ncol = ncol, scales = "free_y")
    if (min_expr < 1) {
        q <- q + expand_limits(y = c(min_expr, 1))
    }
    if (relative_expr) {
        q <- q + ylab("Relative Expression")
    }
    else {
        q <- q + ylab("Absolute Expression")
    }
    q <- q + xlab("Pseudo-time")
    q <- q + monocle_theme_opts()
    q
}

# TEMP: Figures for Presentation
genes_of_interest2 <- c("Gcg","Ins1", "Ghrl", "Vim", "Cdh1")
pdf("Cole_Pseudotime_Alpha.pdf", width = 3, height = 6)
plot_genes_in_pseudotime2(panc_cds_alpha_progenitors[row.names(subset(fData(panc_cds), 
                                                                     gene_short_name %in% genes_of_interest2)),], 
                         color_by = "Time", 
                         panel_order = genes_of_interest2)
dev.off()
pdf("Cole_Pseudotime_Beta.pdf", width = 3, height = 6)
plot_genes_in_pseudotime2(panc_cds_beta_progenitors[row.names(subset(fData(panc_cds), 
                                                                     gene_short_name %in% genes_of_interest2)),], 
                         color_by = "Time", 
                         panel_order = genes_of_interest2)
dev.off()
pdf("Cole_Pseudotime_Epsilon.pdf", width = 3, height = 6)
plot_genes_in_pseudotime2(panc_cds_epsilon_progenitors[row.names(subset(fData(panc_cds), 
                                                                     gene_short_name %in% genes_of_interest2)),], 
                         color_by = "Time", 
                         panel_order = genes_of_interest2)
dev.off()

# Save workspace
save.image(file = 'pancreas_5A.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_5A.RData')
ls()

#cth <- newCellTypeHierarchy()
#cth <- addCellType(cth, "GCG high", classify_func=function(x) {x[Gcg_id,] > 0})
#cth <- addCellType(cth, "INS high", classify_func=function(x) {x[Ins1_id,] > 0 | x[Ins2_id,] > 0})
#cth <- addCellType(cth, "GHRL high", classify_func=function(x) {x[Ghrl_id,] > 0})
#cth <- addCellType(cth, "SST high", classify_func=function(x) {x[Sst_id,] > 100})
#cth <- addCellType(cth, "PPY high", classify_func=function(x) {x[Ppy_id,] > 100})
#cth <- addCellType(cth, "NGN3 high", classify_func=function(x) {x[Ngn3_id,] > 100})
#panc_cds_valid_cells <- classifyCells(panc_cds_valid_cells, cth)
#count(pData(panc_cds_valid_cells)$CellType)

#dim(panc_cds_valid_cells)
#panc_cds_valid_cells_no_ambiguous <- panc_cds_valid_cells[,row.names(subset(pData(panc_cds_valid_cells), !(pData(panc_cds_valid_cells)$CellType == "Ambiguous")))]
#dim(panc_cds_valid_cells_no_ambiguous)
#count(pData(panc_cds_valid_cells_no_ambiguous)$CellType)

#pData(panc_cds_valid_cells_no_ambiguous)$GCG <- pData(panc_cds_valid_cells_no_ambiguous)$CellType == "GCG high"
#count(pData(panc_cds_valid_cells_no_ambiguous)$GCG)
#pData(panc_cds_valid_cells_no_ambiguous)$GHRL <- pData(panc_cds_valid_cells_no_ambiguous)$CellType == "GHRL high"
#count(pData(panc_cds_valid_cells_no_ambiguous)$GHRL)
#pData(panc_cds_valid_cells_no_ambiguous)$INS <- pData(panc_cds_valid_cells_no_ambiguous)$CellType == "INS high"
#count(pData(panc_cds_valid_cells_no_ambiguous)$INS)
#pData(panc_cds_valid_cells_no_ambiguous)$NGN3 <- pData(panc_cds_valid_cells_no_ambiguous)$CellType == "NGN3 high"
#count(pData(panc_cds_valid_cells_no_ambiguous)$NGN3)
#str(pData(panc_cds_valid_cells_no_ambiguous))

#DiffGenes_GCG <- differentialGeneTest(panc_cds_valid_cells_no_ambiguous[genes_to_test,], 
#                                            fullModelFormulaStr="~GCG",
#                                            cores=32, verbose=F)
#diffgenes_GCG_sig <- row.names(subset(DiffGenes_GCG, qval<0.1 & qval>0))
#diffgenes_GCG_sig_table <- DiffGenes_GCG[diffgenes_GCG_sig, c("gene_short_name", "gene_id", "qval", "pval")]
#row.names(diffgenes_GCG_sig_table) <- NULL
#diffgenes_GCG_sig_table <- diffgenes_GCG_sig_table[order(diffgenes_GCG_sig_table$qval),]
#dim(diffgenes_GCG_sig_table)
#head(diffgenes_GCG_sig_table, 20)
#write.table(diffgenes_GCG_sig_table, "DiffGenes_GCG.txt", quote=F, sep="\t", row.names=F, col.names=T)

#DiffGenes_INS <- differentialGeneTest(panc_cds_valid_cells_no_ambiguous[genes_to_test,], 
#                                            fullModelFormulaStr="~INS",
#                                            cores=32, verbose=F)
#diffgenes_INS_sig <- row.names(subset(DiffGenes_INS, qval<0.1 & qval>0))
#diffgenes_INS_sig_table <- DiffGenes_INS[diffgenes_INS_sig, c("gene_short_name", "gene_id", "qval", "pval")]
#row.names(diffgenes_INS_sig_table) <- NULL
#diffgenes_INS_sig_table <- diffgenes_INS_sig_table[order(diffgenes_INS_sig_table$qval),]
#dim(diffgenes_INS_sig_table)
#head(diffgenes_INS_sig_table, 20)
#write.table(diffgenes_INS_sig_table, "DiffGenes_INS.txt", quote=F, sep="\t", row.names=F, col.names=T)

#DiffGenes_GHRL <- differentialGeneTest(panc_cds_valid_cells_no_ambiguous[genes_to_test,], 
#                                            fullModelFormulaStr="~GHRL",
#                                            cores=32, verbose=F)
#diffgenes_GHRL_sig <- row.names(subset(DiffGenes_GHRL, qval<0.1 & qval>0))
#diffgenes_GHRL_sig_table <- DiffGenes_GHRL[diffgenes_GHRL_sig, c("gene_short_name", "gene_id", "qval", "pval")]
#row.names(diffgenes_GHRL_sig_table) <- NULL
#diffgenes_GHRL_sig_table <- diffgenes_GHRL_sig_table[order(diffgenes_GHRL_sig_table$qval),]
#dim(diffgenes_GHRL_sig_table)
#head(diffgenes_GHRL_sig_table, 20)
#write.table(diffgenes_GHRL_sig_table, "DiffGenes_GHRL.txt", quote=F, sep="\t", row.names=F, col.names=T)

#DiffGenes_NGN3 <- differentialGeneTest(panc_cds_valid_cells_no_ambiguous[genes_to_test,], 
#                                            fullModelFormulaStr="~NGN3",
#                                            cores=32, verbose=F)
#diffgenes_NGN3_sig <- row.names(subset(DiffGenes_NGN3, qval<0.1 & qval>0))
#diffgenes_NGN3_sig_table <- DiffGenes_NGN3[diffgenes_NGN3_sig, c("gene_short_name", "gene_id", "qval", "pval")]
#row.names(diffgenes_NGN3_sig_table) <- NULL
#diffgenes_NGN3_sig_table <- diffgenes_NGN3_sig_table[order(diffgenes_NGN3_sig_table$qval),]
#dim(diffgenes_NGN3_sig_table)
#head(diffgenes_NGN3_sig_table, 20)
#write.table(diffgenes_NGN3_sig_table, "DiffGenes_NGN3.txt", quote=F, sep="\t", row.names=F, col.names=T)

# Save workspace
#save.image(file = 'pancreas_5A_1.RData')

# Load packages & set theme for ggplot2
#library(monocle)
#library(stringr)
#library(piano)
#library(reshape2)
#library(plyr)
#library(colorRamps)
#library(pheatmap)
#theme_set(theme_bw(base_size=10))
#time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
#load('pancreas_5A_1.RData')
#ls()

# Source functions required for GO term/reactome pathway analysis
loadGSCSafe <- 
function (file, type = "auto", addInfo, sep="\t", encoding="latin1") 
{
    if (missing(addInfo)) {
        addUserInfo <- "skip"
        addInfo <- "none"
    }
    else {
        addUserInfo <- "yes"
    }
    tmp <- try(type <- match.arg(type, c("auto", "gmt", "sbml", 
        "sif", "data.frame"), several.ok = FALSE), silent = TRUE)
    if (class(tmp) == "try-error") {
        stop("argument type set to unknown value")
    }
    if (type == "auto") {
        if (class(file) == "character") {
            tmp <- unlist(strsplit(file, "\\."))
            type <- tolower(tmp[length(tmp)])
            if (!type %in% c("gmt", "sif", "sbml", "xml")) 
                stop(paste("can not handle .", type, " file extension, read manually using e.g. read.delim() and load as data.frame", 
                  sep = ""))
        }
        else {
            type <- "data.frame"
        }
    }
    if (type == "gmt") {
        con <- file(file, encoding=encoding)
        tmp <- try(suppressWarnings(open(con)), silent = TRUE)
        if (class(tmp) == "try-error") 
            stop("file could not be read")
        if (addUserInfo == "skip") 
            addInfo <- vector()
        gscList <- list()
        i <- 1
        tmp <- try(suppressWarnings(while (length(l <- scan(con, 
            nlines = 1, what = "character", quiet = T, sep=sep)) > 0) {
            if (addUserInfo == "skip") 
                addInfo <- rbind(addInfo, l[1:2])
            tmp <- l[3:length(l)]
            gscList[[l[1]]] <- unique(tmp[tmp != "" & tmp != 
                " " & !is.na(tmp)])
            i <- i + 1
        }), silent = TRUE)
        if (class(tmp) == "try-error") 
            stop("file could not be read")
        close(con)
        gsc <- gscList[!duplicated(names(gscList))]
        if (addUserInfo == "skip") 
            addInfo <- unique(addInfo)
    }
    else if (type %in% c("sbml", "xml")) {
        require(rsbml)
        tmp <- try(sbml <- rsbml_read(file))
        if (class(tmp) == "try-error") {
            stop("file could not be read by rsbml_read()")
        }
        gsc <- list()
        for (iReaction in 1:length(reactions(model(sbml)))) {
            metIDs <- names(c(reactants(reactions(model(sbml))[[iReaction]]), 
                products(reactions(model(sbml))[[iReaction]])))
            geneIDs <- names(modifiers(reactions(model(sbml))[[iReaction]]))
            if (length(geneIDs) > 0) {
                geneNames <- rep(NA, length(geneIDs))
                for (iGene in 1:length(geneIDs)) {
                  geneNames[iGene] <- name(species(model(sbml))[[geneIDs[iGene]]])
                }
                for (iMet in 1:length(metIDs)) {
                  gsc[[metIDs[iMet]]] <- c(gsc[[metIDs[iMet]]], 
                    geneNames)
                }
            }
        }
        if (length(gsc) == 0) {
            stop("no gene association found")
        }
        else {
            for (iMet in 1:length(gsc)) {
                tmp1 <- name(species(model(sbml))[[names(gsc)[iMet]]])
                tmp2 <- compartment(species(model(sbml))[[names(gsc)[iMet]]])
                names(gsc)[iMet] <- paste(tmp1, " (", tmp2, ")", 
                  sep = "")
            }
        }
    }
    else if (type == "sif") {
        tmp <- try(gsc <- as.data.frame(read.delim(file, header = FALSE, 
            quote = "", as.is = TRUE), stringsAsFactors = FALSE), 
            silent = TRUE)
        if (class(tmp) == "try-error") {
            stop("argument file could not be read and converted into a data.frame")
        }
        if (ncol(gsc) != 3) {
            stop("sif file should contain three columns")
        }
        if (addUserInfo == "skip") 
            addInfo <- gsc[, c(1, 2)]
        gsc <- gsc[, c(3, 1)]
        tmp <- nrow(gsc)
        gsc <- unique(gsc)
        geneSets <- unique(gsc[, 2])
        gscList <- list()
        for (iGeneSet in 1:length(geneSets)) {
            gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                1]
        }
        names(gscList) <- geneSets
        gsc <- gscList
    }
    else if (type == "data.frame") {
        tmp <- try(gsc <- as.data.frame(file, stringsAsFactors = FALSE), 
            silent = TRUE)
        if (class(tmp) == "try-error") {
            stop("argument file could not be converted into a data.frame")
        }
        for (i in 1:ncol(gsc)) {
            gsc[, i] <- as.character(gsc[, i])
        }
        if (ncol(gsc) != 2) {
            stop("argument file has to contain exactly two columns")
        }
        tmp <- nrow(gsc)
        gsc <- unique(gsc)
        geneSets <- unique(gsc[, 2])
        gscList <- list()
        for (iGeneSet in 1:length(geneSets)) {
            gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                1]
        }
        names(gscList) <- geneSets
        gsc <- gscList
    }
    if (addUserInfo == "yes") {
        tmp <- try(addInfo <- as.data.frame(addInfo, stringsAsFactors = FALSE), 
            silent = TRUE)
        if (class(tmp) == "try-error") {
            stop("failed to convert additional info in argument 'addInfo' into a data.frame")
        }
    }
    if (class(addInfo) == "data.frame") {
        if (ncol(addInfo) != 2) 
            stop("additional info in argument 'file' or 'addInfo' has to contain 2 columns")
        tmp <- nrow(addInfo)
        addInfo <- unique(addInfo[addInfo[, 1] %in% names(gsc), 
            ])
    }
    else {
    }
    res <- list(gsc, addInfo)
    names(res) <- c("gsc", "addInfo")
    class(res) <- "GSC"
    return(res)
}

collect_gsa_hyper_results <- 
function (cds, gsc, clusters)
{
    gene_universe <- unique(as.character(fData(cds)$gene_short_name))
    gsa_results <- list()
    for (i in (1:max(clusters))) {
        cluster_genes <- unique(names(clusters[clusters == i]))
        gsaRes <- runGSAhyper(cluster_genes, gsc = gsc, universe = gene_universe)
        gsa_results[[length(gsa_results) + 1]] <- gsaRes
    }
    save(gsa_results, file = "gsa_results")
    names(gsa_results) <- 1:max(clusters)
    gsa_results
}

plot_gsa_hyper_heatmap <- function (cds, gsa_results, significance = 0.05, sign_type = "qval")
{
    hyper_df <- ldply(gsa_results, function(gsa_res) {
        data.frame(gene_set = names(gsa_res$pvalues), 
                   pval = gsa_res$pvalues,
                   qval = gsa_res$p.adj)
    })
    colnames(hyper_df)[1] <- "cluster_id"
    hyper_df$qval <- p.adjust(hyper_df$pval, method = "fdr")
    hyper_df <- subset(hyper_df, hyper_df[, sign_type] <= significance)
    hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set),
                                      function(x) {
                                          nrow(x)
                                      }), by = "gene_set")
    save(hyper_df, file = "hyper_df")
    hyper_df$gene_set <- factor(hyper_df$gene_set, levels = unique(arrange(hyper_df,
                                                                           V1, 
                                                                           cluster_id)$gene_set))
    qplot(cluster_id, gene_set, fill = -log10(qval), geom = "tile",
          data = hyper_df) + 
    scale_fill_gradientn(colours = rainbow(7))
}

# Load GO terms: molecular function (mf), cellular component (cc), biological process (bp)
go_mf_gsc <- loadGSCSafe("./GO_Term_Files_From_Trapnell_Dropbox/MOUSE_GO_mf_with_GO_iea_symbol.gmt")
names(go_mf_gsc$gsc) <- str_split_fixed(names(go_mf_gsc$gsc), "%", 2)[,1]
go_cc_gsc <- loadGSCSafe("./GO_Term_Files_From_Trapnell_Dropbox/MOUSE_GO_cc_with_GO_iea_symbol.gmt")
names(go_cc_gsc$gsc) <- str_split_fixed(names(go_cc_gsc$gsc), "%", 2)[,1]
go_bp_gsc <- loadGSCSafe("./GO_Term_Files_From_Trapnell_Dropbox/MOUSE_GO_bp_with_GO_iea_symbol.gmt")
names(go_bp_gsc$gsc) <- str_split_fixed(names(go_bp_gsc$gsc), "%", 2)[,1]
# Load reactome pathways
mouse_reactome_gsc <- loadGSCSafe("./GO_Term_Files_From_Trapnell_Dropbox/Mouse_Reactome_June_20_2014_symbol.gmt", 
                                  encoding="latin1")
names(mouse_reactome_gsc$gsc) <- str_split_fixed(names(mouse_reactome_gsc$gsc), "%", 2)[,1]

# GO term analysis for alpha heatmap
cluster_for_GO1 <- clusters_table1$cluster_number
names(cluster_for_GO1) <- clusters_table1$gene_short_name
# 1. Reactome pathway
heatmap_alpha_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO1)
pdf("heatmap_alpha_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_alpha_reactome, significance=1e-1)
dev.off()
# 2. GO biological process
heatmap_alpha_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO1)
pdf("heatmap_alpha_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_alpha_GObp, significance=1e-1)
dev.off()

# GO term analysis for beta heatmap
cluster_for_GO2 <- clusters_table2$cluster_number
names(cluster_for_GO2) <- clusters_table2$gene_short_name
# 1. Reactome pathway
heatmap_beta_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO2)
pdf("heatmap_beta_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_beta_reactome, significance=1e-1)
dev.off()
# 2. GO biological process
heatmap_beta_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO2)
pdf("heatmap_beta_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_beta_GObp, significance=1e-1)
dev.off()

# GO term analysis for epsilon heatmap
cluster_for_GO3 <- clusters_table3$cluster_number
names(cluster_for_GO3) <- clusters_table3$gene_short_name
# 1. Reactome pathway
heatmap_epsilon_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO3)
pdf("heatmap_epsilon_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_epsilon_reactome, significance=1e-1)
dev.off()
# 2. GO biological process
heatmap_epsilon_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO3)
pdf("heatmap_epsilon_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_epsilon_GObp, significance=1e-1)
dev.off()

# GO term analysis for alpha/beta branched heatmap
cluster_for_GO4 <- clusters_table4$cluster_number
names(cluster_for_GO4) <- clusters_table4$gene_short_name
# 1. Reactome pathway
branched_heatmap_alpha_beta_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO4)
pdf("branched_heatmap_alpha_beta_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_alpha_beta_reactome, 
                       significance=1e-1)
dev.off()
# 2. GO biological process
branched_heatmap_alpha_beta_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO4)
pdf("branched_heatmap_alpha_beta_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_alpha_beta_GObp, 
                       significance=1e-1)
dev.off()

# GO term analysis for alpha/epsilon branched heatmap
cluster_for_GO5 <- clusters_table5$cluster_number
names(cluster_for_GO5) <- clusters_table5$gene_short_name
# 1. Reactome pathway
branched_heatmap_alpha_epsilon_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO5)
pdf("branched_heatmap_alpha_epsilon_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_alpha_epsilon_reactome, 
                       significance=1e-1)
dev.off()
# 2. GO biological process
branched_heatmap_alpha_epsilon_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO5)
pdf("branched_heatmap_alpha_epsilon_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_alpha_epsilon_GObp, 
                       significance=1e-1)
dev.off()

# GO term analysis for beta/epsilon branched heatmap
cluster_for_GO6 <- clusters_table6$cluster_number
names(cluster_for_GO6) <- clusters_table6$gene_short_name
# 1. Reactome pathway
branched_heatmap_beta_epsilon_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO6)
pdf("branched_heatmap_beta_epsilon_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_beta_epsilon_reactome, 
                       significance=1e-1)
dev.off()
# 2. GO biological process
branched_heatmap_beta_epsilon_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO6)
pdf("branched_heatmap_beta_epsilon_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, branched_heatmap_beta_epsilon_GObp, 
                       significance=1e-1)
dev.off()

# GO term analysis for 3-branch heatmap
cluster_for_GO7 <- clusters_table7$cluster_number
names(cluster_for_GO7) <- clusters_table7$gene_short_name
# 1. Reactome pathway
heatmap_alpha_beta_epsilon_reactome <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         mouse_reactome_gsc, 
                                                         cluster_for_GO7)
pdf("heatmap_alpha_beta_epsilon_reactome.pdf", height=48, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_alpha_beta_epsilon_reactome, 
                       significance=1e-1)
dev.off()
# 2. GO biological process
heatmap_alpha_beta_epsilon_GObp <- collect_gsa_hyper_results(panc_cds_valid_cells, 
                                                         go_bp_gsc, 
                                                         cluster_for_GO7)
pdf("heatmap_alpha_beta_epsilon_GObp.pdf", height=80, width=16)
plot_gsa_hyper_heatmap(panc_cds_valid_cells, heatmap_alpha_beta_epsilon_GObp, 
                       significance=1e-1)
dev.off()

# Save workspace
save.image(file = 'pancreas_5B.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_5B.RData')
ls()

# TEMP: Genes that are downregulated on all 3 branches
genes_of_interest3 <- c("Vim","Pax4","Ins1")
#c("Vim","Stmn1","Smox","Hpcal1","Pax4","Mgst1","Hilpa","Nde1","Gulo","Tpcn2")
pdf("pax4_alpha_beta_epsilon.pdf")
plot_genes_in_pseudotime2(panc_cds_alpha_progenitors[row.names(subset(fData(panc_cds), 
                                                                      gene_short_name %in% genes_of_interest3)),], 
                          color_by = "Time", panel_order = genes_of_interest3)
plot_genes_in_pseudotime2(panc_cds_beta_progenitors[row.names(subset(fData(panc_cds), 
                                                                     gene_short_name %in% genes_of_interest3)),], 
                          color_by = "Time", panel_order = genes_of_interest3)
plot_genes_in_pseudotime2(panc_cds_epsilon_progenitors[row.names(subset(fData(panc_cds), 
                                                                        gene_short_name %in% genes_of_interest3)),], 
                          color_by = "Time", panel_order = genes_of_interest3)
dev.off()

# Genes that correlate with vimentin expression
Vim_id <- row.names(fData(panc_cds_valid_cells)[(fData(panc_cds_valid_cells)$gene_short_name == "Vim"),])
pData(panc_cds_valid_cells)$Vim_Exprs <- exprs(panc_cds_valid_cells)[Vim_id,]
head(pData(panc_cds_valid_cells),3)

DiffGenes_Vim <- differentialGeneTest(panc_cds_valid_cells[genes_to_test,],
                                      fullModelFormulaStr = "~Vim_Exprs",# + Total_mRNAs + Time", 
#                                      reducedModelFormulaStr = "~Total_mRNAs + Time",
                                      cores=32, verbose=T)

vim_correlated_genes <- row.names(subset(DiffGenes_Vim, qval<0.01))
vim_correlated_genes_table <- DiffGenes_Vim[vim_correlated_genes, c("gene_short_name", "gene_id", "qval", "pval")]
row.names(vim_correlated_genes_table) <- NULL
vim_correlated_genes_table <- vim_correlated_genes_table[order(vim_correlated_genes_table$qval),]
dim(vim_correlated_genes_table)
head(vim_correlated_genes_table, 20)
write.table(vim_correlated_genes_table, "Vimentin_Correlated_Genes_table.txt", quote=F, sep="\t", row.names=F, col.names=T)

return_heatmap_matrix_of_plot_pseudotime_heatmap_cbind3 <- function(cds_subset1, cds_subset2, cds_subset3, 

                                    norm_method = c("vstExprs", "log"), 
                                    scale_max=3, 
                                    scale_min=-3, 
                                    
                                    trend_formula = '~sm.ns(Pseudotime, df=3)',
                                    
                                    cores=1){
  
  newdata1 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset1)$Pseudotime),length.out = 100)) 
  
  m1 <- genSmoothCurves(cds_subset1, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata1)

  newdata2 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset2)$Pseudotime),length.out = 100)) 
  
  m2 <- genSmoothCurves(cds_subset2, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata2)
  
  newdata3 <- data.frame(Pseudotime = seq(0, max(pData(cds_subset3)$Pseudotime),length.out = 100)) 
  
  m3 <- genSmoothCurves(cds_subset3, cores=cores, trend_formula = trend_formula,  
                       relative_expr = T, new_data = newdata3)

  m <- cbind(m1, m2, m3)

  #remove genes with no expression in any condition
  m=m[!apply(m,1,sum)==0,]
  
  norm_method <- match.arg(norm_method)
  
  # FIXME: this needs to check that vst values can even be computed. (They can only be if we're using NB as the expressionFamily)
  if(norm_method == 'vstExprs' && is.null(cds_subset1@dispFitInfo[["blind"]]$disp_func) == FALSE) {
    m = vstExprs(cds_subset1, expr_matrix=m)
  }     
  else if(norm_method == 'log') {
    m = log10(m+pseudocount)
  }
  
  # Row-center the data.
  m=m[!apply(m,1,sd)==0,]
  m=Matrix::t(scale(Matrix::t(m),center=TRUE))
  m=m[is.na(row.names(m)) == FALSE,]
  m[is.nan(m)] = 0
  m[m>scale_max] = scale_max
  m[m<scale_min] = scale_min

  m  
}

heatmap_matrix_vim_cor <- return_heatmap_matrix_of_plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[vim_correlated_genes,],
                                                                                  panc_cds_beta_progenitors[vim_correlated_genes,],
                                                                                  panc_cds_epsilon_progenitors[vim_correlated_genes,])

dim(heatmap_matrix_vim_cor)
colnames(heatmap_matrix_vim_cor) <- 1:300
heatmap_matrix_vim_cor[1:2,197:203]
Vim_id

correlation_coeff <- cor(heatmap_matrix_vim_cor["ENSMUSG00000026728.4",],t(heatmap_matrix_vim_cor[1:77,]))
length(correlation_coeff)
head(correlation_coeff)

vim_cor <- cbind(heatmap_matrix_vim_cor, t(correlation_coeff))
vim_cor <- cbind(vim_cor, fData(panc_cds_valid_cells)[vim_correlated_genes,3:4])
vim_cor <- vim_cor[,c(303,301)]
colnames(vim_cor) <- c("gene_short_name", "pearson_corr_coeff")
vim_cor <- vim_cor[order(-vim_cor$pearson_corr_coeff),]
dim(vim_cor)
vim_cor[row.names(subset(vim_cor, pearson_corr_coeff>=0.5)),]

top_vim_correlated_genes <- row.names(subset(vim_cor, pearson_corr_coeff>=0.5))
length(top_vim_correlated_genes)

pdf("heatmap_alpha_beta_epsilon_top_vim_correlated_genes.pdf", width=10, height=3)
plot_pseudotime_heatmap_cbind3(panc_cds_alpha_progenitors[top_vim_correlated_genes,],
                               panc_cds_beta_progenitors[top_vim_correlated_genes,],
                               panc_cds_epsilon_progenitors[top_vim_correlated_genes,],
                               num_clusters = 1, cores = 1, show_rownames = T, return_heatmap = F)
dev.off()

# Save workspace
save.image(file = 'pancreas_5C.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_5C.RData')
ls()

# Cell trajectory plots Ngn3+ Arx+ vs. Arx-
pdf("cell_trajectories_ngn3_vs_arx.pdf")
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="CellType") + facet_wrap(~CellType_Ngn3_Arx)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="CellType_Ngn3_Arx") + facet_wrap(~CellType_Ngn3_Arx)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="Time") + facet_wrap(~CellType_Ngn3_Arx)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="Pseudotime") + facet_wrap(~CellType_Ngn3_Arx)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="CellType_Ngn3_Arx") + facet_wrap(~CellType)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="CellType_Ngn3_Arx") + facet_wrap(~Time)
plot_cell_trajectory(panc_cds_valid_cells, x = 1, y = 2, color_by="CellType_Ngn3_Arx") + facet_wrap(~State)
dev.off()

# Subset CDS for protein-coding genes and Ngn3+ cells
genes_to_test_Ngn3_Arx <- row.names(subset(fData(panc_cds_valid_cells), biotype %in% c("protein_coding")))
cells_to_test_Ngn3_Arx <- row.names(subset(pData(panc_cds_valid_cells), CellType_Ngn3_Arx %in% c("Ngn3+ Arx-", "Ngn3+ Arx+")))
cds_subset_Ngn3_Arx <- panc_cds_valid_cells[genes_to_test, cells_to_test_Ngn3_Arx]
dim(cds_subset_Ngn3_Arx)

# Differential Gene Test; subtracting effect of time
diff_Ngn3_Arx <- differentialGeneTest(cds_subset_Ngn3_Arx, 
                                      fullModelFormulaStr = "~CellType_Ngn3_Arx + Time",
                                      reducedModelFormulaStr = "~Time",
                                      cores = 32,
                                      verbose = T)

sig_genes_Ngn3_Arx <- row.names(subset(diff_Ngn3_Arx, qval <0.1))
cds_subset_Ngn3_Arx_signif <- cds_subset_Ngn3_Arx[sig_genes_Ngn3_Arx,]
dim(cds_subset_Ngn3_Arx_signif)

# Table with significantly differentially expressed genes Ngn3+ Arx+ vs. Arx-
sig_genes_Ngn3_Arx_table <- data.frame(diff_Ngn3_Arx[sig_genes_Ngn3_Arx, c("gene_short_name", "qval", "pval")])
sig_genes_Ngn3_Arx_table <- sig_genes_Ngn3_Arx_table[order(sig_genes_Ngn3_Arx_table[,1]),]
write.table(sig_genes_Ngn3_Arx_table, "sig_genes_Ngn3_Arx.txt", row.names=F, col.names=T, quote=F, sep="\t")

# Subset CDS into its 3 components
exprs_Ngn3_Arx_signif <- exprs(cds_subset_Ngn3_Arx_signif)
pData_Ngn3_Arx_signif <- pData(cds_subset_Ngn3_Arx_signif)
fData_Ngn3_Arx_signif <- fData(cds_subset_Ngn3_Arx_signif)

# Replace gene_id as row names by gene_short_name in exprs_Ngn3_Arx_signif
fData_Ngn3_Arx_signif <- fData_Ngn3_Arx_signif[,4, drop=F]
exprs_Ngn3_Arx_signif <- cbind(fData_Ngn3_Arx_signif, exprs_Ngn3_Arx_signif)
row.names(exprs_Ngn3_Arx_signif) <- exprs_Ngn3_Arx_signif$gene_short_name
exprs_Ngn3_Arx_signif <- exprs_Ngn3_Arx_signif[,-1]
exprs_Ngn3_Arx_signif <- exprs_Ngn3_Arx_signif[order(row.names(exprs_Ngn3_Arx_signif)),]
dim(exprs_Ngn3_Arx_signif)
head(exprs_Ngn3_Arx_signif)

# Include CellType_Ngn3_Arx in exprs_Ngn3_Arx_signif
pData_Ngn3_Arx_signif <- pData_Ngn3_Arx_signif[,"CellType_Ngn3_Arx", drop=F]
exprs_Ngn3_Arx_signif <- data.frame(t(exprs_Ngn3_Arx_signif))
exprs_Ngn3_Arx_signif <- cbind(pData_Ngn3_Arx_signif, exprs_Ngn3_Arx_signif)
dim(exprs_Ngn3_Arx_signif)
head(exprs_Ngn3_Arx_signif)

# Sample boxplot
#ggplot(exprs_Ngn3_Arx_signif, aes(x = CellType_Ngn3_Arx, y = Cox5a))+
#geom_boxplot()#+
#scale_y_log10()

# Melt dataframe
exprs_Ngn3_Arx_signif_melted <- melt(exprs_Ngn3_Arx_signif)
head(exprs_Ngn3_Arx_signif_melted)
summary(exprs_Ngn3_Arx_signif_melted)

# Make boxplots with all melted data. 
pdf("Ngn3_Arx_Signif_Boxplots.pdf", width=20, height=40)
ggplot(exprs_Ngn3_Arx_signif_melted, aes(x = CellType_Ngn3_Arx, y = value))+
geom_boxplot()+
#scale_y_log10()+
facet_wrap(~variable, scale="free_y")
dev.off()

# Same but with log scaling the y axis which improves readability. However, one problem is that log 0 is infinite so the 0s get excluded.
pdf("Ngn3_Arx_Signif_Boxplots_log.pdf", width=20, height=40)
ggplot(exprs_Ngn3_Arx_signif_melted, aes(x = CellType_Ngn3_Arx, y = value))+
geom_boxplot()+
scale_y_log10()+
facet_wrap(~variable, scale="free_y")
dev.off()

# Make violin plots with all melted data
# However, if all the values are the same the smoother returns an empty plot! So boxplots are probably better!
pdf("Ngn3_Arx_Signif_Violinplots_log.pdf", width=20, height=40)
ggplot(exprs_Ngn3_Arx_signif_melted, aes(x = CellType_Ngn3_Arx, y = value))+
geom_violin()+
scale_y_log10()+
facet_wrap(~variable, scale="free_y")
dev.off()

# Make gene jitter plots with the CDS (no need for transforming the CDS into a dataframe)
pdf("Ngn3_Arx_Signif_Jitterplots.pdf", width=5, height=250)
plot_genes_jitter(cds_subset_Ngn3_Arx_signif, grouping = "CellType_Ngn3_Arx", plot_trend = T)
dev.off()

# Subset Ngn3+ Arx- vs. Arx+
exprs_Arx_neg <- subset(exprs_Ngn3_Arx_signif, CellType_Ngn3_Arx == "Ngn3+ Arx-")
exprs_Arx_pos <- subset(exprs_Ngn3_Arx_signif, CellType_Ngn3_Arx == "Ngn3+ Arx+")
dim(exprs_Arx_neg)
dim(exprs_Arx_pos)

# Dataframe/table with mean expression values between differentially expressed genes Ngn3+ Arx+ vs. Arx-
means_arx_neg <- colMeans(exprs_Arx_neg[,-1])
means_arx_pos <- colMeans(exprs_Arx_pos[,-1])
means_Ngn3_Arx <- data.frame(means_arx_neg, means_arx_pos)
means_Ngn3_Arx <- round(means_Ngn3_Arx, digits = 2)
means_Ngn3_Arx <- cbind(gene_short_name = rownames(means_Ngn3_Arx), means_Ngn3_Arx)
colnames(means_Ngn3_Arx) <- c("Gene Short Name", "Ngn3+ Arx-", "Ngn3+ Arx+")
rownames(means_Ngn3_Arx) <- NULL
head(means_Ngn3_Arx)
write.table(means_Ngn3_Arx, "Rel_Exprs_Means_Ngn3_Arx_Sign.txt", row.names=F, col.names=T, quote=F, sep="\t")

# Save workspace
save.image(file = 'pancreas_6.RData')

# Load packages & set theme for ggplot2
library(monocle)
library(stringr)
library(piano)
library(reshape2)
library(plyr)
library(colorRamps)
library(pheatmap)
theme_set(theme_bw(base_size=10))
time_colors = c("#D7191C", "#FDAE61", "#2C7BB6")
# Load workspace & check whether/what objects have been loaded
load('pancreas_6.RData')
ls()

# TEMP
dim(panc_cds_valid_cells)
head(pData(panc_cds_valid_cells))
count(pData(panc_cds_valid_cells)$State)

# TEMP
# Differential Gene Test: by State, subtracting effect of Time and CellType
diff_state <- differentialGeneTest(panc_cds_valid_cells[genes_to_test,],
                                   fullModelFormulaStr = "~State + Time + CellType",
                                   reducedModelFormulaStr = "~Time + CellType",
                                   cores=32,
                                   verbose=T)

# TEMP
dim(diff_state)
head(diff_state)

# TEMP
length(row.names(subset(diff_state, qval <0.01)))

# TEMP: Subset alpha/beta states (4&1)
cells_states_1_4 <- row.names(subset(pData(panc_cds_valid_cells), State %in% c("1", "4")))
cds_states_1_4 <- panc_cds_valid_cells[,cells_states_1_4]
dim(cds_states_1_4)

# TEMP
# Differential Gene Test (states 1 vs. 4): by State, subtracting effect of Time and CellType
diff_state_1_4 <- differentialGeneTest(cds_states_1_4[genes_to_test,],
                                   fullModelFormulaStr = "~State + Time + CellType",
                                   reducedModelFormulaStr = "~Time + CellType",
                                   cores=32,
                                   verbose=T)

dim(diff_state_1_4)
length(row.names(subset(diff_state_1_4, qval <0.01)))

sig_genes_1_4 <- row.names(subset(diff_state_1_4, qval <0.01))

pdf("jitter_plot_states_alpha_vs_beta.pdf", height=80, width=3)
plot_genes_jitter(cds_states_1_4[row.names(subset(fData(panc_cds_valid_cells), 
                                                  gene_id %in% sig_genes_1_4)),], 
                  grouping="State")
dev.off()

head(sig_genes_1_4)

# Save workspace
save.image(file = 'pancreas_7.RData')








