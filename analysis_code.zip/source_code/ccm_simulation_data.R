#test rDEM on the simulated dataset: 
rm(list = ls())
source('./function.R')

#test rEDM (ccm algortihm for inferring gene regulatory network)
library(rEDM)
library(monocle)
library(xlsx)
library(xacHelper)
library(reshape2)
library(pheatmap)
library(R.matlab)

cell_simulate <- readMat('/Users/xqiu/Documents/MATLAB/cell_simulate.mat')
test_sim_mat <- t(cell_simulate$cell.simulate[, , 1])
colnames(test_sim_mat) <-  c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')
neuron_simulation_parallel_res <- parallelCCM(ordered_exprs_mat =test_sim_mat , cores = detectCores())

neuron_simulation_parallel_res <- parallelCCM(ordered_exprs_mat =test_sim_mat[300:2001, ] , cores = detectCores())

parallel_res_mat2 <- prepare_ccm_res(neuron_simulation_parallel_res)

# pdf('abs_ccm.pdf', width = 30, height = 30)
pheatmap(parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T)
# dev.off()

parallel_res_mat2 <- prepare_ccm_res(neuron_simulation_parallel_res)
pheatmap(parallel_res_mat2[, ], useRaster = T, cluster_cols = T, cluster_rows = T)
