########################################################################################################################################################################
# 1. implement the idea to detect causality based dy instead of y 

########################################################################################################################################################################

library(lmtest)
library(rEDM)
library(monocle)
library(destiny)
library(reshape2)
library(Scribe)
library(PRROC)
library(ROCR)
library(TransferEntropy)

source('~/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R', echo=TRUE)

#function to calculate correlation (pearson, spearman), granger, MI, CCM, RDI, cRDI 
# CCM
# row is cell; column is gene 
benchmark_all_estimators <- function(time_series, delays_vec = c(1, 11, 21), verbose = T) {
  if(verbose) {
    message('running Pearson correlation ...')
  }
  pearson_res <- cor(time_series)
  pearson_res[lower.tri(pearson_res)] <- 0
  
  if(verbose) {
    message('running Spearman correlation ...')
  }
  spearman_res <- cor(time_series, method = 'spearman')
  
  if(verbose) {
    message('running mutual information ...')
  }

  split(time_series, col(time_series, as.factor = T))
  mi_res <- matrix(1, nrow = ncol(time_series), ncol = ncol(time_series))
  combn_mat <- combn(1:ncol(time_series), 2)
  
  combn_mat_split <- split(t(combn_mat), 1:ncol(combn_mat))
  
  expr_data <- time_series
  combn_mat <- combn(1:ncol(expr_data), 2)
  combn_mat_split <- split(t(combn_mat), 1:ncol(combn_mat))
  
  mi_result <- mclapply(combn_mat_split, function(x, time_series, k = k) {
    col_names <- colnames(time_series)[x]
    mi(as.matrix(time_series[, col_names[1]], ncol = 1), 
       as.matrix(time_series[, col_names[1]], ncol = 1), 
       k = k, normalize = F)
  }, time_series = time_series, k = 5, mc.cores = detectCores() - 2)

  for(x in 1:length(combn_mat_split)) {
    mi_res[combn_mat_split[[x]][1], combn_mat_split[[x]][2]] <- mi_result[[x]]
  }
  
  # mi_res[lower.tri(mi_res)] <- mi_res[upper.tri(mi_res)] #symmetric 
  
  if(verbose) {
    message('running granger causality ...')
  }
  
  granger_res <- parallel_cal_grangertest(time_series[, ], cores =  detectCores() - 2, filename = 'all_linear_sim_granger_res.txt', delays = delays_vec)
  
  if(verbose) {
    message('running CCM ...')
  }
  ccm_parallel_res <- NA
  if(ncol(time_series) < 2000) {
    ccm_parallel_res <- parallelCCM(ordered_exprs_mat = time_series, cores = detectCores() - 2)
    ccm_parallel_res_mat <- prepare_ccm_res(ccm_parallel_res, colnames(time_series))
  } else {
    ccm_parallel_res_mat <- NA
  }
  
  n_genes <- ncol(time_series)
  tmp <- expand.grid(1:n_genes, 1:n_genes, stringsAsFactors = F)
  super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to c++ index
  
  if(verbose) {
    message('running RDI ...')
  }
  
  RDI_parallel_res <- calculate_rdi_cpp(expr_data = as.matrix(time_series), delays = 1, super_graph = as.matrix(super_graph), turning_points = 0, method = 1, uniformalize = F)
  
  if(verbose) {
    message('running conditional RDI ...')
  }
  cRDI_parallel_res <- calculate_conditioned_rdi_cpp_wrap(expr_data = as.matrix(time_series), super_graph = as.matrix(super_graph), 
                                                          max_rdi_value = RDI_parallel_res$max_rdi_value, max_rdi_delays = RDI_parallel_res$max_rdi_delays,
                                                          k = 1, uniformalize = F)
  
  # do dy analysis instead of y
  dy_res <- matrix(0, nrow = ncol(time_series), ncol = ncol(time_series))
  for(i in 1:nrow(super_graph)) {
    tmp <- calculate_rdi_cpp(expr_data = as.matrix(time_series)[, unlist(super_graph[i, ]) + 1], delays = 1, super_graph = matrix(c(0, 1), nrow = 1), 
                      turning_points = 0, method = 1, uniformalize = F)
    dy_res[super_graph[i, 1] + 1, super_graph[i, 2] + 1] <- tmp$max_rdi_value[1, 2]
  }
  
  # if(verbose) {
  #   message('running DI ...')
  # }
  # 
  # DI_parallel_res <- calculate_di(time_series[, unique(RDI_parallel_res$id_1)], delays = delays_vec, cores = detectCores() - 2, verbose = T)
  max_rdi_value <- RDI_parallel_res$max_rdi_value; dimnames(max_rdi_value) <- list(colnames(time_series), colnames(time_series))
  dimnames(cRDI_parallel_res) <- list(colnames(time_series), colnames(time_series))
  
  return(list(Pearson = pearson_res, Spearman = spearman_res, MI = mi_res, Granger = granger_res,
              CCM = ccm_parallel_res_mat, RDI = max_rdi_value, cRDI = cRDI_parallel_res, dy_rdi = dy_res)) # , DI_parallel_res = DI_parallel_res
}

# RDI
# test_res <- benchmark_all_estimators(time_series[, 1:5])
#
# GMP_branch <- expr_mat_norm[pData(new_cds)$State %in% c(2, 3, 5), ]
# CLP_branch <- expr_mat_norm[pData(new_cds)$State %in% c(2, 4, 5), ]
# preMegE_branch <- expr_mat_norm[pData(new_cds)$State %in% c(1, 5), ]
#
# GMP_branch_res <- benchmark_all_estimators(GMP_branch)
# CLP_branch_res <- benchmark_all_estimators(GMP_branch)
# preMegE_branch_res <- benchmark_all_estimators(GMP_branch)

# test on the neuron simulation dataset (use three cells only first):
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig3.RData')

# avoid duplicated cells
exprs(nao_sim_cds)[2, 401] <- 0.001
exprs(nao_sim_cds)[3, 801] <- 0.001

# nao_sim_cds <- reduceDimension(nao_sim_cds, max_components = 3, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F, auto_param_selection = F, initial_method = run_dpt, reduction_method = 'SimplePPT')
nao_sim_cds <- orderCells(nao_sim_cds)
plot_cell_trajectory(nao_sim_cds, color_by = 'State') + facet_wrap(~State)
plot_cell_trajectory(nao_sim_cds, x = 2, y = 3, color_by = 'State') + facet_wrap(~State)

nao_sim_cds <- orderCells(nao_sim_cds, root_state = 4)
dimnames(nao_exprs_mat) <- dimnames(nao_sim_cds)
nao_exprs_mat <- t(nao_exprs_mat)
neuron_branch <- nao_exprs_mat[pData(nao_sim_cds)$State %in% c(4, 3), ]
astrocyte_branch <- nao_exprs_mat[pData(nao_sim_cds)$State %in% c(4, 5), ]
oligodendrocyte_branch <- nao_exprs_mat[pData(nao_sim_cds)$State %in% c(4, 5), ]

neuron_branch_res <- benchmark_all_estimators(neuron_branch[1:200, ], delays_vec = 1)
astrocyte_branch_res <- benchmark_all_estimators(astrocyte_branch[1:200, ], delays_vec = 1)
oligodendrocyte_branch_res <- benchmark_all_estimators(oligodendrocyte_branch[1:200, ], delays_vec = 1)

all_branch_res <- benchmark_all_estimators(Reduce(rbind, list(neuron_branch[1:200, ], astrocyte_branch[1:200, ], oligodendrocyte_branch[1:200, ])), delays_vec = 1)

### increase the number of runs for each lineage 
# all_data_combined: select 5 clusters from each lineage group 

neuron_exprs_mat <- Reduce(cbind, list(as.matrix(all_cell_simulation[, 1:200, neuron_cell_ids[1]]),
                                       as.matrix(all_cell_simulation[, 1:200, neuron_cell_ids[2]]),
                                       as.matrix(all_cell_simulation[, 1:200, neuron_cell_ids[3]]),
                                       as.matrix(all_cell_simulation[, 1:200, neuron_cell_ids[4]]),
                                       as.matrix(all_cell_simulation[, 1:200, neuron_cell_ids[5]]))
                                       )
dimnames(neuron_exprs_mat) = list(gene_names, paste('Cell_', rep(1:1000, 1), sep = ''))

astrocyte_exprs_mat <- Reduce(cbind, list(as.matrix(all_cell_simulation[, 1:200, astrocyte_cell_ids[1]]),
                                          as.matrix(all_cell_simulation[, 1:200, astrocyte_cell_ids[2]]),
                                          as.matrix(all_cell_simulation[, 1:200, astrocyte_cell_ids[3]]),
                                          as.matrix(all_cell_simulation[, 1:200, astrocyte_cell_ids[4]]),
                                          as.matrix(all_cell_simulation[, 1:200, astrocyte_cell_ids[5]]))
                                          )
dimnames(astrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:1000, 1), sep = ''))

oligodendrocyte_exprs_mat <-  Reduce(cbind, list(as.matrix(all_cell_simulation[, 1:200, oligodendrocyte_cell_ids[1]]),
                                                 as.matrix(all_cell_simulation[, 1:200, oligodendrocyte_cell_ids[2]]),
                                                 as.matrix(all_cell_simulation[, 1:200, oligodendrocyte_cell_ids[3]]),
                                                 as.matrix(all_cell_simulation[, 1:200, oligodendrocyte_cell_ids[4]]),
                                                 as.matrix(all_cell_simulation[, 1:200, oligodendrocyte_cell_ids[5]]))
)
dimnames(oligodendrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:1000, 1), sep = ''))

all_branch_res <- benchmark_all_estimators(t(Reduce(cbind, list(neuron_exprs_mat[, 1:1000], astrocyte_exprs_mat[, 1:1000], oligodendrocyte_exprs_mat[, 1:1000]))), delays_vec = 1)

save(neuron_branch, astrocyte_branch, oligodendrocyte_branch, file = './RData/simulation_data.RData')

# neuron_branch_res$CCM_res <- prepare_ccm_res(neuron_branch_res$CCM)
# astrocyte_branch_res$CCM_res <- prepare_ccm_res(astrocyte_branch_res$CCM)
# oligodendrocyte_branch_res$CCM_res <- prepare_ccm_res(oligodendrocyte_branch_res$CCM)

########################################################################################################################################################################
# make AUC curves, etc.
########################################################################################################################################################################

# reference network:
neuron_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/neuron_simulation_network.txt', header = F)

gene_uniq <- unique(row.names(neuron_branch_res$Pearson))
all_cmbns <- expand.grid(gene_uniq, gene_uniq)
valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
valid_all_cmbns_df[paste(tolower(neuron_network$V1), tolower(neuron_network$V2), sep = '_'), 2] <- 1

########################################################################################################################################################################
process_data <- function(benchmark_res) {
  gene_uniq <- unique(row.names(benchmark_res$Pearson))
  all_cmbns <- expand.grid(gene_uniq, gene_uniq)
  valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
  all_valid_gene_pairs <- paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_')

  mlt_pearson_benchmark_res <- melt(benchmark_res$Pearson)
  row.names(mlt_pearson_benchmark_res) <- paste(tolower(mlt_pearson_benchmark_res$Var1), tolower(mlt_pearson_benchmark_res$Var2), sep = '_')

  mlt_spearman_benchmark_res <- melt(benchmark_res$Spearman)
  row.names(mlt_spearman_benchmark_res) <-  paste(tolower(mlt_spearman_benchmark_res$Var1), tolower(mlt_spearman_benchmark_res$Var2), sep = '_')

  mlt_mi_benchmark_res <- melt(benchmark_res$MI)
  row.names(mlt_mi_benchmark_res) <- row.names(mlt_spearman_benchmark_res)

  granger_res <- do.call(rbind.data.frame, neuron_branch_res$Granger)
  row.names(granger_res) <- paste(tolower(granger_res$Gene_1_ID), tolower(granger_res$Gene_2_ID), sep = '_')

  mlt_ccm_benchmark_res <- melt(as.matrix(benchmark_res$CCM))
  row.names(mlt_ccm_benchmark_res) <- paste(tolower(mlt_ccm_benchmark_res$Var2), tolower(mlt_ccm_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X

  mlt_RDI_benchmark_res <- melt(as.matrix(benchmark_res$RDI))
  row.names(mlt_RDI_benchmark_res) <-  paste(tolower(mlt_RDI_benchmark_res$Var2), tolower(mlt_RDI_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X
  
  mlt_cRDI_benchmark_res <- melt(as.matrix(benchmark_res$cRDI))
  row.names(mlt_cRDI_benchmark_res) <-  paste(tolower(mlt_cRDI_benchmark_res$Var2), tolower(mlt_cRDI_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X

  # rdi_benchmark_res <- data.frame(value = apply(benchmark_res$RDI, 1, function(x) max(x[3:(length(x) - 1)])))
  # row.names(rdi_benchmark_res) <- tolower(row.names(rdi_benchmark_res))
  # 
  # crdi_benchmark_res <- data.frame(value = apply(benchmark_res$cRDI, 1, function(x) max(x[3:(length(x) - 1)])))
  # row.names(crdi_benchmark_res) <- tolower(row.names(crdi_benchmark_res))
  # 
  # di_benchmark_res <- data.frame(value = benchmark_res$DI_parallel_res[, 3])
  # row.names(di_benchmark_res) <- tolower(row.names(crdi_benchmark_res))
  
  a_mlt_RDI_benchmark_res <- melt(as.matrix(a_RDI))
  row.names(a_mlt_RDI_benchmark_res) <-  paste(tolower(a_mlt_RDI_benchmark_res$Var2), tolower(a_mlt_RDI_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X
  a_mlt_cRDI_benchmark_res <- melt(as.matrix(a_cRDI))
  row.names(a_mlt_cRDI_benchmark_res) <-  paste(tolower(a_mlt_cRDI_benchmark_res$Var2), tolower(a_mlt_cRDI_benchmark_res$Var1), sep = '_') #x xmap y: y is the casual soure or Y regulates X
  
  network_result_df <- data.frame(Pearson = mlt_pearson_benchmark_res[all_valid_gene_pairs, 'value'],
                         Spearman = mlt_spearman_benchmark_res[all_valid_gene_pairs, 'value'],
                         MI = mlt_mi_benchmark_res[all_valid_gene_pairs, 'value'],
                         Granger = granger_res[all_valid_gene_pairs, 'granger'],
                         CCM = mlt_ccm_benchmark_res[all_valid_gene_pairs, 'value'],
                         RDI = as.numeric(as.character(mlt_RDI_benchmark_res[all_valid_gene_pairs, "value"])),
                         cRDI = as.numeric(as.character(mlt_cRDI_benchmark_res[all_valid_gene_pairs, "value"])),
                         aRDI = as.numeric(as.character(a_mlt_RDI_benchmark_res[all_valid_gene_pairs, "value"])),
                         a_cRDI = as.numeric(as.character(a_mlt_cRDI_benchmark_res[all_valid_gene_pairs, "value"]))
                         )
}

neuron_network_result_df <- process_data(neuron_branch_res)
astrocyte_network_result_df <- process_data(astrocyte_branch_res)
oligodendrocyte_network_result_df <- process_data(oligodendrocyte_branch_res)
all_branch_network_result_df <- process_data(all_branch_res)
  
network_result_df <-  neuron_network_result_df # oligodendrocyte_network_result_df # astrocyte_network_result_df # oligodendrocyte_network_result_df all_branch_network_result_df
#use the spike-in as the gold standard
reference_network_pvals <- valid_all_cmbns_df[, 2]
p_thrsld <- 0
rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- network_result_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)

########################################################################################################################################################################
# Calculate the PR curve (precision / recall curve)
########################################################################################################################################################################
generate_recall_precision_df <- function(p_value, classification, type = 'fpr') {
  pr <- pr.curve(scores.class0 = (p_value - min(p_value)) / (max(p_value) - min(p_value)), scores.class1 = classification, curve = T)

  data.frame(recall = pr$curve[, 1], precision = pr$curve[, 2], auc = pr[[2]])
}

rdi_recall_precision_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- network_result_df[, x]

  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  res <- generate_recall_precision_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('recall', 'precision', 'auc')
  cbind(res, method = x)
})

rdi_recall_precision_df_list <- lapply(rdi_recall_precision_df_list, function(x) {colnames(x) <- c('recall', 'precision', 'auc', 'method'); x} )
rdi_rec_prec_df <- do.call(rbind, rdi_recall_precision_df_list)

qplot(recall, precision, data= rdi_rec_prec_df, geom="step", color = method) + #linetype = Type,
  xlab("Recall") +
  ylab("Precision") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_rec_prec_df <- unique(rdi_rec_prec_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_rec_prec_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylab("AUC (precision / recall)") + ylim(0, 1)

########################################################################################################################################################################
# perform comparision with python implementation
########################################################################################################################################################################
test_data <- read.table('./csv_data/test_res.txt', header = T, row.names = 1)
a_RDI <- read.csv('/Users/xqiu/Downloads/rdi_results.csv', row.names = 1)
a_cRDI <- read.csv('/Users/xqiu/Downloads/crdi_results.csv', row.names = 1)

neuron_branch_res$RDI
t(a_RDI[row.names(neuron_branch_res$RDI), row.names(neuron_branch_res$RDI)])

# confirm the result from the Arman's result (all results are on the same scale)
test_res <- benchmark_all_estimators(t(test_data))
test_res$CCM_res <- prepare_ccm_res(test_res$CCM)

ccm_parallel_res <- parallelCCM(ordered_exprs_mat = t(test_data[, ]), cores = 1)
ccm_parallel_res_mat <- prepare_ccm_res(ccm_parallel_res)
ccm(ordered_exprs_mat, E = 2, random_libs = TRUE, lib_column = lib_colum, #ENSG00000122180.4
    target_column = target_column, lib_sizes = seq(10, 75, by = 5), num_samples = 300, RNGseed = RNGseed)
granger_res <- parallel_cal_grangertest(t(test_data[, ])[, ], cores =  1, filename = 'all_linear_sim_granger_res.txt', delays = c(1, 2, 3))

# check the result: 
a_RDI[colnames(a_RDI), ] - neuron_branch_res$RDI[c("Aldh1L", "Brn2",   "Hes5",   "Pax6",   "Mature", "Myt1L",  "Olig2",  "Mash1",   "Scl",    "Sox8",   "Stat3",  "Tuj1",   "Zic1")  
                                                 , c("Aldh1L", "Brn2",   "Hes5",   "Pax6",   "Mature", "Myt1L",  "Olig2",  "Mash1",   "Scl",    "Sox8",   "Stat3",  "Tuj1",   "Zic1")]

########################################################################################################################################################################
# save the result 
########################################################################################################################################################################
save.image('./RData/all_estimators.RData')


