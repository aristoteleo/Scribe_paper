# functions to extract the module and motif inside of the reconstructed network 

# build a network
load('./RData/analysis_scRNA_seq_Olsson.RData')
load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res") #load the res (we need to mannually set the initial_nodes 1:2 in .process_graph1 function)
gene_list <- names(V(res$g))

source('./Scripts/function.R', echo = T)

colnames(URMM_all_fig1b)[which.min(pData(URMM_all_fig1b)$Pseudotime)]

which(colnames(Olsson_monocyte_cds) == 'Lsk.44')
which(colnames(Olsson_granulocyte_cds) == 'Lsk.44')

# monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
# monocyte_dpt_res <- just_DPT(monocyte_dm)
# granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
# granulocyte_dpt_res <- just_DPT(granulocyte_dm)
# 
Monocyte_data <- exprs(Olsson_monocyte_cds[names(V(res$g)), order(monocyte_dpt_res$DPT73)])
Granulocyte_data <- exprs(Olsson_granulocyte_cds[, order(granulocyte_dpt_res$DPT73)])

write.table(file = 'Monocyte_data.csv', as.matrix(Monocyte_data) , col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = 'fData.csv', fData(Olsson_monocyte_cds)[names(V(res$g)), ] , col.names = T, sep = '\t', row.names = T, quote = F)

RDI_parallel_res <- calculate_and_write_pairwise_dmi(t(Monocyte_data), cores = detectCores() - 2, verbose = T) #delays = c(10, 20, 30), 
Monocyte_cRDI_parallel_res <- calculate_and_write_pairwise_dmi_conditioned(t(Monocyte_data)[, unique(RDI_parallel_res$id_1)], RDI_parallel_res, cores = detectCores() - 2, k = 1, verbose = T)

# run CLR algorithm: 
gene_uniq <- unique(c(RDI_parallel_res$id_1, RDI_parallel_res$id_2))
rdi_mat <- matrix(rep(0, length(gene_uniq)^2), nrow = length(gene_uniq))
dimnames(rdi_mat) <- list(gene_uniq, gene_uniq)
crdi_mat <- rdi_mat 

for(i in 1:nrow(RDI_parallel_res)) rdi_mat[RDI_parallel_res[i, 1], RDI_parallel_res[i, 2]] <- RDI_parallel_res[i, 3]
for(i in 1:nrow(RDI_parallel_res)) crdi_mat[Monocyte_cRDI_parallel_res[i, 1], Monocyte_cRDI_parallel_res[i, 2]] <- Monocyte_cRDI_parallel_res[i, 3]
rdi_mat <- apply(rdi_mat, 1, function(x) (x - mean(x)) / sd(x) )
crdi_mat <- apply(crdi_mat, 1, function(x) (x - mean(x)) / sd(x) )

rdi_benchmark_res <- data.frame(value = apply(RDI_parallel_res, 1, function(x) max(x[3:(length(x) - 1)])))
row.names(rdi_benchmark_res) <- tolower(row.names(rdi_benchmark_res))

crdi_benchmark_res <- data.frame(value = apply(Monocyte_cRDI_parallel_res, 1, function(x) max(x[3:(length(x) - 1)])))
row.names(crdi_benchmark_res) <- tolower(row.names(crdi_benchmark_res))

test_res <- benchmark_all_estimators()
test_res$CCM_res <- prepare_ccm_res(test_res$CCM)

CCM_res <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/ccm_results_Olsson.txt', sep = '\t', header = 1, row.names = 1)
qplot(unlist(CCM_res))
CCM_res_process <- CCM_res
CCM_res_process[CCM_res < 0.1] <- 0
CCM_res_process[is.na(CCM_res_process)] <- 0

g1 <- graph_from_adjacency_matrix(as.matrix(CCM_res_process), mode = "directed", weighted = T)


rdi_mat[rdi_mat < 0] <- 0
g1 <- graph_from_adjacency_matrix(as.matrix(rdi_mat), mode = "directed", weighted = T)

crdi_mat[crdi_mat < 0] <- 0
g2 <- graph_from_adjacency_matrix(as.matrix(crdi_mat), mode = "directed", weighted = T)

pdf(paste('./Figures/main_figures/', 'fig_network.pdf', sep = ''), width = 12, height = 7)
plot(g1, layout = layout_as_tree(g1), vertex.label.cex  = 0.25, vertex.size = 4)
dev.off()

# identify the highly-represented network motif 
# use the FANMOD algorithm 

V(g1)$degree <- degree(g1, mode = 'out')

# plot using ggraph
ggraph(g1, layout = 'kk') + 
  geom_edge_fan(aes(alpha = ..index..), show.legend = FALSE) + 
  geom_node_point(aes(size = degree)) + 
  # facet_edges(~year) + 
  theme_graph(foreground = 'steelblue', fg_text_colour = 'white')

g2 <- graph_from_adjacency_matrix(as.matrix(crdi_mat), mode = "directed", weighted = T)
V(g2)$degree <- degree(g2, mode = 'out')
ggraph(g2, layout = 'kk') + 
  geom_edge_fan(aes(alpha = ..index..), show.legend = FALSE) + 
  geom_node_point(aes(size = degree)) + 
  # facet_edges(~year) + 
  theme_graph(foreground = 'steelblue', fg_text_colour = 'white')
# highschool# identify the hub genes, etc. 

igraph::motifs(g1)
igraph::motifs(g2)

