library(monocle)
library(stringr)
library(plyr)
library(Scribe)

# #analysis Johnathan suggested dataset: 
# 
# #1. Pancreas dataset 
# load('./RData/pancreas_4.RData')
# plot_cell_trajectory(panc_cds_valid_cells)
# plot_cell_trajectory(panc_cds_valid_cells, color_by = 'Pseudotime')
# plot_cell_trajectory(panc_cds_valid_cells, color_by = 'CellType')
# 
# recreate_cds <- function(cds) {
#   pd <- new("AnnotatedDataFrame", data = pData(cds))
#   fd <- new("AnnotatedDataFrame", data = fData(cds))
#   
#   new_cds <- newCellDataSet(as(as.matrix(cds), "sparseMatrix"),
#                             phenoData = pd,
#                             featureData = fd,
#                             expressionFamily=cds@expressionFamily,
#                             lowerDetectionLimit=cds@lowerDetectionLimit)
#   
#   new_cds <- estimateSizeFactors(new_cds)
#   new_cds <- estimateDispersions(new_cds)
#   new_cds
# }
# 
# panc_cds_valid_cells <- recreate_cds(panc_cds_valid_cells)
# panc_cds_valid_cells <- reduceDimension(panc_cds_valid_cells, max_components = 4, auto_param_selection = F, verbose = T)
# panc_cds_valid_cells <- orderCells(panc_cds_valid_cells)
# 
# plot_cell_trajectory(panc_cds_valid_cells)
# plot_cell_trajectory(panc_cds_valid_cells, color_by = 'Pseudotime')
# plot_cell_trajectory(panc_cds_valid_cells, color_by = 'CellType')
# 
# plot_cell_trajectory(panc_cds_valid_cells, color_by = 'State') + facet_wrap(~State)
# panc_cds_valid_cells <- orderCells(panc_cds_valid_cells, root_state = 8)
# 
# pancreas_network <- read.table('./csv_data/endocrine_progenitor_network', sep = '\t', header = T)
# adult_beta_network <- read.table('./csv_data/adule_beta_cell_network', sep = '\t', header = T)
# immature_beta_network <- read.table('./csv_data/immature_beta_cell_network', sep = '\t', header = T)
# 
# #check wether or not the gene list is included in the paper: 
# gene_pairs1 <- pancreas_network[, 2:3]
# gene_pairs2 <- adult_beta_network[, 2:3]
# gene_pairs3 <- immature_beta_network[, 2:3]
# 
# gene_list <- c(as.character(gene_pairs1$Source..regulates.), as.character(gene_pairs1$Target..regulated.),
#                as.character(gene_pairs2$Source..regulates.), as.character(gene_pairs2$Target..regulated.),
#                as.character(gene_pairs3$Source..regulates.), as.character(gene_pairs3$Target..regulated.))
# as.character(gene_list) %in% 
# fData(panc_cds_valid_cells)$gene_short_name
# 
# #gene missing
# unique(gene_list[!(as.character(gene_list) %in% fData(panc_cds_valid_cells)$gene_short_name)])
# # "Nkx2.2" "Nkx6.1" "Nkx6.2" "cMyc"   "Glut2"  "Dnmt1a" "NFATc1" "CcnA2"  "ChgA"   "ChgB"   "Ia2"    "Tnfa"
# 
# #updated: 
# # "Nkx2-2" "Nkx6-1" "Nkx6-2" "Myc"   "Slc2a2"  "Dnmt1" "Nfatc1" "Ccna2"  "Chga"   "Chgb"   "Ptprn"    "Tnf"  
# 
# c("Nkx2-2", "Nkx6-1", "Nkx6-2", "Myc", "Slc2a2", "Dnmt1", "Nfatc1", "Ccna2", "Chga", "Chgb", "Ptprn", "Tnf")
# #find the missing gene name and correct the gene regulatory network
# pancreas_network$Source..regulates. <- revalue(pancreas_network$Source..regulates., 
#                                                c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                  'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                  'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# pancreas_network$Target..regulated. <- revalue(pancreas_network$Target..regulated., 
#                                                c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                  'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                  'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# adult_beta_network$Source..regulates. <- revalue(adult_beta_network$Source..regulates., 
#                                                  c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                    'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                    'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# adult_beta_network$Target..regulated. <- revalue(adult_beta_network$Target..regulated., 
#                                                  c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                    'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                    'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# immature_beta_network$Source..regulates. <- revalue(immature_beta_network$Source..regulates., 
#                                                 c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                   'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                   'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# immature_beta_network$Target..regulated. <- revalue(immature_beta_network$Target..regulated., 
#                                                  c('Nkx2.2' = 'Nkx2-2', 'Nkx6.1' = "Nkx6-1", 'Nkx6.2' = 'Nkx6-2', 'cMyc' = 'Myc',
#                                                    'Glut2' = 'Slc2a2', 'Dnmt1a' = "Dnmt1", 'NFATc1' = 'Nfatc1', 'CcnA2' = 'Ccna2',
#                                                    'ChgA' = 'Chga', 'ChgB' = "Chgb", 'Ia2' = 'Ptprn', 'Tnfa' = 'Tnf'))
# gene_list_update <- c(as.character(immature_beta_network$Source..regulates.), as.character(immature_beta_network$Target..regulated.),
#                as.character(adult_beta_network$Source..regulates.), as.character(adult_beta_network$Target..regulated.),
#                as.character(pancreas_network$Source..regulates.), as.character(pancreas_network$Target..regulated.))
# 
# gene_list_id <- unique(row.names(panc_cds_valid_cells)[ fData(panc_cds_valid_cells)$gene_short_name %in% gene_list_update])
# 
# progenitor_cds <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5:9)]
# write.table(file = './csv_data/progenitor_pancreas.txt', as.matrix(exprs(progenitor_cds[gene_list_id, order(pData(progenitor_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# alpha_branch_cds <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(2, 4:9)]
# write.table(file = './csv_data/alpha_branch.txt', as.matrix(exprs(alpha_branch_cds[gene_list_id, order(pData(alpha_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# beta_branch_cds <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(1, 5:9)]
# write.table(file = './csv_data/beta_branch.txt', as.matrix(exprs(beta_branch_cds[gene_list_id, order(pData(beta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# beta_trunk_cds <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(1)]
# write.table(file = './csv_data/beta_trunk.txt', as.matrix(exprs(beta_trunk_cds[gene_list_id, order(pData(beta_trunk_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# delta_branch_cds <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(2:3, 5:9)]
# write.table(file = './csv_data/delta_branch.txt', as.matrix(exprs(delta_branch_cds[gene_list_id, order(pData(delta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# write.table(fData(panc_cds_valid_cells), row.names = T, col.names = T, quote = F, file = './csv_data/pancreas_gene_feature.txt')
# write.table(pData(panc_cds_valid_cells), row.names = T, col.names = T, quote = F, file = './csv_data/pancreas_cell_feature.txt')
# 
# write.table(pancreas_network, row.names = T, col.names = T, quote = F, file = './csv_data/endocrine_progenitor_network.txt')
# write.table(adult_beta_network, row.names = T, col.names = T, quote = F, file = './csv_data/adule_beta_cell_network.txt')
# write.table(immature_beta_network, row.names = T, col.names = T, quote = F, file = './csv_data/immature_beta_cell_network.txt')
# 
# #only get the small network for simulation: 
# pancreas_simulation_network <- read.table('./csv_data/pancreas_simulation_network.txt', header = T, sep = '\t')
# pancreas_simulation_network$Source <- revalue(pancreas_simulation_network$Source, c("Hnf6" = "Onecut1", "Ngn3" = "Neurog3", "Brn4" = "Pou3f4"))
# pancreas_simulation_network$Target <- revalue(pancreas_simulation_network$Target, c("Hnf6" = "Onecut1", "Ngn3" = "Neurog3", "Brn4" = "Pou3f4"))
# 
# write.table(pancreas_simulation_network, row.names = T, col.names = T, quote = F, file = './csv_data/pancreas_simulation_network_update.txt')
# simulation_gene_list_id <- unique(row.names(panc_cds_valid_cells)[fData(panc_cds_valid_cells)$gene_short_name %in% 
#                                                                      c(as.character(pancreas_simulation_network$Source), as.character(pancreas_simulation_network$Target))])
# 
# write.table(file = './csv_data/progenitor_pancreas_simulation.txt', as.matrix(exprs(progenitor_cds[simulation_gene_list_id, order(pData(progenitor_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/alpha_branch_simulation.txt', as.matrix(exprs(alpha_branch_cds[simulation_gene_list_id, order(pData(alpha_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/beta_branch_simulation.txt', as.matrix(exprs(beta_branch_cds[simulation_gene_list_id, order(pData(beta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/delta_branch_simulation.txt', as.matrix(exprs(delta_branch_cds[simulation_gene_list_id, order(pData(delta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# 
# ###############################################################################################################################################################################################
# # run RDI on the zero-inflation corrected data:
# ###############################################################################################################################################################################################
# pscl_exp_coef_progenitor <- pscl_smooth_genes_exp_coef(t(exprs(progenitor_cds[gene_list_id, ])), window_size = 20) #gene_list_id
# pscl_exp_coef_alpha <- pscl_smooth_genes_exp_coef(t(exprs(alpha_branch_cds[gene_list_id, ])), window_size = 20) #gene_list_id
# pscl_exp_coef_beta <- pscl_smooth_genes_exp_coef(t(exprs(beta_branch_cds[gene_list_id, ])), window_size = 20) #gene_list_id
# pscl_exp_coef_delta <- pscl_smooth_genes_exp_coef(t(exprs(delta_branch_cds[gene_list_id, ])), window_size = 20) #gene_list_id
# 
# write.table(file = './csv_data/progenitor_pancreas_zero_infl.txt', as.matrix(exprs(progenitor_cds[gene_list_id, order(pData(progenitor_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/alpha_branch_zero_infl.txt', as.matrix(exprs(alpha_branch_cds[gene_list_id, order(pData(alpha_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/beta_branch_zero_infl.txt', as.matrix(exprs(beta_branch_cds[gene_list_id, order(pData(beta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
# write.table(file = './csv_data/delta_branch_zero_infl.txt', as.matrix(exprs(delta_branch_cds[gene_list_id, order(pData(delta_branch_cds)$Pseudotime)])), row.names = T, quote = F)
#                                                
# ###############################################################################################################################################################################################
# # run ccm data:
# ###############################################################################################################################################################################################
# # beta branch
# beta_branch_mat <- t(as.matrix(exprs(beta_branch_cds[gene_list_id, order(pData(beta_branch_cds)$Pseudotime)])))
# 
# beta_branch_parallel_res <- parallelCCM(ordered_exprs_mat = beta_branch_mat, cores = detectCores() - 2)
# beta_branch_parallel_res_mat <- prepare_ccm_res(beta_branch_parallel_res)
# 
# pdf('beta_branch_ccm.pdf', width = 10, height = 10)
# pheatmap(beta_branch_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
# dev.off()
# 
# gene_names <- colnames(beta_branch_parallel_res_mat)
# for(gene_id1 in gene_names) {
#   for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
#     df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = as.character(fData(beta_branch_cds[gene_id1, ])$gene_short_name), 
#                      Gene_2_ID = c(gene_id2), Gene_2_NAME = as.character(fData(beta_branch_cds[gene_id2, ])$gene_short_name), delay_max = NA, 
#                      ccm = beta_branch_parallel_res_mat[gene_id1, gene_id2] )
#     write.table(file = 'beta_branch_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
#   }
# }
# #progenitor
# progenitor_mat <- t(as.matrix(exprs(progenitor_cds[gene_list_id, order(pData(progenitor_cds)$Pseudotime)])))
# 
# progenitor_parallel_res <- parallelCCM(ordered_exprs_mat = progenitor_mat, cores = detectCores() - 2)
# progenitor_parallel_res_mat <- prepare_ccm_res(progenitor_parallel_res)
# 
# pdf('progenitor_ccm.pdf', width = 10, height = 10)
# pheatmap(progenitor_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
# dev.off()
# 
# gene_names <- colnames(progenitor_parallel_res_mat)
# for(gene_id1 in gene_names) {
#   for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
#     df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = as.character(fData(beta_branch_cds[gene_id1, ])$gene_short_name), 
#                      Gene_2_ID = c(gene_id2), Gene_2_NAME = as.character(fData(beta_branch_cds[gene_id2, ])$gene_short_name), delay_max = NA, 
#                      ccm = progenitor_parallel_res_mat[gene_id1, gene_id2] )
#     write.table(file = 'progenitor_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
#   }
# }
# 
# #beta trunk
# beta_trunk_mat <- t(as.matrix(exprs(beta_trunk_cds[gene_list_id, order(pData(beta_trunk_cds)$Pseudotime)])))
# 
# beta_trunk_parallel_res <- parallelCCM(ordered_exprs_mat = beta_trunk_mat, cores = detectCores() - 2)
# beta_trunk_parallel_res_mat <- prepare_ccm_res(beta_trunk_parallel_res)
# 
# pdf('beta_trunk_ccm.pdf', width = 10, height = 10)
# pheatmap(beta_trunk_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
# dev.off()
# 
# gene_names <- colnames(beta_trunk_parallel_res_mat)
# for(gene_id1 in gene_names) {
#   for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
#     df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = as.character(fData(beta_branch_cds[gene_id1, ])$gene_short_name), 
#                      Gene_2_ID = c(gene_id2), Gene_2_NAME = as.character(fData(beta_branch_cds[gene_id2, ])$gene_short_name), delay_max = NA, 
#                      ccm = beta_trunk_parallel_res_mat[gene_id1, gene_id2] )
#     write.table(file = 'beta_trunk_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
#   }
# }
# 
# #filter by gene expression / DEGs 
# beta_branch_DEG_res <- differentialGeneTest(beta_branch_cds, cores = detectCores() - 2) #gene_list_id
# beta_deg_pass_qval_genes <- row.names(subset(beta_branch_DEG_res[gene_list_id, ], qval < 0.1))
# write.table(file = './Results//beta_deg_pass_qval_genes.txt', beta_deg_pass_qval_genes, row.names = F, col.names = F, quote = F, sep = '\t')
# 
# beta_trunk_DEG_res <- differentialGeneTest(beta_trunk_cds, cores = detectCores() - 2) #gene_list_id
# beta_trunk_deg_pass_qval_genes <- row.names(subset(beta_trunk_DEG_res[gene_list_id, ], qval < 0.1))
# write.table(file = './Results//beta_trunk_deg_pass_qval_genes.txt', beta_trunk_deg_pass_qval_genes, row.names = F, col.names = F, quote = F, sep = '\t')
# 
# progenitor_trunk_DEG_res <- differentialGeneTest(progenitor_cds, cores = detectCores() - 2) #gene_list_id
# progenitor_trunk_deg_pass_qval_genes <- row.names(subset(progenitor_trunk_DEG_res[gene_list_id, ], qval < 0.1))
# write.table(file = './Results//progenitor_trunk_deg_pass_qval_genes.txt', progenitor_trunk_deg_pass_qval_genes, row.names = F, col.names = F, quote = F, sep = '\t')

###############################################################################################################################################################################################
#2. erythroid network 
# all_wt_GSE72857_cds: wild-type data from Paul 
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/all_wt_GSE72857_cds')

erythroid_network <- read.table('./csv_data/erythroid_network.txt', sep = '\t', header = T)
erythroid_gene_list <- c(as.character(erythroid_network$Upstream.Gene), as.character(erythroid_network$Target.Gene))
print(t(t(unique(erythroid_gene_list[!(as.character(erythroid_gene_list) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]))))
write.table(unique(erythroid_gene_list[!(as.character(erythroid_gene_list) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]),
            row.names = F, col.names = F, quote = F, file = './csv_data/erythroid_missing_gene_list.txt')

# [1] "Foxa2"   "Glis3"   "Hnf1a"   "Hnf1b"   "Hnf4a"   "Isl1"    "Myt1"    "Neurod1" "Neurog3" "Nkx2.2"  "Nkx6.1"  "Nkx6.2"  "Pax4"    "Pax6"    "Rfx6"    "Smad7"   "Tle2"   
# [18] "Ccnd1"   "cMyc"    "Gcg"     "Mafa"    "Ins2"    "Irx1"    "Insm1"   "Fev"     "Neurod2" "Ghrl"    "Mafb"    "Dnmt3a"  "Hdac1"   "Mnx1"    "Pdx1"    "Arx"     "Glut2"  
# [35] "Sst"     "Tle3"    "Tm4sf4"  "Atf2"    "Atf3"    "Egr1"    "Foxo1"   "Gck"     "Ins1"    "Slc2a2"  "G6pc2"   "Glp1r"   "Rbp4"    "Ptf1a"   "Iapp"    "Dnmt1a"  "Mecp2"  
# [52] "NFATc1"  "Ccnd2"   "Cdk4"    "ChgA"    "ChgB"    "Foxm1"   "Ia2"     "Irs2"    "Tnfa"    "Pcsk1"  
update_gene_names <- c("Foxa2", "Glis3", "Hnf1a", "Hnf1b", "Hnf4a", "Isl1", "Myt1", "Pkmyt1", "Neurod1", "Neurog3", "Nkx2-2", "Nkx6-1", "Nkx6-2", "Pax4", "Pax6", "Rfx6", "Smad7", "Tle2", "Ccnd1", 
"Cdkn1a", "Gcg", "Klrg1", "Mafa", "Ins2", "Irx1", "Insm1", "Fev", "Neurod2", "Ghrl", "Mafb", "Dnmt3a", "Hdac1", "Hdac2", "Mnx1", "Pdx1", "Pdhx", "Arx", "Uba2", "Slc2a2", "Sst", 
"Lmx1a", "Tle3", "Tm4sf4", "Gdnf", "Atf2", "Atf3", "Egr1", "Foxo1", "Gck", "Map4k2", "Ins1", "Slc2a2", "G6pc", "G6pc2", "Glp1r", "Rbp4", "Polr2d", "Ptf1a", "Iapp", "Mecp2", 
"Prr14", "Nfatc1", "Ccnd2", "Cdk4", "Defb1", "Chga", "Chgb", "Foxm1", "Ptprn", "H2-Ab1", "Irs2", "Tnf", "Pcsk1")

# write.table(unique(gene_list[!(as.character(update_gene_names) %in% fData(all_wt_GSE72857_cds)$gene_short_name)]),
#             row.names = F, col.names = F, quote = F, file = './csv_data/erythroid_missing_gene_list.txt')

#find the missing gene name and correct the gene regulatory network
erythroid_network$Upstream.Gene <- revalue(erythroid_network$Upstream.Gene, 
                                           c("Beta Catenin" = "Ctnnb1", "LEF-1" = "Lef1", "Hes1" = "Hes1", "notch1" = "Notch1", "CBF1" = "Rbpj", "p45" = "Nfe2", 
                                             "NF-E2" = "Nfe2", "Maf" = "Maf", "Rb" = "Rb1", "SCL in a complex" = "SCL", "TCF3 (Wnt signalling)" = "Tcf3", 
                                             "Wnt signalling (B-catenin)" = "Ctnnb1", "Alpha Globin" = "Hba-a2", "Beta Globin" = "Hbb-bs", 
                                             "Beta Globin (via GATA-1)" = "Hbb-bs", "p45 NF-E2" = "Nfe2", "c-jun (PU.1)" = "Jun", "GATA-1 activity (P300)" = "Gata1", 
                                             "alpha globin" = "Hba-a2", "Runx-1" = "Runx1", "HoxB4" = "Hoxb4", "Notch-1" = "Notch1", "Beta Catenin/LEF-1" = "Ctnnb1", 
                                             "Hes1 (notch1)" = "Hes1", "Notch                                  (and CBF1 aka RBP-J)" = "Notch1", 
                                             "Notch and CBF1(RBPjk)" = "Notch1", "p45 NF-E2 (via Maf proteins)" = "Nfe2", "BMP4" = "Bmp4", 
                                             "CBP" = "Crebbp", "c-jun" = "Jun", "c-myb" = "Myb", "E2A" = "Tcf3", "E47" = "Tcf3", "EKLF" = "Klf1", "Elf-1" = "Elf1", 
                                             "GATA-1" = "Gata1", "GATA-2" = "Gata2", "(notch1)" = "Notch1", "HoxB4" = "Hoxb4", "LMO2" = "Lmo2", "NFE2" = "Nfe2", 
                                             "Notch" = "Notch1", "p45" = "Nfe2", "PU.1" = "Spi1", "Rb" = "Rb1", "SCL" = "Scx", "TCF3" = "Tcf3", "Brachyury" = "T", 
                                             "Hex" = "Hhex", "c-kit" = "Kit", "GPA" = "Gypa", "c-myc" = "Myc", "GPIX" = "Gp9", "EpoR" = "Epor"))
erythroid_network$Target.Gene <- revalue(erythroid_network$Target.Gene, 
                                         c("Beta Catenin" = "Ctnnb1", "LEF-1" = "Lef1", "Hes1" = "Hes1", "notch1" = "Notch1", "CBF1" = "Rbpj", "p45" = "Nfe2", 
                                           "NF-E2" = "Nfe2", "Maf" = "Maf", "Rb" = "Rb1", "SCL in a complex" = "SCL", "TCF3 (Wnt signalling)" = "Tcf3", 
                                           "Wnt signalling (B-catenin)" = "Ctnnb1", "Alpha Globin" = "Hba-a2", "Beta Globin" = "Hbb-bs", 
                                           "Beta Globin (via GATA-1)" = "Hbb-bs", "p45 NF-E2" = "Nfe2", "c-jun (PU.1)" = "Jun", "GATA-1 activity (P300)" = "Gata1", 
                                           "alpha globin" = "Hba-a2", "Runx-1" = "Runx1", "HoxB4" = "Hoxb4", "Notch-1" = "Notch1", "Beta Catenin/LEF-1" = "Ctnnb1", 
                                           "Hes1 (notch1)" = "Hes1", "Notch                                  (and CBF1 aka RBP-J)" = "Notch1", 
                                           "Notch and CBF1(RBPjk)" = "Notch1", "p45 NF-E2 (via Maf proteins)" = "Nfe2", "BMP4" = "Bmp4", 
                                           "CBP" = "Crebbp", "c-jun" = "Jun", "c-myb" = "Myb", "E2A" = "Tcf3", "E47" = "Tcf3", "EKLF" = "Klf1", "Elf-1" = "Elf1", 
                                           "GATA-1" = "Gata1", "GATA-2" = "Gata2", "(notch1)" = "Notch1", "HoxB4" = "Hoxb4", "LMO2" = "Lmo2", "NFE2" = "Nfe2", 
                                           "Notch" = "Notch1", "p45" = "Nfe2", "PU.1" = "Spi1", "Rb" = "Rb1", "SCL" = "Scx", "TCF3" = "Tcf3", "Brachyury" = "T", 
                                           "Hex" = "Hhex", "c-kit" = "Kit", "GPA" = "Gypa", "c-myc" = "Myc", "GPIX" = "Gp9", "EpoR" = "Epor"))

# write.table(file = './csv_data/erythroid_network_update.txt', erythroid_network, row.names = T, quote = F)
erythroid_network_update.txt
erythroid_network <- read.table('./csv_data/erythroid_network_update.txt', sep = ' ', header = T)

###############################################################################################################################################################################################
#3. microglial dataset 
###############################################################################################################################################################################################

microglial_experimental_design <- read.table('./csv_data/microglia/GSE79818_experimental_design.txt', sep = '\t', header = T)
microglial_exprs <- read.table('./csv_data/microglia/GSE79818_umitab.txt', sep = '\t', header = T, row.names = 1)
row.names(microglial_experimental_design) <- microglial_experimental_design$Well_ID
gene_ann <- data.frame(gene_short_name = row.names(microglial_exprs), row.names = row.names(microglial_exprs))
pd <- new("AnnotatedDataFrame",data=microglial_experimental_design)
fd <- new("AnnotatedDataFrame",data=gene_ann)
 
microglial_cds <- newCellDataSet(as(as.matrix(microglial_exprs[, row.names(microglial_experimental_design)]), 'sparseMatrix'), phenoData = pd,featureData =fd,
                               expressionFamily = negbinomial.size(),
                               lowerDetectionLimit=1)
microglial_cds <- estimateSizeFactors(microglial_cds)
microglial_cds <- estimateDispersions(microglial_cds)

###############################################################################################################################################################################################
#run dpFeature to decide the genes: 
###############################################################################################################################################################################################
#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05

microglial_cds <- detectGenes(microglial_cds)
fData(microglial_cds)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(microglial_cds)) #
fData(microglial_cds)$use_for_ordering[fData(microglial_cds)$num_cells_expressed > num_cells_expressed] <- T

microglial_cds@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(microglial_cds, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# microglial_cds <- setOrderingFilter(microglial_cds, quake_id)
microglial_cds <- reduceDimension(microglial_cds, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 5,  verbose = T) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
microglial_cds <- clusterCells(microglial_cds, verbose = T)

#4. check the clusters 
plot_cell_clusters(microglial_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(microglial_cds, color_by = 'as.factor(Experiment_ID)', show_density = F)

#5. also check the decision plot 
plot_rho_delta(microglial_cds, rho_threshold = 50, delta_threshold = 20)

#6. re-run cluster and skipping calculating the rho_sigma 
microglial_cds <- clusterCells(microglial_cds, verbose = T, rho_threshold = 50, delta_threshold = 20, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(microglial_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(microglial_cds, color_by = 'as.factor(Experiment_ID)', show_density = F)

#perform DEG test across clusters: 
microglial_cds@expressionFamily <- negbinomial.size()
pData(microglial_cds)$Cluster <- factor(pData(microglial_cds)$Cluster)
LPSclustering_DEG_genes <- differentialGeneTest(microglial_cds, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

LPS_cell_type_DEG_genes <- differentialGeneTest(microglial_cds, fullModelFormulaStr = '~Experiment_ID', cores = detectCores() - 2)

LPS_clustering_DEG_genes_subset <- LPSclustering_DEG_genes[fData(microglial_cds)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
qval_thrsld <- 0.1
angela_ordering_genes <- row.names(LPS_cell_type_DEG_genes)[order(LPS_cell_type_DEG_genes$qval)][1:1000] row.names(subset(LPS_cell_type_DEG_genes, qval < qval_thrsld))
  
# 
angela_ordering_genes <- row.names(LPS_clustering_DEG_genes_subset)[order(LPS_clustering_DEG_genes_subset$qval)][1:500] 

microglial_cds <- setOrderingFilter(microglial_cds, ordering_genes = angela_ordering_genes)
microglial_cds <- reduceDimension(microglial_cds, verbose = T, param.gamma = 100)
microglial_cds <- orderCells(microglial_cds)

plot_cell_trajectory(microglial_cds, color_by = 'Experiment_ID') 
plot_cell_trajectory(microglial_cds, color_by = 'Pseudotime') 
#pseudotime_DEG_genes_res <- differentialGeneTest(microglial_cds)
#beam_genes_res <- BEAM(microglial_cds[, ], cores = detectCores() - 2) 

#save the microglial dataset 
save(file = 'microglial_cds', microglial_cds) 

###############################################################################################################################################################################################
# save the data frame into csv_file folder for Arman to test the result 
###############################################################################################################################################################################################
#1. 
#
SI5 <- read.table('./csv_data/SI5.txt', sep = '\t', header = T, row.names = 1)


microglia_mat <- as.matrix(exprs(microglial_cds)[, order(pData(microglial_cds)$Pseudotime)])
match_ids <- row.names(SI5)[row.names(SI5) %in% fData(microglial_cds)$gene_short_name]
miss_ids <- row.names(microglial_cds)[unlist(lapply(row.names(SI5)[!(row.names(SI5) %in% fData(microglial_cds)$gene_short_name)], function(x) grep(x, row.names(microglial_cds)) ))]
valid_ids <- c(match_ids, miss_ids)

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/microglia/microglia_fdata.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/microglia/microglia_mat.txt', microglia_mat[unique(valid_ids), ], col.names = T, sep = '\t', row.names = T, quote = F)

###############################################################################################################################################################################################
#3. LPS network from Aviv group
###############################################################################################################################################################################################
# run Census: 
load('/Users/xqiu/Dropbox (Personal)/Projects/BEAM/RData/gen_shalek_figures.RData')

Shalek_abs= relative2abs(Shalek_std)

pd <- new("AnnotatedDataFrame", data = pData(Shalek_std))
fd <- new("AnnotatedDataFrame", data = fData(Shalek_std))
Shalek_abs <-  newCellDataSet(as.matrix(Shalek_abs), 
                              phenoData = pd, 
                              featureData = fd, 
                              expressionFamily=negbinomial(), 
                              lowerDetectionLimit=1)
pData(Shalek_abs)$Total_mRNAs <- colSums(exprs(Shalek_abs))

#Calculate size factors and dispersions
Shalek_abs = estimateSizeFactors(Shalek_abs)
Shalek_abs = estimateDispersions(Shalek_abs)

# Filter to only expressed genes (feel free to change this as needed, I have tried several methods)
Shalek_abs = detectGenes(Shalek_abs, min_expr = 1)

Shalek_abs_subset_ko_LPS <- Shalek_abs[, pData(Shalek_abs)$experiment_name %in% c('Ifnar1_KO_LPS', 'Stat1_KO_LPS',  "LPS", "Unstimulated_Replicate")]
pData(Shalek_abs_subset_ko_LPS)[, 'stim_time'] <- as.character(pData(Shalek_abs_subset_ko_LPS)$time)

pData(Shalek_abs_subset_ko_LPS)$stim_time[pData(Shalek_abs_subset_ko_LPS)$stim_time == ''] <- 0
pData(Shalek_abs_subset_ko_LPS)$stim_time <- as.integer(revalue(pData(Shalek_abs_subset_ko_LPS)$stim_time, c("1h" = 1, "2h" = 2, "4h" = 4, "6h" = 6)))
Shalek_abs_subset_ko_LPS <- detectGenes(Shalek_abs_subset_ko_LPS, min_expr = 0.1)

###############################################################################################################################################################################################
#run dpFeature to decide the genes for KO dataset: 
###############################################################################################################################################################################################
Shalek_abs_subset_ko_LPS <- recreate_cds(Shalek_abs_subset_ko_LPS)

#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05

Shalek_abs_subset_ko_LPS <- detectGenes(Shalek_abs_subset_ko_LPS)
fData(Shalek_abs_subset_ko_LPS)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(Shalek_abs_subset_ko_LPS)) #
fData(Shalek_abs_subset_ko_LPS)$use_for_ordering[fData(Shalek_abs_subset_ko_LPS)$num_cells_expressed > num_cells_expressed] <- T

Shalek_abs_subset_ko_LPS@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(Shalek_abs_subset_ko_LPS, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# Shalek_abs_subset_ko_LPS <- setOrderingFilter(Shalek_abs_subset_ko_LPS, quake_id)
Shalek_abs_subset_ko_LPS <- reduceDimension(Shalek_abs_subset_ko_LPS, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 3,  verbose = T,  perplexity = 30) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
Shalek_abs_subset_ko_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_ko_LPS, verbose = T)

#4. check the clusters 
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(Cluster)', show_density = F)

plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'experiment_name', show_density = F) 

#5. also check the decision plot 
plot_rho_delta(Shalek_abs_subset_ko_LPS, rho_threshold = 8, delta_threshold = 15)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'experiment_name', rho_threshold = 8, delta_threshold = 15)

#6. re-run cluster and skipping calculating the rho_sigma 
Shalek_abs_subset_ko_LPS <- clusterCells_Density_Peak(Shalek_abs_subset_ko_LPS, verbose = T, rho_threshold = 8, delta_threshold = 15, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset_ko_LPS, color_by = 'as.factor(experiment_name)', show_density = F)

#perform DEG test across clusters: 
Shalek_abs_subset_ko_LPS@expressionFamily <- negbinomial.size()
pData(Shalek_abs_subset_ko_LPS)$Cluster <- factor(pData(Shalek_abs_subset_ko_LPS)$Cluster)
LPS_clustering_DEG_genes <- differentialGeneTest(Shalek_abs_subset_ko_LPS, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

LPS_clustering_DEG_genes_subset <- LPS_clustering_DEG_genes[fData(Shalek_abs_subset_ko_LPS)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
qval_thrsld <- 0.1
LPS_ordering_genes <- row.names(subset(LPS_clustering_DEG_genes, qval < qval_thrsld))

# 
LPS_ordering_genes <- row.names(LPS_clustering_DEG_genes_subset)[order(LPS_clustering_DEG_genes_subset$qval)][1:1000] 

Shalek_abs_subset_ko_LPS <- setOrderingFilter(Shalek_abs_subset_ko_LPS, ordering_genes = LPS_ordering_genes)
Shalek_abs_subset_ko_LPS <- reduceDimension(Shalek_abs_subset_ko_LPS, verbose = T)
Shalek_abs_subset_ko_LPS <- orderCells(Shalek_abs_subset_ko_LPS)

plot_cell_trajectory(Shalek_abs_subset_ko_LPS, color_by = 'experiment_name') 
# pseudotime_DEG_genes_res <- differentialGeneTest(Shalek_abs_subset_ko_LPS)
# beam_genes_res <- BEAM(Shalek_abs_subset_ko_LPS[, ], cores = detectCores() - 2) 

###############################################################################################################################################################################################
#run dpFeature to decide the genes for just the wild-type dataset: 
###############################################################################################################################################################################################
Shalek_abs_subset <- Shalek_abs[, pData(Shalek_abs)$experiment_name %in% c("LPS", "Unstimulated_Replicate")]
pData(Shalek_abs_subset)[, 'stim_time'] <- as.character(pData(Shalek_abs_subset)$time)

pData(Shalek_abs_subset)$stim_time[pData(Shalek_abs_subset)$stim_time == ''] <- 0
pData(Shalek_abs_subset)$stim_time <- as.integer(revalue(pData(Shalek_abs_subset)$stim_time, c("1h" = 1, "2h" = 2, "4h" = 4, "6h" = 6)))
Shalek_abs_subset <- detectGenes(Shalek_abs_subset, min_expr = 0.1)

Shalek_abs_subset <- recreate_cds(Shalek_abs_subset)

#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05

Shalek_abs_subset <- detectGenes(Shalek_abs_subset)
fData(Shalek_abs_subset)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(Shalek_abs_subset)) #
fData(Shalek_abs_subset)$use_for_ordering[fData(Shalek_abs_subset)$num_cells_expressed > num_cells_expressed] <- T

Shalek_abs_subset@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(Shalek_abs_subset, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# Shalek_abs_subset <- setOrderingFilter(Shalek_abs_subset, quake_id)
Shalek_abs_subset <- reduceDimension(Shalek_abs_subset, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 15,  verbose = T,  perplexity = 30) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
Shalek_abs_subset <- clusterCells_Density_Peak(Shalek_abs_subset, verbose = T)

#4. check the clusters 
plot_cell_clusters(Shalek_abs_subset, color_by = 'as.factor(Cluster)', show_density = F)

plot_cell_clusters(Shalek_abs_subset, color_by = 'stim_time', show_density = F) 

#5. also check the decision plot 
plot_rho_delta(Shalek_abs_subset, rho_threshold = 0.5, delta_threshold = 50)
plot_cell_clusters(Shalek_abs_subset, color_by = 'experiment_name', rho_threshold = 10, delta_threshold = 25)

#6. re-run cluster and skipping calculating the rho_sigma 
Shalek_abs_subset <- clusterCells_Density_Peak(Shalek_abs_subset, verbose = T, rho_threshold = 7.5, delta_threshold = 20, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(Shalek_abs_subset, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(Shalek_abs_subset, color_by = 'as.factor(stim_time)', show_density = F)

#perform DEG test across clusters: 
Shalek_abs_subset@expressionFamily <- negbinomial.size()
pData(Shalek_abs_subset)$Cluster <- factor(pData(Shalek_abs_subset)$Cluster)
LPS_clustering_DEG_genes <- differentialGeneTest(Shalek_abs_subset, fullModelFormulaStr = '~stim_time', cores = detectCores() - 2)

LPS_clustering_DEG_genes_subset <- LPS_clustering_DEG_genes[fData(Shalek_abs_subset)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
qval_thrsld <- 0.1
LPS_ordering_genes <- row.names(subset(LPS_clustering_DEG_genes, qval < qval_thrsld))

# 
LPS_ordering_genes <- row.names(LPS_clustering_DEG_genes)[order(LPS_clustering_DEG_genes_subset$qval)][1:1000] 

Shalek_abs_subset <- setOrderingFilter(Shalek_abs_subset, ordering_genes = LPS_ordering_genes)
Shalek_abs_subset <- reduceDimension(Shalek_abs_subset, verbose = T)
Shalek_abs_subset <- orderCells(Shalek_abs_subset)

plot_cell_trajectory(Shalek_abs_subset, color_by = 'experiment_name') 
plot_cell_trajectory(Shalek_abs_subset, color_by = 'stim_time') 

# pseudotime_DEG_genes_res <- differentialGeneTest(Shalek_abs_subset)
# beam_genes_res <- BEAM(Shalek_abs_subset[, ], cores = detectCores() - 2) 








