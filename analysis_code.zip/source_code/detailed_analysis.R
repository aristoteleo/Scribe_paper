# running conditional RDI: 
calculate_and_write_pairwise_dmi_conditioned <- function(genes_data, rdi_res_list, k = 1, supergraph = NULL, cores = 1, 
    verbose = F) {
	delay <- rdi_res_list$delays
	rdi_res <- rdi_res_list$rdi_res 

    k <- min(k, nrow(genes_data) - 2)

    gene_num <- nrow(genes_data)
    if(gene_num != nrow(rdi_res))
    	stop('number of genes in the expression data is different from that from the RDI')

    # identify the rdi and the corresponding delay for each pair of genes 
     
    for(i in 1:gene_num) {
    	for(j in 1:gene_num) {
    		rdi_vec <- c(rdi_res[i, j], rdi_res[i, gene_num + j], rdi_res[i, 2 * gene_num + j])
    		max_rdi_value <- max(rdi_vec)
    		max_rdi_ind <- which(rdi_vec == max_rdi_value)
    		max_rdi_mat[i, j] <- max_rdi_value
    		max_rdi_ind[i, j] <-  max_rdi_ind
    	}
    }

	top_k_plus_1_incoming_id_list[i, ] <- sort()[1:k]
	top_k_plus_1_delay <- 

    rdi_res$max_rdi <- apply(rdi_res[, 3:(ncol(rdi_res) - 1)], 
        1, max)
    max_rdi <- apply(rdi_res[, 3:(ncol(rdi_res) - 2)], 1, which.max)
    delays_max <- as.numeric(do.call(rbind.data.frame, strsplit(colnames(rdi_res)[3:(ncol(rdi_res) - 
        2)], " "))[[2]])[max_rdi]
    rdi_res$max_val_delay <- delays_max
    names(delays_max) <- row.names(rdi_res)
    target_gene_list <- unique(rdi_res[, "id_2"])
    top_k_plus_1_incoming_id_list <- lapply(target_gene_list, 
        function(x) {
            rdi_res_subset <- rdi_res[rdi_res$id_2 == x, ]
            nodes <- rdi_res_subset[order(rdi_res_subset$max_rdi, 
                decreasing = T)[1:(k + 1)], "id_1"]
            delay <- rdi_res_subset[order(rdi_res_subset$max_rdi, 
                decreasing = T)[1:(k + 1)], "max_val_delay"]
            names(delay) <- nodes
            return(delay)
        })
    names(top_k_plus_1_incoming_id_list) <- target_gene_list
    tmp <- expand.grid(colnames(genes_data), colnames(genes_data), 
        stringsAsFactors = F)
    all_pairwise_gene <- tmp[as.character(tmp[, 1]) != as.character(tmp[, 
        2]), ]
    if (!is.null(supergraph)) {
        all_pairwise_gene_paste <- paste(all_pairwise_gene[, 
            1], all_pairwise_gene[, 2])
        supergraph_paste <- paste(supergraph[, 1], supergraph[, 
            2])
        all_pairwise_gene <- all_pairwise_gene[all_pairwise_gene_paste %in% 
            supergraph_paste, ]
    }
    all_pairwise_gene_list <- split(all_pairwise_gene, row.names(all_pairwise_gene))
    res <- mclapply(all_pairwise_gene_list, function(gene_pair, 
        genes_data, delays, N_operations) {
        index_name <- paste(gene_pair[1], gene_pair[2], sep = "_")
        top_k_plus_1 <- top_k_plus_1_incoming_id_list[[gene_pair[[2]]]]
        valid_top_k <- top_k_plus_1[!(names(top_k_plus_1) %in% 
            gene_pair[[1]])][1:(length(top_k_plus_1) - 1)]
        calculate_conditioned_rdi(gene_pair[[1]], gene_pair[[2]], 
            genes_data, delays_max[index_name], valid_top_k, 
            N_operations)
    }, genes_data = genes_data, mc.cores = cores)
    res <- do.call(rbind.data.frame, res)
    row.names(res) <- paste(res$id_1, res$id_2, sep = "_")
    res$delay_max <- delays_max[row.names(res)]
    return(res)
}






# detailed analysis

AT1_early <- c("Aqp5", "Pdpn", "Rtkn2", "Ager", "Emp2", "Cav1", "Clic5", "Lmo7", "S100a6", "Col4a3", "Akap5", "Cryab")
AT1_late <- c("Sdpr", "S100a14")

AT2_early <- c("Fabp5", "Lamp3", "Cd36", "Scd1", "Sftpb", "Slc34a2", "Abca3", "Sftpa1", "Egfl6", "Soat1", "Bex2", "Muc1", "Sftpc")
AT2_late <- c("Lcn2", "Il33", "Hc", "Trf", "Lyz2", "S100g", "Lyz1")


run_new_dpt <- function(cds, norm_method = 'none', root = NULL, color_by = 'Cell_type'){
  message('root should be the id to the cell not the cell name ....')
  norm_data <- monocle:::normalize_expr_data(cds, norm_method = norm_method)
  norm_data <- t(norm_data)
  duplicated_genes <- which(base::duplicated.array(norm_data))
  norm_data[duplicated_genes, 1] <- norm_data[duplicated_genes, 1] + rnorm(length(duplicated_genes), 0, 1)
  dm <- DiffusionMap(norm_data)
  dpt <- DPT(dm)
  ts <- dm@transitions
  M <- destiny:::accumulated_transitions(dm)
  if(is.null(root)){
  }
  else{
    dm <- DiffusionMap(norm_data)
    dpt <- DPT(dm, tips = root)
  }
  if('Hours' %in% colnames(pData(cds)))
    pData(cds)$Hours <- pData(cds)[, color_by]
  p1 <- qplot(DM$DC1, DM$DC2, colour = pData(cds)$Hours)
  branch <- dpt@branch
  if(is.null(root))
    root <- which.min(pData(cds)$Pseudotime)
  pt <- dpt[root, ]
  dp_res <- list(dm = dm, pt = pt, ts = ts, M = M, ev = dm@eigenvectors, p1 = p1, branch = branch)
  return(dp_res)
}


library(InformationEstimator)
library(destiny)
library(monocle)
lung <- load_lung()
AT1_lung <- lung[, pData(lung)$State %in% c(1, 3)]
AT2_lung <- lung[, pData(lung)$State %in% c(1, 2)]
AT1_dpt_res <- run_new_dpt(AT1_lung)
AT2_dpt_res <- run_new_dpt(AT2_lung)

lung_exprs_AT1 <- t(exprs(AT1_lung)[, order(AT1_dpt_res$pt)])
lung_exprs_AT2 <- t(exprs(AT2_lung)[, order(AT2_dpt_res$pt)])

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(AT1_lung) * ncol(AT1_lung)), nrow = ncol(AT1_lung))

a <- Sys.time()
AT1_RDI_parallel_res <- calculate_rdi(lung_exprs_AT1 + noise, R_delays = c(5, 10, 15), R_cores = detectCores() - 2)
b <- Sys.time()

AT1_RDI_parallel_res_subset <- AT1_RDI_parallel_res[, 1:nrow(AT1_RDI_parallel_res)]

dimnames(AT1_RDI_parallel_res_subset) <- list(fData(lung)$gene_short_name, fData(lung)$gene_short_name); 

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(AT2_lung) * ncol(AT2_lung)), nrow = ncol(AT2_lung))

a <- Sys.time()
AT2_RDI_parallel_res <- calculate_rdi(lung_exprs_AT2 + noise, R_delays = c(5, 10, 15), R_cores = detectCores() - 2)
b <- Sys.time()

