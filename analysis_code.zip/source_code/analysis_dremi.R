#######################################################################################################################################################################################
# analyze the dremi dataset
#######################################################################################################################################################################################
library(prada)
library(monocle)

# ctr <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/ctr.fcs')
# t30s <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t30s.fcs')
# t1m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t1m.fcs')
# t2m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t2m.fcs')
# t3m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t3m.fcs')
# t4m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t4m.fcs')
# t6m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t6m.fcs')
# t8m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t8m.fcs')
# t20m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t20m.fcs')
# t80m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD8_naive_series2_CD4_costim/t80m.fcs')

ctr <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/ctr.fcs')
t30s <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t30s.fcs')
t1m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t1m.fcs')
t2m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t2m.fcs')
t3m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t3m.fcs')
t4m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t4m.fcs')
t6m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t6m.fcs')
t8m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t8m.fcs')
t20m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t20m.fcs')
t80m <- read.fcs('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Dremi/CD4_naive_series1_CD3_CD28/t80m.fcs')

#create the cds for learning the pseudotime: 
data_list <- list(ctr = ctr, t30s = t30s, t1m = t1m, t2m = t2m, t3m = t3m, t4m = t4m, t6m = t6m, t8m = t8m, t20m = t20m, t80m = t80m)
cds_list <- list()
lapply(names(data_list), function(x) {
  expr_mat <- exprs(data_list[[x]])
  row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')
  
  fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
  pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                    Time = c(#rep("0", nrow(ctr)),
                                                      rep(x, nrow(expr_mat))#,
                                                      #rep("1m", nrow(t1m))#,
                                                      #rep("2m", nrow(t2m)),
                                                      #rep("3m", nrow(t3m)),
                                                      #rep("4m", nrow(t4m)),
                                                      #rep("6m", nrow(t6m)),
                                                      #rep("8m", nrow(t8m)),
                                                      #rep("20m", nrow(t20m)),
                                                      #rep("80m", nrow(t80m))
                                                    ),
                                                    row.names = row.names(expr_mat)))
  
  new_cds <- newCellDataSet(as(asinh(as.matrix(t(expr_mat))), "sparseMatrix"), #he cofactor parameter is used for arcsinh
                            phenoData = pd, 
                            featureData = fd, 
                            expressionFamily=gaussianff(), 
                            lowerDetectionLimit=1)
  
  new_cds_subset <- new_cds[c("pCD3z(Lu175)Dd",
                              "pErk1_2(Er167)Dd",
                              "pSLP76(Gd156)Dd",
                              "pS6(Yb172)Dd"), ]
  # new_cds <- newCellDataSet(as(as.matrix(t(expr_mat)), "sparseMatrix"), #he cofactor parameter is used for arcsinh
  #                           phenoData = pd, 
  #                           featureData = fd, 
  #                           expressionFamily=gaussianff(), 
  #                           lowerDetectionLimit=1)
  
  
  new_cds <- estimateSizeFactors(new_cds)
  pData(new_cds)$Size_Factor <- 1
  # new_cds <- estimateDispersions(new_cds)
  
  new_cds <- setOrderingFilter(new_cds, row.names(new_cds)[1:30])
  new_cds <- reduceDimension(new_cds, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F)
  new_cds <- orderCells(new_cds)
  plot_cell_trajectory(new_cds, color_by = 'Time')
  plot_genes_in_pseudotime(new_cds[c("pCD3z(Lu175)Dd",
                                     "pErk1_2(Er167)Dd",
                                     "pSLP76(Gd156)Dd",
                                     "pS6(Yb172)Dd"), ])  
  
  write.table(file = paste('CD4_naive_series1_CD3_CD28_', x, '.txt', sep = ''), as.matrix(exprs(new_cds[, order(pData(new_cds)$Pseudotime)])), row.names = T, quote = F)

  new_cds_subset <- setOrderingFilter(new_cds_subset, row.names(new_cds_subset)[1:4])
  new_cds_subset <- reduceDimension(new_cds_subset, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F)
  new_cds_subset <- orderCells(new_cds_subset)
  plot_cell_trajectory(new_cds_subset, color_by = 'Time')
  
  #save the data: 
  write.table(file = paste('CD4_naive_series1_CD3_CD28_', x, '_four_genes.txt', sep = ''), as.matrix(exprs(new_cds_subset[, order(pData(new_cds_subset)$Pseudotime)])), row.names = T, quote = F)
  
  cds_list <- c(cds_list, new_cds, new_cds_subset) #
  names(cds_list)[(length(cds_list) - 1):length(cds_list)] <- c(paste(x, 'full_genes', sep = '_'), paste(x, 'four_genes', sep = '_') )
  }
)

#######################################################################################################################################################################################
# pCD3ζ -pSLP76-pERK-pS6 
#######################################################################################################################################################################################
# ctr.fcs		t20m.fcs	t30s.fcs	t4m.fcs		t80m.fcs
# t1m.fcs		t2m.fcs		t3m.fcs		t6m.fcs		t8m.fcs

# > row.names(new_cds)
# [1] "CD45.1(In113)Dd"     "CD45.2(In115)Dd"     "cPARP(La139)Dd"      "CD5(Pr141)Dd"        "p4EBP1(Nd143)Dd"     "CD4(Nd145)Dd"        "CD8(Nd146)Dd"        "pFAK(Nd148)Dd"      
# [9] "CD19(Sm149)Dd"       "(Eu151)Dd"           "Ki67(Sm152)Dd"       "pMAPKAPKII(Eu153)Dd" "pSHP2(Sm154)Dd"      "pSLP76(Gd156)Dd"     "pRb(Gd158)Dd"        "pAkt_S473(Tb159)Dd" 
# [17] "pSyk_ZAP70(Gd160)Dd" "pc-CBL(Dy162)Dd"     "pNFKb(Ho165)Dd"      "Ikba(Er166)Dd"       "pErk1_2(Er167)Dd"    "CD25(Er168)Dd"       "TCRb(Tm169)Dd"       "pLAT(Er170)Dd"      
# [25] "CD44(Yb171)Dd"       "pS6(Yb172)Dd"        "pCD3z(Lu175)Dd"      "pCreb(Yb176)Dd"      "DNA1(Ir191)Dd"       "DNA2(Ir193)Dd"   

# CD10, CD117, CD11b, CD11c, CD123, CD13, CD14, CD15, CD16, CD161, CD19, CD20, CD235a/b, CD3, CD33, CD34, CD38, CD4, CD41, CD44, CD45, CD45RA, 
# CD47, CD56, CD61, CD7, CD8a, CD90, CXCR4, HLADR, IgM, IkB alpha, Ki67, Btk/Itk (pY551/pY511), Creb (pS133), CrkL (pY207), Erk1/2 (pT202/pY204), 
# H3 (pS28), MAPKAPK 2 (pT334), NfkB (pS536), p38 (pT180/pY182), PLCg2 (pY759), S6 (pS235/pS236), Shp2 (pY580), SLP-76 (BLNK) (pY128), Src (pY418), 
# STAT3 (pY705), STAT5 (pY694), ZAP70/Syk (pY319/pY352)

#######################################################################################################################################################################################
# test data for 4m:  
#######################################################################################################################################################################################
expr_mat <- rexprs(data_list$t1m)
row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                  Time = c(rep("0", nrow(ctr))#,
                                                           #rep("1m", nrow(t1m))#,
                                                           #rep("2m", nrow(t2m)),
                                                           #rep("3m", nrow(t3m)),
                                                           #rep("4m", nrow(t4m)),
                                                           #rep("6m", nrow(t6m)),
                                                           #rep("8m", nrow(t8m)),
                                                           #rep("20m", nrow(t20m)),
                                                           #rep("80m", nrow(t80m))
                                                  ),
                                                  row.names = row.names(expr_mat)))

expr_mat <- Reduce(rbind, list(exprs(data_list$ctr), exprs(data_list$t1m), 
                               exprs(data_list$t2m), exprs(data_list$t3m), 
                               exprs(data_list$t4m), exprs(data_list$t6m), 
                               exprs(data_list$t8m), exprs(data_list$t20m), 
                               exprs(data_list$t80m)) ) 
row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                  Time = c(rep("0", nrow(ctr)),
                                                           rep("1m", nrow(t1m)),
                                                           rep("2m", nrow(t2m)),
                                                           rep("3m", nrow(t3m)),
                                                           rep("4m", nrow(t4m)),
                                                           rep("6m", nrow(t6m)),
                                                           rep("8m", nrow(t8m)),
                                                           rep("20m", nrow(t20m)),
                                                           rep("80m", nrow(t80m))
                                                  ),
                                                  row.names = row.names(expr_mat)))

new_cds <- newCellDataSet(as(asinh(as.matrix(t(expr_mat))), "sparseMatrix"), #he cofactor parameter is used for arcsinh
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)

new_cds_subset <- new_cds[c("pCD3z(Lu175)Dd",
                            "pErk1_2(Er167)Dd",
                            "pSLP76(Gd156)Dd",
                            "pS6(Yb172)Dd"), ]

new_cds <- estimateSizeFactors(new_cds)
pData(new_cds)$Size_Factor <- 1
# new_cds <- estimateDispersions(new_cds)

new_cds <- setOrderingFilter(new_cds, row.names(new_cds)[3:30])
new_cds <- reduceDimension(new_cds, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F)
new_cds <- orderCells(new_cds)
plot_cell_trajectory(new_cds, color_by = 'Time')
plot_cell_trajectory(new_cds, color_by = 'State')

new_cds <- orderCells(new_cds, root_state = 3)
plot_genes_in_pseudotime(new_cds[c("pCD3z(Lu175)Dd",
                                   "pErk1_2(Er167)Dd",
                                   "pSLP76(Gd156)Dd",
                                   "pS6(Yb172)Dd"), ])  

write.table(file = paste('./csv_data/CD4_naive_series1_CD3_CD28_', 't4m', '.txt', sep = ''), as.matrix(exprs(new_cds[, order(pData(new_cds)$Pseudotime)])), row.names = T, quote = F)

new_cds_subset <- setOrderingFilter(new_cds_subset, row.names(new_cds_subset)[1:4])
new_cds_subset <- reduceDimension(new_cds_subset, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F)
new_cds_subset <- orderCells(new_cds_subset)
plot_cell_trajectory(new_cds_subset, color_by = 'Time')

plot_genes_in_pseudotime(new_cds[c("pCD3z(Lu175)Dd",
                                   "pErk1_2(Er167)Dd",
                                   "pSLP76(Gd156)Dd",
                                   "pS6(Yb172)Dd"), ])  
#save the data: 
write.table(file = paste('./csv_data/CD4_naive_series1_CD3_CD28_', x, '_four_genes.txt', sep = ''), as.matrix(exprs(new_cds_subset[, order(pData(new_cds_subset)$Pseudotime)])), row.names = T, quote = F)

#######################################################################################################################################################################################
# save data:  
#######################################################################################################################################################################################
save.image('./RData/analysis_dremi.RData')
