library(InformationEstimator)
library(destiny)
library(monocle)

# add the test for the RT-PCR experiments
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_RT_PCR.RData')

# ================================================================================================================================================
# Psaila 1
# ================================================================================================================================================
# test on different datasets: 
MOESM2_mega_ery_cds_ery_rdi <- MOESM2_mega_ery_cds_ery 
MOESM2_mega_ery_cds_meg_rdi <- MOESM2_mega_ery_cds_meg 

library(InformationEstimator)
# run DPT to get the diffusion time 
# verify the result with DPT 

# run Ery dataset
dpt_res <- run_new_dpt(MOESM2_mega_ery_cds_ery)
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(MOESM2_mega_ery_cds_ery) * ncol(MOESM2_mega_ery_cds_ery)), nrow = ncol(MOESM2_mega_ery_cds_ery))
MOESM2_mega_ery_cds_ery_rdi <- calculate_rdi(t(exprs(MOESM2_mega_ery_cds_ery)[, order(dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 9.986093 mins

# run Meg dataset
dpt_res <- run_new_dpt(MOESM2_mega_ery_cds_meg)
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(MOESM2_mega_ery_cds_meg) * ncol(MOESM2_mega_ery_cds_meg)), nrow = ncol(MOESM2_mega_ery_cds_meg))
MOESM2_mega_ery_cds_meg_rdi <- calculate_rdi(t(exprs(MOESM2_mega_ery_cds_meg)[, order(dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() #9.204517

ery_rid_network <- MOESM2_mega_ery_cds_ery_rdi[, 1:87]; dimnames(ery_rid_network) <- list(row.names(MOESM2_mega_ery_cds_meg), row.names(MOESM2_mega_ery_cds_meg))
mega_rid_network <- MOESM2_mega_ery_cds_meg_rdi[, 1:87]; dimnames(mega_rid_network) <- list(row.names(MOESM2_mega_ery_cds_meg), row.names(MOESM2_mega_ery_cds_meg))

# run the CLR procedure: 

# make the directed graph 
pheatmap::pheatmap(ery_rid_network)
pheatmap::pheatmap(mega_rid_network)
ery_q <- quantile(ery_rid_network, probs = 0.99)
meg_q <- quantile(mega_rid_network, probs = 0.99)

ery_rid_network_process <- ery_rid_network; ery_rid_network_process[ery_rid_network < ery_q] <- 0
mega_rid_network_process <- mega_rid_network; mega_rid_network_process[mega_rid_network < meg_q] <- 0

ery_graph_res <- igraph::graph_from_adjacency_matrix(ery_rid_network_process, mode = 'directed', weighted = T)
plot(ery_graph_res, layout = layout.fruchterman.reingold(ery_graph_res), vertex.size=2, vertex.label.size=4)

mega_graph_res <- igraph::graph_from_adjacency_matrix(mega_rid_network_process, mode = 'directed', weighted = T)
plot(mega_graph_res, layout = layout.fruchterman.reingold(mega_graph_res), vertex.size=2, vertex.label.size=4)

# plot using ggraph
ery_dg <- decompose.graph(ery_graph_res)
ery_e <- as.data.frame(get.edgelist(ery_dg[[1]])); colnames(ery_e) <- c('Source', 'Target'); ery_e$type <- 'ery'

mega_dg <- decompose.graph(mega_graph_res)
mega_e <- as.data.frame(get.edgelist(mega_dg[[1]])); colnames(mega_e) <- c('Source', 'Target'); mega_e$type <- 'meg'

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/ery_edge.txt', ery_e, sep = '\t', quote = F, col.names = T, row.names = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/mega_edge.txt', mega_e, sep = '\t', quote = F, col.names = T, row.names = F)

all_e <- rbind(ery_e, mega_e)
all_e$type[duplicated(all_e[, 1:2])] <- 'all'
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/all_e.txt', all_e, sep = '\t', quote = F, col.names = T, row.names = F)

# save the network to a file for manipulation in Cytoscape 
l <- qgraph.layout.fruchtermanreingold(e, vcount=vcount(dg[[1]]))
plot(dg[[1]], vertex.color='black', vertex.label=V(dg[[1]])$name, edge.arrow.size=.6, 
     vertex.label.color="white", vertex.label.size = 3, layout = layout.fruchterman.reingold(dg[[1]]))

plot(dg[[2]], vertex.color='black', vertex.label=V(dg[[2]])$name, edge.arrow.size=.6, 
     vertex.label.color="white", vertex.label.size = 3, layout = layout_nicely(dg[[2]]))

# ================================================================================================================================================
# Dataset 2: Moignard
exprs(new_cds) <- as.matrix(exprs(new_cds))
GMP_branch_cds <- new_cds[, pData(new_cds)$State %in% GMP_states]
CLP_branch_cds <- new_cds[, pData(new_cds)$State %in% CLP_states]
preMegE_branch_cds <- new_cds[, pData(new_cds)$State %in% preMegE_states]

# run Meg dataset
GMP_dpt_res <- run_new_dpt(GMP_branch_cds)
CLP_dpt_res <- run_new_dpt(CLP_branch_cds)
pregMegE_dpt_res <- run_new_dpt(preMegE_branch_cds)

# run Ery dataset
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(GMP_branch_cds) * ncol(GMP_branch_cds)), nrow = ncol(GMP_branch_cds))
GMP_branch_cds_rdi <- calculate_rdi(t(exprs(GMP_branch_cds)[, order(GMP_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 9.986093 mins

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(CLP_branch_cds) * ncol(CLP_branch_cds)), nrow = ncol(CLP_branch_cds))
CLP_branch_cds_rdi <- calculate_rdi(t(exprs(CLP_branch_cds)[, order(CLP_branch_cds$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 9.986093 mins

a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(preMegE_branch_cds) * ncol(preMegE_branch_cds)), nrow = ncol(preMegE_branch_cds))
preMegE_branch_cds_rdi <- calculate_rdi(t(exprs(preMegE_branch_cds)[, order(pregMegE_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 9.986093 mins

# ================================================================================================================================================
# Dataset 3: Guo
State2_branch_cds <- guo_norm_cds[, pData(guo_norm_cds)$State %in% c(1, 2)]
State3_branch_cds <- guo_norm_cds[, pData(guo_norm_cds)$State %in%  c(1, 3)]

State2_branch_cds_dpt_res <- run_new_dpt(State2_branch_cds)
State3_branch_cds_dpt_res <- run_new_dpt(State3_branch_cds)

# run Ery dataset
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(State2_branch_cds) * ncol(State2_branch_cds)), nrow = ncol(State2_branch_cds))
State2_branch_cds_rdi <- calculate_rdi(t(exprs(State2_branch_cds)[, order(State2_branch_cds_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 9.986093 mins

# run Ery dataset
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(State3_branch_cds) * ncol(State3_branch_cds)), nrow = ncol(State3_branch_cds))
State3_branch_cds_rdi <- calculate_rdi(t(exprs(State3_branch_cds)[, order(State3_branch_cds_dpt_res$pt)]) + noise, c(5, 10, 15), 3L)
b <- Sys.time() # 1.680862 mins
b -a 

State2_branch_cds_rdi_subset <- as.data.frame(State2_branch_cds_rdi[, 1:48]); dimnames(State2_branch_cds_rdi_subset) <- list(row.names(State2_branch_cds), row.names(State2_branch_cds)) 
State3_branch_cds_rdi_subset <- as.data.frame(State3_branch_cds_rdi[, 1:48]); dimnames(State3_branch_cds_rdi_subset) <- list(row.names(State3_branch_cds), row.names(State3_branch_cds)) 
state_2_quantile_res <- quantile_selection_network(State2_branch_cds_rdi_subset, experiment = 'state_2')
state_3_quantile_res <- quantile_selection_network(State3_branch_cds_rdi_subset, experiment = 'state_3')

all_e <- rbind(state_2_quantile_res, state_3_quantile_res)
all_e$type[duplicated(all_e[, 1:2])] <- 'all'
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cytoscape/all_e_Guo.txt', all_e, sep = '\t', quote = F, col.names = T, row.names = F)

# ================================================================================================================================================
# Dataset 4: Moignard (3000 + cells)
Moignard_blood_2015_mat$DPT
branch_1_dat <- Moignard_blood_2015_mat$data[Moignard_blood_2015_mat$Branch %in% c(1, 0, 3), ]
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(branch_1_dat) * ncol(branch_1_dat)), nrow = nrow(branch_1_dat))
# branch1 <- calculate_rdi(branch_1_dat + noise, c(5, 10, 15), 3L) # break here
b <- Sys.time() # 9.986093 mins
save(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/branch_1_dat', branch_1_dat)

# run Ery dataset
branch_2_dat <- Moignard_blood_2015_mat$data[Moignard_blood_2015_mat$Branch %in% c(1, 2), ]
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(branch_2_dat) * ncol(branch_2_dat)), nrow = nrow(branch_2_dat))
State2_branch_cds_rdi <- calculate_rdi(branch_2_dat + noise, c(5, 10, 15), 3L) # this part is superslow 
b <- Sys.time() # 9.986093 mins
save(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/branch_2_dat', branch_2_dat)

# ================================================================================================================================================
# Dataset 5: Moignard (620 + cells)

# ================================================================================================================================================
# Dataset 6: 
Kalliopi_dat <- exprs(Kalliopi_cds)
a <- Sys.time()
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(Kalliopi_dat) * ncol(Kalliopi_dat)), nrow = nrow(Kalliopi_dat))
Kalliopi_dat_rdi <- calculate_rdi(Kalliopi_dat + noise, c(5, 10, 15), 3L) # this part is superslow 
b <- Sys.time() # 9.986093 mins

save(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Kalliopi_dat', Kalliopi_dat)

################################################################################################################################################################################
# save the result 
################################################################################################################################################################################

save.image('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/RT_PCR.RData')

