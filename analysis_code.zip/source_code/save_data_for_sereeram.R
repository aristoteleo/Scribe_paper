#functions to save data for collaboration with Sereeram: 
write.table(gene_ids, row.names = F, col.names = F, quote = F, file = './gene_ids.txt')

order_HSMM_myo <- HSMM_myo[, order(pData(HSMM_myo)$Pseudotime)]
write.table(exprs(order_HSMM_myo), row.names = T, col.names = T, quote = F, file = './expr_mat.txt')
write.table(fData(order_HSMM_myo), row.names = T, col.names = T, quote = F, file = './gene_feature.txt')
write.table(pData(order_HSMM_myo), row.names = T, col.names = T, quote = F, file = './cell_feature.txt')
