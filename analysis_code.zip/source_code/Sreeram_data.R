#save the data to sreeram: 
source("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/functions/function.R")
source("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/functions/plotting.R")

shalek_custom_color_scale = c("Unstimulated."="#eff3ff", "On_Chip_Unstim."="#eff3ff", "LPS.1h"="#bdd7e7", "LPS.2h"="#6baed6", "LPS.4h"="#3182bd", "LPS.6h"="#08519c", "PIC.1h"="#bae4b3", "PIC.2h"="#74c476", "PIC.4h"="#31a354", "PIC.6h"="#006d2c", "PAM.1h"="#fdbe85", "PAM.2h"="#fd8d3c", "PAM.4h"="#e6550d", "PAM.6h"="#a63603", "LPS_GolgiPlug.4h_0h"="#fcae91", "LPS_GolgiPlug.4h_1h"="#fb6a4a", "LPS_GolgiPlug.4h_2h"="#cb181d", "Ifnar1_KO_LPS.2h"="#df65b0", "Ifnar1_KO_LPS.4h"="#dd1c77", "Stat1_KO_LPS.2h"="#969696", "Stat1_KO_LPS.4h"="#252525")
shalek_custom_color_scale_plus_states= c(shalek_custom_color_scale, c('1'='#40A43A', '2'='#CB1B1E', '3'='#3660A5', 'Unstimulated_Replicate.' = 'gray'))

library(devtools)
load_all('/Users/xqiu/Dropbox (Personal)/Projects/monocle-dev/')
library(igraph)
library(R.matlab)
library(stringr)

#muscle data: 
load('/Users/xqiu/Downloads/analysis_HSMM_data.RData')
HSMM <- newCellDataSet(as.matrix(HSMM),
               phenoData = new("AnnotatedDataFrame", data = pData(HSMM)),
               featureData = new("AnnotatedDataFrame", data = fData(HSMM)),
               expressionFamily = tobit(),
               lowerDetectionLimit = 1)

gene_ids <- row.names(subset(fData(sc_time_course_ec_cds), gene_short_name %in% c('MYH3', 'MYOG', 'ID1', 'ENO3', 'CCNB2', 'CDK1', 'CCNB1'))) # 'MEF2C', 'TNNT1', 
HSMM_valid <- HSMM[, colnames(sc_time_course_ec_cds)]
HSMM_valid <- setOrderingFilter(HSMM_valid, gene_ids)
HSMM_valid <- estimateSizeFactors(HSMM_valid)
HSMM_valid_norm_data <- convert2DRData(HSMM_valid, norm_method = 'log')
HSMM_valid_DDRTree_res <- DDRTree(HSMM_valid_norm_data, dimensions = 2, verbose = T) #, maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2

#calculate the pseudotime and compare with the real time:
qplot(HSMM_valid_DDRTree_res$Y[1, ], HSMM_valid_DDRTree_res$Y[2, ], color = pData(HSMM_valid)$Time)
HSMM_valid_ordering_res <- custom_ordering(HSMM_valid_DDRTree_res, branch_num = 1)
qplot(HSMM_valid_DDRTree_res$Y[1, as.numeric(row.names(HSMM_valid_ordering_res$cc_ordering))], HSMM_valid_DDRTree_res$Y[2, as.numeric(row.names(HSMM_valid_ordering_res$cc_ordering))], 
      color = HSMM_valid_ordering_res$cc_ordering$cell_state, size = HSMM_valid_ordering_res$cc_ordering$pseudo_time)

order_HSMM_mat <- exprs(HSMM_valid)[, as.numeric(row.names(HSMM_valid_ordering_res$cc_ordering))]
pd <- pData(HSMM_valid[, colnames(order_HSMM_mat)])
pd$State <- HSMM_valid_ordering_res$cc_ordering$cell_state
pd$Pseudotime <- HSMM_valid_ordering_res$cc_ordering$pseudo_time

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/HSMM_order_mat.txt', order_HSMM_mat, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/HSMM_gene_feature.txt', fData(HSMM_valid), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/HSMM_cell_feature.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/HSMM_important_genes.txt', gene_ids, col.names = F, sep = '\t', row.names = F, quote = F)

rm(list = ls())

#lung data: 
load('/Users/xqiu/Dropbox (Personal)/Projects/BEAM/third_submission/RData/prepare_lung_data.RData')

standard_cds <- setOrderingFilter(standard_cds, quake_id)
lung_norm_data <- convert2DRData(standard_cds, norm_method = 'log')
lung_DDRTree_res <- DDRTree(lung_norm_data, dimensions = 2, verbose = T) #, maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2

#calculate the pseudotime and compare with the real time:
qplot(lung_DDRTree_res$Y[1, ], lung_DDRTree_res$Y[2, ], color = pData(absolute_cds)$Time)
lung_ordering_res <- custom_ordering(lung_DDRTree_res, branch_num = 2, root_cell = '160')
qplot(lung_DDRTree_res$Y[1, as.numeric(row.names(lung_ordering_res$cc_ordering))], lung_DDRTree_res$Y[2, as.numeric(row.names(lung_ordering_res$cc_ordering))], 
      color = lung_ordering_res$cc_ordering$cell_state, size = lung_ordering_res$cc_ordering$pseudo_time)

order_lung_mat <- exprs(standard_cds)[, as.numeric(row.names(lung_ordering_res$cc_ordering))]
pd <- pData(standard_cds[, colnames(order_lung_mat)])
pd$State <- lung_ordering_res$cc_ordering$cell_state
pd$Pseudotime <- lung_ordering_res$cc_ordering$pseudo_time

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/lung_order_mat.txt', order_lung_mat, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/lung_gene_feature.txt', fData(standard_cds), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/lung_cell_feature.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/lung_important_genes.txt', quake_gene_name, col.names = F, sep = '\t', row.names = F, quote = F)

rm(list = ls())
#shalek data: 
load('/Users/xqiu/Desktop/analysis_shalek_data.RData')

Shalek_standard_cds <- setOrderingFilter(Shalek_std[, colnames(Shalek_abs_subset_ko_LPS)], 
                                         row.names(Shalek_abs_subset_ko_LPS)[fData(Shalek_abs_subset_ko_LPS)$use_for_ordering])
Shalek_norm_data <- convert2DRData(Shalek_standard_cds, norm_method = 'log')
Shalek_DDRTree_res <- DDRTree(Shalek_norm_data, dimensions = 2, verbose = T) #, maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2

#calculate the pseudotime and compare with the real time:
qplot(Shalek_DDRTree_res$Y[1, ], Shalek_DDRTree_res$Y[2, ], color=interaction(pData(Shalek_abs_subset_ko_LPS)$experiment_name, pData(Shalek_abs_subset_ko_LPS)$time)) + 
  scale_color_manual(values=shalek_custom_color_scale_plus_states)

Shalek_ordering_res <- custom_ordering(Shalek_DDRTree_res, branch_num = 2, root_cell = "359")
qplot(Shalek_DDRTree_res$Y[1, as.numeric(row.names(Shalek_ordering_res$cc_ordering))], Shalek_DDRTree_res$Y[2, as.numeric(row.names(Shalek_ordering_res$cc_ordering))], 
      color = Shalek_ordering_res$cc_ordering$cell_state, size = Shalek_ordering_res$cc_ordering$pseudo_time)

order_shalek_mat <- exprs(Shalek_std)[, as.numeric(row.names(Shalek_ordering_res$cc_ordering))]
pd <- pData(Shalek_std[, colnames(order_shalek_mat)])
pd$State <- Shalek_ordering_res$cc_ordering$cell_state
pd$Pseudotime <- Shalek_ordering_res$cc_ordering$pseudo_time

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Shalek_order_mat.txt', order_shalek_mat, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Shalek_gene_feature.txt', fData(Shalek_std), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Shalek_cell_feature.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/Shalek_branching_genes.txt', ko_branching_genes, col.names = T, sep = '\t', row.names = T, quote = F)

rm(list = ls())

#the drop-seq data: 
###############################################################################################################################################################################################
DropSeq_ESCdata <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/dpt_8_30.mat')

#look at a few genes: 
qplot(DropSeq_ESCdata$DPT, DropSeq_ESCdata$datacc[, 2], size = DropSeq_ESCdata$DPT, color = factor(DropSeq_ESCdata$Branch))

#plot the reduced dimension: 
qplot(DropSeq_ESCdata$phi[, 2], DropSeq_ESCdata$phi[, 3], size = DropSeq_ESCdata$DPT, color = factor(DropSeq_ESCdata$Branch))

#
order_dropseq_esc_mat <- t(DropSeq_ESCdata$datacc[order(DropSeq_ESCdata$DPT), ])
row.names(order_dropseq_esc_mat) <- unlist(DropSeq_ESCdata$cc.genes)
colnames(order_dropseq_esc_mat) <- paste('Cell', 1:ncol(order_dropseq_esc_mat), sep = '_')

pd <- data.frame(Pseudotime = sort(DropSeq_ESCdata$DPT), State = DropSeq_ESCdata$Branch, row.names = paste('Cell', 1:ncol(order_dropseq_esc_mat), sep = '_'))
fd <- data.frame(gene_short_name = row.names(order_dropseq_esc_mat), row.names = row.names(order_dropseq_esc_mat))

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/dropseq_esc_mat.txt', order_dropseq_esc_mat, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/dropseq_esc_cell_feature.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Sreeram_data/dropseq_esc_gene_feature.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)

###separate it into different datasets: 


############################################plot_ly####################################################################################################################################################
#first select genes before perform the DDRTree tree construction:
dim(DropSeq_ESCdata$dataraw)
dimnames(DropSeq_ESCdata$dataraw) <- list(paste('cell', 1:2717, sep = '_'), paste('gene', 1:24174, sep = '_'))
fstree_res_ESC_dropseq_landmark <- fstree(t(DropSeq_ESCdata$dataraw), initial_method = PCA, maxIter = maxIter, eps = 1e-5, dim = 3, cell_time = NULL, C_constant = 0.1,  lambda = 1,  gamma = 1, sigma = 1 , num_landmarks = 500, verbose = T)
# fstree_res_slicer_DM <- fstree_centroid(t(toydata3B$toydata3B[, 1:4]), initial_method = LLE, maxIter = maxIter, eps = 1e-5, dim = d, ncenter = NULL, cell_time = NULL, C_constant = 0.1,  lambda = 1,  gamma = 1, sigma = 1 , num_landmarks = NULL, verbose = T)

genes <- colnames(DropSeq_ESCdata$dataraw)[order(fstree_res_ESC_dropseq_landmark$weights, decreasing = T)][1:300]

drop_seq_DDRTree_res <- DDRTree(t(DropSeq_ESCdata$data[, genes]), dimensions = 3, verbose = T, ncenter = 1000) #, maxIter = 5, sigma = 1e-2, lambda = 1, ncenter = 3, param.gamma = 10, tol = 1e-2
qplot(drop_seq_DDRTree_res$Y[1, ], drop_seq_DDRTree_res$Y[2, ], color = as.factor(toydata3B$Branch))

#10x genomics data: 
#use the clustering results of the genes:  
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/subset_pbmc_cds_use_grace_tSNE.RData')

pbmc_10x_mat <- exprs(subset_pbmc_cds_use_grace_tSNE)
write.table(file = './Sreeram_data/pbmc_10x_mat.txt', as.matrix(pbmc_10x_mat), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './Sreeram_data/pbmc_10x_gene_feature.txt', fData(subset_pbmc_cds_use_grace_tSNE), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './Sreeram_data/pbmc_10x_cell_feature.txt',  pData(subset_pbmc_cds_use_grace_tSNE), col.names = T, sep = '\t', row.names = T, quote = F)

rm(list = ls())

#the blood data: 
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig5.RData')

#look at a few genes: 
plot_cell_trajectory(URMM_all_fig1b)

URMM_all_fig1b <- reduceDimension(URMM_all_fig1b, auto_param_selection = F, verbose = T, maxIter = 100)
URMM_all_fig1b <- orderCells(URMM_all_fig1b)
URMM_all_fig1b <- trimTree(URMM_all_fig1b)

plot_cell_trajectory(URMM_all_fig1b, color_by = 'State')
plot_cell_trajectory(URMM_all_fig1b, color_by = 'paper_cluster')
plot_cell_trajectory(URMM_all_fig1b, color_by = 'Pseudotime')

# network for the gene: 
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/res')

# save the network 
blood_edge_list <- as_edgelist(res$g, names=T)

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_edge_list.txt', blood_edge_list, col.names = T, sep = '\t', row.names = F, quote = F)

gene_list <- unique(c(blood_edge_list[, 1], blood_edge_list[, 2]))
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_gene_list.txt', gene_list, col.names = T, sep = '\t', row.names = F, quote = F)

valid_ids <- as.character(unique(gene_list))
#plot the reduced dimension: 
order_hbp_mat <- as.matrix(exprs(URMM_all_fig1b)[valid_ids, order(pData(URMM_all_fig1b)$Pseudotime)])

order_hbp_mat_state12 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(1, 2)] #monocyte
order_hbp_mat_state13 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(1, 3)] #granulocyte

#smooth the data: 
order_hbp_mat_pscl_smooth_granulocyte <- pscl_smooth_genes_exp_coef(t(order_hbp_mat_state13), window_size = 20)
order_hbp_mat_pscl_smooth_monocyte <-  pscl_smooth_genes_exp_coef(t(order_hbp_mat_state12), window_size = 20)

order_hbp_mat_pscl_smooth_granulocyte_ori <- pscl_smooth_genes(t(order_hbp_mat_state13), window_size = 20)
order_hbp_mat_pscl_smooth_monocyte_ori <- pscl_smooth_genes(t(order_hbp_mat_state12), window_size = 20)

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_hbp_mat_pscl_smooth_monocyte_exp_beta.txt', order_hbp_mat_pscl_smooth_monocyte_t, col.names = T, sep = '\t', row.names = T, quote = F)

pd <- pData(URMM_all_fig1b[, colnames(order_hbp_mat)])
fd <- fData(URMM_all_fig1b)

# write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_magic.txt', order_hbp_mat, col.names = T, sep = '\t', row.names = T, quote = F)
# write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_phenotype_data.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
# write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)


#monocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state12_exp_beta.txt', t(order_hbp_mat_pscl_smooth_monocyte), col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state13_exp_beta.txt', t(order_hbp_mat_pscl_smooth_granulocyte), col.names = T, sep = '\t', row.names = T, quote = F)

order_hbp_mat_state1 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(1)] 
order_hbp_mat_state2 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(2)] 
order_hbp_mat_state3 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(3)] 
#progenitor
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state1_magic.txt', order_hbp_mat_state1, col.names = T, sep = '\t', row.names = T, quote = F)
#monocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state2_magic.txt', order_hbp_mat_state2, col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state3_magic.txt', order_hbp_mat_state3, col.names = T, sep = '\t', row.names = T, quote = F)

#
# mgst2    fam60a
# limd1    acap1
# dstn    irf9
# dstn    flot1
# tmem229b    acap1
# meis1    flot1
# ets1    fam60a

row.names(URMM_all_fig1b)[fData(URMM_all_fig1b)$gene_short_name %in% c("mgst2", "fam60a")]
plot_genes_in_pseudotime(URMM_all_fig1b[c("Ets1", "Fam60a"),  pData(URMM_all_fig1b)$State %in% c(1, 2)])

valid_ids <- as.character(blood_gene_list$x)
monocyte_cds_subset <- URMM_all_fig1b[valid_ids, !(pData(URMM_all_fig1b)$State %in% c(1, 2))]
granulocyte_cds_subset <- URMM_all_fig1b[valid_ids, !(pData(URMM_all_fig1b)$State %in% c(1, 3))]

monocyte_mat <- t(as.matrix(exprs(monocyte_cds_subset[, order(pData(monocyte_cds_subset)$Pseudotime)])))
granulocyte_mat <- t(as.matrix(exprs(granulocyte_cds_subset[, order(pData(granulocyte_cds_subset)$Pseudotime)])))

monocyte_parallel_res <- parallelCCM(ordered_exprs_mat = monocyte_mat, cores = detectCores()) #row is cell, column is gene
monocyte_parallel_res_mat <- prepare_ccm_res(monocyte_parallel_res)
granulocyte_parallel_res <- parallelCCM(ordered_exprs_mat = granulocyte_mat, cores = detectCores())
granulocyte_parallel_res_mat <- prepare_ccm_res(granulocyte_parallel_res)


pdf('mar_seq_gmp_ccm.pdf', width = 10, height = 10)
pheatmap(monocyte_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
dev.off()

gene_names <- colnames(monocyte_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = monocyte_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'monocyte_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = granulocyte_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'granulocyte_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

#granger causality: 
file.remove(c('monocyte_granger_res', 'granulocyte_granger_res'))
monocyte_granger_res <- parallel_cal_grangertest(monocyte_mat[, ], filename = 'monocyte_granger_res', delays = c(1, 11, 21))
granulocyte_granger_res <- parallel_cal_grangertest(granulocyte_mat, filename = 'granulocyte_granger_res', delays = c(1, 11, 21))


###############################################################################################################################################################################################
# MAR-seq dataset
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig_SI6.RData')

plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'cell_type')

all_wt_GSE72857_cds <- reduceDimension(all_wt_GSE72857_cds, auto_param_selection = F, verbose = T, maxIter = 100)
all_wt_GSE72857_cds <- orderCells(all_wt_GSE72857_cds)

all_wt_GSE72857_cds <- trimTree(all_wt_GSE72857_cds)

plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'cell_type')
plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'Pseudotime')
plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'State') + facet_grid(~State)

all_wt_GSE72857_cds <- orderCells(all_wt_GSE72857_cds, root_state = 2)

###############################################################################################################################################################################################
# save the data into data files: 
###############################################################################################################################################################################################
exprs(all_wt_GSE72857_cds)
match_ids <- which(row.names(all_wt_GSE72857_cds) %in% as.character(blood_gene_list$x))
miss_ids <- unlist(lapply(blood_gene_list$x[!(as.character(blood_gene_list$x) %in% row.names(all_wt_GSE72857_cds))], function(x) grep(x, row.names(all_wt_GSE72857_cds)) ))
valid_ids <- c(match_ids, miss_ids)
  
write.table(file = './csv_data/erythroid_branch_marseq_data_exprs_all.txt', as.matrix(exprs(all_wt_GSE72857_cds[, pData(all_wt_GSE72857_cds)$State %in% 1:5])), 
            col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/erythroid_branch_marseq_data_exprs_only_markers.txt', 
            as.matrix(exprs(all_wt_GSE72857_cds[valid_ids, pData(all_wt_GSE72857_cds)$State %in% 1:5])), 
            col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/GMP_branch_marseq_data_exprs_all.txt', as.matrix(exprs(all_wt_GSE72857_cds[, !(pData(all_wt_GSE72857_cds)$State %in% 1:5)])), 
            col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/GMP_branch_marseq_data_exprs_only_markers.txt', 
            as.matrix(exprs(all_wt_GSE72857_cds[valid_ids, !(pData(all_wt_GSE72857_cds)$State %in% 1:5)])), 
            col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/marseq_data_fdata_2_14.txt', fData(all_wt_GSE72857_cds), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/marseq_data_pdata_2_14.txt', pData(all_wt_GSE72857_cds), col.names = T, sep = '\t', row.names = T, quote = F)

###############################################################################################################################################################################################
# Dataset 3 from SCODE paper
###############################################################################################################################################################################################
sc_time_course_ec <- read.csv('csv_data/GSE75748_sc_time_course_ec.csv', row.names = 1)
pd <- as.data.frame(str_split_fixed(colnames(sc_time_course_ec), '_|\\.', 3))
row.names(pd) <- colnames(sc_time_course_ec)
fd <- data.frame(row.names = row.names(sc_time_course_ec), gene_short_name = row.names(sc_time_course_ec))

sc_time_course_ec_cds <- newCellDataSet(as(as.matrix(sc_time_course_ec), 'sparseMatrix'),
                       phenoData = new("AnnotatedDataFrame", data = pd),
                       featureData = new("AnnotatedDataFrame", data = fd),
                       expressionFamily = negbinomial.size(),
                       lowerDetectionLimit = 1)

pData(sc_time_course_ec_cds)$Time <- pData(sc_time_course_ec_cds[, colnames(sc_time_course_ec_cds)])$V2

#1. determine how many pca dimension you want:
sc_time_course_ec_cds <- detectGenes(sc_time_course_ec_cds)
sc_time_course_ec_cds <- estimateSizeFactors(sc_time_course_ec_cds)
sc_time_course_ec_cds <- estimateDispersions(sc_time_course_ec_cds)

fData(sc_time_course_ec_cds)$use_for_ordering <- fData(sc_time_course_ec_cds)$num_cells_expressed > round(ncol(sc_time_course_ec_cds) / 10)
sc_time_course_ec_cds@auxClusteringData[["tSNE"]]$variance_explained <- NULL
plot_pc_variance_explained(sc_time_course_ec_cds, return_all = F)

#2. run reduceDimension with tSNE as the reduction_method
sc_time_course_ec_cds <- reduceDimension(sc_time_course_ec_cds, max_components=2, norm_method = 'log', num_dim = 9, reduction_method = 'tSNE', verbose = T)

#3. initial run of clusterCells_Density_Peak
sc_time_course_ec_cds <- clusterCells_Density_Peak(sc_time_course_ec_cds, verbose = T)

#4. check the clusters (there are three clusters)
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Time)', show_density = F)

#5. also check the decision plot
plot_rho_delta(sc_time_course_ec_cds, rho_threshold = 3.8, delta_threshold = 12)
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Cluster)', show_density = F, rho_threshold = 3.8, delta_threshold = 12)
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Time)', show_density = F, rho_threshold = 3.8, delta_threshold = 12)

#6. re-run cluster and skipping calculating the rho_sigma
sc_time_course_ec_cds <- clusterCells_Density_Peak(sc_time_course_ec_cds, verbose = T,  rho_threshold = 3.8, delta_threshold = 12, skip_rho_sigma = T)

#7. make the final clustering plot:
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(sc_time_course_ec_cds, color_by = 'as.factor(Time)', show_density = F)

#find the important genes and use that for lineage tree construction
#perform DEG test across clusters:
sc_time_course_ec_cds@expressionFamily <- negbinomial.size()
pData(sc_time_course_ec_cds)$Cluster <- as.character(pData(sc_time_course_ec_cds)$Cluster)
sc_time_course_ec_cds_DEG_genes <- differentialGeneTest(sc_time_course_ec_cds, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)
# sc_time_course_ec_cds_DEG_genes_subset <- sc_time_course_ec_cds[fData(sc_time_course_ec_cds)$num_cells_expressed > round(ncol(sc_time_course_ec_cds) / 10, ]

#use all DEG gene from the clusters
sc_time_course_ec_cds_ordering_genes <- row.names(sc_time_course_ec_cds_DEG_genes)[order(sc_time_course_ec_cds_DEG_genes$qval)][1:1000] #row.names(subset(sc_time_course_ec_cds_DEG_genes, qval < qval_thrsld))

# sc_time_course_ec_cds_ordering_genes <- row.names(sc_time_course_ec_cds_clustering_DEG_genes_subset)[order(sc_time_course_ec_cds_clustering_DEG_genes_subset$qval)][1:1000]
sc_time_course_ec_cds_ordering_genes

sc_time_course_ec_cds <- setOrderingFilter(sc_time_course_ec_cds, ordering_genes = sc_time_course_ec_cds_ordering_genes)
sc_time_course_ec_cds <- reduceDimension(sc_time_course_ec_cds, verbose = T, auto_param_selection = F)
sc_time_course_ec_cds <- orderCells(sc_time_course_ec_cds)
plot_cell_trajectory(sc_time_course_ec_cds, color_by = 'Cluster')
plot_cell_trajectory(sc_time_course_ec_cds, color_by = 'Time') 
plot_cell_trajectory(sc_time_course_ec_cds, color_by = 'Time') + facet_wrap(~Time)

plot_cell_trajectory(sc_time_course_ec_cds, color_by = 'Pseudotime') + facet_wrap(~Time)

#get the human TF list: 
human_TFs <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/ human_TFs.txt', header = T, sep = '\t')
all_genes_in_network <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/all.filtered.transfac.txt', header = F, sep = '\t')
valid_human_TFs <- intersect(human_TFs$Symbol, all_genes_in_network$V1)
TFs_ids <- row.names(subset(fData(sc_time_course_ec_cds), gene_short_name %in% valid_human_TFs))

top100_genes <- as.character(unique(fData(sc_time_course_ec_cds)[names(sort(apply(exprs(sc_time_course_ec_cds)[TFs_ids, ], 1, var), decreasing=T))[1:100], 'gene_short_name']))


write.table(file = './csv_data/sc_time_course_ec_exprs_data.csv', 
            as.matrix(exprs(sc_time_course_ec_cds[, order(pData(sc_time_course_ec_cds)$Pseudotime)])), 
            col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/sc_time_course_ec_exprs_data_fdata.csv', fData(sc_time_course_ec_cds), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/sc_time_course_ec_exprs_data_fdata.csv', pData(sc_time_course_ec_cds), col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/sc_time_course_ec_exprs_data_top100_TFs.csv', 
            as.matrix(exprs(sc_time_course_ec_cds[top100_genes, order(pData(sc_time_course_ec_cds)$Pseudotime)])), 
            col.names = T, sep = '\t', row.names = T, quote = F)
###############################################################################################################################################################################################
# save the data to RData
###############################################################################################################################################################################################
save.image('./RData/all_wt_GSE72857_cds.RData')

