Thomas_test_data <- data.frame()

df <- data.frame(lineage = pData(subset_cds)$Lineage, exprs = exprs(subset_cds)[1, ], time = pData(subset_cds)$time)
qplot(time, exprs, data = df, color = lineage, facets = '~lineage') + geom_vline(xintercept = 280)

df <- subset(df, time <= 280)
df$exprs <- df$exprs + min(df$exprs)

vglm_fit <- glm(round(exprs) ~ sm.ns(time, df = 3) * lineage, data = df, family = poisson())
pre_res <- predict(vglm_fit, type = 'response')

vglm_fit_null <- glm(round(exprs) ~ sm.ns(time, df = 3), data = df, family = poisson())
nul_pre_res <- predict(vglm_fit_null, type = 'response')

lrt <- lrtest(vglm_fit, vglm_fit_null) 
pval <- lrt@Body["Pr(>Chisq)"][2,]
pval

smooth_df <- data.frame(lineage = pData(subset_cds)[row.names(df), 'Lineage'], exprs = as.numeric(pre_res[, 1]), time = pData(subset_cds)[row.names(df), 'time'])
qplot(time, exprs, data = smooth_df, color = lineage, facets = '~lineage')

null_smooth_df <- data.frame(lineage = pData(subset_cds)[row.names(df), 'Lineage'], exprs = as.numeric(nul_pre_res[, 1]), time = pData(subset_cds)[row.names(df), 'time'])
qplot(time, exprs, data = null_smooth_df)

plot_lineage_expression <- function (cds, gene_names, ddata, lineage_tree, lineage_coordinates, 
                                     root_cell, lineage_depth = NULL, expression_threshold = 2000, 
                                     show_lineage_pair = FALSE, label_x = 0.45, label_y = 1, return_all = FALSE, 
                                     ...) 
{
  if (!all(grep("_", colnames(cds)))) {
    stop("Column of the cds should start with the cell name and then the underscore _")
  }
  grep_all_lineage_tree_cells <- lapply(V(lineage_tree)$name, 
                                        function(x) {
                                          grep(paste0("^", x, "_"), colnames(cds))
                                        })
  if (!all(unlist(lapply(grep_all_lineage_tree_cells, length)) > 
           0)) {
    missing_cells <- V(lineage_tree)$name[which(!(unlist(lapply(grep_all_lineage_tree_cells, 
                                                                length)) > 0))]
    warning(paste0(unique(missing_cells), " is not included in the graph of lineage_tree stored in the cds object"))
  }
  reachable_cells_list <- graph.neighborhood(lineage_tree, 
                                             length(V(lineage_tree)), nodes = root_cell, "out")
  reachable_cells <- V(reachable_cells_list[[1]])$name
  offspring <- V(graph.neighborhood(lineage_tree, 1, nodes = root_cell, 
                                    "out")[[1]])$name[-1]
  subset_ddata <- subset(ddata)
  mathced_cells <- unlist(lapply(unique(c(as.character(subset_ddata$father), 
                                          as.character(subset_ddata$target))), function(x) colnames(cds)[grep(paste0("^", 
                                                                                                                     x, "_"), colnames(cds))]))
  marker_expression <- as.matrix(exprs(cds)[gene_names, mathced_cells])
  mlt_marker_expression <- melt(marker_expression)
  mlt_marker_expression <- cbind(mlt_marker_expression, str_split_fixed(mlt_marker_expression[, 
                                                                                              1], "_", 2))
  colnames(mlt_marker_expression)[4:5] <- c("cell", "y")
  mlt_marker_expression$y <- pData(cds)[as.character(mlt_marker_expression[, 
                                                                           1]), "time"]
  mlt_marker_expression$x <- lineage_coordinates[as.character(mlt_marker_expression$cell), 
                                                 "x"]
  if (show_lineage_pair == FALSE) {
    p <- ggplot(data = subset_ddata) + scale_y_reverse() + 
      geom_segment(aes(x = x_start, y = y_start, xend = x_end, 
                       yend = y_end)) + xlab("") + ylab("Time (min)") + 
      geom_segment(aes(x = x, y = y, xend = x, yend = y + 
                         1, color = value), data = subset(mlt_marker_expression, 
                                                          cell %in% reachable_cells_a)) + scale_color_viridis(name = paste0("Expression")) + 
      theme(axis.title.x = element_blank(), axis.text.x = element_blank(), 
            axis.ticks.x = element_blank(), axis.line = element_blank())
    if (!is.null(lineage_depth)) {
      p + ylim(lineage_depth, min(subset_ddata$x_start))
    }
  }
  else if (show_lineage_pair == TRUE) {
    reachable_cells_a <- graph.neighborhood(lineage_tree, 
                                            length(V(lineage_tree)), nodes = offspring[1], "out")
    reachable_cells_a <- V(reachable_cells_a[[1]])$name
    reachable_cells_p <- graph.neighborhood(lineage_tree, 
                                            length(V(lineage_tree)), nodes = offspring[2], "out")
    reachable_cells_p <- V(reachable_cells_p[[1]])$name
    subset_ddata <- subset(ddata, father %in% reachable_cells_a & 
                             target %in% reachable_cells_a)
    A_lineage <- ggplot(data = subset_ddata) + geom_segment(aes(x = x_start, 
                                                                y = y_start, xend = x_end, yend = y_end), size = 2) + 
      xlab("") + ylab("Time (min)") + geom_segment(aes(x = x, 
                                                       y = y, xend = x, yend = y + 1, color = value > expression_threshold), 
                                                   size = 2, data = subset(mlt_marker_expression, cell %in% 
                                                                             reachable_cells_a)) + scale_color_viridis(name = paste0("Expressed"), 
                                                                                                                       discrete = T) + theme(axis.title.x = element_blank(), 
                                                                                                                                             axis.text.x = element_blank(), axis.ticks.x = element_blank(), 
                                                                                                                                             axis.line = element_blank())
    if (!is.null(lineage_depth)) {
      A_lineage <- A_lineage + ylim(lineage_depth, min(subset_ddata$x_start))
    }
    subset_ddata <- subset(ddata, father %in% reachable_cells_p & 
                             target %in% reachable_cells_p)
    P_lineage <- ggplot(data = subset_ddata) + scale_y_reverse() + 
      geom_segment(aes(x = x_start, y = y_start, xend = x_end, 
                       yend = y_end), size = 2) + xlab("") + ylab("Time (min)") + 
      geom_segment(aes(x = x, y = y, xend = x, yend = y + 
                         1, color = value > expression_threshold), size = 2, 
                   data = subset(mlt_marker_expression, cell %in% 
                                   reachable_cells_p)) + scale_color_viridis(name = paste0("Expressed"), 
                                                                             discrete = T) + theme(axis.title.x = element_blank(), 
                                                                                                   axis.text.x = element_blank(), axis.ticks.x = element_blank(), 
                                                                                                   axis.line = element_blank())
    if (!is.null(lineage_depth)) {
      P_lineage <- P_lineage + ylim(lineage_depth, min(subset_ddata$x_start))
    }
    p <- plot_grid(P_lineage, A_lineage, labels = rev(offspring), 
                   align = "v", nrow = 2, label_x = label_x, label_y = label_y)
  }
  if (return_all) {
    return(list(subset_ddata = subset_ddata, mlt_marker_expression = mlt_marker_expression, 
                p = p))
  }
  else {
    p
  }
}


function(cds, 
                                    gene_name, 
                                    ddata,  
                                    lineage_tree, 
                                    lineage_coordinates, 
                                    root_cell, 
                                    lineage_depth = NULL,
                                    expression_threshold = 2000, 
                                    show_lineage_pair = FALSE, 
                                    label_x = 0.45, 
                                    label_y = 1,
                                    return_all = FALSE) {
  if(!all(grep('_', colnames(cds)))) {
    stop('Column of the cds should start with the cell name and then the underscore _')
  }
  
  grep_all_lineage_tree_cells <- lapply(V(lineage_tree)$name, function(x) { grep(paste0("^", x, "_"), colnames(cds)) })
  
  if(! all(unlist(lapply(grep_all_lineage_tree_cells, length)) > 0)) {
    missing_cells <- V(lineage_tree)$name[which(!(unlist(lapply(grep_all_lineage_tree_cells, length)) > 0))]
    warning(paste0(unique(missing_cells) , ' is not included in the graph of lineage_tree stored in the cds object'))
  }
  # visualize MSp lineage 
  reachable_cells_list <- graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = root_cell, 'out')
  reachable_cells <- V(reachable_cells_list[[1]])$name
  
  offspring <- V(graph.neighborhood(lineage_tree, 1, nodes = root_cell, 'out')[[1]])$name[-1]
  # map the expression: 
  # alr.1, pes.1 
  subset_ddata <- subset(ddata) #, father %in% reachable_cells &  target %in% reachable_cells & x_start > 570)
  mathced_cells <- unlist(lapply(unique(c(as.character(subset_ddata$father), as.character(subset_ddata$target))), function(x) colnames(cds)[grep(paste0("^", x, "_"), colnames(cds))]))
  marker_expression <- as.matrix(exprs(cds)[gene_names, mathced_cells])
  mlt_marker_expression <- melt(marker_expression)
  
  if(length(gene_names) == 1) {
    mlt_marker_expression <- cbind(mlt_marker_expression, str_split_fixed(mlt_marker_expression[, 1], "_", 2))
    colnames(mlt_marker_expression)[ <- c('cell_id', 'Var2', 'Expression', 'cell', 'y')
  } else {
    mlt_marker_expression <- cbind(mlt_marker_expression, str_split_fixed(mlt_marker_expression[, 2], "_", 2))
    colnames(mlt_marker_expression) <- c('gene', 'cell_id', 'Expression', 'cell', 'y')
  }
  
  mlt_marker_expression$y <- pData(cds)[as.character(mlt_marker_expression[, 1]), 'time']
  
  mlt_marker_expression$x <- lineage_coordinates[as.character(mlt_marker_expression$cell), 'x']
  
  if(show_lineage_pair == FALSE) {
    p <- ggplot(data = subset_ddata) + scale_y_reverse() + 
      # geom_label(aes(label=str_wrap(cell_id,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + 
      geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end)) + xlab('') + ylab('Time (min)') + 
      geom_segment(aes(x = x, y = y, xend = x, yend = y + 1, color = value), data = subset(mlt_marker_expression, cell %in% reachable_cells_a)) + 
      scale_color_viridis(name = paste0("Expression")) +
      theme(axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank(), 
            axis.line = element_blank())
    if(! is.null(lineage_depth)) {
      p  + ylim(lineage_depth, min(subset_ddata$x_start))
    }
  } else if(show_lineage_pair == TRUE) {
    # visualize MSp and MSPa lineage 
    reachable_cells_a <- graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = offspring[1], 'out')
    reachable_cells_a <- V(reachable_cells_a[[1]])$name
    
    reachable_cells_p <- graph.neighborhood(lineage_tree, length(V(lineage_tree)), nodes = offspring[2], 'out')
    reachable_cells_p <- V(reachable_cells_p[[1]])$name
    
    subset_ddata <- subset(ddata, father %in% reachable_cells_a &  target %in% reachable_cells_a)
    A_lineage <- ggplot(data = subset_ddata) + #coord_flip() + 
      # geom_label(aes(label=str_wrap(cell_id,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + 
      geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end), size = 2) + xlab('') + ylab('Time (min)') + 
      geom_segment(aes(x = x, y = y, xend = x, yend = y + 1, color = value > expression_threshold), size = 2,  
                   data = subset(mlt_marker_expression, cell %in% reachable_cells_a)) + 
      scale_color_viridis(name = paste0("Expressed"), discrete = T) +
      theme(axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank(), 
            axis.line = element_blank()) 
    
    if(! is.null(lineage_depth)) {
      A_lineage <- A_lineage + ylim(lineage_depth, min(subset_ddata$x_start))
    }
    
    subset_ddata <- subset(ddata, father %in% reachable_cells_p &  target %in% reachable_cells_p)
    
    P_lineage <- ggplot(data = subset_ddata) + scale_y_reverse() + 
      # geom_label(aes(label=str_wrap(cell_id,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + 
      geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end), size = 2) + xlab('') + ylab('Time (min)') + 
      geom_segment(aes(x = x, y = y, xend = x, yend = y + 1, color = value > expression_threshold), size = 2,  
                   data = subset(mlt_marker_expression, cell %in% reachable_cells_p)) + 
      scale_color_viridis(name = paste0("Expressed"), discrete = T) +
      theme(axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank(), 
            axis.line = element_blank()) 
    
    if(! is.null(lineage_depth)) {
      P_lineage <- P_lineage + ylim(lineage_depth, min(subset_ddata$x_start))
    }
    
    p <- plot_grid(P_lineage, A_lineage, labels = rev(offspring), align = 'v', nrow = 2, label_x = label_x, label_y = label_y)
  }
  
  if(return_all) {
    return(list(subset_ddata = subset_ddata, mlt_marker_expression = mlt_marker_expression, p = p))
  } else {
    p
  }
}


# test the temporal network graph: 

neuron_net <- graph_from_edgelist(as.matrix(neuron_network), directed = T)

layout_coord <- layout_as_tree(neuron_net)
row.names(layout_coord) <- V(neuron_net)$name
layout_coord["Tuj1", ] <- c(-1.25,  0)

layout_coord["Scl", ] <- layout_coord["Olig2", ]
layout_coord["Olig2", ] <- c(1.25, 1.00)
layout_coord["Stat3", ] <- c(0.4, 0.5)
layout_coord["Aldh1L", ] <- c(-0.75, -1)
layout_coord["Myt1L", ] <- layout_coord["Sox8", ]
layout_coord["Sox8", ] <- c(1.95, 0)

color = rep('blue', 21)
color[c(5, 12, 14, 16)] <- 'red'
plot(neuron_net, layout = layout_coord, edge.width=E(neuron_net)$weight / 3, edge.color = color)


simulation_expr_mat_nonlinear <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat_nonlinear')


#####################################################################################################################################################################

model <- hclust(dist(USArrests), "ave")
dhc <- as.dendrogram(model)
# Rectangular lines
ddata_old <- dendro_data(dhc, type = "rectangle")
p <- ggplot(data = ddata) +
  geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end)) +
  coord_flip() +
  scale_y_reverse(expand = c(0.2, 0))

qplot(x, y_min, data = lineage_coord) + geom_point(aes(x, y_max)) + scale_y_reverse() + coord_flip()

# create the dendrogram plot: 
# identify the problematic region 
ggplot(data = subset(ddata, y_start < 80 & x_start > 490)) +
  geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end)) + geom_label(aes(label=str_wrap(father,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + coord_flip() + geom_hline(yintercept = 80, color = 'red')  + geom_vline(xintercept = 470, color = 'red')

subset_data <- subset(ddata, target %in% c('Z2', 'Z3'))
ggplot(data = subset_data) +
  geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end)) + geom_label(aes(label=str_wrap(father,12), x=(x_start + x_end)/2, y=(y_start + y_end)/2),size=3) + 
  coord_flip()

# x, y, x_end, y_end 
ddata_c_elegans <- c()
for(current_cell in row.names(lineage_coord)) {
  target_cell <- V(graph.neighborhood(lineage_tree, 1, nodes = current_cell, 'out')[[1]])[-1]
  if(length(target_cell) > 1) {
    tmp <- data.frame(x = rep(lineage_coord[current_cell, 'x'], 3), 
                      y = as.numeric(lineage_coord[current_cell, c("y_min", "y_max", "y_max")]),
                      xend = as.numeric(c(lineage_coord[current_cell, 'x'], lineage_coord[target_cell, c('x')])),
                      yend = as.numeric(c(lineage_coord[current_cell, 'y_max'], lineage_coord[target_cell, 'y_min']))
    )
  } else {
    tmp <- data.frame(x = rep(lineage_coord[current_cell, 'x'], 1), 
                      y = lineage_coord[current_cell, c("y_min")],
                      xend = c(lineage_coord[current_cell, 'x']),
                      yend = c(lineage_coord[current_cell, 'y_max'])
    )
  }
  
  if(is.null(ddata_c_elegans)) {
    ddata_c_elegans <- tmp
  } else {
    ddata_c_elegans <- rbind(ddata_c_elegans, tmp)
  }
  
}

plot.igraph(lineage_tree, layout=layout_as_tree(lineage_tree, root = 'P0'))

tree_layout <- layout_as_tree(lineage_tree, root = 'P0')
tree_layout <- as.data.frame(tree_layout)
hc <- hclust(dist(tree_layout))
plot(hc)

# get the coordinates and then plot it 
GNI2014$pathString <- paste("world", 
                            GNI2014$continent, 
                            GNI2014$country, 
                            sep = "/")
population <- as.Node(GNI2014)

lineage_tree_df$pathString <- paste(lineage_tree_df$father, lineage_tree_df$target, sep = '/')
data.tree_res <- as.Node(lineage_tree_df)

#######################################################################################################################################
#1. create a hc class object; 2. create the figure; 3. add color for the lines; 4. add cell names for each terminal cells 
#######################################################################################################################################
model <- hclust(dist(USArrests), "ave")
dhc <- as.dendrogram(model)
# Rectangular lines
ddata <- dendro_data(dhc, type = "rectangle")

p <- ggplot(segment(ddata)) + 
  geom_segment(aes(x = x, y = y, xend = xend, yend = yend)) + 
  coord_inverse() + 
  scale_y_reverse(expand = c(0.2, 0))
p

