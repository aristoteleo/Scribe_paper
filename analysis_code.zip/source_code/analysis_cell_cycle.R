# analysis the cell cycle data
rm(list = ls())

library(R.matlab)
library(monocle)
library(destiny)
library(Scribe)
library(reshape2)

source('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R', echo = T)

# 1. read the mat file
cell_cycle_res <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Matlab/cell_cycle_res.mat')

# 2. run dimension reduction 
monocyte_dm <- DiffusionMap(as.matrix(cell_cycle_res$yout))
# monocyte_dpt_res <- just_DPT(monocyte_dm)

qplot(monocyte_dm$DC3, monocyte_dm$DC4)
# 3. build cds and run trajectory reconstruction 


# 4. run network reconstruction and benchmark with the true network 
data <- cell_cycle_res$yout
run_vec <- rep(1, nrow(data))

tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]
#
# add some noise
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(data) * ncol(data)), nrow = nrow(data))
noise_remove_dup = matrix(rnorm(mean = 0, sd = 1e-10, nrow(data) * ncol(data)), nrow = nrow(data))

# run multiple rdi
a <- Sys.time()
rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1) #* 100 + noise
# rdi_list <- calculate_rdi_multiple_run_cpp(data, delay = c(1), run_vec[!duplicated(data)] - 1, as.matrix(super_graph_remove_dup), method = 1) # + noise_remove_dup
b <- Sys.time()
rdi_time <- b - a

cell_cycle_gene_vec <- toupper(unlist(cell_cycle_res$name)) # [c(22, 24, 26, 37:39)]
dimnames(rdi_list$max_rdi_value) <- list(cell_cycle_gene_vec, cell_cycle_gene_vec)
con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 1)
dimnames(con_rdi_res_test) <- list(cell_cycle_gene_vec, cell_cycle_gene_vec)

# 5. show the result of RDI network inference 
cell_cycle_network <- read.csv('./Matlab/cell_cycle_network.csv', sep = ',', header = F)

process_data <- function(parallel_res_list, network = cell_cycle_network) {
  processed_res <- lapply(parallel_res_list, function(x) {
    gene_uniq <- unique(c(as.character(network$V1), as.character(network$V2)))
    all_cmbns <- expand.grid(gene_uniq, gene_uniq)
    valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
    all_valid_gene_pairs <- paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_')
    # 
    # dimnames(x) <- list(c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature'), 
    #                     c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature'))
    mlt_RDI_benchmark_res <- melt(x) #[1:12, 1:12]
    row.names(mlt_RDI_benchmark_res) <- paste(tolower(mlt_RDI_benchmark_res$Var1), tolower(mlt_RDI_benchmark_res$Var2), sep = '_')
    
    t(data.frame(RDI = mlt_RDI_benchmark_res[all_valid_gene_pairs, 'value']))
  })
  return(processed_res)
}

cell_cycle_gene_unique <- unique(as.character(cell_cycle_network$V1), as.character(cell_cycle_network$V2))
cell_cycle_gene_unique[!(cell_cycle_gene_unique %in% cell_cycle_gene_vec)]

valid_cell_cycle_network <- cell_cycle_network[cell_cycle_network$V1 %in% cell_cycle_gene_vec & cell_cycle_network$V2 %in% cell_cycle_gene_vec, ]
valid_cell_cycle_network <- valid_cell_cycle_network[as.character(valid_cell_cycle_network$V1) != as.character(valid_cell_cycle_network$V2), ]
valid_gene_unique <- unique(c(as.character(valid_cell_cycle_network$V1), as.character(valid_cell_cycle_network$V2))) 
valid_rdi <- rdi_list$max_rdi_value[valid_gene_unique, valid_gene_unique]
valid_crdi <- con_rdi_res_test[valid_gene_unique, valid_gene_unique]
RDI_res_df <- process_data(list(rdi = valid_rdi, crdi = valid_crdi), network = valid_cell_cycle_network); #, crdi = con_rdi_res_test
RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))

colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
# colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

# calculate the ROC / AUC values
calROCAUC <- function(res_df, network = neuron_network) {
  gene_uniq <- unique(c(as.character(network[, 1]), as.character(network[, 2])))
  all_cmbns <- expand.grid(gene_uniq, gene_uniq)
  valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
  valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
  row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
  valid_all_cmbns_df[paste(tolower(network$V1), tolower(network$V2), sep = '_'), 2] <- 1
  
  reference_network_pvals <- valid_all_cmbns_df[, 2]
  p_thrsld <- 0
  
  roc_df_list <- lapply(colnames(res_df), function(x, reference_network_pvals_df = reference_network_pvals) {
    pvals <- res_df[, x]
    
    pvals[is.na(pvals)] <- 0
    reference_network_pvals[is.na(reference_network_pvals)] <- 0
    pvals <- (pvals - min(pvals)) / (max(pvals) - min(pvals))
    res <- generate_roc_df(pvals, reference_network_pvals > p_thrsld)
    colnames(res) <- c('tpr', 'fpr', 'auc')
    cbind(res, method = x)
  })
  
  roc_df_list <- lapply(roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
  roc_df <- do.call(rbind, roc_df_list)
  
  return(roc_df)  
}

RDI_df <- calROCAUC(RDI_res_df, network = valid_cell_cycle_network)
# cRDI_df <- calROCAUC(cRDI_res_df)

qplot(tpr, fpr, data = RDI_df)

save.image('./RData/analysis_cell_cycle.RData')
