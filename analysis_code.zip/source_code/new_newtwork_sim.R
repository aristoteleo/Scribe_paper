library(simecol)
## Hodkin-Huxley model
HH <- odeModel(
  main = function(time, init, parms) {
    with(as.list(c(init, parms)),{
      
      am <- function(v) 0.1*(v+40)/(1-exp(-(v+40)/10))
      bm <- function(v) 4*exp(-(v+65)/18)
      ah <- function(v) 0.07*exp(-(v+65)/20)
      bh <- function(v) 1/(1+exp(-(v+35)/10))
      an <- function(v) 0.01*(v+55)/(1-exp(-(v+55)/10))
      bn <- function(v) 0.125*exp(-(v+65)/80)
      
      dv <- (I - gna*h*(v-Ena)*m^3-gk*(v-Ek)*n^4-gl*(v-El))/C
      dm <- am(v)*(1-m)-bm(v)*m
      dh <- ah(v)*(1-h)-bh(v)*h
      dn <- an(v)*(1-n)-bn(v)*n
      
      return(list(c(dv, dm, dh, dn)))
    })
  },
  ## Set parameters
  parms = c(Ena=50, Ek=-77, El=-54.4, gna=120, gk=36, gl=0.3, C=1, I=0),
  ## Set integrations times
  times = c(from=0, to=40, by = 0.25),
  ## Set initial state
  init = c(v=-65, m=0.052, h=0.596, n=0.317),
  solver = "lsoda"
)

HH <- sim(HH)

# run RDI on it: 
data <- HH@out[, -1]
tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

# calculate rdi values
run_vec <- rep(1, nrow(data) - 1)
HH_rdi_list <- calculate_rdi_multiple_run_cpp(data, delay = 1, run_vec - 1, as.matrix(super_graph), method = 1)

#######################################################################################################################################
# cell cycle 
#######################################################################################################################################


#######################################################################################################################################
# hopefully also the haempoiesis process  
#######################################################################################################################################








