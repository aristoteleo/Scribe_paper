library(Scribe)
library(monocle)

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

#######################################################################################################################################
# create all possible boolean logics 
#######################################################################################################################################
N <- 3; steps <- 1000 

f_em <- matrix(0, nrow = 3, ncol = steps + 1)
f_em2 <- f_em

update_function <- function(x_old, n =4, k = 0.1, dt = 0.1, logic = c('OR', 'AND', "NAND", 'NNAND', 'NOR', 'NNOR')) {
  dx <- c() # vector for the data 
  dx["Brn2"] <- 0.025
  # dx["Tuj1"] <- ( x_old["Brn2"]^n + x_old["Zic1"]^n ) / (1 + x_old["Brn2"]^n + x_old["Zic1"]^n) - k*x_old["Tuj1"]
  
  if(logic == 'OR') {
    # OR
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) + x_old["Brn2"]^n / (1 + x_old["Brn2"]^n)) / 2 #- k*x_old["Tuj1"]
  } else if(logic == 'AND') {
    # # AND 
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) *  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n)) # - k*x_old["Tuj1"]    
  } else if(logic == 'NAND') {
    # NAND 
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) * (1 -  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) # - k*x_old["Tuj1"]    
  } else if(logic == 'NNAND') {
    # NNAND
    dx["Tuj1"] <- (1 - x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) * (1 -  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) # - k*x_old["Tuj1"]    
  } else if(logic == 'NOR') {
    # NOR
    dx["Tuj1"] <- 1 -  (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) + (x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) / 2 # - k*x_old["Tuj1"]    
  } else if(logic == 'NNOR') {
    # NNOR
    dx["Tuj1"] <- ((1 - x_old["Zic1"]^n / (1 + x_old["Zic1"]^n)) + (1 -  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) / 2 # - k*x_old["Tuj1"]    
  }
   
  dx["Zic1"] <- 0.025
  
  dx <- dx * dt #+ rnorm(2, mean = 0, sd = .01)
  dx <- x_old + dx 
  return(dx)
}

update_function2 <- function(x_old, n = 4, k = 0.1, dt = 0.1, logic = c('OR', 'AND', "NAND", 'NNAND', 'NOR', 'NNOR')) {
  dx <- c() # vector for the data 
  dx["Brn2"] <- x_old["Brn2"]
  # dx["Tuj1"] <- ( x_old["Brn2"]^n + x_old["Zic1"]^n ) / (1 + x_old["Brn2"]^n + x_old["Zic1"]^n) - k*x_old["Tuj1"]
  
  if(logic == 'OR') {
    # OR
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) + x_old["Brn2"]^n / (1 + x_old["Brn2"]^n)) / 2 #- k*x_old["Tuj1"]
  } else if(logic == 'AND') {
    # # AND 
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) *  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n)) # - k*x_old["Tuj1"]    
  } else if(logic == 'NAND') {
    # NAND 
    dx["Tuj1"] <- (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) * (1 -  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) # - k*x_old["Tuj1"]    
  } else if(logic == 'NNAND') {
    # NNAND
    dx["Tuj1"] <- (1 - x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) * (1 -  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) # - k*x_old["Tuj1"]    
  } else if(logic == 'NOR') {
    # NOR
    dx["Tuj1"] <- 1 -  (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) + (x_old["Brn2"]^n / (1 + x_old["Brn2"]^n))) / 2 # - k*x_old["Tuj1"]    
  } else if(logic == 'NNOR') {
    # NNOR
    dx["Tuj1"] <- 1 - (x_old["Zic1"]^n / (1 + x_old["Zic1"]^n) *  x_old["Brn2"]^n / (1 + x_old["Brn2"]^n)) # - k*x_old["Tuj1"]    
  } 
  
  dx["Zic1"] <- x_old["Zic1"]
  
  return(dx)
}

for(cur_logic in c('OR', 'AND', "NAND", 'NNAND', 'NOR', 'NNOR')) {
  x_int <- rep(0.01, N)
  names(x_int) <- c('Brn2', 'Tuj1', 'Zic1')
  
  f_em[, 1] <- x_int
  f_em2[, 1] <- x_int
  
  for(step in 1:steps) {
    x_old <- f_em[, step]
    names(x_old) <- c('Brn2', 'Tuj1', 'Zic1')
    
    f_temp <- update_function(x_old)
    f_temp[f_temp < 0] <- 0
    f_em[, step + 1] <- f_temp
  }
  
  for(step in 1:steps) {
    x_old <- f_em[, step]
    names(x_old) <- c('Brn2', 'Tuj1', 'Zic1')
    
    f_temp <- update_function(x_old, logic = cur_logic)
    f_temp[f_temp < 0] <- 0
    f_em[, step + 1] <- f_temp
  
    f_temp2 <- update_function2(x_old, logic = cur_logic)
    f_em2[, step + 1] <- f_temp2
    
  }
  
  dimnames(f_em2) <- list(c('Brn2', 'Tuj1', 'Zic1'), 1:(steps + 1))
  pd <- new("AnnotatedDataFrame", data = data.frame(row.names = colnames(f_em2), time = 1:(steps + 1)))
  fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = row.names(f_em2), row.names = row.names(f_em2)))
  
  boolean_logics_cds <- newCellDataSet(as(f_em2, 'sparseMatrix'), 
                                   phenoData = pd,
                                   featureData = fd,
                                   lowerDetectionLimit=1,
                                   expressionFamily=gaussianff())
  
  pdf(paste0(SI_fig_dir, cur_logic, '_logic.pdf'), width = 1, height = 1)
  print(plot_comb_logic(boolean_logics_cds, gene_pairs_target_mat = matrix(c('Zic1', 'Brn2', 'Tuj1'), nrow = 1), grid_num = 25, log = F) + 
    xacHelper::nm_theme() + 
    theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9))) 
  dev.off()
}


hill_eqn <- function(x, n = 4) {
  x^n/(1+x^n)
}

qplot(seq(0, 4, by = 0.01), hill_eqn(seq(0, 4, by = 0.01)))

# AND helper
pdf(paste0(SI_fig_dir, 'AND_logic_helper.pdf'))
plot_comb_logic(boolean_logics_cds, gene_pairs_target_mat = matrix(c('Zic1', 'Brn2', 'Tuj1'), nrow = 1), grid_num = 25, log = F)
dev.off()

#######################################################################################################################################
# show all 7 robust two-gene motifs 
#######################################################################################################################################
N <- 2; steps <- 1000 

f_em <- matrix(0, nrow = N, ncol = steps + 1)
f_em2 <- f_em # visualize the causality or response using delta 

update_function_motif <- function(x_old, n =4, k = 0.1, dt = 0.1, motif_id = c(44, 65, 66, 69, 75, 78)) {
  dx <- c(0, 0) # vector for the data 
  names(dx) <- c('A', 'B')
  
  if(motif_id == 44) {
    dx["A"] <- x_old["B"]^n / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- x_old["A"]^n / (1 + x_old["A"]^n) #- k*x_old["Tuj1"]
  } else if(motif_id == 65) {
    dx["A"] <- 1 / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- 1 / (1 + x_old["A"]^n) #- k*x_old["Tuj1"]
  }  else if(motif_id == 66) {
    dx["A"] <- 1 / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- x_old["B"]^n / (1 + x_old["A"]^n + x_old["B"]^n) #- k*x_old["Tuj1"]
  }  else if(motif_id == 69) {
    dx["A"] <- 1 / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- x_old["B"]^n / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
  }  else if(motif_id == 75) {
    dx["A"] <- x_old["A"]^n / (1 + x_old["B"]^n + x_old["A"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- x_old["B"]^n / (1 + x_old["A"]^n + x_old["B"]^n) #- k*x_old["Tuj1"]
  } else if(motif_id == 78) {
    dx["A"] <- x_old["A"]^n / (1 + x_old["B"]^n + x_old["A"]^n) #- k*x_old["Tuj1"]
    dx["B"] <- x_old["B"]^n / (1 + x_old["B"]^n) #- k*x_old["Tuj1"]
  }
  
  dx <- dx * dt + rnorm(2, mean = 0, sd = .1)
  dx <- x_old + dx 
  return(dx)
}

x_int <- rep(0.01, N)
names(x_int) <- c('A', 'B')

f_em[, 1] <- x_int
f_em2[, 1] <- x_int

for(cur_motif_id in c(44, 65, 66, 69, 75, 78)) {
  for(step in 1:steps) {
    x_old <- f_em[, step]
    names(x_old) <- c('A', 'B')
    
    f_temp <- update_function_motif(x_old, motif_id = cur_motif_id)
    f_temp[f_temp < 0] <- 0
    f_em[, step + 1] <- f_temp
  }
  f_em2 <- f_em
  dimnames(f_em2) <- list(c('A', 'B'), 1:(steps + 1))
  pd <- new("AnnotatedDataFrame", data = data.frame(row.names = colnames(f_em2), time = 1:(steps + 1)))
  fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = row.names(f_em2), row.names = row.names(f_em2)))
  
  boolean_logics_cds <- newCellDataSet(as(f_em2, 'sparseMatrix'), 
                                       phenoData = pd,
                                       featureData = fd,
                                       lowerDetectionLimit=1,
                                       expressionFamily=gaussianff())
  
  pdf(paste0(SI_fig_dir, cur_motif_id, '_all_two_gene_motif_drevi.pdf'), width = 1, height = 1)
  print(plot_lagged_drevi(boolean_logics_cds, gene_pairs_mat = matrix(c('A', 'B'), nrow = 1), grid_num = 25, log = F) + 
          xacHelper::nm_theme() + 
          theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9))) 
  dev.off()
  
  pdf(paste0(SI_fig_dir, cur_motif_id, '_all_two_gene_motif_causality.pdf'), width = 1, height = 1)
  print(plot_gene_pairs_causality(boolean_logics_cds, gene_pairs_mat = matrix(c('A', 'B'), nrow = 1), grid_num = 25, log = F) + 
          xacHelper::nm_theme() + 
          theme(axis.text.x = element_text(angle = 30, hjust = .9), axis.text.y = element_text(angle = 30, vjust = .9))) 
  dev.off()
}
#######################################################################################################################################
# implement all ffl functions (do this during revision)
#######################################################################################################################################


#######################################################################################################################################
# save data 
#######################################################################################################################################



