# prepare the scRNA-seq dataset: 
rm(list = ls())

library(monocle)
library(rEDM)
library(destiny)
library(xacHelper)

########################################################################################################################################################################
# analyze the Olsson dataset  
########################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig5_4_22.RData')
save(file = './RData/fig5_cds_Olsson.RData', URMM_all_fig1b, URMM_all_abs)

rm(list = ls())
load('./RData/fig5_cds_Olsson.RData')

plot_cell_trajectory(URMM_all_fig1b, color_by = 'State')
plot_complex_cell_trajectory(URMM_all_fig1b, color_by = 'State')
plot_cell_trajectory(URMM_all_fig1b, color_by = 'paper_cluster')
plot_complex_cell_trajectory(URMM_all_fig1b, color_by = 'paper_cluster')

Olsson_MEP_cds <- URMM_all_fig1b[, pData(URMM_all_fig1b)$State %in% c(1, 2)]
Olsson_monocyte_cds <- URMM_all_fig1b[, pData(URMM_all_fig1b)$State %in% c(1, 3, 4)]
Olsson_granulocyte_cds <- URMM_all_fig1b[, pData(URMM_all_fig1b)$State %in% c(1, 3, 5)]

Olsson_MEP_cds <- reduceDimension(Olsson_MEP_cds, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Olsson_MEP_cds <- orderCells(Olsson_MEP_cds)
plot_cell_trajectory(Olsson_MEP_cds, color_by = 'State')
plot_cell_trajectory(Olsson_MEP_cds, color_by = 'paper_cluster')

Olsson_monocyte_cds <- reduceDimension(Olsson_monocyte_cds, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Olsson_monocyte_cds <- orderCells(Olsson_monocyte_cds)
plot_cell_trajectory(Olsson_monocyte_cds, color_by = 'State')
plot_cell_trajectory(Olsson_monocyte_cds, color_by = 'paper_cluster')

Olsson_granulocyte_cds <- reduceDimension(Olsson_granulocyte_cds, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Olsson_granulocyte_cds <- orderCells(Olsson_granulocyte_cds)
plot_cell_trajectory(Olsson_granulocyte_cds, color_by = 'State')
plot_cell_trajectory(Olsson_granulocyte_cds, color_by = 'paper_cluster')

# use DPT: 
just_DPT <- function (dm, tips = random_root(dm), ..., w_width = 0.1) 
{
  if (!is(dm, "DiffusionMap")) 
    stop("dm needs to be of class DiffusionMap, not ", class(dm))
  if (!length(tips) %in% 1:3) 
    stop("you need to specify 1-3 tips, got ", length(tips))
  dpt <- destiny:::dummy_dpt(dm)
  all_cells <- seq_len(nrow(dpt))
  # stats <- destiny:::tipstats(dpt, all_cells, tips)
  # branches <- auto_branch(dpt, all_cells, stats, w_width)
  # colnames(branches$branch) <- paste0("Branch", seq_len(ncol(branches$branch)))
  # colnames(branches$tips) <- paste0("Tips", seq_len(ncol(branches$tips)))
  # dpt@branch <- branches$branch
  # dpt@tips <- branches$tips
  dpt
}

which.min(pData(URMM_all_fig1b)$Pseudotime)
# [1] 77

MEP_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_MEP_cds)[fData(Olsson_MEP_cds)$use_for_ordering, ] + 1))))
MEP_dpt_res <- just_DPT(MEP_dm)

monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
monocyte_dpt_res <- just_DPT(monocyte_dm)

granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
granulocyte_dpt_res <- just_DPT(granulocyte_dm)

save.image('./RData/analysis_scRNA_seq_Olsson.RData')

########################################################################################################################################################################
# analyze the Paul dataset
########################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/valid_subset_GSE72857_cds2')
valid_subset_GSE72857_cds2 <- orderCells(valid_subset_GSE72857_cds2, root_state = 10)

plot_cell_trajectory(valid_subset_GSE72857_cds2, color_by = 'State')
plot_complex_cell_trajectory(valid_subset_GSE72857_cds2, color_by = 'cell_type')
plot_cell_trajectory(valid_subset_GSE72857_cds2, color_by = 'cell_type')
plot_complex_cell_trajectory(valid_subset_GSE72857_cds2, color_by = 'cell_type')

Paul_DC <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 3)]
Paul_Neu_Eos <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 1)]
Paul_Bas <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 4)]
Paul_Mono <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 7, 6)]
Paul_MK <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 11)]
Paul_Ery <- valid_subset_GSE72857_cds2[, pData(valid_subset_GSE72857_cds2)$State %in% c(10, 9)]

Paul_DC <- reduceDimension(Paul_DC, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_DC <- orderCells(Paul_DC)
plot_cell_trajectory(Paul_DC, color_by = 'State')
plot_cell_trajectory(Paul_DC, color_by = 'cell_type')

Paul_Neu_Eos <- reduceDimension(Paul_Neu_Eos, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_Neu_Eos <- orderCells(Paul_Neu_Eos)
plot_cell_trajectory(Paul_Neu_Eos, color_by = 'State')
plot_cell_trajectory(Paul_Neu_Eos, color_by = 'cell_type')

Paul_Bas <- reduceDimension(Paul_Bas, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_Bas <- orderCells(Paul_Bas)
plot_cell_trajectory(Paul_Bas, color_by = 'State')
plot_cell_trajectory(Paul_Bas, color_by = 'cell_type')

Paul_Mono <- reduceDimension(Paul_Mono, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_Mono <- orderCells(Paul_Mono)
plot_cell_trajectory(Paul_Mono, color_by = 'State')
plot_cell_trajectory(Paul_Mono, color_by = 'cell_type')

Paul_MK <- reduceDimension(Paul_MK, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_MK <- orderCells(Paul_MK)
plot_cell_trajectory(Paul_MK, color_by = 'State')
plot_cell_trajectory(Paul_MK, color_by = 'cell_type')

Paul_Ery <- reduceDimension(Paul_Ery, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Paul_Ery <- orderCells(Paul_Ery)
plot_cell_trajectory(Paul_Ery, color_by = 'State')
plot_cell_trajectory(Paul_Ery, color_by = 'cell_type')

###################################################################################################################################################### 
# Diffusion map
###################################################################################################################################################### 

Paul_DC_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_DC)[fData(Paul_DC)$use_for_ordering, ] + 1))))
Paul_DC_dpt_res <- just_DPT(Paul_DC_dm)

Paul_Neu_Eos_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_Neu_Eos)[fData(Paul_Neu_Eos)$use_for_ordering, ] + 1))))
Paul_Neu_Eos_dpt_res <- just_DPT(Paul_Neu_Eos_dm)

Paul_Bas_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_Bas)[fData(Paul_Bas)$use_for_ordering, ] + 1))))
Paul_Bas_dpt_res <- just_DPT(Paul_Bas_dm)

Paul_Mono_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_Mono)[fData(Paul_Mono)$use_for_ordering, ] + 1))))
Paul_Mono_dpt_res <- just_DPT(Paul_Mono_dm)

Paul_MK_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_MK)[fData(Paul_MK)$use_for_ordering, ] + 1))))
Paul_MK_res <- just_DPT(Paul_MK_dm)

Paul_Ery_dm <- DiffusionMap(t(as.matrix(log(exprs(Paul_Ery)[fData(Paul_Ery)$use_for_ordering, ] + 1))))
Paul_Ery_res <- just_DPT(Paul_Ery_dm)

save.image('./RData/analysis_scRNA_seq_Paul.RData')
########################################################################################################################################################################
# analyze the Pancreas dataset  
########################################################################################################################################################################
rm(list = ls())

load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/pancreas_4.RData')
plot_cell_trajectory(panc_cds_valid_cells)
plot_cell_trajectory(panc_cds_valid_cells, color_by = 'Pseudotime')
plot_cell_trajectory(panc_cds_valid_cells, color_by = 'CellType')

recreate_cds <- function(cds) {
  pd <- new("AnnotatedDataFrame", data = pData(cds))
  fd <- new("AnnotatedDataFrame", data = fData(cds))
  
  new_cds <- newCellDataSet(as(as.matrix(cds), "sparseMatrix"),
                            phenoData = pd,
                            featureData = fd,
                            expressionFamily=cds@expressionFamily,
                            lowerDetectionLimit=cds@lowerDetectionLimit)
  
  new_cds <- estimateSizeFactors(new_cds)
  new_cds <- estimateDispersions(new_cds)
  new_cds
}

panc_cds_valid_cells <- recreate_cds(panc_cds_valid_cells)
plot_pc_variance_explained(panc_cds_valid_cells)
panc_cds_valid_cells <- reduceDimension(panc_cds_valid_cells, max_components = 4, auto_param_selection = T, verbose = T)
panc_cds_valid_cells <- orderCells(panc_cds_valid_cells)

plot_cell_trajectory(panc_cds_valid_cells)
plot_cell_trajectory(panc_cds_valid_cells, color_by = 'Pseudotime')
plot_cell_trajectory(panc_cds_valid_cells, color_by = 'CellType')
panc_cds_valid_cells <- orderCells(panc_cds_valid_cells, root_state = 5)

plot_complex_cell_trajectory(panc_cds_valid_cells, color_by = 'State') 
plot_complex_cell_trajectory(panc_cds_valid_cells, color_by = 'CellType') 

save(file = './RData/panc_cds_valid_cells.RData', panc_cds_valid_cells)

rm(list = ls())
load('./RData/panc_cds_valid_cells.RData')

########################################################################################################################################################################
# run DPT
########################################################################################################################################################################
Pancreas_epsilon <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5, 4)]
Pancreas_alpha <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5, 3, 2)]
Pancreas_beta <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5, 3, 1)]

Pancreas_epsilon <- reduceDimension(Pancreas_epsilon, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Pancreas_epsilon <- orderCells(Pancreas_epsilon)
plot_cell_trajectory(Pancreas_epsilon, color_by = 'State')
plot_cell_trajectory(Pancreas_epsilon, color_by = 'CellType')

Pancreas_alpha <- reduceDimension(Pancreas_alpha, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Pancreas_alpha <- orderCells(Pancreas_alpha)
plot_cell_trajectory(Pancreas_alpha, color_by = 'State')
plot_cell_trajectory(Pancreas_alpha, color_by = 'CellType')

Pancreas_beta <- reduceDimension(Pancreas_beta, norm_method = 'log', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=1, scaling = T)
Pancreas_beta <- orderCells(Pancreas_beta)
plot_cell_trajectory(Pancreas_beta, color_by = 'State')
plot_cell_trajectory(Pancreas_beta, color_by = 'CellType')

########################################################################################################################################################################
# run DPT
########################################################################################################################################################################
Pancreas_epsilon_dm <- DiffusionMap(t(as.matrix(log(exprs(Pancreas_epsilon)[fData(Pancreas_epsilon)$use_for_ordering, ] + 1))))
Pancreas_epsilon_dpt_res <- just_DPT(Pancreas_epsilon_dm)

Pancreas_alpha_dm <- DiffusionMap(t(as.matrix(log(exprs(Pancreas_alpha)[fData(Pancreas_alpha)$use_for_ordering, ] + 1))))
Pancreas_alpha_dpt_res <- just_DPT(Pancreas_alpha_dm)

Pancreas_beta_dm <- DiffusionMap(t(as.matrix(log(exprs(Pancreas_beta)[fData(Pancreas_beta)$use_for_ordering, ] + 1))))
Pancreas_beta_dpt_res <- just_DPT(Pancreas_beta_dm)

save.image('./RData/analysis_scRNA_seq_pancreas.RData')
########################################################################################################################################################################
# Save the data  
########################################################################################################################################################################
load('./RData/analysis_scRNA_seq_Olsson.RData')
load('./RData/analysis_scRNA_seq_Paul.RData')
load('./RData/analysis_scRNA_seq_Paul.RData')

save.image('./RData/analysis_scRNA_seq.RData')
