rm(list = ls())

#test rEDM (ccm algortihm for inferring gene regulatory network)
library(rEDM)
library(monocle)
library(xlsx)
library(xacHelper)
library(reshape2)
library(pheatmap)

#use the myogenesis dataset: 
load('~/Projects/BEAM/Parallel_the_reproduce/update_nbt_3nd_submission/RData/analysis_lung_data_mc.RData')
#load the data and then order the cells: 

absolute_cds <- make_cds(as.matrix(exprs(absolute_cds)),
                   pd = pData(absolute_cds),
                   fd = fData(absolute_cds),
                   expressionFamily = negbinomial())

standard_cds <- make_cds(as.matrix(exprs(standard_cds)),
                                   pd = pData(standard_cds),
                                   fd = fData(standard_cds),
                                   expressionFamily = tobit())

#we may re-order using the raw ordering set here: 
AT12_cds_subset_all_gene <- reduceDimension(AT12_cds_subset_all_gene, use_vst = T, use_irlba=F, pseudo_expr = 0.1)
AT12_cds_subset_all_gene <- orderCells(AT12_cds_subset_all_gene, num_path = 2)
plot_spanning_tree(AT12_cds_subset_all_gene)

absolute_lung_mat <- t(exprs(absolute_cds)[, order(pData(abs_AT12_cds_subset_all_gene)$Pseudotime)])
std_lung_mat <- t(exprs(standard_cds)[, order(pData(abs_AT12_cds_subset_all_gene)$Pseudotime)])

gene_ids <- row.names(subset(weihgted_mc_AT12_cds_subset_all_gene, qval < 0.01))
abs_parallel_res <- parallelCCM(ordered_exprs_mat = absolute_lung_mat[, gene_ids], cores = detectCores())
abs_parallel_res_mat <- prepare_ccm_res(abs_parallel_res)

pdf('abs_ccm.pdf', width = 30, height = 30)
pheatmap(abs_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T) #, annotation_col = F, annotation_row = F
dev.off()

abs_parallel_res_mat <- prepare_ccm_res(abs_parallel_res)

std_parallel_res <- parallelCCM(ordered_exprs_mat = std_lung_mat[, gene_ids], cores = detectCores())
std_parallel_res_mat <- prepare_ccm_res(std_parallel_res)

pdf('std_ccm.pdf', width = 30, height = 30)
pheatmap(std_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
dev.off()

save.image('ccm_lung.RData')

###############################################################################################################################################################################################
# run mar-seq data:
###############################################################################################################################################################################################
cds_subset <- all_wt_GSE72857_cds[valid_ids, !(pData(all_wt_GSE72857_cds)$State %in% 1:5)]

mar_seq_gmp_mat <- t(as.matrix(exprs(cds_subset[, order(pData(cds_subset)$Pseudotime)])))

mar_seq_gmp_parallel_res <- parallelCCM(ordered_exprs_mat = mar_seq_gmp_mat, cores = detectCores())
mar_seq_gmp_parallel_res_mat <- prepare_ccm_res(mar_seq_gmp_parallel_res)

pdf('mar_seq_gmp_ccm.pdf', width = 10, height = 10)
pheatmap(mar_seq_gmp_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
dev.off()

gene_names <- colnames(mar_seq_gmp_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = mar_seq_gmp_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'mar_seq_gmp_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

###############################################################################################################################################################################################
#run ccm on the 100 genes for the small knockout dataset
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig5.RData')
blood_gene_list <- read.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_gene_list.txt', header = T, sep = '\t')

top_group_branch_time

#look at a few genes: 
plot_cell_trajectory(URMM_all_fig1b)

#plot the reduced dimension: 
order_hbp_mat <- as.matrix(exprs(URMM_all_fig1b)[, order(pData(URMM_all_fig1b)$Pseudotime)])
order_hbp_mat_state12 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(1, 2)] 
order_hbp_mat_state13 <- order_hbp_mat[, pData(URMM_all_fig1b)$State %in% c(1, 3)] 
#monocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state12.txt', order_hbp_mat_state12, col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state13.txt', order_hbp_mat_state13, col.names = T, sep = '\t', row.names = T, quote = F)

valid_ids <- as.character(blood_gene_list$x)
monocyte_cds_subset <- URMM_all_fig1b[valid_ids, !(pData(URMM_all_fig1b)$State %in% c(1, 2))]
granulocyte_cds_subset <- URMM_all_fig1b[valid_ids, !(pData(URMM_all_fig1b)$State %in% c(1, 3))]

monocyte_mat <- t(as.matrix(exprs(monocyte_cds_subset[, order(pData(monocyte_cds_subset)$Pseudotime)])))
granulocyte_mat <- t(as.matrix(exprs(granulocyte_cds_subset[, order(pData(granulocyte_cds_subset)$Pseudotime)])))

monocyte_parallel_res <- parallelCCM(ordered_exprs_mat = monocyte_mat, cores = detectCores()) #row is cell, column is gene
monocyte_parallel_res_mat <- prepare_ccm_res(monocyte_parallel_res)
granulocyte_parallel_res <- parallelCCM(ordered_exprs_mat = granulocyte_mat, cores = detectCores())
granulocyte_parallel_res_mat <- prepare_ccm_res(granulocyte_parallel_res)


pdf('mar_seq_gmp_ccm.pdf', width = 10, height = 10)
pheatmap(monocyte_parallel_res_mat[, ], useRaster = T, cluster_cols = T, cluster_rows = T, annotation_col = F, annotation_row = F)
dev.off()

gene_names <- colnames(monocyte_parallel_res_mat)
for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = monocyte_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'monocyte_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

for(gene_id1 in gene_names) {
  for(gene_id2 in gene_names[!(gene_names %in% gene_id1)]) {
    df <- data.frame(Gene_1_ID = c(gene_id1), Gene_1_NAME = c(gene_id1), Gene_2_ID = c(gene_id2), Gene_2_NAME = c(gene_id2), delay_max = NA, 
                     ccm = granulocyte_parallel_res_mat[gene_id1, gene_id2] )
    write.table(file = 'granulocyte_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F, sep = '\t')
  }
}

#granger causality: 
file.remove(c('monocyte_granger_res', 'granulocyte_granger_res'))
monocyte_granger_res <- parallel_cal_grangertest(monocyte_mat[, ], filename = 'monocyte_granger_res', delays = c(1, 11, 21))
granulocyte_granger_res <- parallel_cal_grangertest(granulocyte_mat, filename = 'granulocyte_granger_res', delays = c(1, 11, 21))


URMM_all_fig1b <- reduceDimension(URMM_all_fig1b, auto_param_selection = F, verbose = T, maxIter = 100)
URMM_all_fig1b <- orderCells(URMM_all_fig1b)
URMM_all_fig1b <- trimTree(URMM_all_fig1b)

plot_cell_trajectory(URMM_all_fig1b, color_by = 'State')
plot_cell_trajectory(URMM_all_fig1b, color_by = 'paper_cluster')
plot_cell_trajectory(URMM_all_fig1b, color_by = 'Pseudotime')

#plot the reduced dimension: 
order_hbp_mat <- as.matrix(exprs(URMM_all_fig1b)[V(res$g)$name, order(pData(URMM_all_fig1b)$Pseudotime)])
pd <- pData(URMM_all_fig1b[, colnames(order_hbp_mat)])
fd <- fData(URMM_all_fig1b)

#plot the reduced dimension: 
order_hbp_mat <- t(as.matrix(exprs(URMM_all_fig1b)[V(res$g)$name, order(pData(URMM_all_fig1b)$Pseudotime)]))
order_hbp_mat_state12 <- order_hbp_mat[pData(URMM_all_fig1b)$State %in% c(1, 2), ] 
order_hbp_mat_state13 <- order_hbp_mat[pData(URMM_all_fig1b)$State %in% c(1, 3), ] 

order_hbp_mat_pscl_smooth_monocyte <- pscl_smooth_genes(order_hbp_mat_state12, window_size = 20)
order_hbp_mat_pscl_smooth_granulocyte <- pscl_smooth_genes(order_hbp_mat_state13, window_size = 20)

order_hbp_mat_pscl_smooth_monocyte_t <- t(order_hbp_mat_pscl_smooth_monocyte)
order_hbp_mat_pscl_smooth_granulocyte_t <- t(order_hbp_mat_pscl_smooth_granulocyte)

#monocyte pscl
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_hbp_mat_pscl_smooth_monocyte.txt', order_hbp_mat_pscl_smooth_monocyte_t, col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte pscl
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/order_hbp_mat_pscl_smooth_granulocyte.txt', order_hbp_mat_pscl_smooth_granulocyte_t, col.names = T, sep = '\t', row.names = T, quote = F)

###############################################################################################################################################################################################
# order the reprogramming data from the Quake group
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/neuron_cds.RData')
neuron_cds <- recreate_cds(neuron_cds)

###############################################################################################################################################################################################
#run dpFeature to decide the genes: 
###############################################################################################################################################################################################
#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05

neuron_cds <- detectGenes(neuron_cds)
fData(neuron_cds)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(neuron_cds)) #
fData(neuron_cds)$use_for_ordering[fData(neuron_cds)$num_cells_expressed > num_cells_expressed] <- T

neuron_cds@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(neuron_cds, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# neuron_cds <- setOrderingFilter(neuron_cds, quake_id)
neuron_cds <- reduceDimension(neuron_cds, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 5,  verbose = T) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
neuron_cds <- clusterCells_Density_Peak(neuron_cds, verbose = T)

#4. check the clusters 
plot_cell_clusters(neuron_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(neuron_cds, color_by = 'experiment', show_density = F) + facet_wrap(~experiment)
plot_cell_clusters(neuron_cds, color_by = 'assignment', show_density = F) + facet_wrap(~assignment)

#5. also check the decision plot 
plot_rho_delta(neuron_cds, rho_threshold = 5, delta_threshold = 5)
plot_cell_clusters(neuron_cds, color_by = 'experiment', rho_threshold = 4, delta_threshold = 5)

#6. re-run cluster and skipping calculating the rho_sigma 
neuron_cds <- clusterCells_Density_Peak(neuron_cds, verbose = T,  rho_threshold = 5, delta_threshold = 5, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(neuron_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(neuron_cds, color_by = 'as.factor(assignment)', show_density = F)

#perform DEG test across clusters: 
neuron_cds@expressionFamily <- negbinomial.size()
pData(neuron_cds)$Cluster <- factor(pData(neuron_cds)$Cluster)
neuron_clustering_DEG_genes <- differentialGeneTest(neuron_cds, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

neuron_clustering_DEG_genes_subset <- neuron_clustering_DEG_genes[fData(neuron_cds)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
neuron_ordering_genes <- row.names(subset(neuron_clustering_DEG_genes, qval < qval_thrsld))

# 
neuron_ordering_genes <- row.names(neuron_clustering_DEG_genes_subset)[order(neuron_clustering_DEG_genes_subset$qval)][1:1000] 

neuron_cds <- setOrderingFilter(neuron_cds, ordering_genes = neuron_ordering_genes)
neuron_cds <- reduceDimension(neuron_cds, verbose = T)
neuron_cds <- orderCells(neuron_cds)

plot_cell_trajectory(neuron_cds, color_by = 'experiment') 
plot_cell_trajectory(neuron_cds, color_by = 'State') 
plot_cell_trajectory(neuron_cds, color_by = 'Pseudotime') 
neuron_cds <- orderCells(neuron_cds, root_state = 2)

pdf(paste(SI_fig_dir, "neuron_cluster_DEG_qval_1k.pdf", sep = ''), height = 2, width = 2)
plot_cell_trajectory(neuron_cds, color_by = 'cell_type') + monocle_theme_opts() + nm_theme()
dev.off()

neuron_cds_subset1 <- neuron_cds[, pData(neuron_cds)$State %in% 1:2]
neuron_cds_subset2 <- neuron_cds[, pData(neuron_cds)$State %in% 2:3]

write.table(file = './csv_data/neuron_data_all_subset1', as.matrix(exprs(neuron_cds_subset1)[, order(pData(neuron_cds_subset1)$Pseudotime)]), 
            col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/neuron_data_all_subset1_top100', 
            as.matrix(exprs(neuron_cds_subset1)[top100_genes_ids, order(pData(neuron_cds_subset1)$Pseudotime)]), 
            col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/neuron_data_all_subset2', as.matrix(exprs(neuron_cds_subset2)[, order(pData(neuron_cds_subset2)$Pseudotime)]), 
            col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/neuron_data_all_subset2_top100', 
            as.matrix(exprs(neuron_cds_subset2)[top100_genes_ids, order(pData(neuron_cds_subset2)$Pseudotime)]), 
            col.names = T, sep = '\t', row.names = T, quote = F)

write.table(file = './csv_data/neuron_fdata.txt', fData(neuron_cds), col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = './csv_data/neuron_pdata.txt', pData(neuron_cds), col.names = T, sep = '\t', row.names = T, quote = F)

###############################################################################################################################################################################################
#run monocle 2 on the top 100 TFs
###############################################################################################################################################################################################
Ricken_TFs <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/mouse_TF_list.csv', sep = '\t')
TFs_ids <- row.names(subset(fData(neuron_cds), gene_short_name %in% Ricken_TFs$V1))

top100_genes <- as.character(unique(fData(neuron_cds)[names(sort(apply(exprs(neuron_cds)[TFs_ids, ], 1, var), decreasing=T))[1:101], 'gene_short_name']))

top100_genes_ids <- row.names(subset(fData(neuron_cds), gene_short_name %in% top100_genes))
neuron_cds <- setOrderingFilter(neuron_cds, ordering_genes = top100_genes_ids)
neuron_cds <- reduceDimension(neuron_cds, verbose = T)
neuron_cds <- orderCells(neuron_cds)
plot_cell_trajectory(neuron_cds, color_by = 'experiment') 

plot_cell_trajectory(neuron_cds, color_by = 'assignment') + facet_wrap(~assignment)

###############################################################################################################################################################################################
#run dpFeature to the new dataset: 
###############################################################################################################################################################################################
time_series <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/GSE75748_sc_time_course_ec.csv', sep = '\t')
TFs_ids <- row.names(subset(fData(neuron_cds), gene_short_name %in% Ricken_TFs$V1))

top100_genes <- as.character(unique(fData(neuron_cds)[names(sort(apply(exprs(neuron_cds)[TFs_ids, ], 1, var), decreasing=T))[1:101], 'gene_short_name']))

top100_genes_ids <- row.names(subset(fData(neuron_cds), gene_short_name %in% top100_genes))
neuron_cds <- setOrderingFilter(neuron_cds, ordering_genes = top100_genes_ids)
neuron_cds <- reduceDimension(neuron_cds, verbose = T)
neuron_cds <- orderCells(neuron_cds)
plot_cell_trajectory(neuron_cds, color_by = 'experiment') 

plot_cell_trajectory(neuron_cds, color_by = 'assignment') + facet_wrap(~assignment)
