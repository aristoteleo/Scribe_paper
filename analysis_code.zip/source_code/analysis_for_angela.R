#analysis for Angela: 
raw_count_matrix <- read.table('/Users/xqiu/Downloads/raw_count_matrix.csv', header = T, sep = ',', col.names = 1)

pd <- data.frame(sample_name = colnames(raw_count_matrix), row.names = colnames(raw_count_matrix))
fd <- data.frame(sample_name = row.names(raw_count_matrix), row.names = row.names(raw_count_matrix))

make_cds <- function (exprs_matrix, pd, fd, expressionFamily) {
  cds <- newCellDataSet(exprs_matrix, 
                        phenoData = new("AnnotatedDataFrame", data = pd), 
                        featureData = new("AnnotatedDataFrame", data = fd), 
                        expressionFamily = expressionFamily, 
                        lowerDetectionLimit = 0.1)
  
  if(identical(expressionFamily, tobit())) {
    cds <- estimateSizeFactors(cds)
    cds <- estimateDispersions(cds)
  }
  return(cds)
}

raw_count_cds <- make_cds(as(as.matrix(raw_count_matrix), 'sparseMatrix'), pd, fd, negbinomial.size())
raw_count_cds <- estimateSizeFactors(raw_count_cds)
raw_count_cds <- estimateDispersions(raw_count_cds)

###############################################################################################################################################################################################
#run dpFeature to decide the genes: 
###############################################################################################################################################################################################
#1. determine how many pca dimension you want: 
num_cells_expressed_percent <- 0.05

raw_count_cds <- detectGenes(raw_count_cds)
fData(raw_count_cds)$use_for_ordering <- F

num_cells_expressed <- round(num_cells_expressed_percent * ncol(raw_count_cds)) #
fData(raw_count_cds)$use_for_ordering[fData(raw_count_cds)$num_cells_expressed > num_cells_expressed] <- T

raw_count_cds@auxClusteringData[["tSNE"]]$variance_explained <- NULL
MAP_pc_variance <- plot_pc_variance_explained(raw_count_cds, return_all = T)

#2. run reduceDimension with tSNE as the reduction_method 
# raw_count_cds <- setOrderingFilter(raw_count_cds, quake_id)
raw_count_cds <- reduceDimension(raw_count_cds, max_components=2, norm_method = 'log', reduction_method = 'tSNE', num_dim = 3,  verbose = T,  perplexity = 5) #, residualModelFormulaStr = '~groups.1'

#check the embedding on each PCA components: 

#3. initial run of clusterCells_Density_Peak
raw_count_cds <- clusterCells_Density_Peak(raw_count_cds, verbose = T)

#4. check the clusters 
plot_cell_clusters(raw_count_cds, color_by = 'as.factor(Cluster)', show_density = F)

pData(raw_count_cds)$batch <- c(rep('Bulk', 2), rep('SC', 6), rep('TA', 6), rep('TD', 6) )
pData(raw_count_cds)$batch <- c(rep('Bulk', 2), rep('SC_1', 2), rep('SC_2', 2), c('SC_3', 'SC_4'), 
                                rep('TA_1', 2), rep('TA_2', 2), c('TA_3', 'TA_4'), 
                                rep('TD1', 2), rep('TD_2', 2), c('TD_3', 'TD_4') )
plot_cell_clusters(raw_count_cds, color_by = 'batch', show_density = F) 

#5. also check the decision plot 
plot_rho_delta(raw_count_cds, rho_threshold = 0.5, delta_threshold = 50)
plot_cell_clusters(raw_count_cds, color_by = 'batch', rho_threshold = 0.5, delta_threshold = 50)

#6. re-run cluster and skipping calculating the rho_sigma 
raw_count_cds <- clusterCells_Density_Peak(raw_count_cds, verbose = T, rho_threshold = 0.5, delta_threshold = 50, skip_rho_sigma = T)

#7. make the final clustering plot: 
plot_cell_clusters(raw_count_cds, color_by = 'as.factor(Cluster)', show_density = F)
plot_cell_clusters(raw_count_cds, color_by = 'as.factor(batch)', show_density = F)

#perform DEG test across clusters: 
raw_count_cds@expressionFamily <- negbinomial.size()
pData(raw_count_cds)$Cluster <- factor(pData(raw_count_cds)$Cluster)
angela_clustering_DEG_genes <- differentialGeneTest(raw_count_cds, fullModelFormulaStr = '~Cluster', cores = detectCores() - 2)

angela_clustering_DEG_genes_subset <- angela_clustering_DEG_genes[fData(raw_count_cds)$num_cells_expressed > num_cells_expressed, ]

#use all DEG gene from the clusters
qval_thrsld <- 0.1
angela_ordering_genes <- row.names(subset(angela_clustering_DEG_genes, qval < qval_thrsld))

# 
angela_ordering_genes <- row.names(angela_clustering_DEG_genes_subset)[order(angela_clustering_DEG_genes_subset$qval)][1:1000] 

raw_count_cds <- setOrderingFilter(raw_count_cds, ordering_genes = angela_ordering_genes)
raw_count_cds <- reduceDimension(raw_count_cds, verbose = T)
raw_count_cds <- orderCells(raw_count_cds)

plot_cell_trajectory(raw_count_cds, color_by = 'batch') 
pseudotime_DEG_genes_res <- differentialGeneTest(raw_count_cds)
beam_genes_res <- BEAM(raw_count_cds[, ], cores = detectCores() - 2) 

plot_genes_branched_heatmap(raw_count_cds[beam_genes_res$qval < 0.1, ], cores = detectCores() - 2) 

save(file = 'raw_count_cds', raw_count_cds)
