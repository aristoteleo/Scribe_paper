# test the running time and accuracy of each KNN algorithm 

a <- Sys.time(); test <- RANN::nn2(XYZ, k = 1000); b <- Sys.time()
a <- Sys.time(); test1 <- rflann::Neighbour(XYZ, XYZ, k = 1000, cores = 1); b <- Sys.time()
a <- Sys.time(); test2 <- FNN::get.knn(XYZ, k = 1000); b <- Sys.time()

make_knn_graph <- function(nn.index, nn.dist) { 
  nn.dist <- nn.dist
  N <- nrow(nn.index)
  
  knn_graph <- NULL
  edges <- reshape2::melt(t(nn.index)); colnames(edges) <- c("B", "A", "C"); edges <- edges[,c("A","B","C")]
  edges_weight <- reshape2::melt(t(nn.dist)); #colnames(edges_weight) = c("B", "A", "C"); edges_weight = edges_weight[,c("A","B","C")]
  edges$B <- edges$C;
  edges$C <- 1#edges_weight$value

  #Remove repetitions
  edges = unique(transform(edges, A = pmin(A,B), B=pmax(A,B)))
  
  Adj <- Matrix::sparseMatrix(i = c(edges$A, edges$B), j = c(edges$B, edges$A), x = c(edges$C, edges$C), dims = c(N, N))
  
  knn_graph <- igraph::graph_from_adjacency_matrix(Adj, mode = "undirected", weighted = T)
  
  return(knn_graph)
}

RANN_res <- make_knn_graph(test$nn.idx, test$nn.dists)
rflann_res <- make_knn_graph(test1$indices, test1$distances)
FNN_res <- make_knn_graph(test2$nn.index, test2$nn.dist)

vertex.size=2, vertex.label=NA, vertex.color = 

plot(RANN_res, layout = layout_with_drl(RANN_res), vertex.size=2, vertex.label=NA)
plot(rflann_res, layout = layout_with_drl(rflann_res), vertex.size=2, vertex.label=NA)
plot(FNN_res, layout = layout_with_drl(FNN_res), vertex.size=2, vertex.label=NA)

rflann_coord <- layout_with_drl(rflann_res)
qplot(rflann_coord[, 1], rflann_coord[, 2], color = )

