# RDI_raw <- read.table('/Users/xqiu/Downloads/RDI_knockout_smaller_w20_d1to40_k1.txt', header = T)
# RDI_magic <- read.table('/Users/xqiu/Downloads/RDI_knockout_smaller_w20_k1_d1to40_MAGIC.txt', header = T)
# qplot(RDI_raw$RDI, RDI_magic$RDI) + xlab('RDI (raw data)') + ylab('RDI (MAGIC imputed data)')
# 
# RDI_df <- data.frame(RDI = c(RDI_raw$RDI, RDI_magic$RDI), Type = c(rep('Raw data', nrow(RDI_raw)), rep('MAGIC imputed data', nrow(RDI_raw))))
# qplot(RDI, geom = 'density', color = Type, data = RDI_df)
# 
library(R.matlab)
cell_simulate_20cell_2000step <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/neuron_network/cell_simulate_20cell_2000step.mat')
cell_simulate_20cell_2000step_end40 <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/neuron_network/cell_simulate_20cell_2000step_end40.mat')

row.names(simulation_expr_mat) <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

dim(cell_simulate_20cell_2000step$cell.simulate)
dim(cell_simulate_20cell_2000step_end40$cell.simulate)

qplot(1:2002, cell_simulate_20cell_2000step_end40$cell.simulate[2, , 1])
qplot(1:2002, cell_simulate_20cell_2000step_end40$cell.simulate[6, , 1])
qplot(1:2002, cell_simulate_20cell_2000step_end40$cell.simulate[7, , 1])
qplot(1:2002, cell_simulate_20cell_2000step_end40$cell.simulate[8, , 1])

qplot(1:40, cell_simulate_20cell_2000step$cell.simulate[2, 1:40, 50])
