###############################################################################################################################################################################################
# run lung data:
###############################################################################################################################################################################################

load('/Users/xqiu/Dropbox (Personal)/Projects/BEAM/appeal/RData/prepare_lung_data.RData')

cell_cycle_gene <- c("Ccnb2", "Cdk1")
marker_genes <- c("Pdpn", "Sftpb")

cell_cycle_gene_id <- row.names(subset(fData(absolute_cds), gene_short_name %in% cell_cycle_gene))
marker_genes_gene_id <- row.names(subset(fData(absolute_cds), gene_short_name %in% marker_genes))

L <- compute_markov(t(exprs(absolute_cds)), knn=30, epsilon=1, distance_metric='euclidean', knn_autotune=10)

absolute_cds <- make_cds(exprs(absolute_cds), pData(absolute_cds), fData(absolute_cds), negbinomial.size())
absolute_cds <- setOrderingFilter(absolute_cds, quake_id)
absolute_cds <- estimateSizeFactors(absolute_cds)
absolute_cds <- estimateDispersions(absolute_cds)
absolute_cds <- reduceDimension(absolute_cds, verbose = T, norm_method = 'none', auto_param_selection = F)
absolute_cds <- orderCells(absolute_cds)

plot_cell_trajectory(absolute_cds, color_by = 'Time')

lung_magic <- MAGIC_R(t(exprs(absolute_cds[quake_id, ])), knn_autotune = 3, knn=3, t = 5)

pd <- new("AnnotatedDataFrame", data = pData(absolute_cds))
fd <- new("AnnotatedDataFrame", data = fData(absolute_cds[quake_id, ]))
lung_magic <- t(as.matrix(lung_magic))
dimnames(lung_magic) <- dimnames(absolute_cds[quake_id, ])
absolute_cds2 <-  newCellDataSet(as(as.matrix(lung_magic), 'sparseMatrix'), 
                                   phenoData = pd, 
                                   featureData = fd, 
                                   expressionFamily=negbinomial.size(), 
                                   lowerDetectionLimit=1)
pData(absolute_cds2)$Total_mRNAs <- colSums(exprs(absolute_cds2))

absolute_cds2 <- setOrderingFilter(absolute_cds2, quake_id)
absolute_cds2 <- estimateSizeFactors(absolute_cds2)
absolute_cds2 <- estimateDispersions(absolute_cds2)

absolute_cds2 <- reduceDimension(absolute_cds2, verbose = T, norm_method = 'log', auto_param_selection = F)
absolute_cds2 <- orderCells(absolute_cds2)

plot_cell_trajectory(absolute_cds2, color_by = 'Time')
plot_cell_trajectory(absolute_cds2)

plot_genes_in_pseudotime(absolute_cds2[c(cell_cycle_gene_id, marker_genes_gene_id), ])
plot_genes_in_pseudotime(absolute_cds[c(cell_cycle_gene_id, marker_genes_gene_id), ])

reverseEnbedingCDS <- function(cds) {
  if(nrow(cds@reducedDimW) < 1)
    stop('You need to first apply reduceDimension function on your cds before the reverse embedding')
  
  FM <- monocle:::normalize_expr_data(cds, norm_method = 'log')
  
  #FM <- FM[unlist(sparseApply(FM, 1, sd, convert_to_dense=TRUE)) > 0, ]
  xm <- Matrix::rowMeans(FM)
  xsd <- sqrt(Matrix::rowMeans((FM - xm)^2))
  FM <- FM[xsd > 0,]
  
  reverse_embedding_data <- reducedDimW(cds) %*% reducedDimS(cds)
  row.names(reverse_embedding_data) <- row.names(FM)
  
  cds_subset <- cds[row.names(FM), ]
  
  #make every value larger than 1: 
  reverse_embedding_data <- t(apply(reverse_embedding_data, 1, function(x) x + abs(min(x))))
    
  #rescale to the original scale: 
  reverse_embedding_data <- reverse_embedding_data * (apply(exprs(cds)[row.names(FM), ], 1, function(x) quantile(x, 0.99)) ) / rowMax(reverse_embedding_data)
  
  exprs(cds_subset) <- reverse_embedding_data
  
  return(cds_subset)
}

RGE_cds <- reverseEnbedingCDS(absolute_cds)

p1 <- qplot(lung_magic[marker_genes_gene_id[1], ], lung_magic[marker_genes_gene_id[2], ])
p1 <- qplot(lung_magic[cell_cycle_gene_id[1], ], lung_magic[cell_cycle_gene_id[2], ])

p2 <- qplot(as.numeric(exprs(absolute_cds[marker_genes_gene_id[1], ])), as.numeric(exprs(absolute_cds[marker_genes_gene_id[2], ])))

xacHelper::multiplot(p1, p2)

write.table(file = './csv_data/lung_data.txt', as.matrix(absolute_cds), row.names = T, quote = F, sep = '\t')

###############################################################################################################################################################################################
# run URMM data:
###############################################################################################################################################################################################

# which(fData(URMM_all_fig1b)$gene_short_name %in% c("Cebpe", "Irf8", "Csf1r", "Ly86", "Gfi1", "S100a8") )
# [1]  4421  5221  7934 10651 11864 18756
# fData(URMM_all_fig1b)$gene_short_name[which(fData(URMM_all_fig1b)$gene_short_name %in% c("Cebpe", "Irf8", "Csf1r", "Ly86", "Gfi1", "S100a8") )]
# [1] Cebpe  Csf1r  Gfi1   Irf8   Ly86   S100a8
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig5.RData')

blood_wt_exprs_magic <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/magic/blood_wt_exprs_magic.txt', sep = '\t')
beam_genes_ids <- row.names(subset(fData(URMM_all_fig1b), gene_short_name %in% row.names(fig1b_beam_genes)[fig1b_beam_genes$qval < 1e-1]))

V(res$g)$name %in% ordering_gene_ori
network_gene_ids <- row.names(subset(fData(URMM_all_fig1b), gene_short_name %in% V(res$g)$name))
ordering_gene_ori <- row.names(URMM_all_fig1b)[fData(URMM_all_fig1b)$use_for_ordering]
URMM_all_fig1b2 <- setOrderingFilter(URMM_all_fig1b, beam_genes_ids) #c(network_gene_ids, ordering_gene_ori)
URMM_all_fig1b2 <- reduceDimension(URMM_all_fig1b2, verbose = T, norm_method = 'log', auto_param_selection = T) #
URMM_all_fig1b2 <- orderCells(URMM_all_fig1b2)
plot_cell_trajectory(URMM_all_fig1b2)
plot_cell_trajectory(URMM_all_fig1b2, color_by = 'paper_cluster')

blood_wt_exprs_magic <- MAGIC_R(t(as.matrix(exprs(URMM_all_fig1b[beam_genes_ids, ]))), knn_autotune = 3, knn=9, t = 3) #knn = 3

blood_wt_exprs_magic <- as.data.frame(t(blood_wt_exprs_magic))
dimnames(blood_wt_exprs_magic) <- dimnames(URMM_all_fig1b[beam_genes_ids, ])

pd <- new("AnnotatedDataFrame", data = pData(URMM_all_fig1b))
fd <- new("AnnotatedDataFrame", data = fData(URMM_all_fig1b[beam_genes_ids, ]))
URMM_all_fig1b2 <-  newCellDataSet(as(as.matrix(blood_wt_exprs_magic), 'sparseMatrix'), 
                              phenoData = pd, 
                              featureData = fd, 
                              expressionFamily=negbinomial.size(), 
                              lowerDetectionLimit=1)
pData(URMM_all_fig1b2)$Total_mRNAs <- colSums(exprs(URMM_all_fig1b2))

URMM_all_fig1b2 <- estimateSizeFactors(URMM_all_fig1b2)
URMM_all_fig1b2 <- estimateDispersions(URMM_all_fig1b2)

URMM_all_fig1b2 <- reduceDimension(URMM_all_fig1b2, verbose = T, norm_method = 'log', auto_param_selection = F)
URMM_all_fig1b2 <- orderCells(URMM_all_fig1b2)
plot_cell_trajectory(URMM_all_fig1b2) + facet_wrap(~State)
plot_cell_trajectory(URMM_all_fig1b2, color_by = 'paper_cluster')
plot_cell_trajectory(URMM_all_fig1b2, color_by = 'Pseudotime')
plot_cell_trajectory(URMM_all_fig1b2, color_by = 'Pseudotime')

URMM_all_fig1b2 <- orderCells(URMM_all_fig1b2, root_state = 1)
plot_genes_in_pseudotime(URMM_all_fig1b2[c(1:5), ])
plot_genes_in_pseudotime(URMM_all_fig1b2[c(1:5), ])

example_genes <- c('Cebpe', 'Csf1r', 'Gfi1', 'Irf8', 'Ly86', 'S100a8')
example_genes_id <- row.names(subset(fData(URMM_all_fig1b2), gene_short_name %in% example_genes))
qplot(pData(URMM_all_fig1b2)$Pseudotime, exprs(URMM_all_fig1b2)[1, ])
qplot(pData(URMM_all_fig1b2)$Pseudotime, exprs(URMM_all_fig1b2)[2, ])

#plot the reduced dimension: 
order_hbp_mat <- as.matrix(exprs(URMM_all_fig1b2)[, order(pData(URMM_all_fig1b2)$Pseudotime)])
pd <- pData(URMM_all_fig1b2[, colnames(order_hbp_mat)])
fd <- fData(URMM_all_fig1b2)

write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_magic.txt', order_hbp_mat, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_phenotype_data.txt',  pd, col.names = T, sep = '\t', row.names = T, quote = F)
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_genotype_data.txt',  fd, col.names = T, sep = '\t', row.names = T, quote = F)

order_hbp_mat_state12 <- order_hbp_mat[, pData(URMM_all_fig1b2)$State %in% c(1:2)] 
order_hbp_mat_state13 <- order_hbp_mat[, pData(URMM_all_fig1b2)$State %in% c(1, 3)] 
#monocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state12_magic_t3.txt', order_hbp_mat_state12, col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state13_magic_t3.txt', order_hbp_mat_state13, col.names = T, sep = '\t', row.names = T, quote = F)

order_hbp_mat_state1 <- order_hbp_mat[, pData(URMM_all_fig1b2)$State %in% c(1)] 
order_hbp_mat_state2 <- order_hbp_mat[, pData(URMM_all_fig1b2)$State %in% c(2)] 
order_hbp_mat_state3 <- order_hbp_mat[, pData(URMM_all_fig1b2)$State %in% c(3)] 
#progenitor
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state1_magic_t3.txt', order_hbp_mat_state1, col.names = T, sep = '\t', row.names = T, quote = F)
#monocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state2_magic_t3.txt', order_hbp_mat_state2, col.names = T, sep = '\t', row.names = T, quote = F)
#granulocyte
write.table(file = '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/blood_wt_data_state3_magic_t3.txt', order_hbp_mat_state3, col.names = T, sep = '\t', row.names = T, quote = F)

###############################################################################################################################################################################################
# run mar-seq data:
###############################################################################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig_SI6.RData')

plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'cell_type')

all_wt_GSE72857_cds <- reduceDimension(all_wt_GSE72857_cds, auto_param_selection = F, verbose = T, maxIter = 100)
all_wt_GSE72857_cds <- orderCells(all_wt_GSE72857_cds)

all_wt_GSE72857_cds <- trimTree(all_wt_GSE72857_cds)

plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'cell_type')
plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'Pseudotime')
plot_cell_trajectory(all_wt_GSE72857_cds, color_by = 'State') + facet_grid(~State)

all_wt_GSE72857_cds <- orderCells(all_wt_GSE72857_cds, root_state = 2)
mar_seq_ordering_genes_ids <- row.names(subset(fData(all_wt_GSE72857_cds), use_for_ordering == T))
mar_seq_exprs_magic <- MAGIC_R(t(as.matrix(exprs(all_wt_GSE72857_cds[mar_seq_ordering_genes_ids, ]))), knn_autotune = 3, knn= 6, t = 8) #knn = 3

mar_seq_exprs_magic <- as.data.frame(t(mar_seq_exprs_magic))
dimnames(mar_seq_exprs_magic) <- dimnames(all_wt_GSE72857_cds[mar_seq_ordering_genes_ids, ])

pd <- new("AnnotatedDataFrame", data = pData(all_wt_GSE72857_cds))
fd <- new("AnnotatedDataFrame", data = fData(all_wt_GSE72857_cds[mar_seq_ordering_genes_ids, ]))
all_wt_GSE72857_cds2 <-  newCellDataSet(as(as.matrix(mar_seq_exprs_magic), 'sparseMatrix'), 
                                   phenoData = pd, 
                                   featureData = fd, 
                                   expressionFamily=negbinomial.size(), 
                                   lowerDetectionLimit=1)
pData(all_wt_GSE72857_cds2)$Total_mRNAs <- colSums(exprs(all_wt_GSE72857_cds2))

all_wt_GSE72857_cds2 <- estimateSizeFactors(all_wt_GSE72857_cds2)
all_wt_GSE72857_cds2 <- estimateDispersions(all_wt_GSE72857_cds2)

all_wt_GSE72857_cds2 <- reduceDimension(all_wt_GSE72857_cds2, verbose = T, norm_method = 'log', auto_param_selection = T)
 all_wt_GSE72857_cds2 <- orderCells(all_wt_GSE72857_cds2)
plot_cell_trajectory(all_wt_GSE72857_cds2) + facet_wrap(~State)
plot_cell_trajectory(all_wt_GSE72857_cds2, color_by = 'cell_type')
plot_cell_trajectory(all_wt_GSE72857_cds2, color_by = 'Pseudotime')
plot_cell_trajectory(all_wt_GSE72857_cds2, color_by = 'Pseudotime')

###############################################################################################################################################################################################
# save the data:
###############################################################################################################################################################################################


