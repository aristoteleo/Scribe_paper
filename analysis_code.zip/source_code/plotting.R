#' make the level plot when given a graph 
plot_graph_hierarchy <- function(g){
  res <- netbiov::level.plot(g)
  
  cus_layout <- res$layout
  v_size <- rep(res$vertex.size, nrow(cus_layout))
  res$vertex.label.cex <- rep(0.25, length(v_size))
  res$vertex.label.cex <- 0.2
  res$layout <- cus_layout
  res$bg <- 'white'
  res$vertex.size <- v_size
  
  res$vertex.label <- V(res$g)$name
  res$lab.color <- 'black'
  
  res$vertex.color[1:2] <- c('#BCA0CC')
  res$vertex.color[res$vertex.color == 'orange2'] <- '#7EB044'
  
  res$vertex.frame.color <- res$vertex.color
  
  update_res <- plot.netbiov(res)
  
  return(update_res)
}
