########################################################################################################################################################################
# Plotting function to make the network plots
########################################################################################################################################################################
g1 <- graph_from_adjacency_matrix(as.matrix(hbp_network_mat), mode = "directed")

setdiff(V(g1)$name, as.character(df$labels))
setdiff(uniq_genes, as.character(df$labels))

# #
# load('./RData/ccm_res')
# 
# abs_parallel_res_mat1 <- prepare_ccm_res(abs_parallel_res_lineage1, gene_names = colnames(abs_parallel_res_mat1))
# abs_parallel_res_mat2 <- prepare_ccm_res(abs_parallel_res_lineage2, gene_names = colnames(abs_parallel_res_mat1))
# 
# #create a graph and then plot the graph as a hiearchical fashion: 
# abs_parallel_res_mat1_g <- abs_parallel_res_mat1
# abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) > 0.1, arr.ind = T)] <- abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) > 0.1, arr.ind = T)]
# abs_parallel_res_mat1_g[which(abs(abs_parallel_res_mat1_g) < 0.1, arr.ind = T)] <- 0
# 
# #netbiov, igraph, 
# #build a graph: 
# layouts <- grep("^layout_", ls("package:igraph"), value=TRUE)[-1]
# g1 <- graph_from_adjacency_matrix(as.matrix(abs_parallel_res_mat1_g), mode = "directed", weighted = T)
# 
# plot(g1, layout = layout.reingold.tilford(g1, root = c('Irf8','Gfi1')), vertex.size = 6)
# # plot(g1, layout = layout_nicely(g1, ))
# 
# g5 <- graph.adjacency(m5$adjacency, mode="undirected")
# plot(g5, layout = layout_as_tree(g5) )
# tkplot(g1)
# 
# # create data frames for vertices and edges with the right variable names
# MapperNodes <- mapperVertices(mapper_res, 1:length(mapper_res$points_in_vertex) )
# dev.off()
# 
# MapperLinks <- mapperEdges(mapper_res)
# 
# # interactive plot
# forceNetwork(Nodes = MapperNodes, Links = MapperLinks,
#              Source = "Linksource", Target = "Linktarget",
#              Value = "Linkvalue", NodeID = "Nodename",
#              Group = "Nodegroup", opacity = 0.8,
#              linkDistance = 10, charge = -400)
# 
# mst.plot.mod(g1, v.size=1.5,e.size=.25,
#              colors=c("red",   "orange",   "yellow",   "green"),
#              mst.e.size=1.2,expression=abs(runif(vcount(g1),
#                                                  max=5,   min=1)),   sf=1,   v.sf=1,
#              mst.edge.col="white",   layout.function=layout.fruchterman.reingold)
# 
# 
# plot.abstract.nodes(g1,
#                     lab.cex=1, lab.color="white", v.sf=0, e.sf = 0, 
#                     layout.function=layout.fruchterman.reingold)

# level.plot(g1, layout.function=NULL, type=1, initial_nodes=c('Gfi1', 'Irf8'),
#            init_nodes=0, order_degree = "in", plotsteps = FALSE, 
#            saveplots=FALSE, dirname=NULL, vertex.colors=NULL, 
#            edge.col=NULL, tkplot=F, nodeset=NULL,path.col="green", 
#            col.s1="red", col.s2="yellow", nodes.on.path=TRUE,v.size=2, 
#            e.size=.5, v.lab=T, bg="black", v.lab.cex=0.5, 
#            v.lab.col="skyblue",sf=4,e.path.width=1,e.curve=.5, 
#            level.spread=FALSE)  

# pdf('./main_figures/fig4i.pdf')
# level.plot(g1, layout.function=NULL, type=1, initial_nodes=c(1, 2),
#            init_nodes=0, order_degree = "in", plotsteps = FALSE, 
#            saveplots=FALSE, dirname=NULL, vertex.colors=NULL, 
#            edge.col=NULL, tkplot=F, nodeset=NULL,path.col="green", 
#            col.s1="red", col.s2="yellow", nodes.on.path=TRUE,v.size=2, 
#            e.size=.5, v.lab=T, bg="black", v.lab.cex=0.5, 
#            v.lab.col="skyblue",sf=4,e.path.width=1,e.curve=.5, 
#            level.spread=FALSE)  
# dev.off()
V(g1)$label <- V(g1)$name

pdf(paste(main_fig_dir, 'fig4i.pdf', sep = ''))
res <- level.plot(g1)  
dev.off()

save(file = '/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res', res)
#save the data: 
################################################################################################################################################################################################################################################
# save.image('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/fig5.RData')
save.image('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig5.RData')
################################################################################################################################################################################################################################################

# #convert to jason: only restricted to tree structure not others 
# library(data.tree)
# tree <- FromDataFrameNetwork(as.data.frame(as.matrix(hbp_network_mat)))

#create the tree with just igraph: 
# V(g1)$label <- V(g1)$name
# V(g1)$name <- 1:length(V(g1)$name)
# res <- level.plot(g1 , initial_nodes=1:2, v.lab = T) # , initial_nodes=c('Gfi1', 'Irf8'
# 
# # res <- level.plot(g1 , initial_nodes=c('Gfi1', 'Irf8')) # , initial_nodes=c('Gfi1', 'Irf8'
# # res <- level.plot(g1, v.lab = T, init_nodes = 2) # , initial_nodes=c('Gfi1', 'Irf8'
# 
# res <- level.plot(g1) # , initial_nodes=c('Gfi1', 'Irf8'

# load("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/res") #load the res (we need to mannually set the initial_nodes 1:2 in .process_graph1 function)

# make network plots: 

# load("/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/res") #load the res (we need to mannually set the initial_nodes 1:2 in .process_graph1 function)
load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res") #load the res (we need to mannually set the initial_nodes 1:2 in .process_graph1 function)

cus_layout <- res$layout
master_regulator_id <- 1:2 #cus_layout[, 2] %in% min(unique(cus_layout[, 2])) #1:2 #
direct_target_id <- cus_layout[, 2] %in% unique(cus_layout[, 2])[order(unique(cus_layout[, 2])) == 2]
secondary_target_id <- cus_layout[, 2] %in% max(unique(cus_layout[, 2]))

cus_layout[master_regulator_id, 1]
cus_layout[master_regulator_id, 1] <- c(-15, 15)
cus_layout[direct_target_id, 1] <- cus_layout[direct_target_id, 1] * 1.5 #order(cus_layout[direct_target_id, 1]) * 2  - length(cus_layout[direct_target_id, 1]) * 20
cus_layout[secondary_target_id, 1] <- cus_layout[secondary_target_id, 1] * 1#order(cus_layout[secondary_target_id, 1]) * 10 - length(cus_layout[secondary_target_id, 1])  * 5

v_size <- rep(res$vertex.size, nrow(cus_layout)) 
v_size[master_regulator_id] <- 12
v_size[direct_target_id] <- 4#v_size[direct_target_id] * 1.5
v_size[secondary_target_id] <- 2.5

cus_layout[master_regulator_id, 2] <- 0
cus_layout[direct_target_id, 2] <- -1
cus_layout[secondary_target_id, 2] <- -2

# [1] "g"                  "layout"             "vertex.color"
# [4] "edge.color"         "edge.arrow.size"    "vertex.label.cex"
# [7] "vertex.label"       "lab.color"          "lab.dist"
# [10] "vertex.frame.color" "edge.width"         "bg"
# [13] "edge.curved"
res$vertex.label.cex <- rep(0.25, length(v_size))
res$vertex.label.cex[1:2] <- 1
res$layout <- cus_layout
res$bg <- 'white'
res$vertex.size <- v_size

res$vertex.label <- V(res$g)$name
res$lab.color <- 'black'

res$vertex.color[1:2] <- c('#BCA0CC')
res$vertex.color[direct_target_id] <- '#77CCD2'
res$vertex.color[res$vertex.color == 'orange2'] <- '#7EB044'

#label the second layer genes without outdegree
secondary_layer_degree <- degree(res$g, v = V(res$g)$name[cus_layout[, 2] == -1], mode = c("out"),
                                 loops = TRUE, normalized = FALSE) 
res$vertex.color[which(cus_layout[, 2] == -1)[secondary_layer_degree == 0]] <- '#F3756C'
# secondary_layer <- degree(res$g, v = V(res$g)$name[cus_layout[, 2] == -1], mode = c("out"),
#                           loops = TRUE, normalized = FALSE) 

res$vertex.frame.color <- res$vertex.color
res$vertex.label <- c(res$vertex.label[1:2], rep('', length(res$vertex.label) - 2))

pdf(paste(main_fig_dir, 'fig5i.pdf', sep = ''), width = 12, height = 7)
plot.netbiov(res)
dev.off()
