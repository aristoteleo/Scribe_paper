# rank the RDI sum for both the Olsson data as well as the pancreas dataset

# pancreas dataset
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_pancreas.RData')

# run the entire procedure 
# select the genes and order pseudotime 
# alpha cell: Glucagon; beta cell: insulin  
alpha_cell <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5, 3, 2)]
beta_cell <- panc_cds_valid_cells[, pData(panc_cds_valid_cells)$State %in% c(5, 3, 1)]

gene_list <- fData(panc_cds_valid_cells[fData(panc_cds_valid_cells)$use_for_ordering, ])$gene_short_name
gene_list <- c(gene_list, )
exprs(alpha_cell) <- as.matrix(exprs(alpha_cell)); exprs(beta_cell) <- as.matrix(exprs(beta_cell)); 
alpha_cell_dpt_res <- run_new_dpt(alpha_cell); beta_cell_dpt_res <- run_new_dpt(beta_cell)

alpha_cell_exprs <- t(exprs(alpha_cell)[, order(alpha_cell_dpt_res$pt)])
beta_cell_exprs <- t(exprs(beta_cell)[fData(panc_cds_valid_cells)$use_for_ordering, order(beta_cell_dpt_res$pt)]) #

# run RDI, CRDI, etc. 

################################################################################################################################################
# alpha cells 
################################################################################################################################################
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(alpha_cell_exprs) * ncol(alpha_cell_exprs)), nrow = nrow(alpha_cell_exprs))
a <- Sys.time()
alpha_RDI_parallel_res <- calculate_rdi(alpha_cell_exprs + noise, delays = c(5, 10, 15))
b <- Sys.time()

a <- Sys.time()
alpha_cRDI_parallel_res <- calculate_conditioned_rdi(alpha_cell_exprs + noise, rdi_list = alpha_RDI_parallel_res)
b <- Sys.time()

################################################################################################################################################
# beta cells 
################################################################################################################################################
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(beta_cell_exprs) * ncol(beta_cell_exprs)), nrow = nrow(beta_cell_exprs))
a <- Sys.time()
beta_RDI_parallel_res <- calculate_rdi(beta_cell_exprs + noise, delays = c(5, 10, 15))
b <- Sys.time()

a <- Sys.time()
beta_cRDI_parallel_res <- calculate_conditioned_rdi(beta_cell_exprs + noise, rdi_list = beta_RDI_parallel_res)
b <- Sys.time()

# rank the sum of RDI, cRDI results 
# rowSum of the RDI values 
dimnames(alpha_cRDI_parallel_res) <- list(fData(alpha_cell)[row.names(alpha_cRDI_parallel_res), 'gene_short_name'], fData(alpha_cell)[row.names(alpha_cRDI_parallel_res), 'gene_short_name'])
apply(alpha_cRDI_parallel_res, 1, function(x) sum(x, na.rm = T)) # out-flow sum 

which(names(sort(apply(alpha_cRDI_parallel_res, 1, function(x) sum(x, na.rm = T)))) %in% 'Neurog3')

dimnames(beta_cRDI_parallel_res) <- dimnames(alpha_cRDI_parallel_res) 
apply(beta_cRDI_parallel_res, 1, function(x) sum(x, na.rm = T)) # 25 # out-flow sum 

which(names(sort(apply(beta_cRDI_parallel_res, 1, function(x) sum(x, na.rm = T)))) %in% 'Neurog3') # 20 # out-flow sum

# Node influence metric

library(igraph)
beta_cRDI_parallel_res[is.na(beta_cRDI_parallel_res)] <- 0
beta_cRDI_parallel_res_update <- sqrt(InformationEstimator::clr(beta_cRDI_parallel_res) * t(InformationEstimator::clr(t(beta_cRDI_parallel_res))))

g <- igraph::graph_from_adjacency_matrix(beta_cRDI_parallel_res_update, mode = 'directed', weighted = T)
sort(eigen_centrality(g)$vector)
sort(hub_score(g)$vector)
sort(authority_score(g)$vector)
sort(page_rank(g)$vector)
sort(rowSums(shortest.paths(g, V(g))))

# save data 




