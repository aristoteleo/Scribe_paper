
#' test 
load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/RData/all_cell_simulation.RData')
all_cell_simulation_subset <- all_cell_simulation[, ,1]
gen_zero_inf_sim_data(all_cell_simulation_subset)

####################################################################################################################################################################################
gene_names <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

neuron_exprs_mat <- t(gen_zero_inf_sim_data(all_cell_simulation_subset))
#as.matrix(all_cell_simulation[, , neuron_cell_ids[1]])
dimnames(neuron_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

astrocyte_exprs_mat <- t(gen_zero_inf_sim_data(as.matrix(all_cell_simulation[, , astrocyte_cell_ids[1]])))
#as.matrix(all_cell_simulation[, , astrocyte_cell_ids[1]])
dimnames(astrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

oligodendrocyte_exprs_mat <- t(gen_zero_inf_sim_data(as.matrix(all_cell_simulation[, , oligodendrocyte_cell_ids[1]])))
#as.matrix(all_cell_simulation[, , oligodendrocyte_cell_ids[1]])
dimnames(oligodendrocyte_exprs_mat) = list(gene_names, paste('Cell_', rep(1:400, 1), sep = ''))

PD <- data.frame(Time = rep(1:400, 1), row.names = paste('Cell_', rep(1:400, 1), sep = ''))
FD <- data.frame(gene_short_names = gene_names, row.names = gene_names)

pd <- new("AnnotatedDataFrame",data=PD)
fd <- new("AnnotatedDataFrame",data=FD)

make_cds <- function (exprs_matrix, pd, fd, lowerDetectionLimit = 1, expressionFamily) {
  cds <- new("CellDataSet", assayData = assayDataNew("environment",
                                                     exprs = exprs_matrix), phenoData = pd, featureData = fd,
             lowerDetectionLimit = lowerDetectionLimit, expressionFamily = expressionFamily,
             dispFitInfo = new.env(hash = TRUE))
  return(cds)
}

neuron_sim_cds <- make_cds(neuron_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'neuron'
astrocyte_sim_cds <- make_cds(astrocyte_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'astrocyte'
oligodendrocyte_sim_cds <- make_cds(oligodendrocyte_exprs_mat, pd, fd, expressionFamily = negbinomial())
pData(neuron_sim_cds)$cell_type <- 'oligodendrocyte'

neuron_sim_cds <- estimateSizeFactors(neuron_sim_cds)
neuron_sim_cds <- estimateDispersions(neuron_sim_cds)
astrocyte_sim_cds <- estimateSizeFactors(astrocyte_sim_cds)
astrocyte_sim_cds <- estimateDispersions(astrocyte_sim_cds)
oligodendrocyte_sim_cds <- estimateSizeFactors(oligodendrocyte_sim_cds)
oligodendrocyte_sim_cds <- estimateDispersions(oligodendrocyte_sim_cds)

neuron_sim_cds <- setOrderingFilter(neuron_sim_cds, ordering_genes = row.names(neuron_sim_cds))
neuron_sim_cds <- reduceDimension(neuron_sim_cds, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=0, scaling = F)
neuron_sim_cds <- orderCells(neuron_sim_cds)
plot_cell_trajectory(neuron_sim_cds)

neuron_sim_cds <- orderCells(neuron_sim_cds, root_state = 3)
plot_cell_trajectory(neuron_sim_cds)
qplot(pData(neuron_sim_cds)$Time, pData(neuron_sim_cds)$Pseudotime) + xlab('real time') + ylab('pseudotime')

astrocyte_sim_cds <- setOrderingFilter(astrocyte_sim_cds, ordering_genes = row.names(neuron_sim_cds))
astrocyte_sim_cds <- reduceDimension(astrocyte_sim_cds, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=0, scaling = F)
astrocyte_sim_cds <- orderCells(astrocyte_sim_cds)
plot_cell_trajectory(astrocyte_sim_cds, color_by = 'Time')
qplot(pData(astrocyte_sim_cds)$Time, pData(astrocyte_sim_cds)$Pseudotime) + xlab('real time') + ylab('pseudotime')

oligodendrocyte_sim_cds <- setOrderingFilter(oligodendrocyte_sim_cds, ordering_genes = row.names(neuron_sim_cds))
oligodendrocyte_sim_cds <- reduceDimension(oligodendrocyte_sim_cds, norm_method = 'none', verbose = T, auto_param_selection = F, maxIter = 100,  pseudo_expr=0, scaling = F)
oligodendrocyte_sim_cds <- orderCells(oligodendrocyte_sim_cds)
plot_cell_trajectory(oligodendrocyte_sim_cds, color_by = 'Time')
qplot(pData(oligodendrocyte_sim_cds)$Time, pData(oligodendrocyte_sim_cds)$Pseudotime) + xlab('real time') + ylab('pseudotime')

####################################################################################################################################################################################
# run the full simulation 
####################################################################################################################################################################################







