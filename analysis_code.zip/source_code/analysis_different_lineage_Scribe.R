# run different lineages and check which gene pair doesn't make sense 
library(Scribe)

load("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Monocle 2/first_revision/Monocle2_revision/RData/fig3.RData") # cds data

##########################################################################################################################################################
# show the drevi plot 
##########################################################################################################################################################
# show the neuron 
fData(neuron_sim_cds)$gene_short_name <- fData(neuron_sim_cds)$gene_short_names
plot_lag_drevi(neuron_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)

# show the oligodendrocyte 
fData(oligodendrocyte_sim_cds)$gene_short_name <- fData(oligodendrocyte_sim_cds)$gene_short_names
plot_lag_drevi(oligodendrocyte_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)

# show the astrocyte
fData(astrocyte_sim_cds)$gene_short_name <- fData(astrocyte_sim_cds)$gene_short_names
plot_lag_drevi(astrocyte_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)

##########################################################################################################################################################
# show the gardiner plot 
##########################################################################################################################################################
plot_rdi_pairs_heatmap(neuron_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)
plot_rdi_pairs_heatmap(oligodendrocyte_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)
plot_rdi_pairs_heatmap(astrocyte_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, verbose = T)
                       
##########################################################################################################################################################
# run RDI, cRDI and then comparing the result 
##########################################################################################################################################################
run_vec <- rep(1, ncol(neuron_sim_cds))
tmp <- expand.grid(1:ncol(neuron_sim_cds), 1:ncol(neuron_sim_cds), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

##########################################################################################################################################################
# run RDI 
##########################################################################################################################################################
# neuron
data <- t(exprs(neuron_sim_cds)[, 1:200]) # prepare the data (row is sample, column is gene)
noise = matrix(rnorm(mean = 0, sd = 0, nrow(data) * ncol(data)), nrow = nrow(data))

run_vec <- rep(1, nrow(data)) # run information for each cell

# create the network graph we want to estimate RDI (here we calculate all possible pair of gene regulation)
tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 #
super_graph <- super_graph[, c(2, 1)]

neuron_rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise

# run cRDI 
dimnames(neuron_rdi_list$max_rdi_value) <- list(gene_names, gene_names)
neuron_con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data + noise, as.matrix(super_graph), as.matrix(neuron_rdi_list$max_rdi_value), as.matrix(neuron_rdi_list$max_rdi_delays), run_vec - 1, 1)
dimnames(neuron_con_rdi_res_test) <- list(gene_names, gene_names)

# visualize the network by heatmap
pheatmap::pheatmap(neuron_rdi_list$max_rdi_value, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)
pheatmap::pheatmap(neuron_con_rdi_res_test, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)

# astrocyte
data <- t(exprs(astrocyte_sim_cds)[, 1:200]) # prepare the data (row is sample, column is gene)
astrocyte_rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise

# run cRDI 
dimnames(astrocyte_rdi_list$max_rdi_value) <- list(gene_names, gene_names)
astrocyte_con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data + noise, as.matrix(super_graph), as.matrix(astrocyte_rdi_list$max_rdi_value), as.matrix(astrocyte_rdi_list$max_rdi_delays), run_vec - 1, 1)
dimnames(astrocyte_con_rdi_res_test) <- list(gene_names, gene_names)

# visualize the network by heatmap
pheatmap::pheatmap(astrocyte_rdi_list$max_rdi_value, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)
pheatmap::pheatmap(astrocyte_con_rdi_res_test, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)

# oligodendrocyte
data <- t(exprs(oligodendrocyte_sim_cds)[, 1:200]) # prepare the data (row is sample, column is gene)
oligo_rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise

# run cRDI 
dimnames(oligo_rdi_list$max_rdi_value) <- list(gene_names, gene_names)
oligo_con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data + noise, as.matrix(super_graph), as.matrix(oligo_rdi_list$max_rdi_value), as.matrix(oligo_rdi_list$max_rdi_delays), run_vec - 1, 1)
dimnames(oligo_con_rdi_res_test) <- list(gene_names, gene_names)

# visualize the network by heatmap
pheatmap::pheatmap(oligo_rdi_list$max_rdi_value, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)
pheatmap::pheatmap(oligo_con_rdi_res_test, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)

##########################################################################################################################################################
# Calculate the ROC AUC values 
##########################################################################################################################################################
# compare with the python implementation
rdi_list$max_rdi_value[sort(uniq_gene), sort(uniq_gene)]
con_rdi_res_test[sort(uniq_gene), sort(uniq_gene)]

rdi_list <- oligo_rdi_list # astrocyte_rdi_list # neuron_rdi_list 
con_rdi_res_test <- oligo_con_rdi_res_test # astrocyte_con_rdi_res_test # neuron_con_rdi_res_test

RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))

colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

# calculate the ROC / AUC values
RDI_df <- calROCAUC(RDI_res_df)
cRDI_df <- calROCAUC(cRDI_res_df)

##########################################################################################################################################################
# check whether or not the top 25 genes includes a lot true network links 
##########################################################################################################################################################
rdi_list <- oligo_rdi_list # astrocyte_rdi_list # neuron_rdi_list
top_25_gene_val <- sort(rdi_list$max_rdi_value, decreasing = T)[25]
arr_ind <- which(rdi_list$max_rdi_value > top_25_gene_val, arr.ind = T)
arr_ind[, 1] <- row.names(rdi_list$max_rdi_value)[arr_ind[, 1]]
arr_ind[, 2] <- row.names(rdi_list$max_rdi_value)[as.numeric(arr_ind[, 2])]

##########################################################################################################################################################
# save the result 
##########################################################################################################################################################

