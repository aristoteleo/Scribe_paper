repmat <- function(X,m,n){
  ##R equivalent of repmat (matlab)
  mx = dim(X)[1]
  nx = dim(X)[2]
  matrix(t(matrix(X,mx,nx*n)),mx*m,nx*n,byrow=T)
}

dn_sparsifer <- function(W, alpha = 2, lambda = 20, B = 184) {
  N <- nrow(W)
  
  tmp <- matrix(-1, nrow = N, ncol = N) + diag(1, N)
  A <- matrix(as.vector(tmp), nrow = 1)
  b <- -B
  
  # initialize Theta 
  Theta <- matrix(0, nrow = N, ncol = N)
  w <- matrix(unlist(W), nrow = 1)
  sortw <- sort(w, decreasing = T)
  sigma <- sortw[B]
  Theta[W > sigma] <- 1
  
  idx <- which(sortw < 1e-10)
  xi <- sortw[idx[1] - 1] * matrix(1, nrow = N, ncol = 1)
  
  iter <- 1 
  
  while(1) {
    row_norm <- matrix(rowSums(Theta), ncol = 1)
    col_norm <- matrix(colSums(Theta), nrow = 1)
    
    eta <- repmat(1 / (row_norm + xi), 1, N) + repmat(1 / (col_norm + t(xi)), N, 1)
    
    # termination condition 
    obj1 <- -sum(sum(W * (Theta - lambda * tmp)))
    obj2 <- alpha * sum(log ((row_norm + xi)))
    obj <- obj1 + obj2 
    
    if(iter > 1) {
      obj_diff <- old_obj - obj 
      rel_diff <- abs(obj_diff / old_obj)
      message('iter = ', iter, ' obj = ', obj, ' obj_diff = ', obj_diff, ' rel_diff = ', rel_diff)
      if(rel_diff < 1e-6) {
        message('converge!')
        break 
      }
    }
    old_obj <- obj 
    
    ######################################################################################################################################################### 
    # solve linear reprogramming 
    ######################################################################################################################################################### 
    fmat <- alpha * eta - lambda * tmp - Theta
    f <- matrix(unlist(fmat), nrow = 1)
    lprec <- make.lp(length(b), length(f))
    set.objfn(lprec, f)
    for(i in 1:nrow(A)) {
      add.constraint(lprec, A[i, ], "<=", b)
    }
    
    set.bounds(lprec, lower = rep(0, N * N), upper = rep(1, N*N)) #				set.bounds(lprec, lower = c(rep(0, nw), -Inf*rep(1, K*D)), columns = 1:length(b))
    #solve the model, if this return 0 an optimal solution is found
    solve(lprec)
    
    obj_W <- get.objective(lprec)
    theta <- get.variables(lprec)
    
    Theta <- matrix(theta, nrow = N, ncol = N)
    Theta[Theta < 1e-6] <- 0 
    
    iter <- iter + 1
  }
  
  return(Theta)
}

