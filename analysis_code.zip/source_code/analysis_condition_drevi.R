

# inflection point detection
v1 = c(0.299584,0.314446,0.357783,0.388896,0.410417,0.427182,0.450383,0.466671,0.474884,0.474749,0.493566,0.500374,0.522482,0.529851,0.538387,0.577901,0.610939,0.639383,0.662433,0.692656,0.720543,0.738255,0.748055,0.7591,0.770595,0.781811,0.794479,0.794588,0.789448,0.77667,0.765406,0.75152,0.740408,0.726898,0.720766,0.709445,0.69896,0.687508,0.673382,0.65795,0.639214,0.620445,0.590047,0.561773,0.526807,0.486848,0.439681,0.387545,0.313369,0.282872,0.279908,0.271836,0.269088,0.262727,0.259782)

v2 = c(0.081309,0.206263,0.429069,0.511859,0.565194,0.578792,0.56919,0.51985,0.432563,0.193907,0.0771,0.086603,0.18303,0.177608,0.169706,0.260917,0.292062,0.2979,0.263249,0.270576,0.250422,0.25219,0.182878,0.080623,0.079443,0.088944,0.087623,0.126403,0.155563,0.273942,0.312054,0.370195,0.357087,0.336452,0.300574,0.243105,0.243105,0.25593,0.227401,0.218047,0.15857,0.157727,0.139801,0.125742,0.129142,0.142166,0.142166,0.136748,0.107755,0.064377,0.072801,0.060093,0.103441,0.111704,0.124544)

plot(v2, type="l", col="darkblue", lwd=2)
# v2 <- smooth(v2, kind="3")  # optional
lines(v2, lwd=1, col="red")
d2 <- diff(v2)
d2 <- d2>0
d2 <- d2*2 -1 
k <- 5
cutoff <- 10
scores <- sapply(k:(length(d2)-k), FUN=function(i){
  score <- abs(mean(-d2[ i-1:k ], na.rm=T) + mean(d2[ i+0:k ], na.rm=T))
})


scores <- sapply(k:(length(v2)-k), FUN=function(i){
  left <- (v2[sapply(i-1:k, max, 1) ]<v2[i])*2-1
  right <- (v2[sapply(i+1:k, min, length(v2)) ]<v2[i])*2-1
  
  score <- abs(sum(left) + sum(right))
})

inflections <- (k:(length(v2)-k))[scores>=cutoff]

plot(v2, type="l")
abline(v=inflections, col="red", lwd=3)
print(inflections)

# test inflection point 
debug(plot_genes_in_pseudotime)
plot_genes_in_pseudotime(Olsson_monocyte_cds[gene_name_vec, ])
ggplot(aes(Pseudotime, expression), data = cds_exprs)
qplot(Pseudotime, expectation, data = subset(cds_exprs, f_id == 'Irf8')) + geom_vline(xintercept = 15.66864)

library(inflection)
cds_exprs$inflection_point <- 0
for(gene_name in unique(cds_exprs$f_id)) {
  data <- subset(cds_exprs, f_id == gene_name)
  message('gene_name is ', gene_name)
  inflection_point <- bede(data$Pseudotime, data$expectation, 0)
  if(!is.finite(inflection_point$iplast))
    inflection_point <- bede(data$Pseudotime, data$expectation, 1)
  # inflection_point <- tryCatch(bede(data$Pseudotime, data$expectation, 0), error = function() 
  #   message('Running inflection point detection in the mode of convex/concave failed, trying concave/convex mode instead'), 
  #   bede(data$Pseudotime, data$expectation, 1))
  message('inflection_point is ', inflection_point$iplast)
  cds_exprs[row.names(data), 'inflection_point'] <- inflection_point$iplast
}

# qplot(Pseudotime, expectation, data = cds_exprs,color = f_id)#subset(cds_exprs, f_id == 'Zeb2')) + geom_vline(xintercept = 15.91852)
# 
# bede(data$Pseudotime, data$expectation, 1) 
# qplot(Pseudotime, expectation, data = data) + geom_vline(xintercept = 191)
# 

data <- Reduce(cbind, list(x, y, z))

if(conditioning) {
  xyz_kde <- kde(data, gridsize = c(100,100, 100))

  x_meshgrid <- xyz_kde$eval.points[[1]]
  y_meshgrid <- xyz_kde$eval.points[[2]]
  z_meshgrid <- xyz_kde$eval.points[[3]]
  
  den_res <- matrix(0, nrow = length(x_meshgrid), ncol = length(y_meshgrid))
  flat_res <- as.data.frame(matrix(0, nrow = length(x_meshgrid)^2, ncol = 4))
  ridge_curve <- as.data.frame(matrix(0, nrow = length(x_meshgrid), ncol = 3))

  xy <- data.frame()
  colnames(flat_res) <- c("x", "y", "den", "type")
  colnames(ridge_curve) <- c("x", "y", "type")
  
  nConBins <- length(z_meshgrid)
  for(conBins in 1:nConBins) {
    den_res_tmp <- xyz_kde$estimate[, , conBins]
    den_res_tmp[!is.finite(den_res_tmp)] <- 0
    den_res <- den_res + den_res_tmp / (nConBins * sum(den_res_tmp)) 
  }
  
  den_x <- colSums(den_res) # just calculate the sum for each column 
} else {
  bandwidth <- c(MASS::bandwidth.nrd(x), MASS::bandwidth.nrd(y))
  if(any(bandwidth == 0)) {
    max_vec <- c(max(x), max(y))
    bandwidth[bandwidth == 0] <- max_vec[bandwidth == 0] / dim_val
  }
  den_xy <- MASS::kde2d(x, y, n = c(dim_val, dim_val), lims = c(min(x), max(x), min(y), max(y)), h = bandwidth)
  den_res <- as.data.frame(den_xy$z)
  # dimnames(den_res) <- list(paste0("x_", as.character(den_xy$x)), paste0("y_", as.character(den_xy$y)))
  # den_x_res <- density(x, n = round(length(x))/ 4, from = min(x), to = max(x))
  # den_x <- den_x_res$y
  den_x <- colSums(den_res) # just calculate the sum for each column 
  
  x_meshgrid <- den_xy$x
  y_meshgrid <- den_xy$y
}

for(i in 1:length(x_meshgrid)) {
  max_val <- max(den_res[i, ] / den_x[i]) # 
  max_ind <- which.max(den_res[i, ] / den_x[i]) 
  # message("i is ", i, "max_val is ", max_val, "max_ind is ", max_ind)
  ridge_curve[i + r_ini_ind, ] <- c(den_xy$x[i], den_xy$y[max_ind], gene_pair_name)
  
  for(j in 1:length(x_meshgrid)) {
    flat_res[(i - 1) * length(den_xy$x) + j + f_ini_ind, ] <- c(den_xy$x[i], den_xy$y[j], den_res[i, j] / den_x[i] / max_val, gene_pair_name)
  }
}
xy_tmp <- data.frame(x = x, y = y, 'type' = gene_pair_name)
xy <- rbind(xy, xy_tmp)    

id <- id + 1
}

for(i in 1:length(x_meshgrid)) {
  max_val <- max(den_res[i, ] / den_x[i]); min_val <- 0 #min(den_res[i, ] / den_x[i]) # 
  max_ind <- which.max(den_res[i, ] / den_x[i]) 
  # message("i is ", i, "j is ", j, "vector is ", c(x_meshgrid[i], y_meshgrid[max_ind], gene_pair_name))
  ridge_curve[i + r_ini_ind, ] <- c(x_meshgrid[i], y_meshgrid[max_ind], gene_pair_name)
  
  for(j in 1:length(y_meshgrid)) {
    rescaled_val <- (den_res[i, j] / den_x[i] - min_val) / (max_val - min_val)
    flat_res[(i - 1) * length(x_meshgrid) + j + f_ini_ind, ] <- c(x_meshgrid[i], y_meshgrid[j], rescaled_val, gene_pair_name)
  }
}
xy_tmp <- data.frame(x = x, y = y, 'type' = gene_pair_name)
xy <- rbind(xy, xy_tmp)    

id <- id + 1

ridge_curve
colnames(xy) <- c('x', 'y', 'type')
flat_res[, 1:3] <- as.data.frame(flat_res[, 1:3])
ggplot(aes(as.numeric(x), as.numeric(y)), data = flat_res) +  geom_raster(aes(fill = as.numeric(den))) + 
  scale_fill_gradientn("Density", colours = terrain.colors(10)) + 
  geom_rug(aes(as.numeric(x), as.numeric(y)), data = xy, col="darkred",alpha=.1) + 
  geom_path(aes(as.numeric(x), as.numeric(y)), data  = ridge_curve, color = 'red') + facet_wrap(~type, scales = scales, nrow = n_row, ncol = n_col) + 
  xlab('Source') + ylab('Target') 

# Zic1 Tuj1 
x  <- matrix(x[1:(nrow(x) - d), ], ncol = 1)
y <- matrix(y_ori[-(1:d), ], ncol = 1)
z <- y_ori[d:(nrow(y_ori) - 1), ]

x <- matrix(exprs(neuron_sim_cds['Pax6', 1:199]), ncol = 1)
y <- matrix(exprs(neuron_sim_cds['Mash1', 2:200]), ncol = 1) 
z <- matrix(exprs(neuron_sim_cds['Mash1', 1:199]), ncol = 1)   

x <- log(x)
y <- log(y)
z <- log(z)

plot_ly(type = 'scatter3d', x = as.vector(x), y = as.vector(y), z = as.vector(z), mode = 'markers') # show the original space

plot_ly(type = 'scatter3d', x = 1:10, y = 1:10, z = 1:10, mode = 'markers') # show the original space

data <- Reduce(cbind, list(x, y, z))
xyz_kde <- kde(data, gridsize = c(10, 10, 4), xmin = c(min(x), min(y), min(z)), xmax = c(max(x), max(y), max(z)))

library(ks)
plot(xyz_kde, drawpoints=TRUE)

################################################################################################################################################################
# test on a lot data points: 
################################################################################################################################################################

all_exprs_mat <- as.matrix(all_cell_simulation[, 1:200, 1:200])
dim(all_exprs_mat) <- c(13, 200 * 200)

all_PD <- data.frame(Time = rep(1:200, 200), row.names = paste('Cell_', 1:40000, sep = ''))
pd <- new("AnnotatedDataFrame",data=all_PD)
  
FD <- data.frame(gene_short_names = gene_names, row.names = gene_names)
fd <- new("AnnotatedDataFrame",data=FD)

all_sim_cds <- make_cds(all_exprs_mat, pd, fd, expressionFamily = gaussianff())

fData(all_sim_cds)$gene_short_name <- fData(all_sim_cds)$gene_short_names
plot_rdi_pairs(all_sim_cds[, ], gene_pairs_mat = as.matrix(neuron_network[1:4, 1:2]), d = 1, n_row = 5, n_col = 5, conditioning = T, nConBins = 10, verbose = T)

################################################################################################################################################################
# test on a lot data points: 
################################################################################################################################################################

simulation_expr_mat_nonlinear <- read.csv('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/simulation_expr_mat_nonlinear_n_0_step_400_N_end_20')
ncells <- ncol(simulation_expr_mat_nonlinear) - 3
ncells <- 200

PD <- data.frame(Time = 1:(ncells + 1), row.names = paste('X', 0:ncells, sep = ''))
pd <- new("AnnotatedDataFrame",data=PD)

FD <- data.frame(gene_short_name = simulation_expr_mat_nonlinear$X, row.names = simulation_expr_mat_nonlinear$X)
fd <- new("AnnotatedDataFrame",data=FD)

all_exprs_mat <- as.matrix(simulation_expr_mat_nonlinear[, 3:(ncells + 3)])

qplot(all_exprs_mat[1, ], all_exprs_mat[3, ])

row.names(all_exprs_mat) <- simulation_expr_mat_nonlinear$X
all_sim_cds <- make_cds(all_exprs_mat, PD, FD, expressionFamily = gaussianff())

plot_rdi_pairs(all_sim_cds[, ], gene_pairs_mat = as.matrix(neuron_network[1:4, 1:2]), d = 1, n_row = 5, n_col = 5, conditioning = F, nConBins = 10, verbose = T)

plot_rdi_pairs(all_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[, 1:2]), d = 1, n_row = 5, n_col = 5, conditioning = T, nConBins = 10, verbose = T)
qplot(all_exprs_mat['Hes5', 1:200], all_exprs_mat['Mash1', 1:200])
qplot(all_exprs_mat['Hes5', 1:200], all_exprs_mat['Hes5', 2:201])

df <- data.frame(Gene = rep(c('Hes5', 'Mash1'), each = 200), 
                 Expression = rep(c(all_exprs_mat['Hes5', 1:200], all_exprs_mat['Mash1', 1:200])),
                 Time = c(1:200, 1:200))
qplot(all_exprs_mat['Pax6', 1:200], all_exprs_mat['Mash1', 1:200])

qplot(Time, Expression, data = df, color = Gene)

################################################################################################################################################################
# test on a lot data points: 
################################################################################################################################################################



