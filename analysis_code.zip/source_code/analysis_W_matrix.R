#test whether or not the W matrix is correlated to the BEAM qvalues: 
lung <- load_lung()
qplot(lung@reducedDimW[, 1], lung@reducedDimW[, 2], size = -BEAM_res[row.names(lung_norm_mat), 'pval'] )

qplot(abs(lung@reducedDimW[, 1] -  lung@reducedDimW[, 2]), -BEAM_res[row.names(lung_norm_mat), 'pval'] )
qplot(abs((lung@reducedDimW[, 1])^2 + (lung@reducedDimW[, 2])^2), -BEAM_res[row.names(lung_norm_mat), 'qval'] )

