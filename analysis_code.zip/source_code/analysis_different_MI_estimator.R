# run different MI estimators from the fastMI package
library(fastGeneMI)

################################################################################################################################################################################################################
# Test the Gaussian distribution  
################################################################################################################################################################################################################

################################################################################################################################################################################################################
# Test the Gaussian distribution  
################################################################################################################################################################################################################
XYZ <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Genes_Inference_in_Cell_Differentiation_Process/notebook/XYZ_tab.txt', header = F, sep = '\t')
XYZ <- t(XYZ)
linear_ML <- Sys.time()
ML_XYZ_res <- get.mim.ML(XYZ)
linear_MM <- Sys.time()
MM_XYZ_res <- get.mim.MM(XYZ)
linear_CS <- Sys.time()
CS_XYZ_res <- get.mim.CS(XYZ)
linear_Shrink <- Sys.time()
Shrink_XYZ_res <- get.mim.shrink(XYZ)
linear_Bspline <- Sys.time()
Bspline_XYZ_res <- get.mim.bspline(XYZ, order = 3)
linear_end <- Sys.time()

linear_KNN <- Sys.time()
get.mim.knn(XYZ, k = 3)
linear_KNN2 <- Sys.time()

# show the results
estimator_running_time <- data.frame(Type = factor(c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)'), levels =
                                                     c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)')), 
                                     Time = c(linear_MM - linear_ML, linear_CS - linear_MM, linear_Shrink - linear_CS, linear_Bspline - linear_Shrink, linear_end - linear_Bspline, 45.9710960388))

qplot(Type, Time, data = estimator_running_time, color = Time)

a <- Sys.time()
computeTE(X, Y, embedding = 3, k = 3)
computeTE(Y, Z, embedding = 3, k = 3)
computeTE(X, Z, embedding = 3, k = 3)
b <- Sys.time()
b - a 
# import numpy as np
# from random import gauss, uniform
# 
# 
# N = 100000
# alpha = .9; alpha_tilda=np.sqrt(1-alpha**2)
# 
# X = np.array([[abs(gauss(0,3))] for i in range(N)])
# Y = np.array([[alpha*X[i][0]+alpha_tilda*abs(gauss(0,1))] for i in range(N)])
# Z = np.array([[alpha*Y[i][0]+alpha_tilda*abs(gauss(0,1))] for i in range(N)])

# 1/2*log(var(y)/var(noise))

theoretical_mi <- function(x_var, alpha, alpha_tilde) {
  0.5 * log((alpha^2 * x_var +  alpha_tilde^2) / (alpha_tilde^2))
}

theoretical_mi(1, 0.9, sqrt(1 - 0.9^2))

N <- 100000
alpha <- 0.9; alpha_tilda <- sqrt(1 - 0.9^2)

X <- (rnorm(N, mean = 0, sd = 1))
Y <- alpha * X + alpha_tilda * (rnorm(N, 0, 1))
Z <- alpha * Y + alpha_tilda * (rnorm(N, 0, 1))

X <- (runif(N, min = 0, max = 1))
Y <- alpha * X + alpha_tilda * (runif(N, 0, 1))
Z <- alpha * Y + alpha_tilda * (runif(N, 0, 1))

X <- (rexp(N,1))
Y <- alpha * X + alpha_tilda * (rexp(N, 1))
Z <- alpha * Y + alpha_tilda * (rexp(N, 1))

XYZ_new <- data.frame(X = X, Y = Y, Z = Z)
linear_ML <- Sys.time()
ML_XYZ_res <- get.mim.ML(XYZ_new)
linear_MM <- Sys.time()
MM_XYZ_res <- get.mim.MM(XYZ_new)
linear_CS <- Sys.time()
CS_XYZ_res <- get.mim.CS(XYZ_new)
linear_Shrink <- Sys.time()
Shrink_XYZ_res <- get.mim.shrink(XYZ_new)
linear_Bspline <- Sys.time()
Bspline_XYZ_res <- get.mim.bspline(XYZ_new, order = 1, as.integer(nrow(XYZ_new)^(1/2)))
linear_end <- Sys.time()

linear_KNN <- Sys.time()
get.mim.knn(XYZ_new, k = 3)
linear_KNN2 <- Sys.time()

# show the results
estimator_running_time <- data.frame(Type = factor(c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)'), levels =
                                                     c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)')), 
                                     Time = c(linear_MM - linear_ML, linear_CS - linear_MM, linear_Shrink - linear_CS, linear_Bspline - linear_Shrink, linear_end - linear_Bspline, 2.78999996185))

ML_XYZ_res
MM_XYZ_res
CS_XYZ_res
Shrink_XYZ_res
Bspline_XYZ_res
qplot(Type, Time, data = estimator_running_time, color = Time)

# N = 50: 
N <- 50

X <- rnorm(N, mean = 0, sd = 1)
Y <- alpha * rnorm(N, mean = 0, sd = 1) + alpha_tilda * abs(rnorm(N, 0, 1))
Z <- rnorm(N, mean = 0, sd = 1) + alpha_tilda * abs(rnorm(N, 0, 1))

XYZ_new <- data.frame(X = X, Y = Y, Z = Z)
linear_ML <- Sys.time()
ML_XYZ_res <- get.mim.ML(XYZ_new)
linear_MM <- Sys.time()
MM_XYZ_res <- get.mim.MM(XYZ_new)
linear_CS <- Sys.time()
CS_XYZ_res <- get.mim.CS(XYZ_new)
linear_Shrink <- Sys.time()
Shrink_XYZ_res <- get.mim.shrink(XYZ_new)
linear_Bspline <- Sys.time()
Bspline_XYZ_res <- get.mim.bspline(XYZ_new, order = 3)
linear_end <- Sys.time()

ML_XYZ_res
MM_XYZ_res
CS_XYZ_res
Shrink_XYZ_res
Bspline_XYZ_res
# show the results
estimator_running_time <- data.frame(Type = factor(c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)'), levels =
                                                     c('ML', "MM", 'CS', 'Shrink', 'Bspline', 'KNN (our implementation)')), 
                                     Time = c(linear_MM - linear_ML, linear_CS - linear_MM, linear_Shrink - linear_CS, linear_Bspline - linear_Shrink, linear_end - linear_Bspline, 0.0120000839233))

qplot(Type, Time, data = estimator_running_time, color = Time)

################################################################################################################################################################################################################
# Test on the linear system 
################################################################################################################################################################################################################
simulation_expr_mat_linear_random_graph_noise01 <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat_linear/simulation_expr_mat_linear_random_graph_noise01.txt', header = F, sep = '\t')
simulation_expr_mat_linear_random_graph <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat_linear/simulation_expr_mat_linear_random_graph.txt', header = F, sep = '\t')
simulation_expr_mat_linear <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat_linear/simulation_expr_mat_linear.txt', header = F, sep = '\t')

true_network_random_graph_noise01 <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat_linear/true_network_random_graph_noise01.txt', header = F, sep = '\t')
true_network_random_graph <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/simulation_expr_mat_linear/true_network_random_graph.txt', header = F, sep = '\t')

a_simulation_expr_mat_linear_random_graph_noise01_process <- t(matrix(unlist(t(simulation_expr_mat_linear_random_graph_noise01[, -c(1:2)])), ncol = 20 * 501, nrow = 13, byrow = T))

ML_a_res <- get.mim.ML(a_simulation_expr_mat_linear_random_graph_noise01_process)
MM_a_res <- get.mim.MM(a_simulation_expr_mat_linear_random_graph_noise01_process)
CS_a_res <- get.mim.CS(a_simulation_expr_mat_linear_random_graph_noise01_process)
Shrink_a_res <- get.mim.shrink(a_simulation_expr_mat_linear_random_graph_noise01_process)

linear_a <- Sys.time()
Bspline_a_res <- get.mim.bspline(a_simulation_expr_mat_linear_random_graph_noise01_process, order = 3)
linear_a.1 <- Sys.time()

b_simulation_expr_mat_linear_random_graph_process <- t(matrix(unlist(t(simulation_expr_mat_linear_random_graph[, -c(1:2)])), ncol = 20 * 501, nrow = 13, byrow = T))
ML_b_res <- get.mim.ML(a_simulation_expr_mat_linear_random_graph_noise01_process)
MM_b_res <- get.mim.MM(a_simulation_expr_mat_linear_random_graph_noise01_process)
CS_b_res <- get.mim.CS(a_simulation_expr_mat_linear_random_graph_noise01_process)
Shrink_b_res <- get.mim.shrink(a_simulation_expr_mat_linear_random_graph_noise01_process)

linear_b <- Sys.time()
Bspline_b_res <- get.mim.bspline(b_simulation_expr_mat_linear_random_graph_process, order = 3)
linear_b.1 <- Sys.time()

c_simulation_expr_mat_linear <- t(matrix(unlist(t(simulation_expr_mat_linear[, -c(1:2)])), ncol = 10 * 1001, nrow = 13, byrow = T))
ML_c_res <- get.mim.ML(c_simulation_expr_mat_linear)
MM_c_res <- get.mim.MM(c_simulation_expr_mat_linear)
CS_c_res <- get.mim.CS(c_simulation_expr_mat_linear)
Shrink_c_res <- get.mim.shrink(c_simulation_expr_mat_linear)

linear_c <- Sys.time()
Bspline_b_res <- get.mim.bspline(c_simulation_expr_mat_linear, order = 3)
linear_c.1 <- Sys.time()

# test on the result: 


################################################################################################################################################################################################################
# Real data  
################################################################################################################################################################################################################
load('./RData/test_MI_estimator.RData')

data("ecoli.expr.data")
data("ecoli.gs.net")
data("insilico.expr.data")
data("insilico.gs.net")
data("scerevisiae.expr.data")
data("scerevisiae.gs.net")
 
# test the running time: 
a <- Sys.time()
ML_ecoli_res <- get.mim.ML(ecoli.expr.data, n.cores = 6)
b <- Sys.time()
MM_ecoli_res <- get.mim.MM(ecoli.expr.data, n.cores = 6)
c <- Sys.time()
CS_ecoli_res <- get.mim.CS(ecoli.expr.data, n.cores = 6)
d <- Sys.time()
Shrink_ecoli_res <- get.mim.shrink(ecoli.expr.data, n.cores = 6)
e <- Sys.time()
Bspline_ecoli_res <- get.mim.bspline(ecoli.expr.data, n.cores = 6)
f <- Sys.time()

mi_res <- matrix(1, nrow = ncol(ecoli.expr.data), ncol = ncol(ecoli.expr.data))
combn_mat <- combn(1:ncol(ecoli.expr.data), 2)
combn_mat_split <- split(t(combn_mat), 1:ncol(combn_mat))
g <- Sys.time()
mi_result <- mclapply(combn_mat_split, function(x, ordered_exprs_mat){
  col_names <- colnames(ordered_exprs_mat)[x]
  di::mi(ecoli.expr.data[, col_names[1]], ecoli.expr.data[, col_names[2]])
}, ordered_exprs_mat = ecoli.expr.data, mc.cores = detectCores() - 2)
h <- Sys.time()

# show the running time: 
estimator_running_time <- data.frame(Type = c('ML', "MM", 'CS', 'Shrink', 'Bspline'), 
                                     Time = c(b - a, c - b, d - c, e - d, f - e))

qplot(Type, Time, data = estimator_running_time, color = Time)

# test the performance on the simulation data: 
a <- Sys.time()
ML_neuron_sim_res <- get.mim.ML(neuron_branch[1:200, ])
b <- Sys.time()
MM_neuron_sim_res <- get.mim.MM(neuron_branch[1:200, ])
c <- Sys.time()
CS_neuron_sim_res <- get.mim.CS(neuron_branch[1:200, ])
d <- Sys.time()
Shrink_neuron_sim_res <- get.mim.shrink(neuron_branch[1:200, ])
e <- Sys.time()
Bspline_neuron_sim_res <- #get.mim.bspline(neuron_branch[1:200, ], order = 5) #as.integer(nrow(neuron_branch)^(1/3)
f <- Sys.time()

generate_recall_precision_df <- function(p_value, classification, type = 'fpr') {
  pr <- pr.curve(scores.class0 = (p_value - min(p_value)) / (max(p_value) - min(p_value)), scores.class1 = classification, curve = T)
  
  data.frame(recall = pr$curve[, 1], precision = pr$curve[, 2], auc = pr[[2]])
}

neuron_branch_res$MI <- ML_neuron_sim_res
neuron_branch_res$MM <- MM_neuron_sim_res
neuron_branch_res$CS <- CS_neuron_sim_res
neuron_branch_res$Shrink <- Shrink_neuron_sim_res
# neuron_branch_res$Bspline <- Bspline_neuron_sim_res

valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
all_valid_gene_pairs <- paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_')

ML_neuron_sim_res_mlt <- melt(ML_neuron_sim_res)
row.names(ML_neuron_sim_res_mlt) <- paste(tolower(ML_neuron_sim_res_mlt$Var1), tolower(ML_neuron_sim_res_mlt$Var2), sep = '_')
MM_neuron_sim_res_mlt <- melt(MM_neuron_sim_res)
row.names(MM_neuron_sim_res_mlt) <- paste(tolower(MM_neuron_sim_res_mlt$Var1), tolower(MM_neuron_sim_res_mlt$Var2), sep = '_')
CS_neuron_sim_res_mlt <- melt(CS_neuron_sim_res)
row.names(CS_neuron_sim_res_mlt) <- paste(tolower(CS_neuron_sim_res_mlt$Var1), tolower(CS_neuron_sim_res_mlt$Var2), sep = '_')
Shrink_neuron_sim_res_mlt <- melt(Shrink_neuron_sim_res)
row.names(Shrink_neuron_sim_res_mlt) <- paste(tolower(Shrink_neuron_sim_res_mlt$Var1), tolower(Shrink_neuron_sim_res_mlt$Var2), sep = '_')
Bspline_neuron_sim_res_mlt <- melt(Bspline_neuron_sim_res)
row.names(Bspline_neuron_sim_res_mlt) <- paste(tolower(Bspline_neuron_sim_res_mlt$Var1), tolower(Bspline_neuron_sim_res_mlt$Var2), sep = '_')

neuron_network_result_df$ML <- ML_neuron_sim_res_mlt[all_valid_gene_pairs, 'value']
neuron_network_result_df$MM <- MM_neuron_sim_res_mlt[all_valid_gene_pairs, 'value']
neuron_network_result_df$CS <- CS_neuron_sim_res_mlt[all_valid_gene_pairs, 'value']
neuron_network_result_df$Shrink <- Shrink_neuron_sim_res_mlt[all_valid_gene_pairs, 'value']
neuron_network_result_df$Bspline <- melt(Bspline_neuron_sim_res)[, 'value']

network_result_df <- neuron_network_result_df
  
################################################################################################################################################################################################################
# ROC curve
################################################################################################################################################################################################################

rdi_roc_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  rdi_pvals <- (rdi_pvals - min(rdi_pvals)) / (max(rdi_pvals) - min(rdi_pvals))
  res <- generate_roc_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('tpr', 'fpr', 'auc')
  cbind(res, method = x)
})

rdi_roc_df_list <- lapply(rdi_roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
rdi_roc_df <- do.call(rbind, rdi_roc_df_list)

qplot(fpr, tpr, data= rdi_roc_df, geom="step", color = method) + #linetype = Type,
  xlab("False positive rate") +
  ylab("True positive rate") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_auc_df <- unique(rdi_roc_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_auc_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)

################################################################################################################################################################################################################
# precision-recall 
################################################################################################################################################################################################################
rdi_recall_precision_df_list <- lapply(colnames(network_result_df), function(x, reference_network_pvals_df = reference_network_pvals_df) {
  rdi_pvals <- network_result_df[, x]
  
  rdi_pvals[is.na(rdi_pvals)] <- 0
  reference_network_pvals[is.na(reference_network_pvals)] <- 0
  res <- generate_recall_precision_df(rdi_pvals, reference_network_pvals > p_thrsld)
  colnames(res) <- c('recall', 'precision', 'auc')
  cbind(res, method = x)
})

rdi_recall_precision_df_list <- lapply(rdi_recall_precision_df_list, function(x) {colnames(x) <- c('recall', 'precision', 'auc', 'method'); x} )
rdi_rec_prec_df <- do.call(rbind, rdi_recall_precision_df_list)

qplot(recall, precision, data= rdi_rec_prec_df, geom="step", color = method) + #linetype = Type,
  xlab("Recall") +
  ylab("Precision") +
  ylim(c(0, 1.0)) + geom_abline(color = 'red') +
  facet_wrap(~method) +
  #scale_color_manual(values = cols, name = "Type") #+ nm_theme()
  xlim(c(0, 1.0))

uniq_rdi_rec_prec_df <- unique(rdi_rec_prec_df[, c('method', 'auc')])

ggplot(aes(method, auc), data = uniq_rdi_rec_prec_df) + geom_bar(position = 'dodge', stat = 'identity', aes(fill=method)) +
  xlab("") + ylim(0, 1)

################################################################################################################################################################################################################
# Test the RDI / DI package
################################################################################################################################################################################################################
rdi_single_run(XYZ[, 1], XYZ[, 2])
rdi_single_run(XYZ[, 1], XYZ[, 3])
rdi_single_run(XYZ[, 2], XYZ[, 3])

################################################################################################################################################################################################################
# Save the data 
################################################################################################################################################################################################################
save.image('./RData/analysis_different_MI_estimator.RData')

