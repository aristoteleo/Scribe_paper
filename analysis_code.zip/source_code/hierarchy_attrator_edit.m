function hierarchy_attrator_edit(Parameters)

%reference: Predicting pancreas cell fate decisions and reprogramming with
%a hierarchical multi-attractor model
%Xiaojie Qiu @ ECNU, emailto: Tuexy.xiaojie@gmail.com
%version 1.0;

%set the default value for the parameters of the SDEs
def = struct(...
        'a_s', 2.2, ...
        'a_e', 6, ...
        'a', 4, ...
        'k',1, ...
        'namada', 0.25, ...
        'namada_m', 0.125, ...
        'n',4, ...
        'm',0.01, ...
        'N', 10);

%check the input and set the parameters of the SDEs
if ~nargin 
    Parameters = def;
elseif ~isstruct(Parameters);
    error('MATLAB:hierarcy_attractor', 'You need to input a struct');
else 
    fs = {'a_s', 'a_e', 'a', 'k', 'namada', 'namada_m', 'n', ...
        'm', 'N'};
    for n = 1:length(fs)
        if ~isfield(Parameters, fs{n}), Parameters.(fs{n}) = def.(fs{nm}); end
    end
end

%main setting
a_s = Parameters.a_s;
a_e = Parameters.a_e;
a = Parameters.a;
k = Parameters.k;
eta = Parameters.namada;
eta_m = Parameters.namada_m;
n = Parameters.n;
m = Parameters.m;
N = Parameters.N;

N_end = 35;
steps = 1000;
dt = N_end / steps;
cells=250;     
mu = zeros(steps, N); %1000steps,N dimentions

syms x_1 x_2 x_3 x_4 x_5 x_6 x_7 x_8 x_9 x_10 x_11; 

%Pdx1
F = [a_s * (x_4^n + x_7^n + x_8^n + x_10^n) / (1 + x_4^n + x_7^n + x_8^n + x_10^n) - k * x_1 ; ... %add noise
%Ptf1a
%a * (x_10 ^ n) / (1 + x_10^n + x_3^n) - k * x_2 ; ...
a * (x_10 ^ n) / (1 + x_10^n + x_3^n + x_1^n) - k * x_2 ; ... %an alternative model
%Ngn3
%a * (x_10^n) / (1 + x_10^n + x_2^n) - k * x_3 ; ...
a * (x_10^n) / (1 + x_10^n + x_2^n + x_1^n) - k * x_3 ; ... %an alternative model
%Pax6
a * ((eta^n) * (x_3^n) + x_4^n) / (1 + eta^n * x_3^n + x_4^n) - k * x_4 ; ...
%Pax4
a_e * (eta_m^n * x_1^n * eta^n * x_3^n) / (1 + eta_m^n * x_1^n * eta^n * x_3^n + x_6^n)  - k * x_5 ; ...
%Arx
a_e * (eta_m ^ n * x_1^n * eta^n * x_3^n) / (1 + eta_m^n * x_1^n *eta^n * x_3^n + x_5^n) - k * x_6 ; ...
%MafA
a * (eta_m^n * x_1^n * eta^n * x_3^n * x_5^n + x_7^n) / (1 + eta_m^n * x_1^n * eta^n * x_3^n * x_5^n + x_7^n + x_8^n)  - k * x_7 ; ...
%delta gene
a * (eta_m^n * x_1^n * eta^n * x_3^n * x_5^n + x_8^n) / (1 + eta_m^n * x_1^n * eta^n * x_3^n * x_5^n + x_7^n + x_8^n) - k * x_8; ...
%Brn4
a * (eta^n * x_6^n + x_9^n) / (1 + eta^n * x_6^n + x_9^n) - k * x_9 ; ...
%Hnf6
a_s * 1 / (1 + eta^n * (x_2 + x_7 +  x_8 + x_9)^n * x_11^n) - k * x_10; ...
%Maturity
m];

%EM method
%cell_simulate = zeros(50, 11, 1000); %1000 cells * 11 genes * 5000 steps
cell_simulate = zeros(N+1, steps + 1, cells);
f_em = zeros(N+1, steps+1);
f_init = zeros(N + 1, 1);
f_init([1 10]) = [2 2]; %large expression level of Hnf6 and Pdx1;
%f_temp = f_init;
D(N, N, steps)=0;
f_em(:,1) = f_init;
for cell = 1:cells
    f_temp = f_init;
    d = randn(1, N, steps) / 10;
    for sh = 1:steps
        D(:,:,sh) = (d(:,:,steps))' * d(:,:,steps);   %diffusion matrix
    end
    noise = mvnrnd(mu, 2*D, steps); %use mvnrnd to set the noise and multiply the sqrt of time
    for i = 1:steps
        f_temp = f_temp + double(subs(F, {x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10,x_11}, f_temp(1:11)))*dt + [noise(i, :) 0]' * sqrt(dt); 
        f_temp(f_temp <0) = 0; %keep non-negative of the expression value
        f_em(:, (i+1)) = f_temp;
    end
   % cell_simulate(cells, :, :) = f_em;
   cell_simulate(:, :, cell) = f_em;
end
save cell_simulate.mat; %save the data for future use;

%expression(steps+1)=0;
%figure 3 in the paper
figure(1);

subplot(3, 2, 1);  %1st branching
x = 0:dt:35;
for cell = 1:cells
 plot(x, cell_simulate(10, :, cell), x, cell_simulate(2,:,cell), x, cell_simulate(3, :, cell),... %2, 3, 10????
       'LineWidth', 2)  
   hold on;
end
axis([0 35 0 5]);
legend('Hnf6', 'Ptf1', 'Ngn3') %here? 
ylabel('Gene expression');
grid on;
title('lst branching, Ptf1a - Nn3');

subplot(3, 2, 3); %2st branching 
for cell=1:cells
   plot(x, cell_simulate(5,:,cell), 'c', x, cell_simulate(6,:,cell), 'g', x, cell_simulate(9,:,cell), 'b', 'LineWidth', 2); 
   hold on;
end
axis([0 35 0 5]);
title('2nd branching, Pax4 - Arx');
legend('Pax4', 'Arx', 'Brn4'); 
ylabel('Gene expression'); grid on;

subplot(3, 2, 5); 
for cell=1:cells
   plot(x, cell_simulate(7,:,cell), 'r', x, cell_simulate(8,:,cell), 'b', 'LineWidth', 2); 
   hold on;
end
axis([0 35 0 5]);
title('3rd branching, \beta-\sigma cell'); %tex usage in matlab
legend('MafA', '\delta gene');
ylabel('Gene expression'); grid on;

subplot(3, 2, 2);
for cell=1:cells
   plot(cell_simulate(3,:,cell), cell_simulate(2,:,cell), 'r', 'LineWidth', 2); 
   hold on;
end
xlabel('Ngn3'), ylabel('Ptf1a'), grid on; axis([0 5 0 5]);

subplot(3, 2, 4); 
for cell=1:cells
   plot(cell_simulate(5,:,cell), cell_simulate(6,:,cell), 'r', 'LineWidth', 2); 
   hold on;
end
xlabel('Pax4'), ylabel('Arx'), grid on; axis([0 5 0 5]);

subplot(3, 2, 6);   
for cell=1:cells
   plot(cell_simulate(7,:,cell), cell_simulate(8,:,cell), 'r', 'LineWidth', 2); 
   hold on;
end
grid on; axis([0 5 0 5]);

%figure 4 in the paper 
figure(2) %pca for visulize the trajectories of gene expression
%cell_simulate = reshape(cell_simulate, 50, steps);
cell_simulate = reshape(cell_simulate, steps, cells * N)'; %reshape and transpose the matrix
%[coefs, scores, variance, t2] = princomp(cell_simulate);
coefs = princomp(cell_simulate);
%plot3(scores(:, 1), scores(:, 2),scores(:, 3), '-');
plot3(coefs(:, 1), coefs(:, 2), coefs(:, 3));
xlabel('Component 1');ylabel('Component 2');zlabel('Component 3');
view([30 40]);
%plot(); %PCA

%figure 5 in the paper: master model and another alternative model;
figure(3);
subplot(2, 1, 1);
plot(cell_simulate([1 2 3 5 4],:,cell), cell_simulate(6,:,cell), 'LineWidth', 2); 
%plot(cell_simulate_alternative([1 2 3 5 4],:,cell),
%cell_simulate(6,:,cell), 'LineWidth', 2); %first run the alternative model;

%figure 6 in the paper: knock out simulation
figure(4);
%set Pax4/Arx to be zero;

%figure 7 in the paper: knock out Pdx1 with noise
figure(5);

%figure 8 in the paper: reprogramming with recipe of Pdx1, Ngn3 and MafA
figure(6);

%figure 9 in the paper; repgrogramming with a different recipe of Pdx1,
%Ngn3, Pax4 and MafA
figure(7);