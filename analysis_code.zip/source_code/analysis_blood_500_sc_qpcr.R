#make the network for the blood sc RT-PCR dataset
library(netbiov)
library(igraph)
library(monocle)

fig1b_net <- read.table('./csv_data/fig1b_network', sep = '\t')

uniq_genes <- unique(c(as.character(fig1b_net[, 1]), as.character(fig1b_net[, 2]))) #, 'Vdr', 'Hoxa9'
scRT_PCR_network_mat <- as.data.frame(matrix(rep(0, length(uniq_genes)^2), nrow = length(uniq_genes), dimnames = list(uniq_genes,  uniq_genes)))
for(ind in 1:nrow(fig1b_net)){
  message(ind)
  if(all(c(as.character(fig1b_net[ind, 1]), as.character(fig1b_net[ind, 2])) %in% uniq_genes))
    scRT_PCR_network_mat[as.character(fig1b_net[ind, 1]), as.character(fig1b_net[ind, 2])] <- 1
}

g1 <- graph_from_adjacency_matrix(as.matrix(scRT_PCR_network_mat), mode = "undirected")

load('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/res')

V(g1)$label <- V(g1)$name
res <- level.plot(g1) 
layout <- layout.circle(g1)

res$bg <- 'white'
res$vertex.size <- 12
res$vertex.label.cex <- rep(0.8, length(V(g1)$name))
res$bg <- 'white'
res$vertex.size <- v_size

res$vertex.label <- V(res$g)$name
res$lab.color <- 'red'

#follow the ordering in the original graph: 

row.names(res$layout) <- c("Erg", "Eto2", "Fli1", "Gata1", "Gata2", "Gfi1", "Gfi1b", "Hhex", "Ldb1", "Lmo2", "Lyl1", "Meis1", "Mitf", "Nfe2", "Pu.1", "Runx1", "Scl", "Tel")
current_order <- c('Gata2', 'Gata1', 'Fli1', 'Eto2', 'Erg', 'Tel', 'Scl', 'Runx1', 'Pu.1', 'Nfe2', 'Mitf', 'Meis1', 'Lyl1', 'Lmo2', 'Ldb1', 'Hhex', 'Gfi1b', 'Gfi1')
reorder_id <- unlist(lapply(current_order, function(x) which(row.names(res$layout) %in% x)))
# res$layout <- layout[reorder_id, ]

edge(res$g)[[1]]
res$edge.color <- 'brown'

plot(res$g, layout = res$layout, vertex.color = res$vertex.color, 
     edge.color = res$edge.color, vertex.label.color = res$lab.color, 
     vertex.size = res$vertex.size, edge.arrow.size = res$edge.arrow.size, 
     vertex.label.cex = res$vertex.label.cex, vertex.label = res$vertex.label, 
     vertex.frame.color = res$vertex.frame.color, edge.width = res$edge.width, 
     edge.label.color = res$edge.label.color, edge.label.cex = res$edge.label.cex, 
     edge.curved = res$edge.curved, vertex.label.family = res$vertex.label.family, 
     edge.label = res$edge.label)

################################################################################################################################################################################
# create the network for the RDI
################################################################################################################################################################################
simpleCap <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), substring(s, 2),
        sep="", collapse=" ")
}

RDI_net <- read.table('./csv_data/output_RDI_conditioned.txt', sep = '\t', header = T)

# uniq_genes <- unique(c(as.character(RDI_net[, 1]), as.character(RDI_net[, 3]))) #, 'Vdr', 'Hoxa9'
# uniq_genes <- sapply(uniq_genes, simpleCap)

RDI_network_mat <- as.data.frame(matrix(rep(0, length(uniq_genes)^2), nrow = length(uniq_genes), dimnames = list(uniq_genes,  uniq_genes)))

valid_RDI_net <- RDI_net[order(RDI_net$RDI, decreasing = T)[1:72], ]

for(ind in 1:nrow(valid_RDI_net)){
  message(ind)
  if(all(c(simpleCap(as.character(valid_RDI_net[ind, 1])), simpleCap(as.character(valid_RDI_net[ind, 3]))) %in% uniq_genes))
    RDI_network_mat[simpleCap(as.character(valid_RDI_net[ind, 1])), simpleCap(as.character(valid_RDI_net[ind, 3]))] <- 1
}

g2 <- graph_from_adjacency_matrix(as.matrix(RDI_network_mat), mode = "directed")
V(g2)$label <- V(g2)$name
res <- level.plot(g2) 
layout <- layout.circle(g2)

res$bg <- 'white'
res$vertex.size <- 12
res$vertex.label.cex <- rep(0.8, length(V(g2)$name))
res$bg <- 'white'
res$vertex.size <- v_size

res$vertex.label <- V(res$g)$name
res$lab.color <- 'red'

#follow the ordering in the original graph: 
row.names(res$layout) <- c("Erg", "Eto2", "Fli1", "Gata1", "Gata2", "Gfi1", "Gfi1b", "Hhex", "Ldb1", "Lmo2", "Lyl1", "Meis1", "Mitf", "Nfe2", "Pu.1", "Runx1", "Scl", "Tel")
current_order <- c('Gata2', 'Gata1', 'Fli1', 'Eto2', 'Erg', 'Tel', 'Scl', 'Runx1', 'Pu.1', 'Nfe2', 'Mitf', 'Meis1', 'Lyl1', 'Lmo2', 'Ldb1', 'Hhex', 'Gfi1b', 'Gfi1')
reorder_id <- unlist(lapply(current_order, function(x) which(row.names(res$layout) %in% x)))
# res$layout <- layout[reorder_id, ]

edge(res$g)[[1]]
res$edge.color <- 'brown'

plot(res$g, layout = res$layout, vertex.color = res$vertex.color, 
     edge.color = res$edge.color, vertex.label.color = res$lab.color, 
     vertex.size = res$vertex.size, edge.arrow.size = res$edge.arrow.size, 
     vertex.label.cex = res$vertex.label.cex, vertex.label = res$vertex.label, 
     vertex.frame.color = res$vertex.frame.color, edge.width = res$edge.width, 
     edge.label.color = res$edge.label.color, edge.label.cex = res$edge.label.cex, 
     edge.curved = res$edge.curved, vertex.label.family = res$vertex.label.family, 
     edge.label = res$edge.label)

################################################################################################################################################################################
#ROC curve for the precision: 
################################################################################################################################################################################
for(rdi ){
  
}

################################################################################################################################################################################
# save the data 
################################################################################################################################################################################
save.image('./RData/analysis_blood_500_sc_qpcr.RData')


