
################################################################################################################################################################
# network inference with RNA-velocity  
# use current / projected matrix   
################################################################################################################################################################
current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])

n_genes <- length(valid_gene)
tmp <- expand.grid(1:n_genes, 1:n_genes, stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ]
super_graph[, 1] <- valid_gene[super_graph[, 1]]
super_graph[, 2] <- valid_gene[super_graph[, 2]]

# cmi: I(x(t - 1), y (t) | y(t - 1) )
res <- apply(super_graph, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE, layout = layout.circle(g))

################################################################################################################################################################
# use emat / emat + deltaE 
################################################################################################################################################################
emat_proj <- emat[row.names(rvel.cd$deltaE), colnames(rvel.cd$deltaE)] + rvel.cd$deltaE
emat_curr <- emat[row.names(rvel.cd$deltaE), colnames(rvel.cd$deltaE)]

current_n <- as.matrix(emat_curr[valid_gene, valid_cells])
projected <- as.matrix(emat_proj[valid_gene, valid_cells])

res <- apply(super_graph, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 5, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE, layout = layout.circle(g))

################################################################################################################################################################
# do a pseudotime ordering and then run the network inference: 
# use dpt 
################################################################################################################################################################
source('./Scripts/function.R', echo = T)

norm_data <- t(rvel.cd$current[, valid_cells])
duplicated_genes <- which(base::duplicated.array(norm_data))
norm_data[duplicated_genes, 1] <- norm_data[duplicated_genes, 1] + rnorm(length(duplicated_genes), 0, 1)
dm <- destiny::DiffusionMap(as.matrix(norm_data))
dpt <- destiny::DPT(dm)
plot(dpt)
# identify the root: 
root <- cell_type[valid_cells[which(dpt@tips[, 1])]]
dpt <- DPT(dm, tips = which(row.names(norm_data) == names(root)[3]))
pt <- dpt[, which(row.names(norm_data) == names(root)[3])]

qplot(dpt@dm$DC1, dpt@dm$DC2, color = pt)

################################################################################################################################################################
# run Monocle 2  
################################################################################################################################################################
# create a cds 
pData <- data.frame(cell = row.names(norm_data), row.names = row.names(norm_data))
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(norm_data), row.names = colnames(norm_data))
fd <- new("AnnotatedDataFrame", data = fData)

pigment_cds <- newCellDataSet(as(t(norm_data), "sparseMatrix"), 
                              phenoData = pd, 
                              featureData = fd,
                              lowerDetectionLimit=1,
                              expressionFamily=gaussianff())

################################################################################################################################################################
# network inference with Monocle 2 estimated pseudotime 
################################################################################################################################################################
pData(pigment_cds)$Pseudotime <- pt
pData(pigment_cds)$Pseudotime_dpt <- pt
plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')

pigment_cds <- reduceDimension(pigment_cds, ncenter = NULL,  norm_method = 'none', scaling = F, pseudo_expr = 0, verbose = T)
pigment_cds <- orderCells(pigment_cds)
plot_cell_trajectory(pigment_cds)

plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')
pigment_cds <- orderCells(pigment_cds, root_state = 10)
plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')

rdi_res <- Scribe::calculate_rdi(pigment_cds[valid_gene, ], delays = 1, log = F, uniformalize = T)
dimnames(rdi_res$max_rdi_delays) <- dimnames(rdi_res$max_rdi_value)
  
g <- igraph::graph_from_adjacency_matrix(as.matrix(rdi_res$max_rdi_value), weighted = T, mode = "direct")
plot.igraph(g, edge.width=E(g)$weight * 20, edge.curved=TRUE, layout = layout.circle(g))

# sox10, sox2, pou3f1, and foxd3
exam_gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% c('sox10', 'sox2', 'pou3f1', 'foxd3', 'mbpa')))
plot_genes_in_pseudotime(valid_cds[exam_gene_ids, ], color_by = 'Pseudotime')

# do the combined analysis with pseudotime and the RNA-velocity 
################################################################################################################################################################
# analyze the data with scaled unspliced and exon expression 
################################################################################################################################################################
names(pt) <- colnames(pigment_cds)
spliced <- rvel.cd$gamma * rvel.cd$current[names(rvel.cd$gamma), ]
qplot(pt, as.numeric(spliced['mitfa', colnames(pigment_cds)]) ) + ylab('Expression')

#spliced: vlm.Sx_sz[i, pc_obj.ixsort]*vlm.gammas[i] 
#unspliced: Ux_sz

# unspliced is early than spliced: 
qplot(pt, as.numeric(rvel.cd$gamma['mitfa'] * rvel.cd$current['mitfa', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['mitfa', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['pmela'] * rvel.cd$current['pmela', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['pmela', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['dct'] * rvel.cd$current['dct', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['dct', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['tyrp1b'] * rvel.cd$current['tyrp1b', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['tyrp1b', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

scaled_spliced <- rvel.cd$gamma[valid_gene] * rvel.cd$current[valid_gene, colnames(pigment_cds)]
unspliced <- rvel.cd$conv.nmat.norm[valid_gene, colnames(pigment_cds)]

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
res <- apply(super_graph, 1, function(x) {
  #Scribe::cmi(as.matrix(unspliced[x[1], ]), as.matrix(scaled_spliced[x[2], ]), as.matrix(unspliced[x[2], ]), k = 15, normalize = F)$cmi_res
  Scribe::cmi(as.matrix(scaled_spliced[x[1], ]), as.matrix(unspliced[x[2], ]), as.matrix(scaled_spliced[x[2], ]), k = 15, normalize = T)$cmi_res
  # Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(unspliced[x[2], ] ), as.matrix(current_n[x[2], ]), k = 5, normalize = T)$cmi_res
})

# use current / unspliced and future 

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE, layout = layout.circle(g))

################################################################################################################################################################
# combining pseudotime and RNA velocity 
# a. concatenate pseudotime (all expression ordered data) and RNA-velocity (exon ordered)
# b. performing pseudotime ordering with exon and then do RDI with exon and the unspliced in the RDI (need to change the Scribe c++ code) 
################################################################################################################################################################

# 1. concatenate pseudotime (all expression ordered data) and RNA-velocity (exon ordered)

ind <- which(names(cell_type) %in% valid_cells)
ind <- setdiff(ind, which(duplicated(names(cell_type))))
valid_cds <- comb2_cds_cell[, ind]

pData(valid_cds)$Pseudotime <- pData(pigment_cds[, names(cell_type)[ind]])$Pseudotime
gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% valid_gene))
plot_genes_in_pseudotime(valid_cds[gene_ids, ], color_by = 'Cell_type')

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
sort_gene_expression <- as.matrix(exprs(valid_cds)[gene_ids, sort(pData(valid_cds)$Pseudotime)])
row.names(sort_gene_expression) <- valid_gene
ncells <- ncol(sort_gene_expression)
sort_gene_expression <- sort_gene_expression / sizeFactors(valid_cds)[sort(pData(valid_cds)$Pseudotime)]
sort_gene_expression <- log(sort_gene_expression + 1) 

delay <- 5

# use all the genes and the full cds as well as the pseudotime based RDI: 
full_gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% gene_list))

rdi_res <- Scribe::calculate_rdi(valid_cds[full_gene_ids, ], delays = c(1:15), uniformalize = F, log = F)
dimnames(rdi_res$max_rdi_value) <- list(fData(valid_cds)[full_gene_ids, 'gene_short_name'], fData(valid_cds)[full_gene_ids, 'gene_short_name'])
dimnames(rdi_res$max_rdi_delay) <- list(fData(valid_cds)[full_gene_ids, 'gene_short_name'], fData(valid_cds)[full_gene_ids, 'gene_short_name'])
causality_res <- rdi_res$max_rdi_value

causality_res[!(causality_res > t(causality_res))] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(causality_res), weighted = T, mode = "direct")
plot.igraph(g, edge.width=(E(g)$weight - 2 * min(E(g)$weight)) /(max(E(g)$weight) - 2 * min(E(g)$weight)) * 5, edge.curved=TRUE, layout = layout_as_tree(g), edge.arrow.size = 0.5)

################################################################################################################################################################
res <- apply(super_graph, 1, function(x) {
  x_t_min_1 <- as.matrix(c(current_n[x[1], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  y_t <- as.matrix(c(projected[x[2], ], sort_gene_expression[x[1], (1 + delay):ncells]) )
  y_t_min_1 <- as.matrix(c(current_n[x[2], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  
  Scribe::cmi(x_t_min_1, y_t, y_t_min_1, k = 15, normalize = T)$cmi_res
  # Scribe::cmi(x_t_min_1[1:length(ncol(current_n))], y_t[1:length(ncol(current_n))], y_t_min_1[1:length(ncol(current_n))], k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
adj_mat <- adj_mat + abs(min(adj_mat))
adj_mat[!(adj_mat > t(adj_mat))] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")
pheatmap::pheatmap(adj_mat)
plot.igraph(g, edge.width=(E(g)$weight - 2 * min(E(g)$weight)) /(max(E(g)$weight) - 2 * min(E(g)$weight)) * 5, edge.curved=TRUE, layout = layout.circle(g))

################################################################################################################################################################
# 2. performing pseudotime ordering with exon and then do RDI with exon and the unspliced in the RDI (need to change the Scribe c++ code)
################################################################################################################################################################
ind <- which(names(cell_type) %in% valid_cells)
ind <- setdiff(ind, which(duplicated(names(cell_type))))
valid_cds <- comb2_cds_cell[, ind]

pData(valid_cds)$Pseudotime <- pData(pigment_cds[, names(cell_type)[ind]])$Pseudotime
gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% valid_gene))
plot_genes_in_pseudotime(valid_cds[gene_ids, ], color_by = 'Cell_type')

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
sort_gene_expression <- as.matrix(rvel.cd$current[valid_gene, sort(pData(valid_cds[, ])$Pseudotime)])
row.names(sort_gene_expression) <- valid_gene
ncells <- ncol(sort_gene_expression)
delay <- 1

res <- apply(super_graph, 1, function(x) {
  x_t_min_1 <- as.matrix(sort_gene_expression[x[1], 1:(ncells - delay)])
  y_t <- as.matrix(projected[x[2], (1 + delay):ncells])
  y_t_min_1 <- as.matrix(current_n[x[2], (1 + delay):ncells])
  Scribe::cmi(x_t_min_1, y_t, y_t_min_1, k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 10, edge.curved=TRUE, layout = layout.circle(g))

################################################################################################################################################################
# save the data
################################################################################################################################################################
save.image('./RData/zebrafish_analysis_RNA_velocity_shawnn_cells.RData')
