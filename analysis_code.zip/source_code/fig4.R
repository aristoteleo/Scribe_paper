################################################################################################################################################
# generate the temporal RDI interactively for the Olsson dataset's granulocyte or monocyte branch 
# load the packages and data: 
# add temporal causality for the simulation dataset as well as this one in the supplementary figures 
################################################################################################################################################
rm(list =ls())

# library(Scribe)
library(pheatmap)
library(netbiov)
library(monocle)
library(plyr)
library(inflection)
library("animation")

library(devtools)
load_all('./Cpp/Real_deal/Scribe/Scribe/')

source('~/Dropbox (Personal)/Projects/Causal_network/causal_network/Scripts/function.R', echo=TRUE)

load('./RData/analysis_scRNA_seq_Olsson.RData')
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/analysis_scRNA_seq_Olsson.RData')
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig5.RData')

# load("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/fig3_res.RData")
# MEP_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_MEP_cds)[fData(Olsson_MEP_cds)$use_for_ordering, ] + 1))))
# MEP_dpt_res <- just_DPT(MEP_dm)
#
# monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
# monocyte_dpt_res <- just_DPT(monocyte_dm)
#
# granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
# granulocyte_dpt_res <- just_DPT(granulocyte_dm)

load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/Jupyter_notebook/network_res')

#######################################################################################################################################
main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'
#######################################################################################################################################

plot.netbiov(res)
olsson_gene_names <- unique(igraph::V(res$g)$name)

################################################################################################################################################
# prepare the data for making the figures
################################################################################################################################################

# order the cell by dpt using pseudotime ordering:
exprs(Olsson_MEP_cds) <- as.matrix(exprs(Olsson_MEP_cds)); exprs(Olsson_monocyte_cds) <- as.matrix(exprs(Olsson_monocyte_cds)); exprs(Olsson_granulocyte_cds) <- as.matrix(exprs(Olsson_granulocyte_cds));
MEP_dpt_res <- run_new_dpt(Olsson_MEP_cds); monocyte_dpt_res <- run_new_dpt(Olsson_monocyte_cds); granulocyte_dpt_res <- run_new_dpt(Olsson_granulocyte_cds);

pData(Olsson_monocyte_cds)$Pseudotime <- order(monocyte_dpt_res$pt)
pData(Olsson_granulocyte_cds)$Pseudotime <- order(granulocyte_dpt_res$pt)
pData(Olsson_MEP_cds)$Pseudotime <- order(MEP_dpt_res$pt)

qplot(MEP_dm@eigenvectors[, 1], MEP_dm@eigenvectors[, 2], color = pData(Olsson_MEP_cds)$cluster)
qplot(monocyte_dm@eigenvectors[, 1], monocyte_dm@eigenvectors[, 2], color = pData(Olsson_monocyte_cds)$cluster)
qplot(granulocyte_dm@eigenvectors[, 1], granulocyte_dm@eigenvectors[, 2], color = pData(Olsson_granulocyte_cds)$cluster)

qplot(MEP_dm@eigenvectors[, 1], MEP_dm@eigenvectors[, 2], color = MEP_dpt_res$pt)
qplot(monocyte_dm@eigenvectors[, 1], monocyte_dm@eigenvectors[, 2], color = monocyte_dpt_res$pt)
qplot(granulocyte_dm@eigenvectors[, 1], granulocyte_dm@eigenvectors[, 2], color = granulocyte_dpt_res$pt)

# prepare the network
gene_name_vec <- c('Irf8', "Gfi1", 'Klf4', 'Per3', 'Zeb2', 'Ets1', 'Irf5')
sort(esApply(Olsson_monocyte_cds[gene_name_vec, ], 1, mean)) # Irf8, Per3, Zeb2
# gene_name_vec <- c('Irf8', 'Per3', 'Zeb2')

Olsson_core_network <- matrix(c("Irf8", "Gfi1", "Gfi1", "Irf8", "Irf8", "Klf4", "Irf8", "Per3", "Irf8", "Zeb2", "Irf8",
                                "Irf5", "Gfi1", "Per3", "Gfi1", "Klf4", "Gfi1", "Zeb2", "Gfi1", "Ets1"), ncol = 2, byrow = T)

Olsson_all_gene_ids <- V(res$g)$name
Olsson_monocyte_cds_exprs <- t(exprs(Olsson_monocyte_cds)[Olsson_all_gene_ids, order(monocyte_dpt_res$pt)])
Olsson_granulocyte_cds_exprs <- t(exprs(Olsson_granulocyte_cds)[Olsson_all_gene_ids, order(granulocyte_dpt_res$pt)])

example_data_gran <- t(exprs(Olsson_granulocyte_cds[fData(Olsson_granulocyte_cds)$gene_short_name %in% gene_name_vec, order(granulocyte_dpt_res$pt)]))
example_data_mono <- t(exprs(Olsson_monocyte_cds[fData(Olsson_monocyte_cds)$gene_short_name %in% gene_name_vec, order(monocyte_dpt_res$pt)]))
example_data_MEP <- t(exprs(Olsson_MEP_cds[fData(Olsson_MEP_cds)$gene_short_name %in% gene_name_vec, order(MEP_dpt_res$pt)]))
example_data <- as.matrix(Reduce(rbind, list(example_data_gran, example_data_mono, example_data_MEP)))
example_data <- example_data_mono #example_data_gran #

noise = matrix(rnorm(mean = 0, sd = 0, nrow(example_data) * ncol(example_data)), nrow = nrow(example_data))
pData(Olsson_granulocyte_cds)$Pseudotime <- order(granulocyte_dpt_res$pt)
pData(Olsson_monocyte_cds)$Pseudotime <- order(monocyte_dpt_res$pt)

################################################################################################################################################
# calculate temporal RDI values
################################################################################################################################################

rdi_crdi_pseudotime_res_list_gran <- calculate_temporal_causality(Olsson_granulocyte_cds[fData(Olsson_granulocyte_cds)$gene_short_name %in% gene_name_vec, ], conditioning = T)
rdi_crdi_pseudotime_res_list_mono <- calculate_temporal_causality(Olsson_monocyte_cds[fData(Olsson_monocyte_cds)$gene_short_name %in% gene_name_vec, ], uniformalize = F, conditioning = T)

rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime_res_list_gran
# rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime_res_list_mono

# dimnames(rdi_list$max_rdi_value) <- list(uniq_gene, uniq_gene)
# con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 1)
# dimnames(con_rdi_res_test) <- list(uniq_gene, uniq_gene)

# plot gene-pair regulation strength over pseudotime
rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res

dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])
rdi_res[!is.finite(rdi_res)] <- 0

all_cmbns <- expand.grid(colnames(example_data), colnames(example_data))
valid_all_cmbns_df <- data.frame(pair = paste(all_cmbns$Var1, all_cmbns$Var2, sep = ' -> '), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
colnames(rdi_res) <- valid_all_cmbns_df$pair
pheatmap::pheatmap(t(rdi_res), cluster_rows = T, cluster_cols = F, annotation_names_row = T, border_color = NA)

true_edges0 <- paste(Olsson_core_network[, 1], '->', Olsson_core_network[, 2])
true_edges <- true_edges0
repression_vec <- c(1:2, 4, 8, 9)
true_edges[repression_vec] <- paste(Olsson_core_network[repression_vec, 1], '-|', Olsson_core_network[repression_vec, 2])

rdi_res[rdi_res < 0] <- 0
rdi_res <- apply(rdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
rdi_res[!is.finite(rdi_res)] <- 0

colnames(rdi_res)[colnames(rdi_res) %in% true_edges0] <- true_edges

pdf('./Figures/main_figures/Olsson_temporal_core_network_regulation_gran.pdf', height = 1, width = 2) #_gran
pheatmap::pheatmap(t(rdi_res[, true_edges]), cluster_rows = T, cluster_cols = F,
                   annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6, treeheight_row = 0)
dev.off()

################################################################################################################################################
# smooth temporal causality and then clustering them: 
rdi_res_old <- rdi_res
tmp <- rdi_crdi_pseudotime_res_list$rdi_res
dim(tmp) <- c(dim(tmp)[1], dim(tmp)[2] * dim(tmp)[2])
tmp[!is.finite(tmp)] <- 0
rdi_res_old[, 1:ncol(rdi_res)] <- tmp

smoothed_rdi_res_true_edges <- rdi_res_old[, true_edges]
for(i in true_edges) {
  df <- data.frame(Pseudotime = 1:nrow(rdi_res), Expression = rdi_res_old[, i])
  test <- loess(Expression ~ Pseudotime, df)
  smoothed_rdi_res_true_edges[, i] <-  predict(test)
}

smoothed_rdi_res_true_edges[smoothed_rdi_res_true_edges < 0] <- 0
smoothed_rdi_res_true_edges <- apply(smoothed_rdi_res_true_edges, 2, function(x) (x - min(x)) / (max(x) - min(x)))
smoothed_rdi_res_true_edges[!is.finite(smoothed_rdi_res_true_edges)] <- 0

pdf('./Figures/supplementary_figures/Olsson_temporal_core_network_regulation_mono_smoothed.pdf', height = 1, width = 2) #_gran
pheatmap::pheatmap(t(smoothed_rdi_res_true_edges[, true_edges]), cluster_rows = T, cluster_cols = F, 
                   annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6, treeheight_row = 0)
dev.off()

################################################################################################################################################
# smooth temporal causality and then clustering them: 
rdi_res_old <- rdi_res
tmp <- rdi_crdi_pseudotime_res_list$rdi_res
dim(tmp) <- c(dim(tmp)[1], dim(tmp)[2] * dim(tmp)[2])
tmp[!is.finite(tmp)] <- 0
rdi_res_old[, 1:ncol(rdi_res)] <- tmp

smoothed_rdi_res_true_edges <- rdi_res_old[, true_edges]
for(i in true_edges) {
  df <- data.frame(Pseudotime = 1:nrow(rdi_res), Expression = rdi_res_old[, i])
  test <- loess(Expression ~ Pseudotime, df)
  smoothed_rdi_res_true_edges[, i] <-  predict(test)
}

smoothed_rdi_res_true_edges[smoothed_rdi_res_true_edges < 0] <- 0
smoothed_rdi_res_true_edges <- apply(smoothed_rdi_res_true_edges, 2, function(x) (x - min(x)) / (max(x) - min(x)))
smoothed_rdi_res_true_edges[!is.finite(smoothed_rdi_res_true_edges)] <- 0

pdf('./Figures/supplementary_figures/Olsson_temporal_core_network_regulation_gran_smoothed.pdf', height = 1, width = 2) #_gran
pheatmap::pheatmap(t(smoothed_rdi_res_true_edges[, true_edges]), cluster_rows = T, cluster_cols = F, 
                   annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6, treeheight_row = 0)
dev.off()

################################################################################################################################################

################################################################################################################################################

plot_gene_pairs_in_pseudotime(Olsson_granulocyte_cds, gene_pairs_mat = Olsson_core_network, n_col = 2, n_row = 5)
plot_gene_pairs_in_pseudotime(Olsson_monocyte_cds, gene_pairs_mat = Olsson_core_network, n_col = 2, n_row = 5)

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example.pdf'), width =  2, height = 1)
plot_gene_pairs_in_pseudotime(Olsson_monocyte_cds, gene_pairs_mat = Olsson_core_network[c(4, 5), ], n_col = 2, n_row = 1, cell_size = 0.2) + xacHelper::nm_theme() + 
  viridis::scale_color_viridis(discrete = T, option = 'D')# geom_jitter(aes(color = Time), size = 0.5) +
dev.off()

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example_mono.pdf'), width =  2, height = 1)
plot_gene_pairs_in_pseudotime(Olsson_monocyte_cds, gene_pairs_mat = Olsson_core_network[c(4, 5), ], n_col = 2, n_row = 1, cell_size = 0.2) + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example_gran.pdf'), width =  2, height = 1)
plot_gene_pairs_in_pseudotime(Olsson_granulocyte_cds, gene_pairs_mat = Olsson_core_network[c(4, 5), ], n_col = 2, n_row = 1, cell_size = 0.2) + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example_mono_all.pdf'), width =  4.5, height = 1.5)
plot_gene_pairs_in_pseudotime(Olsson_monocyte_cds, gene_pairs_mat = Olsson_core_network[, ], n_col = 5, n_row = 2, cell_size = 0.2) + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example_gran_all.pdf'), width =  4.5, height = 1.5)
plot_gene_pairs_in_pseudotime(Olsson_granulocyte_cds, gene_pairs_mat = Olsson_core_network[, ], n_col = 5, n_row = 2, cell_size = 0.2) + xacHelper::nm_theme()
dev.off()

pdf(paste0(main_fig_dir, 'Olsson_kinetic_curve_example_gran_all_helper.pdf'))
plot_gene_pairs_in_pseudotime(Olsson_granulocyte_cds, gene_pairs_mat = Olsson_core_network[, ], n_col = 5, n_row = 2, cell_size = 0.2) 
dev.off()

################################################################################################################################################
# only visualize the true edges
################################################################################################################################################
pheatmap::pheatmap(t(rdi_res[, true_edges]), cluster_rows = T, cluster_cols = F, annotation_names_row = T, border_color = NA)
# pheatmap::pheatmap(t(crdi_res[, true_edges]), cluster_rows = T, cluster_cols = F, annotation_names_row = T, border_color = NA)

################################################################################################################################################
# make the kinetic curves
################################################################################################################################################
gene_pairs <- row.names(subset(fData(Olsson_monocyte_cds), gene_short_name %in% c('Irf9', 'Irf8')))
pData(Olsson_monocyte_cds)[rownames(example_data_mono), 'Pseudotime'] <- 1:nrow(example_data_mono)
pData(Olsson_granulocyte_cds)[rownames(example_data_gran), 'Pseudotime'] <- 1:nrow(example_data_gran)
pData(Olsson_MEP_cds)[rownames(example_data_MEP), 'Pseudotime'] <- 1:nrow(example_data_MEP)
plot_genes_in_pseudotime(Olsson_monocyte_cds[gene_pairs, ])

rdi_res[, 2] - rdi_crdi_pseudotime_res_list$rdi_res[, 2, 1]

data <- t(exprs(Olsson_monocyte_cds[gene_name_vec, order(pData(Olsson_monocyte_cds)$Pseudotime)]))
smooth_data <- data
smoothing <- T

if(smoothing) {
  for(i in 1:ncol(data)) {
    df <- data.frame(Pseudotime = 1:nrow(data), Expression = data[, i])
    test <- loess(Expression ~ Pseudotime, df)
    smooth_data[, i] <-  predict(test)
  }
}

df <- data.frame(Time = rep(1:230, times = 2), expression = c(smooth_data[, 'Irf8'], smooth_data[, 'Per3']), Type = c(rep('Irf8', 230), rep('Per3', 230)))
df <- data.frame(Time = rep(1:230, times = 2), expression = c(smooth_data[, 'Irf8'], smooth_data[, 'Zeb2']), Type = c(rep('Irf8', 230), rep('Zeb2', 230)))
qplot(Time, expression, data = df, color = Type)

################################################################################################################################################
# get the network
################################################################################################################################################
example_data <- as.matrix(Reduce(rbind, list(example_data_gran, example_data_mono, example_data_MEP)))
# example_data <- example_data_gran

tmp <- expand.grid(1:ncol(example_data), 1:ncol(example_data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

message('current range index is ', i)
run_vec <- rep(1, nrow(example_data))
rdi_list <- calculate_rdi_multiple_run_cpp(as.matrix(example_data), delay = c(1:15), run_vec - 1, as.matrix(super_graph), method = 1, uniformalize = F) #* 100 + noise

con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(as.matrix(example_data), as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 6, uniformalize = F)  # conditional on all other genes
max_rdi_value_correct_edge <- as.matrix(rdi_list$max_rdi_value)
dimnames(max_rdi_value_correct_edge) <- list(colnames(example_data), colnames(example_data))
max_rdi_value_correct_edge[! (colnames(max_rdi_value_correct_edge) %in% c('Gfi1', "Irf8")), ] <- -1
con_rdi_res_test_correct_edge <- calculate_conditioned_rdi_multiple_run_wrap(as.matrix(example_data), as.matrix(super_graph), max_rdi_value_correct_edge, as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 6, uniformalize = F)  # conditional on all other genes

dimnames(con_rdi_res_test) <- list(colnames(example_data), colnames(example_data))
con_rdi_res_test <- clr_directed_R(con_rdi_res_test)

pheatmap::pheatmap(con_rdi_res_test, cluster_rows = T, cluster_cols = T, annotation_names_col = T, annotation_names_row = T)
pdf('./Figures/main_figures/Olsson_core_network_inferred_rdi.pdf', height = 1, width = 2)
pheatmap::pheatmap(con_rdi_res_test[c('Gfi1', 'Irf8'), ], cluster_rows = F, cluster_cols = F,
                   annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6)
dev.off()

con_rdi_res_test_correct_edge[con_rdi_res_test_correct_edge < 0] <- 0
dimnames(con_rdi_res_test_correct_edge) <- list(colnames(example_data), colnames(example_data))

pdf('./Figures/main_figures/Olsson_core_network_inferred.pdf', height = 1, width = 2)
pheatmap::pheatmap(con_rdi_res_test_correct_edge[c('Gfi1', 'Irf8'), ], cluster_rows = F, cluster_cols = F,
                   annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6)
dev.off()

dimnames(rdi_list$max_rdi_value) <- list(colnames(example_data), colnames(example_data))
dimnames(rdi_list$max_rdi_delays) <- list(colnames(example_data), colnames(example_data))
pheatmap::pheatmap(rdi_list$max_rdi_value, cluster_rows = T, cluster_cols = T, annotation_names_col = T, annotation_names_row = T)
pheatmap::pheatmap(rdi_list$max_rdi_delays, cluster_rows = F, cluster_cols = F, annotation_names_col = T, annotation_names_row = T)
# qplot(0:150, rdi_list$RDI[1, seq(3, ncol(rdi_list$RDI),by = 3)]) + ylab('rdi') + xlab('time delay') # this gene should not have long time delay but very close

# Aug 30 11:49:58 D-69-91-168-252.dhcp4.washington.edu R[872] <Error>: CGContextDelegateCreateForContext: invalid context 0x7fa97035c4a0.
# This is a serious error. This application, or a library it uses, is using an invalid context  and is thereby contributing to an overall
# degradation of system stability and reliability. This notice is a courtesy: please fix this problem. It will become a fatal error in an upcoming update.
Olsson_core_g <- graph_from_edgelist(as.matrix(Olsson_core_network[, 1:2]), directed = T)
res <- level.plot(Olsson_core_g)
# save(file = './RData/Olsson_core_g_res', res)

layout_coord <- res$layout
row.names(layout_coord) <- V(Olsson_core_g)$name
plot(Olsson_core_g, layout = layout_coord)

layout_coord["Irf8", ] <- c(-1,  0)
layout_coord["Gfi1", ] <- c(1, 0)
layout_coord["Klf4", 2] <- -1
layout_coord["Per3", 2] <- -1
layout_coord["Zeb2", ] <- c(-1, -1)
layout_coord["Irf5", 2] <- -1
layout_coord["Ets1", ] <- c(2, -1)

# swap the direct:

color = rep('blue', length(edge(res$g)[[1]]))
color[c(1, 2, 4, 8, 9)] <- 'red'

res <- apply(rdi_crdi_pseudotime_res_list$rdi_res, 2, function(x) c(mean(x[1:47]), mean(x[48:94]), mean(x[95:141]), mean(x[142:190])))

pdf('Olsson_core_g.pdf', height = 2, width = 2)
plot(Olsson_core_g, layout = layout_coord, edge.width=1, edge.color = color, )
dev.off()

# save the figure:
for (i in 1:4) {
  pdf(paste0("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/temporal_Olsson_core_g_", i, '.pdf'))
  plot(Olsson_core_g, layout = layout_coord, edge.width=res[i, ] * 10, edge.color = color)
  dev.off()
}

oopt <- ani.options(interval = 0.2, nmax = 4)
network.evolution <- function(layout_coord = layout_coord, res = res, color = color, ...) {
  for (i in 1:ani.options("nmax")) {
    dev.hold()
    plot(Olsson_core_g, layout = layout_coord, edge.width=res[i, ] * 10, edge.color = color)
    ani.pause()
  }
}

# create an animation with multiple figures: 
saveGIF({
  ani.options(interval = 0.05, nmax = 4)
  par(mar = c(4, 4, .1, 0.1), mgp = c(2, 0.7, 0))
  network.evolution(layout_coord = layout_coord, res = res, color = color)
  }, movie.name = "temporal_network_plot", ani.height = 300, ani.width = 550,
  title = "Demonstration of the Temporal Regulation",
  description = c("Temporal RDI value for the network",
                    "Visualize the temporal network"))

################################################################################################################################################
# compare with the gene pair with the network in the paper
################################################################################################################################################
ind_mat <- as.matrix(which(con_rdi_res_test >= sort(con_rdi_res_test, decreasing = T)[10], arr.ind = T))
ind_mat <- as.matrix(which(rdi_list$max_rdi_value >= sort(rdi_list$max_rdi_value, decreasing = T)[10], arr.ind = T))

ind_mat[, 1] <- colnames(example_data)[ind_mat[, 1]]
ind_mat[, 2] <- colnames(example_data)[as.numeric(ind_mat[, 2])]
ind_mat

# check gran branch as well as MEP branch and finally all branches 

plot_genes_in_pseudotime(Olsson_monocyte_cds[gene_name_vec, ])

################################################################################################################################################
# test other visualization tools
################################################################################################################################################
subset_combinatorial_net <- matrix(c("Irf8", "Gfi1", "Zeb2", "Irf8", "Gfi1", 'Per3'), ncol = 3, byrow = T)

plot_lagged_drevi(cds_subset = URMM_all_fig1b[, ], gene_pairs_mat =  subset_combinatorial_net[, 1:2], d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()

plot_gene_pairs_causality(cds_subset = URMM_all_fig1b[, ], gene_pairs_mat =  subset_combinatorial_net[, 1:2], d = 0, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()

################################################################################################################################################
# make the combinatorial logic plot 
################################################################################################################################################

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic_olsson.pdf'), width =  2, height = 1)
plot_comb_logic(cds_subset = URMM_all_fig1b[, ], gene_pairs_target_mat =  subset_combinatorial_net, d = 0, n_row = 1, n_col = 2, grid_num = 100, log = T) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

res <- monocle:::reverseEmbeddingCDS(URMM_all_fig1b) # apply RGE to get the denoised data 

pdf(paste0(main_fig_dir, 'gene_pair_combinatorial_logic_olsson_RGE.pdf'), width =  2, height = 1)
plot_comb_logic(cds_subset = res[, ], gene_pairs_target_mat =  subset_combinatorial_net, d = 0, n_row = 1, n_col = 2, grid_num = 100, log = T) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
dev.off()

plot_cell_trajectory(URMM_all_fig1b)

################################################################################################################################################
# perform temporal RDI calculation 
################################################################################################################################################
data("neuron_network") # network data
data("neuron_sim_cds") # network data
data("na_sim_cds") # network data
data("example_graph") # network data
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig3.RData')

# neuron_network not exist
neuron_network$Type <- c('Neuron', 'Oligo', 'Astro', 'Neuron', 'AO', 
                         'Neuron', 'Neuron', 'Neuron', 'Neuron', "Neuron", 
                         'AO', 'AO', 'Astro', 'Oligo', 'Olig', 'Astro', 
                         'Astro', 'Astro', 'Olig', 'Astro', 'Oligo')

# 
fData(neuron_sim_cds)$gene_short_name <- fData(neuron_sim_cds)$gene_short_names
fData(na_sim_cds)$gene_short_name <- fData(na_sim_cds)$gene_short_names

gene_name_vec <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

main_fig_dir <- "/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/"
SI_fig_dir <- '/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/supplementary_figures/'

for(curr_cell_type in c('neuron', 'astrocyte', 'oligodendrocyte')) {
  if(curr_cell_type == 'neuron') {
    current_cds <- neuron_sim_cds[, 1:200]
  } else if(curr_cell_type == 'astrocyte') {
    current_cds <- astrocyte_sim_cds[, 1:200]
  } else if(curr_cell_type == 'oligodendrocyte') {
    current_cds <- oligodendrocyte_sim_cds[, 1:200]
  }
  message('current cell type is ', curr_cell_type)
  
  rdi_crdi_pseudotime_res_list <- calculate_temporal_causality(cds_subset = current_cds, window_size = 50, conditioning = T) #13 mature gives Na values
  
  rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
  crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res
  
  dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])
  
  all_cmbns <- expand.grid(gene_name_vec[1:12], gene_name_vec[1:12])
  valid_all_cmbns_df <- data.frame(pair = paste((all_cmbns$Var1), (all_cmbns$Var2), sep = ' -> '), pval = 0)
  
  row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
  rdi_res <- as.data.frame(rdi_res)
  colnames(rdi_res) <- valid_all_cmbns_df$pair
  
  valid_all_cmbns_df <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
  valid_rdi_res <- rdi_res[, as.character(valid_all_cmbns_df$pair)]
  norm_valid_rdi_res <- apply(valid_rdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
  norm_valid_rdi_res[!is.finite(norm_valid_rdi_res)] <- 0
  pheatmap::pheatmap(t(norm_valid_rdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)
  
  valid_all_cmbns_df_back <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
  valid_rdi_res_back <- rdi_res[, as.character(valid_all_cmbns_df_back$pair)]
  
  # smooth temporal causality and then clustering them: 

  smoothed_valid_rdi_res_back <- valid_rdi_res_back
  for(i in as.character(valid_all_cmbns_df_back$pair)) {
    df <- data.frame(Pseudotime = 1:nrow(smoothed_valid_rdi_res_back), Expression = valid_rdi_res_back[, i])
    test <- loess(Expression ~ Pseudotime, df)
    smoothed_valid_rdi_res_back[, i] <-  predict(test)
  }
  
  smoothed_valid_rdi_res_back[smoothed_valid_rdi_res_back < 0] <- 0
  smoothed_valid_rdi_res_back <- apply(smoothed_valid_rdi_res_back, 2, function(x) (x - min(x)) / (max(x) - min(x)))
  smoothed_valid_rdi_res_back[!is.finite(smoothed_valid_rdi_res_back)] <- 0
  
  # pheatmap::pheatmap(t(smoothed_valid_rdi_res_back[, order(apply(smoothed_valid_rdi_res_back, 2, which.max))]), cluster_rows = F, cluster_cols = F, 
  # annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6, treeheight_row = 0)

  pdf(paste0(SI_fig_dir, curr_cell_type, '_temporal_causality_smooth.pdf'))
  pheatmap::pheatmap(t(smoothed_valid_rdi_res_back[, ]), cluster_rows = F, cluster_cols = F, 
                     annotation_names_col = T, annotation_names_row = T, border_color = NA, fontsize = 6, treeheight_row = 0)
  dev.off()
  
  norm_valid_rdi_res_back <- apply(valid_rdi_res_back, 2, function(x) (x - min(x)) / (max(x) - min(x)))
  
  norm_valid_rdi_res_back[!is.finite(norm_valid_rdi_res_back)] <- 0
  pdf(paste0(SI_fig_dir, curr_cell_type, '_temporal_causality.pdf'))
  pheatmap::pheatmap(t(norm_valid_rdi_res_back[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)
  dev.off()
}

# # plot crdi_res
# dim(crdi_res) <- c(dim(crdi_res)[1], dim(crdi_res)[2] * dim(crdi_res)[2])
# 
# valid_all_cmbns_df <- data.frame(pair = paste((all_cmbns$Var1), (all_cmbns$Var2), sep = ' -> '), pval = 0)
# colnames(crdi_res) <- valid_all_cmbns_df$pair
# 
# valid_all_cmbns_df <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
# valid_crdi_res <- crdi_res[, as.character(valid_all_cmbns_df$pair)]
# norm_valid_crdi_res <- apply(valid_crdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
# # norm_valid_crdi_res_ordered <- norm_valid_crdi_res[, order(unlist(apply(norm_valid_crdi_res, 2, which.max)))]
# norm_valid_crdi_res[!is.finite(norm_valid_crdi_res)] <- 0
# pheatmap::pheatmap(t(norm_valid_crdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)
# 
# pheatmap::pheatmap(t(norm_valid_crdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)

################################################################################################################################################
# save the data  
################################################################################################################################################
save.image('./RData/RDI_cRDI_over_pseudotime.RData')

# make the gene-pair plot 



