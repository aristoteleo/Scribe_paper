###############################################################################################################################################
# require a lot work to enable me to make the hive plots runnable 
###############################################################################################################################################

# test on hive plot 
rm(list = ls())

suppressMessages(library("HiveR"))
suppressMessages(library("grid"))
suppressMessages(library("FuncMap"))
suppressMessages(library("sna"))
suppressMessages(library("xtable"))
suppressMessages(library("knitr"))
suppressMessages(library("bipartite"))

###############################################################################################################################################
# making the E. Coli network 
###############################################################################################################################################

EC1 <- dot2HPD(file = "~/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/network_tf_gene.parsed.dot",
               node.inst = NULL,
               edge.inst = "~/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/EdgeInst.csv",
               desc = "E coli gene regulatory network (RegulonDB)",
               axis.cols = rep("grey", 3))

sumHPD(EC1)

EC2 <- mineHPD(EC1, option = "rad <- tot.edge.count")
sumHPD(EC2)

EC3 <- mineHPD(EC2, option = "axis <- source.man.sink")
sumHPD(EC3)

EC4 <- mineHPD(EC3, option = "remove zero edge")
sumHPD(EC4)

edges <- EC4$edges
edgesR <- subset(edges, color == 'red')
edgesG <- subset(edges, color == 'green')
edgesO <- subset(edges, color == 'orange')

edges <- rbind(edgesO, edgesG, edgesR)
EC4$edges <- edges

EC4$edges$weight = 0.5

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
grid.newpage()
pushViewport(viewport(layout = grid.layout(3, 1)))
#
pushViewport(vplayout(1, 1)) # upper plot

plotHive(EC4, dr.nodes = FALSE, ch = 20,
         axLabs = c("source", "sink", "manager"),
         axLab.pos = c(40, 75, 35),
         axLab.gpar = gpar(fontsize = 6, col = "white", lwd = 2),
         arrow = c("degree", 150, 100, 180, 70), np = FALSE)
grid.text("native units", x = 0.5, y = 0.05, default.units = "npc", gp = gpar(fontsize = 8, col = "white"))

popViewport(2)
#
pushViewport(vplayout(2, 1)) # middle plot

plotHive(EC4, dr.nodes = FALSE, method = "rank", ch = 100,
         #axLabs = c("source", "sink", "manager"),
         #axLab.pos = c(100, 125, 180),
         #axLab.gpar = gpar(fontsize = 10, col = "white"),
         np = FALSE)
grid.text("ranked units", x = 0.5, y = 0.05, default.units = "npc", gp = gpar(fontsize = 8, col = "white"))

popViewport(2)
#
pushViewport(vplayout(3, 1)) # lower plot

plotHive(EC4, dr.nodes = FALSE, method = "norm", ch = 0.1, axLabs = c("source", "sink", "manager"),
         axLab.pos = c(0.1, 0.2, 0.2), axLab.gpar = gpar(fontsize = 6, col = "white"), np = FALSE)
grid.text("normed units", x = 0.5, y = 0.05, default.units = "npc", gp = gpar(fontsize = 8, col = "white"))

###############################################################################################################################################
# showing the HIV-protein network 
###############################################################################################################################################
load("~/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/HIVhuH3.RData")
plot3dHive(HIVhuH3)

###############################################################################################################################################
# re-render the hiearchical network as the Hive layout  
###############################################################################################################################################
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/Jupyter_notebook/network_res') # res

############################################################################################
# Now the new (HiveR) part
dataSet.ext <- as.data.frame(get.edgelist(res$g))
colnames(dataSet.ext) <- c('Source', 'Target')
dataSet.ext$weight <- 1
# Create a hive plot from the data frame
hive1 <- edge2HPD(edge_df = dataSet.ext)
#sumHPD(hive1)

# Assign nodes to a radius based on their degree (number of edges they are touching)
hive2 <- mineHPD(hive1, option = "rad <- tot.edge.count")

# Assign nodes to axes based on their position in the edge list 
# (this function assumes direct graphs, so it considers the first column to be a source and second column to be a sink )
hive3 <- mineHPD(hive2, option = "axis <- source.man.sink")

# Removing zero edges for better visualization 
hive4 <- mineHPD(hive3, option = "remove zero edge")

# And finally, plotting our graph (Figure 1)
plotHive(hive4, method = "abs", bkgnd = "white", axLabs = c("source", "hub", "sink"), axLab.pos = 1)


############################################################################################
# example
############################################################################################

require(HiveR)
require(plyr)
require(colorspace)
require(classInt)

d = ggplot2::diamonds
d = d[,c(1:4,7)]
head(d); dim(d)

# separate carat-size data into equal interval groups
brks = classIntervals(d$carat, n=11, style="quantile")$brks[1:11] # also try 'equal' style
d$carat = findInterval(d$carat, brks)

## NODES DATA

nodegroups = list()
for(i in 1:4){
  vals = as.numeric(unique(d[[i]]))
  nodegroup = data.frame(id = 1:length(vals), lab = unique(d[[i]]), vals = vals,
                         radius = 100 * vals/max(vals), axis = i)
  sizes = table(d[[i]])
  nodegroup$size = as.numeric(sizes[ match(nodegroup$lab, names(sizes)) ])
  nodegroup$size = 2 * nodegroup$size / max(nodegroup$size)
  if(i>1) nodegroup$id = nodegroup$id + max(nodegroups[[i-1]]$id)
  nodegroups[[ names(d)[i] ]] = nodegroup
}
nodegroups

nodes = rbind(nodegroups[[1]], nodegroups[[2]], nodegroups[[3]], nodegroups[[4]])
nodes$lab = as.character(nodes$lab)
nodes$axis = as.integer(nodes$axis)
nodes$radius = as.numeric(nodes$radius)
nodes$color = "#ffffff"
head(nodes)

## EDGES DATA

# first update edge data with new node IDs
head(d)
for(i in 1:4) {
  header = paste0(names(nodegroups)[i], 'id')
  d[[header]] = nodegroups[[i]]$id[ match(as.numeric(d[[i]]), nodegroups[[i]]$vals) ]
}
head(d)

# edges between the 4 axes in terms of node IDs
for(i in 6:8){
  edgegroup = data.frame(id1 = d[[i]], id2 = d[[i+1]], price = d[[5]])
  if(i==6) all_edges = edgegroup else all_edges = rbind(all_edges, edgegroup)
}
head(all_edges); dim(all_edges)

# summarise edge data
edges = aggregate(all_edges$price, by=list(all_edges$id1, all_edges$id2), FUN='mean')
names(edges) = c('id1','id2','price')
edges = edges[with(edges, order(id1,id2)),]             # reorder

# set edge weights (stroke thickness)
weights = count(all_edges, vars = c('id1', 'id2'))      # summary data
weights = weights[with(weights, order(id1,id2)),]       # reorder to match egdes
all(weights$id1 == edges$id1, weights$id2 == edges$id2) # check all IDs match up
edges$weight = weights$freq * 0.004
edges$weight = pmax(edges$weight, 0.2)  # set min edge weight to still visible
range(weights$freq)
range(edges$weight)

# normalise prices for each group of edges (to utilise full colour range)
p = edges$price
edges$colorvals = 0

for(i in nodegroups[1:3]){
  sel = edges$id1 %in% range(i$id)[1] : range(i$id)[2]
  edges$colorvals[sel] = (p[sel] - min(p[sel])) / (max(p[sel]) - min(p[sel]))
}

edges$color = paste0(hex(HSV(edges$colorvals * 300, 1, 1)), '60')  # set alpha
edges = edges[order(edges$weight, decreasing=T),]   # draw thin edges last

head(edges)

hpd = list()
hpd$nodes = nodes
hpd$edges = edges
hpd$type = "2D"
hpd$desc = "Diamonds"
hpd$axis.cols = rep('#00000000', 4) # make invisible
hpd$axLabs = c("carats","cut","colour","clarity")
class(hpd) = "HivePlotData"

# Check data correctly formatted
chkHPD(hpd, confirm = TRUE)

# plot hive!
pdf('hive.pdf', width=8, height=8)
plotHive(hpd, axLabs = hpd$axLabs, ch = 0.1)
dev.off()
browseURL('hive.pdf')

############################################################################################
# example
############################################################################################
test2 <- ranHiveData(nx = 2)
test3 <- ranHiveData(nx = 3)
test4 <- ranHiveData(nx = 4)
#
# plot one with defaults:
plotHive(test3)
#
# Add axis labels & options to nx = 3 example.  Note that rot is not part of gpar
require("grid")
plotHive(test3, ch = 5, labs = c("axis 1", "axis 2", "axis 3"),
         lab.pos = c(10, 15, 15), lab.gpar = gpar(col = "orange", fontsize = 14),
         rot = c(0, 30, -30))
#
# Now the nx = 2 case.
# Note that gpar contains parameters that apply to both the
# axis labels and arrow. A 6th value in arrow offsets the arrow vertically:
plotHive(test2, ch = 5, labs = c("axis 1", "axis 2"), rot = c(-90, 90),
         lab.pos = c(20, 20), lab.gpar = gpar(col = "pink", fontsize = 14, lwd = 2),
         arrow = c("radius units", 0, 20, 60, 25, 40))

# The following must be run interactively:
## Not run: 
plot3dHive(test4)

