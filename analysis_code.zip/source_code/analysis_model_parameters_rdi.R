# analysis the result with different parameters for the simulation network 
library(Scribe)
library(scRNASeqSim)
library(reshape2)

N_RDI_df_list <- list()
N_cRDI_df_list <- list()

for(N in c(0:5)) {
  message(paste0('current N is ', N))
  
  file_name <- paste0("simulation_expr_mat_nonlinear_n_", N, "_step_400_N_end_20")
  simulation_expr_mat_nonlinear <- read.csv(paste0('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/', file_name))
  ncells <- ncol(simulation_expr_mat_nonlinear) - 3
  ncells <- 200
  
  run_vec <- rep(1, ncells)
    
  all_exprs_mat <- as.matrix(simulation_expr_mat_nonlinear[, 3:(ncells + 3)])
  row.names(all_exprs_mat) <- simulation_expr_mat_nonlinear$X
  
  all_exprs_mat <- all_exprs_mat[gene_name_vec, ]
  
  a <- Sys.time()
  rdi_list <- calculate_rdi_multiple_run_cpp(t(all_exprs_mat), delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise
  b <- Sys.time()
  rdi_time <- b - a
  
  dimnames(rdi_list$max_rdi_value) <- list(gene_name_vec, gene_name_vec)
  con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(t(all_exprs_mat), as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 5)
  dimnames(con_rdi_res_test) <- list(gene_name_vec, gene_name_vec)
  
  rdi_list$max_rdi_value <- rdi_list$max_rdi_value[gene_name_vec, gene_name_vec]
  con_rdi_res_test <- con_rdi_res_test[gene_name_vec, gene_name_vec]
  
  RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
  cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))
  
  colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
  colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))
  
  # calculate the ROC / AUC values
  RDI_df <- calROCAUC(RDI_res_df)
  cRDI_df <- calROCAUC(cRDI_res_df)
  
  N_RDI_df_list <- c(N_RDI_df_list, list(RDI_df))
  N_cRDI_df_list <- c(N_cRDI_df_list, list(cRDI_df))
}

lapply(N_RDI_df_list, function(x) unique(x$auc))
lapply(N_cRDI_df_list, function(x) unique(x$auc))

N_end_RDI_df_list <- list()
N_end_cRDI_df_list <- list()

for(N_end in c(20, 40, 60, 80, 120, 200, 300, 400)) {
  message(paste0('current N_end is ', N_end))
  
  file_name <- paste0("simulation_expr_mat_nonlinear_n_4_step_400_N_end_", N_end)
  simulation_expr_mat_nonlinear <- read.csv(paste0('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Python_code/', file_name))
  ncells <- ncol(simulation_expr_mat_nonlinear) - 3
  ncells <- 200
  
  run_vec <- rep(1, ncells)
  
  all_exprs_mat <- as.matrix(simulation_expr_mat_nonlinear[, 3:(ncells + 3)])
  row.names(all_exprs_mat) <- simulation_expr_mat_nonlinear$X
  
  all_exprs_mat <- all_exprs_mat[gene_name_vec, ]
  
  a <- Sys.time()
  rdi_list <- calculate_rdi_multiple_run_cpp(t(all_exprs_mat), delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise
  b <- Sys.time()
  rdi_time <- b - a
  
  dimnames(rdi_list$max_rdi_value) <- list(gene_name_vec, gene_name_vec)
  con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(t(all_exprs_mat), as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 5)
  dimnames(con_rdi_res_test) <- list(gene_name_vec, gene_name_vec)
  
  rdi_list$max_rdi_value <- rdi_list$max_rdi_value[gene_name_vec, gene_name_vec]
  con_rdi_res_test <- con_rdi_res_test[gene_name_vec, gene_name_vec]
  
  RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
  cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))
  
  colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
  colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))
  
  # calculate the ROC / AUC values
  RDI_df <- calROCAUC(RDI_res_df)
  cRDI_df <- calROCAUC(cRDI_res_df)
  
  N_end_RDI_df_list <- c(N_end_RDI_df_list, list(RDI_df))
  N_end_cRDI_df_list <- c(N_end_cRDI_df_list, list(cRDI_df))  
}

lapply(N_end_RDI_df_list, function(x) unique(x$auc))
lapply(N_end_cRDI_df_list, function(x) unique(x$auc))

qplot(1:6, unlist(lapply(N_RDI_df_list, function(x) unique(x$auc)))) 
qplot(1:6, unlist(lapply(N_cRDI_df_list, function(x) unique(x$auc)))) 

qplot(1:8, unlist(lapply(N_end_RDI_df_list, function(x) unique(x$auc)))) 
qplot(1:8, unlist(lapply(N_end_cRDI_df_list, function(x) unique(x$auc)))) 
