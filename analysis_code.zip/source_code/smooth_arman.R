#implement the smoothing in R as that implemented by Arman in python
# def smooth_genes(genes_data, data_mode, window_size = 40):
#   
#   print "Smoothing the genes by taking a moving average over a window of size", window_size, "...",
# 
# if data_mode=="single_run":
#   for id in genes_data.keys():
#   genes_data_tmp = []
#   for j in range(len(genes_data[id]) - window_size):
#     genes_data_tmp.append([np.mean(genes_data[id][j:j + window_size])])
#   genes_data[id] = genes_data_tmp[:]
#   
#   elif data_mode=="multi_run": # Multi_run
#     for gene_id in genes_data.keys():
#     for run_id in genes_data[gene_id].keys():
#     genes_data_tmp = []
#   for j in range(len(genes_data[gene_id][run_id]) - window_size):
#     genes_data_tmp.append([np.mean(genes_data[gene_id][run_id][j:j + window_size])])
#   genes_data[gene_id][run_id] = genes_data_tmp[:]
#   
#   else: ValueError("Invalid paramter value: data_mode")
#   
#   print "DONE.\n"
#   

# function to reproduce the smooth used by Arman
smooth_data <- function(exprs, window_size = 40) {
  win_range <- ncol(exprs) - window_size
  exprs_smooth <- exprs[, -c(window_size)]
  for(i in 1:win_range) {
    exprs_smooth[, i] <- apply(exprs)
  }
  apply(exprs, 1, function(x) {
    tmp <- rep(0, win_range)
    for(i in 0:(win_range - 1))
      tmp[i + 1] <- mean(x[i + 1:window_size])
  })
}