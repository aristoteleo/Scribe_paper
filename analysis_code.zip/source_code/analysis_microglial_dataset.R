#test the microglial dataset's results: 

#1. rank the conditioned RDI 
#2. correlate with the fold-change 
#3. correlate with the p-value after the test 

# output%5Coutput_RDI_conditioned.txt
library(monocle)
library(di)

microglial_rdi_res <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/microglia/Microglial_k1_results_d1to40_w20/output%5Coutput_RDI_conditioned.txt', 
                                 header = T, sep = '\t', stringsAsFactors = F)
mafb_targets_res <- read.table('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/csv_data/microglia/MafB_knockout', 
                               header = T, sep = '\t', row.names = 1, stringsAsFactors = F)

uniq_gene_names <- unique(microglial_rdi_res$Gene_1_ID)
valid_gene_names <- intersect(uniq_gene_names, tolower(row.names(mafb_targets_res)))

row.names(mafb_targets_res) <- tolower(row.names(mafb_targets_res))
valid_gene_res <- mafb_targets_res[valid_gene_names, ]
valid_gene_res$NB_log2_fc <- log2(valid_gene_res$NB.Mafb.KO / valid_gene_res$NB.CTRL)
valid_gene_res$Adult_log2_fc <- log2(valid_gene_res$Adult.Mafb.KO / valid_gene_res$Adult.CTRL)
valid_gene_res$log2_fc <- 1/2 * (valid_gene_res$NB_log2_fc + valid_gene_res$Adult_log2_fc)

subset_microglial_rdi_res <- subset(microglial_rdi_res, Gene_1_ID == 'mafb' & Gene_2_ID %in% valid_gene_names)
row.names(subset_microglial_rdi_res) <- subset_microglial_rdi_res$Gene_2_ID

valid_gene_res$MafB_RDI <- subset_microglial_rdi_res[row.names(valid_gene_res), 'RDI']

qplot(NB_log2_fc, MafB_RDI, data = valid_gene_res)
qplot(Adult_log2_fc, MafB_RDI, data = valid_gene_res)
qplot(log2_fc, MafB_RDI, data = valid_gene_res)
 
########################################################################################################################################################
# run normalization (normalize RDI by expression value)
########################################################################################################################################################
microglia_exprs <- read.table('./csv_data/microglia/microglia_mat.txt', header = T, row.names = 1)
row.names(microglia_exprs) <- tolower(row.names(microglia_exprs))

load('./RData/microglial_cds')

Capitalize_first <- function(str) {
  res <- strsplit(str, '')[[1]]
  tmp <- toupper(res[1])
  for(i in res[-1])
    tmp <- paste(tmp, i, sep = '', collapse = '')
  
  tmp
}

Capitalize_name <- unlist(lapply(row.names(valid_gene_res), Capitalize_first))
  
valid_gene_res$avg_expr <- esApply(microglial_cds[Capitalize_name, ], 1, mean)
qplot(avg_expr, MafB_RDI, data = valid_gene_res)

#calculate the residual: 
monocle:::genSmoothCurveResiduals(cds[Capitalize_name, ], rend_formula = "~sm.ns(avg_expr, df = 3)")
#fit the curve with VGAM: 
vglm_fit <- vglm(MafB_RDI ~ sm.ns(avg_expr, df = 3), family = gaussianff(), data = valid_gene_res)

valid_gene_res$vglm_fit <- 0
valid_gene_res[row.names(predict(vglm_fit)), 'vglm_fit'] <- predict(vglm_fit)[, 1]

#get the residual from the data: 
qplot(avg_expr, vglm_fit, data = valid_gene_res) + geom_point(aes(avg_expr, MafB_RDI, color = 'gray') )

valid_gene_res$residual <- 0
valid_gene_res[row.names(predict(vglm_fit)), 'residual'] <- resid(vglm_fit)

#basically there is no correlation 
qplot(residual, NB_log2_fc, data = valid_gene_res)
qplot(residual, Adult_log2_fc, data = valid_gene_res)

########################################################################################################################################################
# save the result 
########################################################################################################################################################





