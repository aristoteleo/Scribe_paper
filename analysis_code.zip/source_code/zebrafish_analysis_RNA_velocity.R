# select the cells from the cds 
load('./RData/zebrafish_RNA_velocity_combined_euth_hypo.RData')

# load necessary packages 
library(devtools)
load_all('/Users/xqiu/Dropbox (Personal)/Projects/monocle-dev')
load_all('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Cpp/Real_deal/Scribe/Scribe/')
################################################################################################################################################################
# create RNA velocity analysis
################################################################################################################################################################
dat_names <- names(r$clusters$PCA$multilevel)

cell_type <- pData(comb2_cds_cell)$Cell_type 
condition <- pData(comb2_cds_cell)$condition
condition[condition == 'euTH'] <- 'euth'
condition[condition == 'hypoTH'] <- 'hypo'

names(cell_type) <- paste0(stringr::str_split_fixed(colnames(comb2_cds_cell), "-", 2)[, 1], "-1 ", condition)

intersect(stringr::str_split_fixed(colnames(comb2_cds_cell), "-", 2)[, 1], stringr::str_split_fixed(names(r$clusters$PCA$multilevel), "-", 2)[, 1])

pdf('./Figures/supplementary_figures/cell_cluster_euth_hypo.pdf')
r$plotEmbedding(type='PCA',colors = pagoda2:::fac2col(cell_type[dat_names]), group.level.colors = pagoda2:::fac2col(cell_type[dat_names]), groups =  cell_type[dat_names], 
                embeddingType='tSNE',show.legend=T,mark.clusters=T,min.group.size=10,shuffle.colors=F,mark.cluster.cex=1,alpha=0.3,main='cell clusters')
dev.off()

# visualize the cell types: 
pdf('./Figures/supplementary_figures/velocity_euth_hypo.pdf')
show.velocity.on.embedding.cor(emb,rvel.cd,n=200,scale='sqrt',cell.colors=ac(pagoda2:::fac2col(cell_type[dat_names]),alpha=0.5),cex=0.8,arrow.scale=3,show.grid.flow=TRUE,min.grid.cell.mass=0.5,grid.n=40,arrow.lwd=1,do.par=F,cell.border.alpha = 0.1)
dev.off()

# visualize the condition: 
names(condition) <- names(cell_type)
pdf('./Figures/supplementary_figures/velocity_euth_hypo_by_condition.pdf')
show.velocity.on.embedding.cor(emb,rvel.cd,n=200,scale='sqrt',cell.colors=ac(pagoda2:::fac2col(condition[dat_names]),alpha=0.5),cex=0.8,arrow.scale=3,show.grid.flow=TRUE,min.grid.cell.mass=0.5,grid.n=40,arrow.lwd=1,do.par=F,cell.border.alpha = 0.1)
dev.off()

################################################################################################################################################################
# collect cells in the interesting clusters and do the downstream network inference analysis: 
################################################################################################################################################################

################################################################################################################################################################
# do the same for the Schawann cell: 
################################################################################################################################################################
table(cell_type)
valid_cell_types <- c("Progenitor 1 (G2/Mitosis)", 'Progenitor 2', 'Myelinating Schwann Cell', 'Schwann Cell') # 'unknown',  
sum(cell_type %in% valid_cell_types) # 'unknown', 

valid_cells <- intersect(colnames(rvel.cd$current), names(cell_type)[cell_type %in% valid_cell_types])

gene_list <- c("sox10", 'sce', 'pou3f1', 'mse', 'erg2b', 'mpz',
               "fabp7", "erbb3", "plp1", "dhh", "ngfr", "mag", "sox2", "sh3tc2", "prrx", "arhgef10", "foxd3", 
               "lamb2", "lamb1", "lama2", "lama4", "mal", "s100b", "lgi4",
               "nfkbiaa", "brn2", "sox2", 'MO2-jun', 'srebp', 'hmg', 'coa', 'mbpa', 'cx32')
gene_list[gene_list %in% fData(comb2_cds_cell)$gene_short_name]
valid_gene <- gene_list[gene_list %in% rownames(rvel.cd$current)]

################################################################################################################################################################
# network inference with RNA-velocity  
# use current / projected matrix   
################################################################################################################################################################
current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])

n_genes <- length(valid_gene)
tmp <- expand.grid(1:n_genes, 1:n_genes, stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ]
super_graph[, 1] <- valid_gene[super_graph[, 1]]
super_graph[, 2] <- valid_gene[super_graph[, 2]]

# cmi: I(x(t - 1), y (t) | y(t - 1) )
res <- apply(super_graph, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE)

################################################################################################################################################################
# use emat / emat + deltaE 
################################################################################################################################################################
emat_proj <- emat[row.names(rvel.cd$deltaE), colnames(rvel.cd$deltaE)] + rvel.cd$deltaE
emat_curr <- emat[row.names(rvel.cd$deltaE), colnames(rvel.cd$deltaE)]

current_n <- as.matrix(emat_curr[valid_gene, valid_cells])
projected <- as.matrix(emat_proj[valid_gene, valid_cells])

res <- apply(super_graph, 1, function(x) {
  Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(projected[x[2], ]), as.matrix(current_n[x[2], ]), k = 5, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE)

################################################################################################################################################################
# do a pseudotime ordering and then run the network inference: 
# use dpt 
################################################################################################################################################################
source('./Scripts/function.R', echo = T)

norm_data <- t(rvel.cd$current[, valid_cells])
duplicated_genes <- which(base::duplicated.array(norm_data))
norm_data[duplicated_genes, 1] <- norm_data[duplicated_genes, 1] + rnorm(length(duplicated_genes), 0, 1)
dm <- destiny::DiffusionMap(as.matrix(norm_data))
dpt <- destiny::DPT(dm)
plot(dpt)
# identify the root: 
root <- cell_type[valid_cells[which(dpt@tips[, 1])]]
dpt <- DPT(dm, tips = which(row.names(norm_data) == names(root)[3]))
pt <- dpt[, which(row.names(norm_data) == names(root)[3])]

qplot(dpt@dm$DC1, dpt@dm$DC2, color = pt)

################################################################################################################################################################
# run Monocle 2  
################################################################################################################################################################
# create a cds 
pData <- data.frame(cell = row.names(norm_data), row.names = row.names(norm_data))
pd <- new("AnnotatedDataFrame", data = pData)
fData <- data.frame(gene_short_name = colnames(norm_data), row.names = colnames(norm_data))
fd <- new("AnnotatedDataFrame", data = fData)

pigment_cds <- newCellDataSet(as(t(norm_data), "sparseMatrix"), 
                                 phenoData = pd, 
                                 featureData = fd,
                                 lowerDetectionLimit=1,
                                 expressionFamily=gaussianff())

################################################################################################################################################################
# network inference with Monocle 2 estimated pseudotime 
################################################################################################################################################################
pData(pigment_cds)$Pseudotime <- pt
pData(pigment_cds)$Pseudotime_dpt <- pt
plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')

pigment_cds <- reduceDimension(pigment_cds, ncenter = NULL,  norm_method = 'none', scaling = F, pseudo_expr = 0, verbose = T)
pigment_cds <- orderCells(pigment_cds)
plot_cell_trajectory(pigment_cds)

plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')
pigment_cds <- orderCells(pigment_cds, reverse = T)
plot_genes_in_pseudotime(pigment_cds[valid_gene, ], color_by = 'Pseudotime')

rdi_res <- Scribe::calculate_rdi(pigment_cds[valid_gene, ], delays = 1, log = F, uniformalize = T)
g <- igraph::graph_from_adjacency_matrix(as.matrix(rdi_res$max_rdi_value), weighted = T, mode = "direct")
plot.igraph(g, edge.width=E(g)$weight * 20, edge.curved=TRUE)

# do the combined analysis with pseudotime and the RNA-velocity 
################################################################################################################################################################
# analyze the data with scaled unspliced and exon expression 
################################################################################################################################################################
names(pt) <- colnames(pigment_cds)
spliced <- rvel.cd$gamma * rvel.cd$current[names(rvel.cd$gamma), ]
qplot(pt, as.numeric(spliced['mitfa', colnames(pigment_cds)]) ) + ylab('Expression')

#spliced: vlm.Sx_sz[i, pc_obj.ixsort]*vlm.gammas[i] 
#unspliced: Ux_sz

# unspliced is early than spliced: 
qplot(pt, as.numeric(rvel.cd$gamma['mitfa'] * rvel.cd$current['mitfa', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['mitfa', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['pmela'] * rvel.cd$current['pmela', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['pmela', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['dct'] * rvel.cd$current['dct', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['dct', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

qplot(pt, as.numeric(rvel.cd$gamma['tyrp1b'] * rvel.cd$current['tyrp1b', colnames(pigment_cds)]), color = 'spliced' ) + ylab('Expression') + # conv.emat.norm
  geom_point(aes(pt, as.numeric(rvel.cd$conv.nmat.norm['tyrp1b', colnames(pigment_cds)]), color = 'unspliced') ) + ylab('Expression')

scaled_spliced <- rvel.cd$gamma[valid_gene] * rvel.cd$current[valid_gene, colnames(pigment_cds)]
unspliced <- rvel.cd$conv.nmat.norm[valid_gene, colnames(pigment_cds)]

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
res <- apply(super_graph, 1, function(x) {
  #Scribe::cmi(as.matrix(unspliced[x[1], ]), as.matrix(scaled_spliced[x[2], ]), as.matrix(unspliced[x[2], ]), k = 15, normalize = F)$cmi_res
  Scribe::cmi(as.matrix(scaled_spliced[x[1], ]), as.matrix(unspliced[x[2], ]), as.matrix(scaled_spliced[x[2], ]), k = 15, normalize = T)$cmi_res
  # Scribe::cmi(as.matrix(current_n[x[1], ]), as.matrix(unspliced[x[2], ] ), as.matrix(current_n[x[2], ]), k = 5, normalize = T)$cmi_res
})

# use current / unspliced and future 

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 100, edge.curved=TRUE)

################################################################################################################################################################
# combining pseudotime and RNA velocity 
# a. concatenate pseudotime (all expression ordered data) and RNA-velocity (exon ordered)
# b. performing pseudotime ordering with exon and then do RDI with exon and the unspliced in the RDI (need to change the Scribe c++ code) 
################################################################################################################################################################

# 1. concatenate pseudotime (all expression ordered data) and RNA-velocity (exon ordered)

ind <- which(names(cell_type) %in% valid_cells)
ind <- setdiff(ind, which(duplicated(names(cell_type))))
valid_cds <- comb2_cds_cell[, ind]

pData(valid_cds)$Pseudotime <- pData(pigment_cds[, names(cell_type)[ind]])$Pseudotime
gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% valid_gene))
plot_genes_in_pseudotime(valid_cds[gene_ids, ], color_by = 'Cell_type')

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
sort_gene_expression <- as.matrix(exprs(valid_cds)[gene_ids, sort(pData(valid_cds)$Pseudotime)])
row.names(sort_gene_expression) <- valid_gene
ncells <- ncol(sort_gene_expression)
sort_gene_expression <- sort_gene_expression / sizeFactors(valid_cds)[sort(pData(valid_cds)$Pseudotime)]
sort_gene_expression <- log(sort_gene_expression + 1) 

delay <- 5

# only the genes: 
# fit the gene expression first: 
Pseudotime <- pData(valid_cds)$Pseudotime 

genes_data <- log(t(as.matrix(exprs(valid_cds)[full_gene_ids, order(pData(valid_cds)$Pseudotime)])) / sizeFactors(valid_cds)[order(pData(valid_cds)$Pseudotime)] + 1) # Rows are samples while columns are features

smoothed_exprs <- apply(genes_data, 2, function(x) {
  df <- data.frame(Expression = x, 
             Pseudotime = Pseudotime)
  fit <- loess(Expression ~ Pseudotime, df) #, span = 0.1
  predict(fit)
})

exprs(valid_cds[full_gene_ids, ]) <- as(t(smoothed_exprs), 'sparseMatrix')
rdi_res <- calculate_rdi(valid_cds[full_gene_ids, ], delays = c(5, 10, 15))
dimnames(rdi_res$max_rdi_value) <- list(fData(valid_cds)[full_gene_ids, 'gene_short_name'], fData(valid_cds)[full_gene_ids, 'gene_short_name'])
causality_res <- rdi_res$max_rdi_value

causality_res[!(causality_res > t(causality_res))] <- 0

causality_res <- causality_res[c("sox10", "sox2", "pou3f1", "foxd3", "mbpa"), c("sox10", "sox2", "pou3f1", "foxd3", "mbpa")]

colnames(smoothed_exprs) <- fData(valid_cds[full_gene_ids, ])$gene_short_name
mlt_smoothed_exprs <- reshape2::melt(smoothed_exprs)
mlt_smoothed_exprs$Var1 <- Pseudotime[mlt_smoothed_exprs$Var1]
qplot(Var1, value, data = subset(mlt_smoothed_exprs, Var2 %in% c("sox10", "sox2", "pou3f1", "foxd3", "mbpa")), color = Var2)
g <- igraph::graph_from_adjacency_matrix(as.matrix(causality_res), weighted = T, mode = "direct")
plot.igraph(g, edge.width=(E(g)$weight - 2 * min(E(g)$weight)) /(max(E(g)$weight) - 2 * min(E(g)$weight)) * 2, edge.curved=TRUE, layout = layout_as_tree(g))

################################################################################################################################################################
res <- apply(super_graph, 1, function(x) {
  x_t_min_1 <- as.matrix(c(current_n[x[1], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  y_t <- as.matrix(c(projected[x[2], ], sort_gene_expression[x[1], (1 + delay):ncells]) )
  y_t_min_1 <- as.matrix(c(current_n[x[2], ], sort_gene_expression[x[1], 1:(ncells - delay)]) )
  
  Scribe::cmi(x_t_min_1, y_t, y_t_min_1, k = 15, normalize = T)$cmi_res
  # Scribe::cmi(x_t_min_1[1:length(ncol(current_n))], y_t[1:length(ncol(current_n))], y_t_min_1[1:length(ncol(current_n))], k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
adj_mat <- adj_mat + abs(min(adj_mat))
adj_mat[!(adj_mat > t(adj_mat))] <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")
pheatmap::pheatmap(adj_mat)
plot.igraph(g, edge.width=(E(g)$weight - 2 * min(E(g)$weight)) /(max(E(g)$weight) - 2 * min(E(g)$weight)) * 5, edge.curved=TRUE)

################################################################################################################################################################
# 2. performing pseudotime ordering with exon and then do RDI with exon and the unspliced in the RDI (need to change the Scribe c++ code)
################################################################################################################################################################
ind <- which(names(cell_type) %in% valid_cells)
ind <- setdiff(ind, which(duplicated(names(cell_type))))
valid_cds <- comb2_cds_cell[, ind]

pData(valid_cds)$Pseudotime <- pData(pigment_cds[, names(cell_type)[ind]])$Pseudotime
gene_ids <- row.names(subset(fData(valid_cds), gene_short_name %in% valid_gene))
plot_genes_in_pseudotime(valid_cds[gene_ids, ], color_by = 'Cell_type')

current_n <- as.matrix(rvel.cd$current[valid_gene, valid_cells])
projected <- as.matrix(rvel.cd$projected[valid_gene, valid_cells])
sort_gene_expression <- as.matrix(rvel.cd$current[valid_gene, sort(pData(valid_cds[, ])$Pseudotime)])
row.names(sort_gene_expression) <- valid_gene
ncells <- ncol(sort_gene_expression)
delay <- 1

res <- apply(super_graph, 1, function(x) {
  x_t_min_1 <- as.matrix(sort_gene_expression[x[1], 1:(ncells - delay)])
  y_t <- as.matrix(projected[x[2], (1 + delay):ncells])
  y_t_min_1 <- as.matrix(current_n[x[2], (1 + delay):ncells])
  Scribe::cmi(x_t_min_1, y_t, y_t_min_1, k = 15, normalize = T)$cmi_res
})

causality_res <- cbind(super_graph, res)
adj_mat <- reshape2::dcast(causality_res, Var1 ~ Var2)
row.names(adj_mat) <- adj_mat$Var
adj_mat <- adj_mat[, -1]
diag(adj_mat) <- 0
g <- igraph::graph_from_adjacency_matrix(as.matrix(adj_mat), weighted = T, mode = "direct")

plot.igraph(g, edge.width=E(g)$weight * 10, edge.curved=TRUE)

################################################################################################################################################################
# save the data
################################################################################################################################################################
save.image('./RData/zebrafish_analysis_RNA_velocity_shawnn_cells.RData')

################################################################################################################################################################
# do this for the entire markov chance process (some ideas from the Waddington-ot paper?)
################################################################################################################################################################

