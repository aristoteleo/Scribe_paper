library(Scribe)
library(R.matlab)
library(reshape2)
library(xacHelper)
library(plyr)

cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')
# run RDI with and without uniformalization 
##########################################################################################################################################################
# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
# run the gradient for all lineages (up to 40 cells)
calStatisticsLadder <- function(data = all_cell_simulation[, 1:200, ], cell_ids = neuron_cell_ids, ladder_vec = c(2, 5, 10, 15, 20, 25, 40), delay = c(1), uniformalize = FALSE) {
  
  # collect the RDI and cRDI network for each run
  RDI_parallel_res_list <- list()
  cRDI_parallel_res_list <- list()
  
  # run RDI / cRDI for each sampled run
  set.seed(2017)
  for(id in ladder_vec) {
    message(id)
    
    # a <- Sys.time() # calculate RDI
    # RDI_parallel_res <- calculate_rdi_many_run(all_cell_simulation[, 1:200, ], sample(cell_ids, id))
    # b <- Sys.time()
    
    RDI_parallel_res <- calculate_rdi_many_run_concatenation(data, sample(cell_ids, id), delay = delay, uniformalize)
    
    # no conditioning for this part:
    # a <- Sys.time() # calculate cRDI
    # cRDI_parallel_res <- calculate_rdi_many_run(all_cell_simulation[, 1:200, ], sample(cell_ids, id))
    # b <- Sys.time()
    
    RDI_parallel_res_list <- c(RDI_parallel_res_list, RDI_parallel_res = list(RDI_parallel_res$max_rdi_value)) # RDI_parallel_res returned is a matrix
    cRDI_parallel_res_list <- c(cRDI_parallel_res_list, cRDI_parallel_res = list(RDI_parallel_res$con_rdi_res_test))
  }
  
  # extract only the max_rdi_values
  RDI_res_df <- process_data(RDI_parallel_res_list); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
  cRDI_res_df <- process_data(cRDI_parallel_res_list); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))
  
  colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
  # colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))
  
  # calculate the ROC / AUC values
  RDI_df <- calROCAUC(RDI_res_df)
  cRDI_df <- calROCAUC(cRDI_res_df)
  
  # return the results
  return(list(RDI_df = RDI_df, cRDI_df = cRDI_df, RDI_parallel_res_list = RDI_parallel_res_list, cRDI_parallel_res_list = cRDI_parallel_res_list))
}

# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
# function to run multiple run by concatenation:
calculate_rdi_many_run_concatenation <- function(x3d, cell_ids = neuron_cell_ids, delay = c(1), sd = 0, uniformalize = FALSE) {
  # concatenate to a two-dimensional matrix instead of a three dimensional one
  data <- x3d[, , cell_ids] # subset the data
  
  run_vec <- rep(1:length(cell_ids), each = dim(data)[2]) # set the run id for each cell
  
  dim(data) <- c(nrow(x3d), dim(data)[2] * dim(data)[3]) # convert the dimension of data
  
  # correctly assign the value for each gene (firstly use entire run from the first run followed by the second run, etc.)
  for(i in 1:nrow(x3d)) {
    tmp <- x3d[i, , cell_ids]
    dim(tmp) <- c(1, dim(tmp)[1] * dim(tmp)[2])
    data[i, ] <- tmp
  }
  
  # add random noise
  set.seed(831)
  noise = matrix(rnorm(mean = 0, sd = sd, nrow(data) * ncol(data)), nrow = nrow(data)) # 1e-12
  # noise = matrix(rnorm(mean = 0, sd = sd, nrow(data) * ncol(data)), nrow = nrow(data))
  data_noise <- t(data + noise)
  
  tmp <- expand.grid(1:ncol(data_noise), 1:ncol(data_noise), stringsAsFactors = F)
  super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
  super_graph <- super_graph[, c(2, 1)]
  
  # calculate rdi values
  a <- Sys.time()
  rdi_list <- calculate_rdi_multiple_run_cpp(data_noise, delay = delay, run_vec - 1, as.matrix(super_graph), method = 1, uniformalize) #calculate_rdi(data_noise, delay, method = 1)
  b <- Sys.time()
  rdi_time <- b - a
  
  # calculate crdi values
  con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data_noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 5, F)
  
  return(list(max_rdi_value = rdi_list$max_rdi_value, con_rdi_res_test = con_rdi_res_test))
}

# function to run multiple run: (x3d/y3d: three dimensional array: 1: gene; 2: time step; 3: run)
calculate_rdi_many_run <- function(x3d, cell_ids = neuron_cell_ids, sd = 0, uniformalize = FALSE) {
  gene_step_cells <- dim(x3d)
  
  res <- matrix(nrow = gene_step_cells[1], ncol = gene_step_cells[1])
  
  noise = matrix(rnorm(mean = 0, sd = sd, gene_step_cells[2] * length(cell_ids)), nrow = gene_step_cells[2])
  
  for(i in 1:gene_step_cells[1]) {
    for(j in 1:gene_step_cells[1]) {
      message(paste('i is', i, 'j is', j))
      if(i == j) {
        res[i, j] <- NA
      }
      else {
        res[i, j] <- rdi_many_runs(as.matrix(x3d[i, ,cell_ids]) + noise, as.matrix(x3d[j, ,cell_ids]) + noise, uniformalize) # + noise
        message(res[i, j])
      }
    }
  }
  
  return(res)
}

process_data <- function(parallel_res_list, network = neuron_network) {
  processed_res <- lapply(parallel_res_list, function(x) {
    gene_uniq <- unique(c(as.character(network$V1), as.character(network$V2)))
    all_cmbns <- expand.grid(gene_uniq, gene_uniq)
    valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
    all_valid_gene_pairs <- paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_')
    
    dimnames(x) <- list(c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature'), 
                        c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature'))
    mlt_RDI_benchmark_res <- melt(x[1:12, 1:12])
    row.names(mlt_RDI_benchmark_res) <- paste(tolower(mlt_RDI_benchmark_res$Var1), tolower(mlt_RDI_benchmark_res$Var2), sep = '_')
    
    t(data.frame(RDI = mlt_RDI_benchmark_res[all_valid_gene_pairs, 'value']))
  })
  return(processed_res)
}

calROCAUC <- function(res_df, network = neuron_network) {
  gene_uniq <- unique(c(as.character(network[, 1]), as.character(network[, 2])))
  all_cmbns <- expand.grid(gene_uniq, gene_uniq)
  valid_all_cmbns <- all_cmbns[all_cmbns$Var1 != all_cmbns$Var2, ]
  valid_all_cmbns_df <- data.frame(pair = paste(tolower(valid_all_cmbns$Var1), tolower(valid_all_cmbns$Var2), sep = '_'), pval = 0)
  row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
  valid_all_cmbns_df[paste(tolower(network$V1), tolower(network$V2), sep = '_'), 2] <- 1
  
  reference_network_pvals <- valid_all_cmbns_df[, 2]
  p_thrsld <- 0
  
  roc_df_list <- lapply(colnames(res_df), function(x, reference_network_pvals_df = reference_network_pvals) {
    pvals <- res_df[, x]
    
    pvals[is.na(pvals)] <- 0
    reference_network_pvals[is.na(reference_network_pvals)] <- 0
    pvals <- (pvals - min(pvals)) / (max(pvals) - min(pvals))
    res <- generate_roc_df(pvals, reference_network_pvals > p_thrsld)
    colnames(res) <- c('tpr', 'fpr', 'auc')
    cbind(res, method = x)
  })
  
  roc_df_list <- lapply(roc_df_list, function(x) {colnames(x) <- c('tpr', 'fpr', 'auc', 'method'); x} )
  roc_df <- do.call(rbind, roc_df_list)
  
  return(roc_df)  
}

neuron_ladder <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = 1:200, ladder_vec = c(2, 5, 10, 15, 20, 25), delay = 1) #neuron_cell_ids
neuron_ladder_uniform <- calStatisticsLadder(data = all_cell_simulation[, 1:200, ], cell_ids = 1:200, ladder_vec = c(2, 5, 10, 15, 20, 25), delay = 1, uniformalize = T) #

# add both of the RDI and cRDI's result here
neuron_ladder$RDI_df$method <- revalue(neuron_ladder$RDI_df$method, c("cluster_1" = 2,  "cluster_2" = 5, "cluster_3" = 10, "cluster_4" = 15, "cluster_5" = 20,  "cluster_6" = 25))
neuron_ladder$RDI_df$method <- as.numeric(as.character(neuron_ladder$RDI_df$method))
neuron_ladder$cRDI_df$method <- revalue(neuron_ladder$cRDI_df$method, c("cRDI_parallel_res" = 2,  "cRDI_parallel_res1" = 5, "cRDI_parallel_res2" = 10, "cRDI_parallel_res3" = 15, "cRDI_parallel_res4" = 20,  "cRDI_parallel_res5" = 25))
neuron_ladder$cRDI_df$method <- as.numeric(as.character(neuron_ladder$cRDI_df$method))
# neuron_ladder$cRDI_df$method <- neuron_ladder$RDI_df$method
# add both of the RDI and cRDI's result here
neuron_ladder_uniform$RDI_df$method <- revalue(neuron_ladder_uniform$RDI_df$method, c("cluster_1" = 2,  "cluster_2" = 5, "cluster_3" = 10, "cluster_4" = 15, "cluster_5" = 20,  "cluster_6" = 25))
neuron_ladder_uniform$RDI_df$method <- as.numeric(as.character(neuron_ladder_uniform$RDI_df$method))
neuron_ladder_uniform$cRDI_df$method <- revalue(neuron_ladder_uniform$cRDI_df$method, c("cRDI_parallel_res" = 2,  "cRDI_parallel_res1" = 5, "cRDI_parallel_res2" = 10, "cRDI_parallel_res3" = 15, "cRDI_parallel_res4" = 20,  "cRDI_parallel_res5" = 25))
neuron_ladder_uniform$cRDI_df$method <- as.numeric(as.character(neuron_ladder_uniform$cRDI_df$method))
 
pdf(paste0(SI_fig_dir, 'Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder$RDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()
pdf(paste0(SI_fig_dir, 'cRDI_Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder$cRDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()

pdf(paste0(SI_fig_dir, 'Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder_uniform$RDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()
pdf(paste0(SI_fig_dir, 'cRDI_Runs_AUC.pdf'), width =  1, height = 1)
ggplot(aes(method, auc), data = neuron_ladder_uniform$cRDI_df) + geom_line(aes(color = "red")) + geom_point() + xlab('') + ylab('AUC (RDI)') + nm_theme() + ylim(0, 1) #+ geom_smooth()
dev.off()

###############################################################################################################################################################################
# test the code mannually 
###############################################################################################################################################################################
all_cell_simulation <- cell_simulate$cell.simulate

all_cell_simulation <- simulate_cns(steps = 200, N_end = 40, cells = 200) # from scRNASeqSim library 

run_num <- 10
set.seed(2017)
permute_ind <- sample(1:200, 200)
data <-  t(cbind(all_cell_simulation[, 1:200, permute_ind[1]], 
                 all_cell_simulation[, 1:200, permute_ind[2]],
                 all_cell_simulation[, 1:200, permute_ind[3]],
                 all_cell_simulation[, 1:200, permute_ind[4]],
                 all_cell_simulation[, 1:200, permute_ind[5]],
                 all_cell_simulation[, 1:200, permute_ind[6]], 
                 all_cell_simulation[, 1:200, permute_ind[7]],
                 all_cell_simulation[, 1:200, permute_ind[8]],
                 all_cell_simulation[, 1:200, permute_ind[9]],
                 all_cell_simulation[, 1:200, permute_ind[10]], 
                 all_cell_simulation[, 1:200, permute_ind[11]], 
                 all_cell_simulation[, 1:200, permute_ind[12]],
                 all_cell_simulation[, 1:200, permute_ind[13]],
                 all_cell_simulation[, 1:200, permute_ind[14]],
                 all_cell_simulation[, 1:200, permute_ind[15]],
                 all_cell_simulation[, 1:200, permute_ind[16]], 
                 all_cell_simulation[, 1:200, permute_ind[17]],
                 all_cell_simulation[, 1:200, permute_ind[18]],
                 all_cell_simulation[, 1:200, permute_ind[19]],
                 all_cell_simulation[, 1:200, permute_ind[20]],
                 all_cell_simulation[, 1:200, permute_ind[21]], 
                 all_cell_simulation[, 1:200, permute_ind[22]],
                 all_cell_simulation[, 1:200, permute_ind[23]],
                 all_cell_simulation[, 1:200, permute_ind[24]],
                 all_cell_simulation[, 1:200, permute_ind[25]],
                 all_cell_simulation[, 1:200, permute_ind[26]], 
                 all_cell_simulation[, 1:200, permute_ind[27]],
                 all_cell_simulation[, 1:200, permute_ind[28]],
                 all_cell_simulation[, 1:200, permute_ind[29]],
                 all_cell_simulation[, 1:200, permute_ind[30]])) #, 
                 all_cell_simulation[, 1:200, permute_ind[31]], 
                 all_cell_simulation[, 1:200, permute_ind[32]],
                 all_cell_simulation[, 1:200, permute_ind[33]],
                 all_cell_simulation[, 1:200, permute_ind[34]],
                 all_cell_simulation[, 1:200, permute_ind[35]],
                 all_cell_simulation[, 1:200, permute_ind[36]], 
                 all_cell_simulation[, 1:200, permute_ind[37]],
                 all_cell_simulation[, 1:200, permute_ind[38]],
                 all_cell_simulation[, 1:200, permute_ind[39]],
                 all_cell_simulation[, 1:200, permute_ind[40]]
           )) 

run_vec <- rep(1:run_num, each = 200)
tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

data_rem_dup <- data[!duplicated(data), ]
tmp <- expand.grid(1:ncol(data_rem_dup), 1:ncol(data_rem_dup), stringsAsFactors = F)
super_graph_remove_dup <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph_remove_dup <- super_graph_remove_dup[, c(2, 1)]
#
# add some noise
noise = matrix(rnorm(mean = 0, sd = 0, nrow(data) * ncol(data)), nrow = nrow(data))
noise_remove_dup = matrix(rnorm(mean = 0, sd = 0, nrow(data_rem_dup) * ncol(data_rem_dup)), nrow = nrow(data_rem_dup))

# run multiple rdi
a <- Sys.time()
rdi_list1 <- calculate_rdi_multiple_run_cpp(data, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0, uniformalize = F) #* 100 + noise
rdi_list2 <- calculate_rdi_multiple_run_cpp(data, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0, uniformalize = T) #* 100 + noise
rdi_list <- rdi_list1
b <- Sys.time()
rdi_time <- b - a

dimnames(rdi_list$max_rdi_value) <- list(gene_name_vec, gene_name_vec)
# con_rdi_res_test <- calculate_conditioned_rdi_multiple_run_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, k = 1, uniformalize = F)
# dimnames(con_rdi_res_test) <- list(gene_name_vec, gene_name_vec)

# compare with the python implementation (see below)
rdi_list$max_rdi_value[sort(gene_name_vec), sort(gene_name_vec)]
# con_rdi_res_test[sort(gene_name_vec), sort(gene_name_vec)]

RDI_res_df <- process_data(list(rdi_list$max_rdi_value)); RDI_res_df <- t(do.call(rbind.data.frame, RDI_res_df))
# cRDI_res_df <- process_data(list(con_rdi_res_test)); cRDI_res_df <- t(do.call(rbind.data.frame, cRDI_res_df))

colnames(RDI_res_df) <- paste0("cluster_", 1:ncol(RDI_res_df))
# colnames(cRDI_res_df) <- paste0("cluster_", 1:ncol(cRDI_res_df))

# calculate the ROC / AUC values
RDI_df <- calROCAUC(RDI_res_df)
# cRDI_df <- calROCAUC(cRDI_res_df)

qplot(fpr, tpr, data = RDI_df)
# qplot(fpr, tpr, data = cRDI_df)
###############################################################################################################################################################################
dimnames(rdi_list1$max_rdi_value) <- list(gene_name_vec, gene_name_vec)
dimnames(rdi_list2$max_rdi_value) <- list(gene_name_vec, gene_name_vec)

write.csv(file = './csv_data/RDI.txt', x = rdi_list1$max_rdi_value)
write.csv(file = './csv_data/RDI2.txt', x = rdi_list2$max_rdi_value)

###############################################################################################################################################################################
# compare kde estimation between python and cpp for the neuron dataset: 
###############################################################################################################################################################################
# Aldh1L -> Tuj1: ucmi is the highest; Hes5 -> Brn2: cmi is the highest 
data <- t(exprs(neuron_sim_cds))
colnames(data) <- gene_name_vec 
data_xz <- matrix(c(data[, 'Aldh1L'], data[, 'Tuj1']), ncol = 2, byrow = F)
data_xz <- matrix(c(data[, 'Hes5'], data[, 'Brn2']), ncol = 2, byrow = F)
a <- Sys.time()
kde_cpp_res <- kde_cpp(as.matrix(data_xz), k = 1, b = 1, pdf = 1, density_sample_type = 1) # this is very slow 
b <- Sys.time()
b - a 

ucmi_res <-ucmi(as.matrix(data_xz[, 1], ncol = 1), as.matrix(data_xz[sample(1:nrow(data_xz), nrow(data_xz)), 2], ncol = 1), as.matrix(data_xz[, 2], ncol = 1), k = 5, method = 1, k_density = 0, bw = 0)

write.csv(file = './csv_data/data_xz.txt', x = data_xz)
weight_test <- read.csv('./Python_code/weight_test.txt', header = F)

weight_test_0.01 <- read.csv('./Python_code/weight_test_0.01.txt', header = F)
weight_test_0.1 <- read.csv('./Python_code/weight_test_0.1.txt', header = F)
weight_test_0.5 <- read.csv('./Python_code/weight_test_0.5.txt', header = F)

weight = (1 / kde_cpp_res) / mean(1 / kde_cpp_res)

qplot((weight), weight_test[, 1])

qplot(data_xz[, 1], data_xz[, 2], color = weight, size = 3)
qplot(data_xz[, 1], data_xz[, 2], color = weight_test, size = 3)

qplot(data_xz[, 1], data_xz[, 2], color = weight_test_0.01, size = 3)
qplot(data_xz[, 1], data_xz[, 2], color = weight_test_0.1, size = 3)
qplot(data_xz[, 1], data_xz[, 2], color = weight_test_0.5, size = 3)
###############################################################################################################################################################################
# reproduce Arman's benchmark between UCMI and CMI  
###############################################################################################################################################################################
N <- 20000
u_max <- .2
n <- 5

cmi_vec <- rep(0, 10)
ucmi_vec <- rep(0, 10)

for(i in 1:10) {
  X <- runif(N)^ i # [ [uniform(0,1)**n] for i in range(N) ]
  Z <- runif(N)^ i # [ [uniform(0,1)**n] for i in range(N) ]
  Y <- X + Z + runif(N, min = 0, max = u_max) # [ [ X[i][0] +Z[i][0] +uniform(0,u_max) ] for i in range(N) ]
  
  x <- matrix(X, ncol = 1); y <- matrix(Y, ncol = 1); z <- matrix(Z, ncol = 1); 
  cmi_res <-cmi(x, y, z, k = 5L, 0L)
  ucmi_res <- ucmi(x, y, z, k = 5, method = 1, k_density = 0, bw = 0)
  cmi_vec[i] <- cmi_res$cmi_res
  ucmi_vec[i] <- ucmi_res$ucmi_res
}

# make the plot: 
info_mat <- data.frame(n = rep(1:10, times = 3), 
                       value = c(cmi_vec, ucmi_vec, rep(log(1/.2), 10)), 
                       type = c(rep('CMI', 10), rep('UCMI', 10), rep('theoretical value', 10)))

pdf(paste0(SI_fig_dir, 'n_value_20000.pdf'), width =  1, height = 1)
qplot(n, value, color = type, data = info_mat, geom = c('line', 'point'), size = I(0.5)) + nm_theme()
dev.off()
  
N <- 1000
u_max <- .2
n <- 5

cmi_vec_1000 <- rep(0, 10)
ucmi_vec_1000 <- rep(0, 10)

for(i in 1:10) {
  X <- runif(N)^ i # [ [uniform(0,1)**n] for i in range(N) ]
  Z <- runif(N)^ i # [ [uniform(0,1)**n] for i in range(N) ]
  Y <- X + Z + runif(N, min = 0, max = u_max) # [ [ X[i][0] +Z[i][0] +uniform(0,u_max) ] for i in range(N) ]
  
  x <- matrix(X, ncol = 1); y <- matrix(Y, ncol = 1); z <- matrix(Z, ncol = 1); 
  cmi_res <-cmi(x, y, z, k = 5L, 0L)
  ucmi_res <- ucmi(x, y, z, k = 5, method = 1, k_density = 0, bw = 0)
  cmi_vec_1000[i] <- cmi_res$cmi_res
  ucmi_vec_1000[i] <- ucmi_res$ucmi_res
}

# make the plot: 
info_mat_1000 <- data.frame(n = rep(1:10, times = 3), 
                       value = c(cmi_vec_1000, ucmi_vec_1000, rep(log(1/.2), 10)), 
                       type = c(rep('CMI', 10), rep('UCMI', 10), rep('theoretical value', 10)))

pdf(paste0(SI_fig_dir, 'n_value_1000.pdf'), width =  1, height = 1)
qplot(n, value, color = type, data = info_mat_1000, geom = c('line', 'point'), size = I(0.5)) + nm_theme()
dev.off()
###############################################################################################################################################################################
# save the data 
###############################################################################################################################################################################
save.image('./RData/analysis_uniformalization_cmi.RData')

  