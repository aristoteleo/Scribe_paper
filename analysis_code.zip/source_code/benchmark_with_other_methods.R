####################################################################################################################################################################################
#load all necessary libraries
####################################################################################################################################################################################
library(rEDM)
library(parallel)
library(reshape2)
library(lmtest)
library(vars)

####################################################################################################################################################################################
#load all data
####################################################################################################################################################################################
fixed_alpha <- read.table('../compare_alex/generated_data_fixed_alpha.txt', skip = 1)
random_alpha <- read.table('../compare_alex/generated_data_random_alpha.txt', skip = 1)

####################################################################################################################################################################################
#V1: gene id; V2: run id
dream_sim <- read.table('../compare_alex/dream_insilico_mat.txt', skip = 1) #20 genes * 60 runs where each run has 11 time samples 
gene_name <- as.character(unique(dream_sim$V1))
run_name <- as.character(unique(dream_sim$V2))

combn_df <- combn(gene_name, m = 2)

split_combn_df <- split(t(combn_df), rep(1:ncol(combn_df), nrow(combn_df)))
  
dream_sim_res <- mclapply(split_combn_df, function(x) {
  res <- lapply(run_name, function(y){
    subset_df <- t(subset(dream_sim, V1 %in% x & V2 == y)[, 3:13])
    colnames(subset_df) <- c('x0', 'x1')
    cal_cross_map(subset_df, "x0", "x1")    
  })
  res_df <- do.call(rbind.data.frame, res)
  df <- data.frame(Gene_1_ID = c(x[1], x[2]), Gene_1_NAME = c(x[1], x[2]), Gene_2_ID = c(x[2], x[1]), Gene_2_NAME = c(x[2], x[1]), delay_max = NA, 
                   ccm = c(mean(res_df$mean_target_xmap_lib_means), mean(res_df$mean_lib_xmap_target_means)) )
  write.table(file = 'dream_sim_ccm_res.txt', df, append = T, row.names = F, col.names = F, quote = F)
}, mc.cores = detectCores() - 2)

granger_dream_sim_res <- mclapply(split_combn_df, function(x) {
  res <- lapply(run_name, function(y){
    subset_df <- t(subset(dream_sim, V1 %in% x & V2 == y)[, 3:13])
    colnames(subset_df) <- c('x0', 'x1')
    cal_grangertest(subset_df)
  })
  res_df <- do.call(rbind.data.frame, res)
  df <- data.frame(Gene_1_ID = c(x[1], x[2]), Gene_1_NAME = c(x[1], x[2]), Gene_2_ID = c(x[2], x[1]), Gene_2_NAME = c(x[2], x[1]), delay_max = NA, 
                   granger = c(mean(res_df$x1_by_x0), mean(res_df$x0_by_x1)) )
  write.table(file = 'dream_sim_granger_res.txt', df, append = T, row.names = F, col.names = F, quote = F)
}, mc.cores = detectCores() - 2)

#output format: Gene_1_ID	Gene_1_NAME	Gene_2_ID	Gene_2_NAME	delay_max	RDI


####################################################################################################################################################################################
#all functions used for calculating ccm, granger causality: either based on lmtest or VAR package
####################################################################################################################################################################################
cal_cross_map <- function(ordered_exprs_mat, lib_colum, target_column, RNGseed = 2016) { 
  # lib_xmap_target <- ccm(ordered_exprs_mat, E = 3, random_libs = TRUE, lib_column = lib_colum, #ENSG00000122180.4
  #                        target_column = target_column, lib_sizes = seq(10, 75, by = 5), num_samples = 300, RNGseed = RNGseed)
  # target_xmap_lib <- ccm(ordered_exprs_mat, E = 3, random_libs = TRUE, lib_column = target_column, #ENSG00000122180.4
  #                        target_column = lib_colum, lib_sizes = seq(10, 75, by = 5), num_samples = 300, RNGseed = RNGseed)
  # 
  lib_xmap_target <- ccm(ordered_exprs_mat, lib_column = lib_colum, E = 1, #ENSG00000122180.4
                         target_column = target_column, RNGseed = RNGseed)
  target_xmap_lib <- ccm(ordered_exprs_mat, lib_column = target_column, E = 1, #ENSG00000122180.4
                         target_column = lib_colum, RNGseed = RNGseed)
  
  lib_xmap_target_means <- ccm_means(lib_xmap_target)
  target_xmap_lib_means <- ccm_means(target_xmap_lib)
  
  return(data.frame(mean_lib_xmap_target_means = mean(lib_xmap_target_means$rho[is.finite(lib_xmap_target_means$rho)], na.rm = T), 
              mean_target_xmap_lib_means = mean(target_xmap_lib_means$rho[is.finite(target_xmap_lib_means$rho)], na.rm = T)))
}

cal_grangertest <- function(ordered_exprs_mat) {
  df <- data.frame(ordered_exprs_mat)
  x0_by_x1 <- grangertest(x0 ~ x1, order = 1, data = df)
  x1_by_x0 <- grangertest(x1 ~ x0, order = 1, data = df)
  
  return(data.frame(x0_by_x1 = x0_by_x1$`Pr(>F)`[2], 
                    x1_by_x0 = x1_by_x0$`Pr(>F)`[2]))
}

cal_grangertest_var <- function(ordered_exprs_mat) {
  var <- VAR(ordered_exprs_mat, p = 1, type = "const")
  x1_by_x0 <- causality(var, cause = "x0")$Granger
  x0_by_x1 <- causality(var, cause = "x1")$Granger
  
  return(data.frame(x0_by_x1 = x0_by_x1$p.value, 
                    x1_by_x0 = x1_by_x0$p.value))
}

####################################################################################################################################################################################
#run CCM
####################################################################################################################################################################################
fixed_alpha_res <- mclapply(1:1000, function(x) {
  subset_df <- subset(fixed_alpha, fixed_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_cross_map(ordered_exprs_mat, "x0", "x1")
}, mc.cores = detectCores() - 2)

random_alpha_res <- mclapply(1:1000, function(x) {
  subset_df <- subset(random_alpha, random_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_cross_map(ordered_exprs_mat, "x0", "x1")
}, mc.cores = detectCores() - 2)

fixed_alpha_df <- do.call(rbind.data.frame, fixed_alpha_res)
random_alpha_df <- do.call(rbind.data.frame, random_alpha_res)

# plot the res
mlt_fixed_alpha_df <- melt(fixed_alpha_df)
qplot(value, data = mlt_fixed_alpha_df, fill = variable)
mlt_random_alpha_df <- melt(random_alpha_df)
qplot(value, data = mlt_random_alpha_df, fill = variable)

####################################################################################################################################################################################
#run granger causality (grangertest)
####################################################################################################################################################################################
granger_fixed_alpha_res <- mclapply(1:1000, function(x) {
  subset_df <- subset(fixed_alpha, fixed_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_grangertest(ordered_exprs_mat)
}, mc.cores = detectCores() - 2)

granger_random_alpha_res <- mclapply(1:1000, function(x) {
  subset_df <- subset(random_alpha, random_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_grangertest(ordered_exprs_mat)
}, mc.cores = detectCores() - 2)

granger_fixed_alpha_df <- do.call(rbind.data.frame, granger_fixed_alpha_res)
granger_random_alpha_df <- do.call(rbind.data.frame, granger_random_alpha_res)

# plot the res
mlt_granger_fixed_alpha_df <- melt(granger_fixed_alpha_df)
qplot(value, data = mlt_granger_fixed_alpha_df, fill = variable)
mlt_granger_random_alpha_df <- melt(granger_random_alpha_df)
qplot(value, data = mlt_granger_random_alpha_df, fill = variable)

####################################################################################################################################################################################
#run granger causality (causality)
####################################################################################################################################################################################
granger_fixed_alpha_res2 <- mclapply(1:1000, function(x) {
  subset_df <- subset(fixed_alpha, fixed_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_grangertest_var(ordered_exprs_mat)
}, mc.cores = detectCores() - 2)

granger_random_alpha_res2 <- mclapply(1:1000, function(x) {
  subset_df <- subset(random_alpha, random_alpha$V1 == x)
  ordered_exprs_mat <- t(subset_df[, -c(1:2)])
  colnames(ordered_exprs_mat) <- c('x0', 'x1')
  cal_grangertest_var(ordered_exprs_mat)
}, mc.cores = detectCores() - 2)

granger_fixed_alpha_df2 <- do.call(rbind.data.frame, granger_fixed_alpha_res2)
granger_random_alpha_df2 <- do.call(rbind.data.frame, granger_random_alpha_res2)

# plot the res
mlt_granger_fixed_alpha_df2 <- melt(granger_fixed_alpha_df2)
qplot(value, data = mlt_granger_fixed_alpha_df2, fill = variable)
mlt_granger_random_alpha_df2 <- melt(granger_random_alpha_df2)
qplot(value, data = mlt_granger_random_alpha_df2, fill = variable)

#comparing between lmtest and VAR based granger causality: 
qplot(mlt_granger_fixed_alpha_df$value, mlt_granger_fixed_alpha_df2$value)
qplot(mlt_granger_random_alpha_df$value, mlt_granger_random_alpha_df2$value)

####################################################################################################################################################################################
#save the data
####################################################################################################################################################################################
#save ccm: 
write.table(file = 'fixed_ccm_causality.txt', fixed_alpha_df, row.names = T, quote = F)
write.table(file = 'random_ccm_causality.txt', random_alpha_df, row.names = T, quote = F)

#save lmtest based granger causality 
write.table(file = 'fixed_lmtest_granger_causality.txt', granger_fixed_alpha_df, row.names = T, quote = F)
write.table(file = 'random_lmtest_granger_causality.txt', granger_random_alpha_df, row.names = T, quote = F)

#save var based granger causality 
write.table(file = 'fixed_VAR_granger_causality.txt', granger_fixed_alpha_df2, row.names = T, quote = F)
write.table(file = 'random_VAR_granger_causality.txt', granger_random_alpha_df2, row.names = T, quote = F)

save.image('benchmark_with_other_methods.RData')
