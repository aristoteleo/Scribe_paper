#######################################################################################################################################################################################
# analyze the fabian's data 
#######################################################################################################################################################################################
rm(list = ls())
library(R.matlab)
library(plyr)
library(monocle)
library(R.matlab)

#######################################################################################################################################################################################
# run the hsc dataset with 3k cells: 
#######################################################################################################################################################################################
qpcr_data <- readMat('/Users/xqiu/Downloads/dpt\ 4/examples/ESC_qpcr_Goettgens.mat')

expr_mat <- qpcr_data$data
colnames(expr_mat) <- unlist(qpcr_data$Genes.analysed)
row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                  Time = c(#rep("0", nrow(ctr)),
                                                    rep('Time', nrow(expr_mat))#,
                                                  ),
                                                  row.names = row.names(expr_mat)))

new_cds <- newCellDataSet(as(as.matrix(t(expr_mat)), "sparseMatrix"), #he cofactor parameter is used for arcsinh
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)
new_cds <- estimateSizeFactors(new_cds)
pData(new_cds)$Size_Factor <- 1
# new_cds <- estimateDispersions(new_cds)

new_cds <- setOrderingFilter(new_cds, row.names(new_cds)[1:42])
new_cds <- reduceDimension(new_cds, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F)
new_cds <- orderCells(new_cds)
plot_cell_trajectory(new_cds, color_by = 'Time')
plot_genes_in_pseudotime(new_cds[c("pCD3z(Lu175)Dd",
                                   "pErk1_2(Er167)Dd",
                                   "pSLP76(Gd156)Dd",
                                   "pS6(Yb172)Dd"), ])  

write.table(file = paste('./csv_data/blood_data_tree_fabian', x, '.txt', sep = ''), as.matrix(exprs(new_cds[, order(pData(new_cds)$Pseudotime)])), row.names = T, quote = F)

#######################################################################################################################################################################################
# run the hsc dataset from the snap-shot paper
#######################################################################################################################################################################################
rm(list = ls())
library(R.matlab)
library(plyr)
library(monocle)
library(R.matlab)
library(rgl)

genenames_vicki18_data <- readMat('/Users/xqiu/Downloads/inferenceSnapshot 2/Real/genenames_vicki18.mat')
BMApprxCensored_sigma0.9 <- readMat('/Users/xqiu/Downloads/inferenceSnapshot 2/Real/BMApprxCensored_sigma0.9.mat')

#######################################################################################################################################################################################
# confirm the branches 
#######################################################################################################################################################################################
# qplot(BMApprxCensored_sigma0.9$psi[, 2], BMApprxCensored_sigma0.9$psi[, 3], color = factor(BMApprxCensored_sigma0.9$label))
# 
# plot3D(BMApprxCensored_sigma0.9$psi[, 1], BMApprxCensored_sigma0.9$psi[, 2], BMApprxCensored_sigma0.9$psi[, 3])
# 
# # capture snapshot
# snapshot3d(filename = '3dplot.png', fmt = 'png')

x <- BMApprxCensored_sigma0.9$psi[, 1]
y <- BMApprxCensored_sigma0.9$psi[, 2]
z <- BMApprxCensored_sigma0.9$psi[, 3]

plot3d(x, y, z, col=rainbow(6)[BMApprxCensored_sigma0.9$label], size=3)
legend3d("topright", paste('Cell type', c("1", "2", "3", "4", "5")), pch = 16, cex=1,  col = rainbow(6), inset=c(0.02,0.2))

#######################################################################################################################################################################################

expr_mat <- read.table('/Users/xqiu/Downloads/dpt/examples/gene_exprs_original_data', row.names = 1, header = 1)
expr_mat_norm <- read.table('/Users/xqiu/Downloads/inferenceSnapshot\ 2/Real/vicki_normalized.txt', sep = ',')

expr_mat <- BMApprxCensored_sigma0.9$psi[, 1:3]
colnames(expr_mat) <- unlist(genenames_vicki18_data$genenames18[1:3])
row.names(expr_mat) <- paste('cell_', 1:nrow(expr_mat), sep = '')

fd <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat), row.names = colnames(expr_mat)))
pd <- new("AnnotatedDataFrame", data = data.frame(cell = row.names(expr_mat), 
                                                  Time = c(#rep("0", nrow(ctr)),
                                                    rep('Time', nrow(expr_mat))#,
                                                  ),
                                                  label = BMApprxCensored_sigma0.9$label,
                                                  row.names = row.names(expr_mat)))

new_cds <- newCellDataSet(as(as.matrix(t(log2(expr_mat + 1))), "sparseMatrix"),
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)

new_cds <- newCellDataSet(as(as.matrix(t(expr_mat)) * 500, "sparseMatrix"), #make the space bigger
                          phenoData = pd, 
                          featureData = fd, 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)
new_cds <- estimateSizeFactors(new_cds)
pData(new_cds)$Size_Factor <- 1
# new_cds <- estimateDispersions(new_cds)

pData(new_cds)$label <- revalue(as.character(pData(new_cds)$label), c("1" = 'CLP', '2' = "GMP", "3" = 'HSC', '4' = 'LMPP', '5' = 'preMegE'))
new_cds <- setOrderingFilter(new_cds, row.names(new_cds))
new_cds <- reduceDimension(new_cds, max_components = 3, norm_method = 'none', verbose = T, pseudo_expr = 0, scaling = F, auto_param_selection = F)
new_cds <- orderCells(new_cds)
plot_cell_trajectory(new_cds, color_by = 'label')
plot_cell_trajectory(new_cds, color_by = 'State') + facet_wrap(~State)
new_cds <- orderCells(new_cds, root_state = 2)
plot_cell_trajectory(new_cds, color_by = 'Pseudotime')

#
GMP_branch_cds <- new_cds[, pData(new_cds)$State %in% c(2:3, 5:11, 12)]
CLP_branch_cds <- new_cds[, pData(new_cds)$State %in% c(2:4, 5:11)]
preMegE_branch_cds <- new_cds[, pData(new_cds)$State %in% c(1:2,  5:11)]

colnames(expr_mat_norm) <- unlist(genenames_vicki18_data$genenames18)

GMP_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% c(2:3, 5:11, 12)]
CLP_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% c(2:11)]
preMegE_branch <- t(expr_mat_norm)[, pData(new_cds)$State %in% c(1:2, 5:11)]

write.table(file = './csv_data/GMP_branch.txt', as.matrix(GMP_branch[, order(pData(GMP_branch_cds)$Pseudotime)]), row.names = T, quote = F)
write.table(file = './csv_data/CLP_branch.txt', as.matrix(CLP_branch[, order(pData(CLP_branch_cds)$Pseudotime)]), row.names = T, quote = F)
write.table(file = './csv_data/preMegE_branch.txt', as.matrix(preMegE_branch[, order(pData(preMegE_branch_cds)$Pseudotime)]), row.names = T, quote = F)

#######################################################################################################################################################################################
# Pseudotime plot
#######################################################################################################################################################################################
exprs_new_cds <- newCellDataSet(as(as.matrix(t(expr_mat_norm)), "sparseMatrix"), #he cofactor parameter is used for arcsinh
                          phenoData = pd, 
                          featureData = new("AnnotatedDataFrame", data = data.frame(gene_short_name = colnames(expr_mat_norm), row.names = colnames(expr_mat_norm))), 
                          expressionFamily=gaussianff(), 
                          lowerDetectionLimit=1)
exprs_new_cds <- estimateSizeFactors(exprs_new_cds)
pData(exprs_new_cds)$Size_Factor <- 1

six_genes <- c('Nfe2', 'Gata2', 'SCL', 'Gfi1', 'Gfi1b')

BMApprxCensored_sigma0.9$labels

pData(exprs_new_cds) <- pData(new_cds)
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(GMP_branch_cds)])
order(pData(CLP_branch_cds)$Pseudotime)

plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(GMP_branch_cds)]) + ggtitle('GMP branch') #remove outlier cells at the end 
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(CLP_branch_cds)]) + ggtitle('CLP branch') #remove outlier cells at the end 
plot_genes_in_pseudotime(exprs_new_cds[six_genes, colnames(preMegE_branch_cds)]) + ggtitle('preMegE branch') #remove outlier cells at the end 

#######################################################################################################################################################################################
# analyze the fabian's data 
#######################################################################################################################################################################################
save.image('./RData/fabian_data_qpcr2.RData')
