# generate the RDI vs pseudotime plot 

rdi_crdi_pseudotime <- function(data, window_size = 20, delay = 1) {
  win_range <- nrow(data) - window_size - 1
  gene_num <- ncol(data)
  
  window_gene_gene_result <- array(dim = c(win_range + 1, gene_num, gene_num)) 
  crdi_window_gene_gene_result <- window_gene_gene_result 
  
  run_vec <- rep(1, nrow(data))
  tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
  super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
  super_graph <- super_graph[, c(2, 1)]
  
  for(i in 1:(win_range + 1)) {
    message('current range index is ', i)
    rdi_list <- calculate_rdi_multiple_run_cpp(data[i:(i + window_size), ], delay = c(5), run_vec[i:(i + window_size)] - 1, as.matrix(super_graph), method = 1) #* 100 + noise
    con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data[i:(i + window_size), ], as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec[i:(i + window_size)] - 1, 1)
  
    window_gene_gene_result[i, , ] <- rdi_list$max_rdi_value
    crdi_window_gene_gene_result[i, , ] <- con_rdi_res_test
    
  }

  return(list(rdi_res = window_gene_gene_result, crdi_res = crdi_window_gene_gene_result))
}

plot_regulation_over_time <- function(res, gene_name_vec) {
  dim(res) <- c(dim(res)[1], dim(res)[2] * dim(res)[2])
  
  all_cmbns <- expand.grid(gene_name_vec, gene_name_vec)
  valid_all_cmbns_df <- data.frame(pair = paste(tolower(all_cmbns$Var1), tolower(all_cmbns$Var2), sep = '_'), pval = 0)
  row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
  colnames(res) <- valid_all_cmbns_df$pair
  pheatmap::pheatmap(res, cluster_rows = F, cluster_cols = T, annotation_names_col = T)
}


cell_simulate <- readMat('/Users/xqiu/Dropbox (Personal)/Projects/DDRTree_fstree/DDRTree_fstree/mat_data/cell_simulate.mat')
all_cell_simulation <- cell_simulate$cell.simulate[, 1:400, ] #time 0-20 are the period two branches appear

################################################################################################################################################
# real data 
################################################################################################################################################
library(monocle)
library(Scribe)
lung <- load_lung()
lung_AT1 <- lung[, pData(lung)$State %in% c(2, 3)]
lung_AT1 <- lung_AT1[, order(pData(lung_AT1)$Pseudotime)]

data_pseudotime_order <- run_cell_by_dpt(exprs(lung_AT1), 1)
pData(lung_AT1)[colnames(data_pseudotime_order), "Pseudotime"] <- 1:ncol(lung_AT1)

AT1_early <- c("Aqp5", "Pdpn", "Rtkn2", "Ager", "Emp2", "Cav1", "Clic5", "Lmo7", "S100a6", "Col4a3", "Akap5", "Cryab")
AT1_late <- c("Sdpr", "S100a14")
AT2_early <- c("Fabp5", "Lamp3", "Cd36", "Scd1", "Sftpb", "Slc34a2", "Abca3", "Sftpa1", "Egfl6", "Soat1", "Bex2", "Muc1", "Sftpc")
AT2_late <- c("Lcn2", "Il33", "Hc", "Trf", "Lyz2", "S100g", "Lyz1")

example_data <- exprs(lung_AT1)[fData(lung_AT1)$gene_short_name %in% c(AT1_early, AT1_late), ] #, AT2_early, AT2_late
fData(lung_AT1)[fData(lung_AT1)$gene_short_name %in% c(AT1_early, AT1_late, AT2_early, AT2_late), ]
gene_short_names_list <- as.character(fData(lung_AT1)[fData(lung_AT1)$gene_short_name %in% c(AT1_early, AT1_late), 'gene_short_name']) #, AT2_early, AT2_late
gene_name_vec <- gene_short_names_list

# example_data <- all_cell_simulation[, , 1]
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(example_data) * ncol(example_data)), nrow = nrow(example_data))
rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime(t(example_data[, ] + noise))

# dimnames(rdi_list$max_rdi_value) <- list(uniq_gene, uniq_gene)
# con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 1)
# dimnames(con_rdi_res_test) <- list(uniq_gene, uniq_gene)

# plot gene-pair regulation strength over pseudotime 
rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res

dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])

all_cmbns <- expand.grid(gene_name_vec, gene_name_vec)
valid_all_cmbns_df <- data.frame(pair = paste(tolower(all_cmbns$Var1), tolower(all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
colnames(rdi_res) <- valid_all_cmbns_df$pair
pheatmap::pheatmap(rdi_res, cluster_rows = F, cluster_cols = T, annotation_names_col = T)

rdi_res[, 2] - rdi_crdi_pseudotime_res_list$rdi_res[, 2, 1]

################################################################################################################################################
# real data 
################################################################################################################################################
load('./RData/analysis_scRNA_seq_Olsson.RData')

# MEP_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_MEP_cds)[fData(Olsson_MEP_cds)$use_for_ordering, ] + 1))))
# MEP_dpt_res <- just_DPT(MEP_dm)
# 
# monocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_monocyte_cds)[fData(Olsson_monocyte_cds)$use_for_ordering, ] + 1))))
# monocyte_dpt_res <- just_DPT(monocyte_dm)
# 
# granulocyte_dm <- DiffusionMap(t(as.matrix(log(exprs(Olsson_granulocyte_cds)[fData(Olsson_granulocyte_cds)$use_for_ordering, ] + 1))))
# granulocyte_dpt_res <- just_DPT(granulocyte_dm)

load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/Jupyter_notebook/network_res')

library(netbiov)
library(monocle)

plot.netbiov(res)
olsson_gene_names <- unique(igraph::V(res$g)$name)

gene_name_vec <- olsson_gene_names[1:10]
gene_name_vec <- c('Irf8', "Gfi1", 'Klf4', 'Per3', 'Zeb2', 'Ets1', 'Irf5')
sort(esApply(Olsson_monocyte_cds[gene_name_vec, ], 1, mean)) # Irf8, Per3, Zeb2
gene_name_vec <- c('Irf8', 'Per3', 'Zeb2')

example_data_gran <- t(exprs(Olsson_granulocyte_cds[fData(Olsson_granulocyte_cds)$gene_short_name %in% gene_name_vec, order(granulocyte_dpt_res$DPT77)]))
example_data_mono <- t(exprs(Olsson_monocyte_cds[fData(Olsson_monocyte_cds)$gene_short_name %in% gene_name_vec, order(monocyte_dpt_res$DPT77)]))
example_data_MEP <- t(exprs(Olsson_MEP_cds[fData(Olsson_MEP_cds)$gene_short_name %in% gene_name_vec, order(MEP_dpt_res$DPT77)]))
example_data <- as.matrix(Reduce(rbind, list(example_data_gran, example_data_mono, example_data_MEP)))
example_data <- example_data_mono

noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(example_data) * ncol(example_data)), nrow = nrow(example_data))
rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime(as.matrix(example_data[, ]) + noise)

# dimnames(rdi_list$max_rdi_value) <- list(uniq_gene, uniq_gene)
# con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 1)
# dimnames(con_rdi_res_test) <- list(uniq_gene, uniq_gene)

# plot gene-pair regulation strength over pseudotime 
rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res

dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])

all_cmbns <- expand.grid(colnames(example_data), colnames(example_data))
valid_all_cmbns_df <- data.frame(pair = paste(tolower(all_cmbns$Var1), tolower(all_cmbns$Var2), sep = '_'), pval = 0)
row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
colnames(rdi_res) <- valid_all_cmbns_df$pair
pheatmap::pheatmap(rdi_res, cluster_rows = F, cluster_cols = T, annotation_names_col = T)

################################################################################################################################################
# make the kinetic curves 
################################################################################################################################################
gene_pairs <- row.names(subset(fData(Olsson_monocyte_cds), gene_short_name %in% c('Irf9', 'Irf8')))
pData(Olsson_monocyte_cds)[rownames(example_data_mono), 'Pseudotime'] <- 1:nrow(example_data_mono)
pData(Olsson_granulocyte_cds)[rownames(example_data_gran), 'Pseudotime'] <- 1:nrow(example_data_gran)
pData(Olsson_MEP_cds)[rownames(example_data_MEP), 'Pseudotime'] <- 1:nrow(example_data_MEP)
plot_genes_in_pseudotime(Olsson_monocyte_cds[gene_pairs, ])

rdi_res[, 2] - rdi_crdi_pseudotime_res_list$rdi_res[, 2, 1]

################################################################################################################################################
# get the network 
################################################################################################################################################
tmp <- expand.grid(1:ncol(example_data), 1:ncol(example_data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 # convert to C++ index
super_graph <- super_graph[, c(2, 1)]

message('current range index is ', i)
run_vec <- rep(1, nrow(example_data))
rdi_list <- calculate_rdi_multiple_run_cpp(as.matrix(example_data) + noise, delay = c(0:150), run_vec - 1, as.matrix(super_graph), method = 1) #* 100 + noise

con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(as.matrix(example_data), as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 6)  # conditional on all other genes 
  
dimnames(con_rdi_res_test) <- list(colnames(example_data), colnames(example_data))
pheatmap::pheatmap(con_rdi_res_test, cluster_rows = T, cluster_cols = T, annotation_names_col = T, annotation_names_row = T)

dimnames(rdi_list$max_rdi_value) <- list(colnames(example_data), colnames(example_data))
dimnames(rdi_list$max_rdi_delays) <- list(colnames(example_data), colnames(example_data))
pheatmap::pheatmap(rdi_list$max_rdi_value, cluster_rows = T, cluster_cols = T, annotation_names_col = T, annotation_names_row = T)
pheatmap::pheatmap(rdi_list$max_rdi_delays, cluster_rows = T, cluster_cols = T, annotation_names_col = T, annotation_names_row = T)
qplot(0:150, rdi_list$RDI[1, seq(3, 453,by = 3)]) + ylab('rdi') + xlab('time delay') # this gene should not have long time delay but very close 

# Aug 30 11:49:58 D-69-91-168-252.dhcp4.washington.edu R[872] <Error>: CGContextDelegateCreateForContext: invalid context 0x7fa97035c4a0. 
# This is a serious error. This application, or a library it uses, is using an invalid context  and is thereby contributing to an overall 
# degradation of system stability and reliability. This notice is a courtesy: please fix this problem. It will become a fatal error in an upcoming update.

################################################################################################################################################
# compare with the gene pair with the network in the paper
################################################################################################################################################
ind_mat <- as.matrix(which(con_rdi_res_test >= sort(con_rdi_res_test, decreasing = T)[10], arr.ind = T))
ind_mat <- as.matrix(which(rdi_list$max_rdi_value >= sort(rdi_list$max_rdi_value, decreasing = T)[10], arr.ind = T))

ind_mat[, 1] <- colnames(example_data)[ind_mat[, 1]]
ind_mat[, 2] <- colnames(example_data)[as.numeric(ind_mat[, 2])]
ind_mat

# check gran branch as well as MEP branch and finally all branches 

plot_genes_in_pseudotime(Olsson_monocyte_cds[gene_name_vec, ])

################################################################################################################################################
# save the data  
################################################################################################################################################
save.image('./RData/RDI_cRDI_over_pseudotime.RData')

# make the gene-pair plot 







