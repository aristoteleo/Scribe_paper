# make two variable expresson: 
load('/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/fig5_4_22.RData')
plot_cell_trajectory(URMM_all_fig1b)
exam_cds <- URMM_all_fig1b[c("Irf8", "Gfi1", "Cebpe", "Zeb2"), pData(URMM_all_fig1b)$State %in% c(1, 3, 4)]
plot_genes_in_pseudotime(exam_cds)
# maybe run DPT 
Irf8_expr <- exprs(exam_cds)["Irf8", ]
Gfi1_expr <- exprs(exam_cds)["Gfi1", ]
Cebpe_expr <- exprs(exam_cds)["Cebpe", ]
Zeb2_expr <- exprs(exam_cds)["Zeb2", ]

newdata <- data.frame(Pseudotime = seq(0, max(pData(exam_cds)$Pseudotime), length.out = 50))   
smoothed_res <- genSmoothCurves(exam_cds, newdata)

Irf8_Gif1_cepbe_zeb2_expr <- data.frame(expression = c(smoothed_res[1, ], smoothed_res[2, ], smoothed_res[3, ], smoothed_res[4, ]), 
                             Gene = c(rep("Irf8", length(smoothed_res[1, ])), rep("Gfi1", length(smoothed_res[1, ])), 
                                      rep("Cebpe", length(smoothed_res[1, ])), rep("Zeb2", length(smoothed_res[1, ]))),
                             Pseudotime = rep(newdata$Pseudotime, 4),
                             Order = rep(order(newdata$Pseudotime), 4))))
qplot(Pseudotime, expression, data = Irf8_Gif1_expr, color = Gene, facets = '~Gene')

Irf8_Gif1_cepbe_expr$order <- order(Irf8_Gif1_cepbe_expr$Pseudotime)
pdf("/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/Figures/main_figures/example_fig2.pdf", height = 3, width = 2.5)
ggplot(aes(Order, expression), data = Irf8_Gif1_cepbe_expr) + geom_point(color = 'black', size = 0.1) + facet_wrap(~Gene, ncol = 1) + nm_theme() # + theme_classic() #Gene
dev.off()

# create other figures for cartoon 
# Irf8, Zeb2
